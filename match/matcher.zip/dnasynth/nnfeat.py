"""The inverse model's INPUT: what the network hears of one note, and the on-the-fly training data.

    from dnasynth import nnfeat as NF
    X = NF.features(audio, midi, gate_s, device="mps")    # torch float32 [B, NF.N_CH, T]
    b = NF.make_batch(rng, 64)                            # prior genomes rendered as notes (numpy)

THE WINDOW. A note is analysed over a fixed window of SECS = 2.5 s at 44.1 kHz (the Odin2 bench's
HOLD 1.2 s + TAIL 1.3 s): a longer recording is cut, a shorter one zero-padded. T = 216 frames
(hop 512, 11.6 ms).

THE CHANNELS (per frame; every level channel is ABSOLUTE dB re a full-scale sine, floored at
DB_FLOOR, then mapped (dB - DB_CENTER) / DB_SCALE; nothing is normalised per note, because the
engine has no output gain and a sustain level or a resonance IS a level -- unless the model's cfg
sets "norm": then every note is first scaled to that loudest-frame level, in training and in use
alike. The matcher always normalises a recording (fitness.normalize), and DNA v3's macro sounds
span 40 dB (10-90 %) around a median 12 dB under that level, so a network trained on the raw level
saw its targets off its own distribution: checkpoints/v3m's heard-macro error was 0.197 on raw
audio and 0.232 normalised, noise 0.23 vs 0.39 (docs/matcher/results.md section 13)):

  mel   N_MELS log-mel bands, 20 Hz .. 20 kHz (the full band: an oscillator's top octaves and the
        noise colour live up there), 2048-point Hann frames; a band's value is the SUM of its bins'
        power under a unit-peak triangle, so a sine reads its own level in any band.
  harm  HARM_Q magnitudes on the QUARTER-HARMONIC grid of the known pitch, q * f0 / 4 for
        q = 1 .. 64 (0.25 f0 .. 16 f0), from 4096-point frames (the peak of the 3 nearest bins).
        Key-invariant by construction: a saw's 1/n series looks the same at C1 and C5, and osc B's
        ratios 1/4, 1/2, 3/4, 3/2, 5/2, 7/2 land on the grid too. Grid points above 0.47 sr are
        set to the floor.
  env   SUB fine-envelope values per frame: the RMS of 128-sample blocks (2.9 ms), the attack
        resolution the 2048-point frames smear.
  gate  two channels: a soft step that is 1 while the key is held and 0 after the note-off, and a
        flag that the gate is KNOWN. Unknown gate: the step is 0.5 everywhere and the flag 0 (the
        model is trained with the gate hidden P_NOGATE of the time, so propose works without it).

The midi note is not a channel; the model embeds it (model.py) -- the filter sits at absolute Hz,
so the network must know the key to tell a key-tracked filter from a fixed one.

THE DATA (make_batch / batch_worker): genomes from the prior (dnasynth.prior.sample, canonical,
with their family), a fractional midi note uniform in [midi_lo, midi_hi] (default 28 .. 96),
gates in groups of GATE_GROUP (dn_render_batch takes one gate per call): uniform in
[gate_lo, gate_hi], or held through the window with probability p_held. The noise seed changes
every call. batch_worker runs make_batch in ONE background process (the training script's
data worker); this module imports torch only inside features(), so that process stays light.
"""
from __future__ import annotations

import math

import numpy as np

SR = 44100.0
SECS = 2.5
N_FFT, HOP = 2048, 512
N_MELS, F_MIN, F_MAX = 128, 20.0, 20000.0
HARM_FFT = 4096
HARM_Q, HARM_DIV = 64, 4             # q * f0 / 4, q = 1..64
HARM_TOP = 0.47                      # grid points above this fraction of sr read the floor
SUB = 4                              # fine-envelope blocks per hop (HOP / SUB = 128 samples)
DB_FLOOR, DB_CENTER, DB_SCALE = -100.0, -50.0, 25.0
NORM_MAX_DB = 60.0                   # features(norm=...): the most a near-silent note is raised
N_CH = N_MELS + HARM_Q + SUB + 2
VERSION = 1

# VERSION 2 (the v1y network, 2026-09-29; results.md section 17, literature.md network section 4):
# three things version 1 could not see -- a pitch that moves (a kick's or a tom's drop, a
# vibrato), the spectrum of a 20 ms attack (a tine, a mallet, a click), the partials above 16 f0
# and the low notes' grid (at MIDI 28 the 4096-point grid put quarter-harmonics under one bin):
#   harm   HARM_Q2 = 128 quarter-harmonic magnitudes, 0.25 .. 32 f0, from 8192-point frames
#   short  SHORT_MELS log-mel bands of 512-point frames at the fine envelope's four sub-frames
#          (2.9 ms), folded into 4 x SHORT_MELS channels (band-major)
#   pitch  two channels: the pitch's deviation from the note in octaves (PITCH_ST candidates,
#          -1 .. +1) and the periodicity there (0 .. 1): the normalised autocorrelation of 46 ms
#          frames (Boersma's window correction): the best candidate, or the octave above it when
#          that is within PITCH_NEAR of it (a missing fundamental does not halve the pitch),
#          refined by a parabola through its neighbours; lags past half a window read 0
# channels: mel 128, harm 128, env 4, short 128, pitch 2, gate 2 = 392
HARM_FFT2, HARM_Q2 = 8192, 128
SHORT_FFT, SHORT_HOP, SHORT_MELS, SHORT_FMIN = 512, 128, 32, 150.0
PITCH_W, PITCH_FFT = 2048, 4096
PITCH_ST = np.arange(-12.0, 12.01, 0.5)
PITCH_NEAR = 0.85
PITCH_OCT = 24                       # candidates per octave (0.5 st steps)
N_CH2 = N_MELS + HARM_Q2 + SUB + SUB * SHORT_MELS + 2 + 2
CHUNK2 = 16                          # version 2's long FFTs run over this many notes at a time


# VERSION 3 (fine-tunes of a version-1 network, results.md section 19): version 1's channels
# unchanged and FIRST, then version 2's short (128), pitch (2) and 32 f0 harm (128) = 456; a
# version-1 network extends to it with zero weights on the new channels (model.warm_start), so
# it starts exactly where it was and learns what the new channels add
N_CH3 = N_CH + SUB * SHORT_MELS + 2 + HARM_Q2


def n_channels(version=VERSION):
    """the feature channels of a feature version (a model's cfg["feat_version"])"""
    return {1: N_CH, 2: N_CH2, 3: N_CH3}[int(version)]

GATE_GROUP = 8                       # examples per render call (one gate each call)
P_NOGATE = 0.15                      # training: the gate is hidden from the model this often
P_HELD = 0.08                        # training: the key is held through the whole window


def n_samples(secs=SECS, sr=SR):
    return int(round(secs * sr))


def n_frames(secs=SECS, sr=SR):
    return 1 + n_samples(secs, sr) // HOP


def fit_length(audio, n):
    """[B, m] or [m] -> float32 [B, n]: cut, or zero-pad at the end"""
    x = np.atleast_2d(np.asarray(audio, np.float32))
    if x.shape[1] > n:
        return np.ascontiguousarray(x[:, :n])
    if x.shape[1] < n:
        return np.pad(x, ((0, 0), (0, n - x.shape[1])))
    return np.ascontiguousarray(x)


def resample(audio, sr, sr_to=SR):
    """a recording at another rate -> SR (polyphase)"""
    if abs(float(sr) - sr_to) < 1e-6:
        return np.asarray(audio, np.float32)
    from fractions import Fraction
    from scipy.signal import resample_poly
    fr = Fraction(sr_to / float(sr)).limit_denominator(1000)
    return resample_poly(np.asarray(audio, np.float64), fr.numerator, fr.denominator,
                         axis=-1).astype(np.float32)


_MEL = {}


def mel_matrix(n_fft=N_FFT, sr=SR, n_mels=N_MELS, f_min=F_MIN, f_max=F_MAX):
    """[n_mels, n_fft//2+1] unit-peak triangles on the mel scale (HTK formula). A band narrower
    than a bin still reads its nearest bin (no empty bands at the bottom)."""
    key = (n_fft, sr, n_mels, f_min, f_max)
    if key not in _MEL:
        mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)                     # noqa: E731
        imel = lambda m: 700.0 * (10.0 ** (m / 2595.0) - 1.0)                   # noqa: E731
        edges = imel(np.linspace(mel(f_min), mel(min(f_max, sr / 2)), n_mels + 2))
        f = np.fft.rfftfreq(n_fft, 1.0 / sr)
        M = np.zeros((n_mels, f.size))
        for i in range(n_mels):
            lo, c, hi = edges[i], edges[i + 1], edges[i + 2]
            up = (f - lo) / max(c - lo, 1e-9)
            dn = (hi - f) / max(hi - c, 1e-9)
            M[i] = np.clip(np.minimum(up, dn), 0.0, 1.0)
            if M[i].sum() <= 0:
                M[i, int(np.argmin(np.abs(f - c)))] = 1.0
        _MEL[key] = M.astype(np.float32)
    return _MEL[key]


def midi_hz(midi):
    return 440.0 * 2.0 ** ((np.asarray(midi, np.float64) - 69.0) / 12.0)


def _gate_array(gate_s, B):
    """None / scalar / [B] (NaN = unknown) -> float64 [B] with NaN where unknown"""
    if gate_s is None:
        return np.full(B, np.nan)
    g = np.asarray(gate_s, np.float64)
    return np.broadcast_to(g, (B,)).astype(np.float64).copy()


_DEV_CACHE = {}


def _consts(device, sr):
    import torch
    key = (str(device), float(sr))
    if key not in _DEV_CACHE:
        dev = torch.device(device)
        w1 = torch.as_tensor(np.hanning(N_FFT + 1)[:N_FFT].astype(np.float32), device=dev)
        w2 = torch.as_tensor(np.hanning(HARM_FFT + 1)[:HARM_FFT].astype(np.float32), device=dev)
        _DEV_CACHE[key] = dict(
            w1=w1, w2=w2, s1=float((2.0 / w1.sum()) ** 2), s2=float((2.0 / w2.sum()) ** 2),
            mel=torch.as_tensor(mel_matrix(N_FFT, sr), device=dev),
            q=torch.arange(1, HARM_Q + 1, device=dev, dtype=torch.float32) / HARM_DIV)
    return _DEV_CACHE[key]


def _consts2(device, sr):
    import torch
    key = ("v2", str(device), float(sr))
    if key not in _DEV_CACHE:
        dev = torch.device(device)
        wh = torch.as_tensor(np.hanning(HARM_FFT2 + 1)[:HARM_FFT2].astype(np.float32), device=dev)
        ws = torch.as_tensor(np.hanning(SHORT_FFT + 1)[:SHORT_FFT].astype(np.float32), device=dev)
        wp = np.hanning(PITCH_W + 1)[:PITCH_W]
        rw = np.correlate(wp, wp, "full")[PITCH_W - 1:]                  # the window's own
        rw = rw / rw[0]                                                  # autocorrelation
        _DEV_CACHE[key] = dict(
            wh=wh, sh=float((2.0 / wh.sum()) ** 2), ws=ws, ss=float((2.0 / ws.sum()) ** 2),
            wp=torch.as_tensor(wp.astype(np.float32), device=dev),
            rw=torch.as_tensor(np.maximum(rw[:PITCH_W // 2 + 2], 1e-3).astype(np.float32),
                               device=dev),
            mel_s=torch.as_tensor(mel_matrix(SHORT_FFT, sr, SHORT_MELS, SHORT_FMIN), device=dev),
            q=torch.arange(1, HARM_Q2 + 1, device=dev, dtype=torch.float32) / HARM_DIV,
            st=torch.as_tensor(PITCH_ST.astype(np.float32), device=dev))
    return _DEV_CACHE[key]


def _v2_channels(x, f0, T, sr, db, device):
    """version 2's harm, short and pitch channels of x [B, n] (f0 [B] Hz) -> three tensors
    [B, HARM_Q2, T], [B, SUB * SHORT_MELS, T], [B, 2, T]"""
    import torch
    F = torch.nn.functional
    c = _consts2(device, sr)
    B, n = x.shape
    harm, pitch = [], []
    for a in range(0, B, CHUNK2):                        # the long FFTs a few notes at a time
        xs, fs = x[a:a + CHUNK2], f0[a:a + CHUNK2]
        b = xs.shape[0]
        S = torch.stft(xs, HARM_FFT2, HOP, window=c["wh"], center=True, pad_mode="constant",
                       return_complex=True)
        P = (S.real * S.real + S.imag * S.imag) * c["sh"]                       # [b, F, T]
        fq = fs[:, None] * c["q"][None]
        kb = torch.round(fq / (sr / HARM_FFT2)).long().clamp(1, HARM_FFT2 // 2 - 1)
        idx = torch.stack([kb - 1, kb, kb + 1], 1).reshape(b, 3 * HARM_Q2)
        g = torch.gather(P, 1, idx[:, :, None].expand(b, 3 * HARM_Q2, P.shape[2]))
        hp = g.reshape(b, 3, HARM_Q2, P.shape[2]).amax(dim=1)
        harm.append(db(torch.where((fq < HARM_TOP * sr)[:, :, None], hp, torch.zeros_like(hp))))
        del S, P, g
        # pitch: the autocorrelation of each 46 ms frame, Boersma-corrected, at the candidates
        Sp = torch.stft(xs, PITCH_FFT, HOP, win_length=PITCH_W, window=c["wp"], center=True,
                        pad_mode="constant", return_complex=True)
        r = torch.fft.irfft(Sp.real * Sp.real + Sp.imag * Sp.imag, n=PITCH_FFT, dim=1)
        r = r[:, :PITCH_W // 2 + 2]
        e = r[:, :1]
        rn = r / e.clamp(min=1e-12) / c["rw"][None, :, None]                   # [b, L, T]
        lag = sr / (fs[:, None] * 2.0 ** (c["st"][None] / 12.0))              # [b, K]
        ok = (lag >= 2.0) & (lag <= PITCH_W // 2)
        lc = lag.clamp(2.0, PITCH_W // 2 - 1)
        lo = lc.floor()
        fr = (lc - lo)[:, :, None]
        li = lo.long()[:, :, None].expand(-1, -1, rn.shape[2])
        v = torch.gather(rn, 1, li) * (1 - fr) + torch.gather(rn, 1, li + 1) * fr
        v = torch.where(ok[:, :, None], v, torch.zeros_like(v)).clamp(-1.0, 1.0)  # [b, K, T]
        m, k = v.max(dim=1)                                                      # [b, T]
        K = v.shape[1]
        ko = (k + PITCH_OCT).clamp(max=K - 1)                   # the octave above, if as strong
        vo = torch.gather(v, 1, ko[:, None])[:, 0]
        k = torch.where((k + PITCH_OCT < K) & (vo >= PITCH_NEAR * m), ko, k)
        m = torch.gather(v, 1, k[:, None])[:, 0]
        km, kp = (k - 1).clamp(min=0), (k + 1).clamp(max=K - 1)   # parabolic refinement
        vm, vp = torch.gather(v, 1, km[:, None])[:, 0], torch.gather(v, 1, kp[:, None])[:, 0]
        den = vm - 2 * m + vp
        off = torch.where(den.abs() > 1e-6, 0.5 * (vm - vp) / den, torch.zeros_like(den))
        off = torch.where((k > 0) & (k < K - 1), off.clamp(-0.5, 0.5), torch.zeros_like(off))
        conf = m.clamp(0.0, 1.0) * (e[:, 0] > 1e-9).float()
        step = float(PITCH_ST[1] - PITCH_ST[0])
        dv = (c["st"][k] + off * step) / 12.0 * (conf > 0.2).float()
        pitch.append(torch.stack([dv, conf], 1))
        del Sp, r, rn
    # short: 512-point frames centred on the fine envelope's sub-frame centres
    # (t * HOP - 192 + s * 128, s = 0..3), SHORT_MELS log-mel bands, folded band-major
    pad_l = 3 * SHORT_HOP // 2
    need = (SUB * T - 1) * SHORT_HOP - (n + pad_l)
    xs = F.pad(x, (pad_l, max(0, need) + 1))
    S = torch.stft(xs, SHORT_FFT, SHORT_HOP, window=c["ws"], center=True, pad_mode="constant",
                   return_complex=True)[:, :, :SUB * T]
    Ps = (S.real * S.real + S.imag * S.imag) * c["ss"]
    sm = db(torch.einsum("mf,bft->bmt", c["mel_s"], Ps))                      # [B, M, 4T]
    short = sm.reshape(B, SHORT_MELS, T, SUB).permute(0, 1, 3, 2).reshape(B, SHORT_MELS * SUB, T)
    return torch.cat(harm, 0), short, torch.cat(pitch, 0)


def features(audio, midi, gate_s=None, device="cpu", sr=SR, secs=SECS, norm=None, version=1):
    """audio [B, n] or [n] (numpy or torch, at SR) -> torch float32 [B, n_channels(version), T]
    on `device`. midi: scalar or [B] (fractional is fine); gate_s: None (unknown), a scalar, or
    [B] with NaN for unknown rows. The audio is cut / zero-padded to `secs`. norm: None (the level
    as given), or a dBFS level every note's loudest 1024-sample frame is scaled to first
    (fitness.normalize's rule, at most NORM_MAX_DB of gain) -- a network trained so never relies
    on the level, which a recording does not have. version: 1 (mel, harm, env, gate), or 2 (mel,
    the 32 f0 harm, env, short, pitch, gate; see VERSION 2 above)."""
    import torch
    dev = torch.device(device)
    n = n_samples(secs, sr)
    if isinstance(audio, torch.Tensor):
        x = audio.to(dev, torch.float32)
        x = x[None] if x.dim() == 1 else x
        if x.shape[1] != n:
            x = torch.nn.functional.pad(x[:, :n], (0, max(0, n - x.shape[1])))
    else:
        x = torch.as_tensor(fit_length(audio, n), device=dev)
    B = x.shape[0]
    if norm is not None:
        fr = x[:, :(n // 1024) * 1024].reshape(B, -1, 1024)
        p = (fr * fr).mean(dim=2).amax(dim=1).clamp(min=1e-20)
        gain = torch.sqrt(10.0 ** (float(norm) / 10.0) / p).clamp(max=10.0 ** (NORM_MAX_DB / 20.0))
        x = x * gain[:, None]
    c = _consts(device, sr)
    T = 1 + n // HOP
    lo = 10.0 ** (DB_FLOOR / 10.0)

    def db(p):
        return (10.0 * torch.log10(torch.clamp(p, min=lo)) - DB_CENTER) / DB_SCALE

    # mel
    S = torch.stft(x, N_FFT, HOP, window=c["w1"], center=True, pad_mode="constant",
                   return_complex=True)                                           # [B, F, T]
    P = (S.real * S.real + S.imag * S.imag) * c["s1"]
    mel = db(torch.einsum("mf,bft->bmt", c["mel"], P))
    f0 = torch.as_tensor(np.broadcast_to(midi_hz(midi), (B,)).astype(np.float32), device=dev)
    extra, tail = [], []
    if int(version) == 2:
        harm, short, pitch = _v2_channels(x, f0, T, sr, db, device)
        extra = [short, pitch]
    if int(version) == 3:
        harm2, short, pitch = _v2_channels(x, f0, T, sr, db, device)
        tail = [short, pitch, harm2]
    if int(version) != 2:
        # quarter-harmonic grid
        S2 = torch.stft(x, HARM_FFT, HOP, window=c["w2"], center=True, pad_mode="constant",
                        return_complex=True)
        P2 = (S2.real * S2.real + S2.imag * S2.imag) * c["s2"]                    # [B, F2, T]
        fq = f0[:, None] * c["q"][None]                                           # [B, Q]
        kb = torch.round(fq / (sr / HARM_FFT)).long().clamp(1, HARM_FFT // 2 - 1)
        idx = torch.stack([kb - 1, kb, kb + 1], 1).reshape(B, 3 * HARM_Q)         # [B, 3Q]
        g = torch.gather(P2, 1, idx[:, :, None].expand(B, 3 * HARM_Q, T))
        hp = g.reshape(B, 3, HARM_Q, T).amax(dim=1)
        hp = torch.where((fq < HARM_TOP * sr)[:, :, None], hp, torch.zeros_like(hp))
        harm = db(hp)
    # fine envelope: 128-sample blocks around each frame centre
    blk = HOP // SUB
    xp = torch.nn.functional.pad(x, (HOP // 2, T * HOP - n - HOP // 2))
    e = (xp * xp).reshape(B, T * SUB, blk).mean(dim=2) * 2.0                       # sine -> 0 dB
    env = db(e).reshape(B, T, SUB).transpose(1, 2)
    # gate
    ga = _gate_array(gate_s, B)
    known = np.isfinite(ga)
    t = torch.arange(T, device=dev, dtype=torch.float32) * (HOP / sr)
    gt = torch.as_tensor(np.where(known, ga, 0.0).astype(np.float32), device=dev)
    step = torch.clamp((gt[:, None] - t[None]) / (HOP / sr) + 0.5, 0.0, 1.0)
    kn = torch.as_tensor(known.astype(np.float32), device=dev)[:, None]
    step = step * kn + 0.5 * (1.0 - kn)
    gate = torch.stack([step, kn.expand(B, T)], 1)
    return torch.cat([mel, harm, env] + extra + [gate] + tail, 1).contiguous()


# ============================================================================= training data

def make_batch(rng, B, midi_lo=28.0, midi_hi=96.0, gate_lo=0.1, gate_hi=2.3, secs=SECS,
               p_held=P_HELD, p_nogate=P_NOGATE, group=GATE_GROUP, pool=None, family=None,
               engine="v1", threads=1):
    """B prior genomes of `engine` (engines.get) rendered as notes: dict(genes float32[B, N]
    (canonical), fam int[B], midi float32[B], gate float32[B] (the true gate; > secs = held),
    known bool[B] (is the gate shown to the model), audio float32[B, n]). `pool`: a
    ThreadPoolExecutor to render the gate groups in parallel (ctypes drops the GIL); v2 renders
    each group's patches on `threads` threads instead (its binding has its own pool)."""
    from . import engines as EN
    E = EN.get(engine)
    if engine in ("v1", "v1x") and family is not None:
        from . import prior as PR
        G, fam = PR.sample(B, rng, family=family, return_family=True)
        if engine == "v1":                          # the version-2 layout: 40 genes, the rest off
            from . import core
            G[:, core.N_GENES_V2:] = PR.NEUTRAL[core.N_GENES_V2:]
            G = PR.canonical(G)[:, :core.N_GENES_V2]
    else:
        G, fam = E.sample(B, rng, return_family=True)
    render_batch = E.render_batch
    extra = {} if engine in ("v1", "v1x", "v1xm", "v1y") else dict(threads=max(1, int(threads)))
    midi = rng.uniform(midi_lo, midi_hi, B).astype(np.float32)
    ng = int(math.ceil(B / group))
    gates = rng.uniform(gate_lo, gate_hi, ng)
    gates[rng.random(ng) < p_held] = secs + 1.0
    seeds = rng.integers(1, 2 ** 31 - 1, ng)
    spans = [(i * group, min(B, (i + 1) * group)) for i in range(ng)]

    def job(i):
        a, b = spans[i]
        return render_batch(G[a:b], midi=midi[a:b], gate_s=float(gates[i]), secs=secs,
                            sr=SR, seed=int(seeds[i]), **extra)

    outs = list(pool.map(job, range(ng))) if pool is not None else [job(i) for i in range(ng)]
    audio = np.concatenate(outs, 0)
    gate = np.repeat(gates, group)[:B].astype(np.float32)
    known = rng.random(B) >= p_nogate
    return dict(genes=G, fam=fam.astype(np.int64), midi=midi, gate=gate, known=known,
                audio=audio)


def shown_gate(batch):
    """the gate as the model sees it: NaN where hidden; a held note's gate = the window's end"""
    g = np.minimum(batch["gate"].astype(np.float64), SECS + 0.5)
    return np.where(batch["known"], g, np.nan)


def batch_worker(q, stop, seed, B, kw, threads=2, shm_name=None, free=None, nslots=0):
    """a data process: make_batch forever until the `stop` event.
    Without shm_name: whole batches into queue q (pickled through a pipe: ~28 MB per batch of 64,
    which the READER unpickles in its own thread). With shm_name (see Ring): the audio goes into
    a free slot of a shared-memory ring and only (slot, the small arrays) go through q."""
    import queue as _q
    from concurrent.futures import ThreadPoolExecutor
    q.cancel_join_thread()          # exit at once on stop, without flushing batches nobody reads
    rng = np.random.default_rng(seed)
    v1 = kw.get("engine", "v1") in ("v1", "v1x", "v1xm", "v1y")   # the C voice: a pool
    pool = ThreadPoolExecutor(max_workers=threads) if threads > 1 and v1 else None
    if not v1:
        kw = dict(kw, threads=threads)
    shm = None
    if shm_name is not None:
        from multiprocessing import shared_memory
        shm = shared_memory.SharedMemory(name=shm_name)
        n = n_samples(kw.get("secs", SECS))
    try:
        while not stop.is_set():
            b = make_batch(rng, B, pool=pool, **kw)
            if shm is not None:
                slot = None
                while slot is None and not stop.is_set():
                    try:
                        slot = free.get(timeout=0.5)
                    except _q.Empty:
                        continue
                if slot is None:
                    break
                view = np.ndarray((B, n), np.float32, buffer=shm.buf, offset=slot * B * n * 4)
                view[:] = b.pop("audio")
                del view
                b["slot"] = slot
            while not stop.is_set():
                try:
                    q.put(b, timeout=0.5)
                    break
                except _q.Full:
                    continue
    finally:
        if pool is not None:
            pool.shutdown(wait=False)
        if shm is not None:
            shm.close()


class Ring:
    """The trainer's side of the shared-memory batch ring: `nslots` slots of B notes. Start the
    worker with worker_args(); get() returns a batch dict with its audio copied out of the slot
    (a 28 MB memcpy instead of a pipe + unpickle) and the slot handed back."""

    def __init__(self, ctx, B, nslots=4, secs=SECS):
        from multiprocessing import shared_memory
        self.B, self.n, self.nslots = B, n_samples(secs), nslots
        self.shm = shared_memory.SharedMemory(create=True, size=nslots * B * self.n * 4)
        self.q, self.free = ctx.Queue(maxsize=nslots), ctx.Queue()
        for i in range(nslots):
            self.free.put(i)

    def worker_kwargs(self):
        return dict(shm_name=self.shm.name, free=self.free, nslots=self.nslots)

    def get(self, timeout=120):
        b = self.q.get(timeout=timeout)
        s = b.pop("slot")
        view = np.ndarray((self.B, self.n), np.float32, buffer=self.shm.buf,
                          offset=s * self.B * self.n * 4)
        b["audio"] = np.array(view)
        del view
        self.free.put(s)
        return b

    def drain(self):
        try:
            while True:
                b = self.q.get_nowait()
                self.free.put(b.pop("slot"))
        except Exception:
            pass

    def close(self):
        try:
            self.shm.close()
            self.shm.unlink()
        except Exception:
            pass
