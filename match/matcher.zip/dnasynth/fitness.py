"""The matcher's fitness: how far a candidate render is from a target, in dB-like units.

    from dnasynth.fitness import Target, distance
    T = Target(target_audio, sr=44100)      # the target's features, computed once
    s = T.score(cands)                       # cands [K, n] -> float32[K]; 0 = identical, lower = closer
    T = Target(target_audio, device="mps")   # the same numbers from the GPU (torch), ~10x the rate
    d = distance(a, b, sr)                   # one pair, a is the reference

WHAT IT MUST SEE (each a lesson paid for in graft / pchsynth; docs/matcher/foundation.md):

  * LEVEL. Not gain- or affine-invariant: a copy at -6 dB is a different sound (graft's 1-corr ruler
    scored a 48 dB contrast mangling as ~0). Every term is taken against floors fixed by the TARGET.
  * TIME. Frame by frame, never a time-averaged spectrum (a Welch ruler could not see a strike), and
    the frames at the target's onset weigh 5x, fading over ~0.1 s (an attack is a small share of
    the frames but much of what the ear keys on; graft's validated ruler weighted it 3x).
  * THE FULL BAND, 20 Hz to Nyquist, the log floor 80 dB under the target's loudest cell (a 60 dB
    floor and a 3 kHz band ceiling erased graft's high image and made its matches dull).
  * PITCH. The 4096-point resolution keeps 24 bands per octave, so harmonics stay resolved (a
    semitone moves a C3 saw's partials across bands).
  * NOT THE NOISE SEED. A noisy target is one realisation and every candidate gets another. Bins are
    pooled into log bands (6 / 12 / 24 per octave for 256 / 1024 / 4096 points) and every band is
    averaged over a few frames (Welch-like), so a noisy patch's own re-render with another seed
    scores well under a musically small change (validation: about 0.4x a 0.03 gene step).

THE TERMS (per candidate, vectorised over K):

  spec  multi-resolution log-band L1, dB. FFT sizes RES (Hann, hop n/2, centred frames); bin power
        pooled into log bands (RES_BPO per octave, never narrower than one bin), averaged over
        RES_SMOOTH frames; each octave weighs the same, each frame 1 + ONSET_BOOST e^-(t-onset)/TAU.
        |10 log10 max(Pc, floor) - 10 log10 max(Pt, floor)|, floor = target's loudest cell - FLOOR_DB.
  sc    spectral convergence on third-octave band MAGNITUDES, || |Bc| - |Bt| ||_F / || |Bt| ||_F:
        the linear term, ruled by the loud cells, level-sensitive (silence scores 1).
  env   frame-RMS envelope (1024 / hop 256), dB, the same floor rule and time weights, L1.

  score = W_SPEC * spec + W_SC * sc + W_ENV * env      (weights from the validation grid)

A RECORDING has an arbitrary level and dnasynth has no output-gain gene: bring it to the engine's
level first (normalize(audio): its loudest 1024-sample frame at LOUD_DB, the prior's median), or
score with Target(audio, free_gain=True) (each candidate at its best gain, GAIN_COST per dB).

`python3 -m dnasynth.fitness --validate` runs the full validation, `--odin` the out-of-domain one
on Odin2 knob sweeps, `--tune` the weight / constant grid the values below came from (the numbers
docs/matcher/foundation.md reports); tests/test_fitness.py runs a smaller one as a gate.
"""
from __future__ import annotations

import numpy as np

try:
    import scipy.fft as _fft
    from scipy.ndimage import uniform_filter1d as _uf1
    _FFT_KW = {"workers": -1}
except Exception:                                    # pragma: no cover - numpy fallback
    _fft, _uf1, _FFT_KW = np.fft, None, {}

RES = (256, 1024, 4096)                     # FFT sizes, hop n/2 (512 and 2048 measured to add nothing)
RES_BPO = {256: 6, 512: 8, 1024: 12, 2048: 24, 4096: 24}    # log bands per octave, per size
RES_SMOOTH = {256: 5, 512: 3, 1024: 3, 2048: 3, 4096: 3}    # frames averaged (odd, centred)
SC_BPO = 3                                  # the linear (sc) term's bands per octave
F_LO = 20.0                                 # the lowest band edge, Hz (DC and below are ignored)
FLOOR_DB = 80.0                             # the log floor, dB under the target's loudest cell
F_TAPER, TAPER_P = 14000.0, 6.0             # band weights x (F_TAPER / f)^TAPER_P above F_TAPER
ENV_N, ENV_HOP = 1024, 256                  # the envelope's frame and hop
ONSET_BOOST = 4.0                           # frames just after the onset weigh 1 + this ...
ONSET_TAU = 0.10                            # ... decaying with this time constant, seconds
W_SPEC, W_SC, W_ENV = 1.0, 3.0, 0.5         # the term weights
GAIN_COST = 0.25                            # free_gain: score per dB of gain the candidate needed
GAIN_RANGE_DB, GAIN_MAX_DB = 40.0, 24.0     # ... fitted over the target's top 40 dB, at most +-24
CHUNK = 16                                  # numpy path: candidates per pass (~25 MB per chunk)
TORCH_CHUNK = 64                            # torch path: candidates per pass
# Target(mod=True), the MODULATION-aware score (results.md section 25): frame by frame, a vibrato
# at another phase than the recording's costs more than no vibrato at all (eval/reach/
# vibrato_ladder.py), so where the note HOLDS a separate term compares its wobble -- how deep and
# how fast each band's level and pitch move, never when. That alone ranks the right vibrato at
# another phase over none; mod="hold" / "both" also time-smooth the held part (phase-free frames),
# an ablation only: smoothing a decay hid what the frames see (a DX7 bass's 0.3 s brightness fall)
HOLD_T0, HOLD_RAMP = 0.06, 0.14             # smoothing from the onset + T0, in full at + T0 + RAMP, s
HOLD_SMOOTH = 0.2                           # two boxcars of this length, s: a 0.4 s triangle
HOLD_STEADY_DB_S = 20.0                     # the note HOLDS where the target's band levels move
#                                             under this (fully at 0 dB/s, half at 10: strings, organs,
#                                             leads -- not a 20 dB/s E.Piano decay; section 25)
MOD_STEADY = 0.5                            # the wobble term's frames: held at least this much
MOD_N, MOD_HOP = 1024, 512                  # the wobble term's STFT (86 frames a second at 44.1 kHz)
MOD_BPO, MOD_F_LO, MOD_F_HI = 3, 80.0, 16000.0     # ... its bands
MOD_T0, MOD_RANGE_DB = 0.15, 30.0           # its frames: from the onset + T0, within 30 dB of the top
MOD_MIN_S = 0.25                            # a held part shorter than this has no wobble term
MOD_RATES = (2.5, 4.0, 6.0, 9.0, 13.5, 20.0)   # soft rate bins, Hz (log-Gaussian, MOD_RATE_W oct)
MOD_RATE_W = 0.35
MOD_CENTS = 10.0                            # a pitch wobble of this many cents weighs as 1 dB of level
MOD_BAND_DB = 40.0                          # the bands within this of the target's loudest count
W_MOD = 0.2                                 # the wobble term's weight: the least that still ranks
#                                             the right vibrato at any phase over none (vibrato_ladder:
#                                             1.71 vs 2.18); 0.4 pushed the search into motion the
#                                             engine cannot make (results.md section 25)
MOD_DEFAULT = False                         # Target(mod=None) takes this (the bench's A/B switch)

_PLANS = {}


def _plan(n, sr):
    """one resolution's pooling: first bin `lo`, reduceat starts of the log bands over bins [lo:],
    band weights (each octave sums to the same), band centres, and reduceat starts that group the
    log bands into SC_BPO-per-octave bands for the linear term"""
    key = (n, float(sr))
    if key not in _PLANS:
        bpo = RES_BPO.get(n, 12)
        f = np.fft.rfftfreq(n, 1.0 / sr)
        lo = max(int(np.searchsorted(f, F_LO)), 1)
        fb = f[lo:]
        band = np.floor(np.log2(fb / F_LO) * bpo).astype(np.int64)
        starts = np.flatnonzero(np.r_[True, band[1:] != band[:-1]])
        fc = np.array([fb[s:e].mean() for s, e in zip(starts, np.r_[starts[1:], len(fb)])])
        octv = np.floor(np.log2(fc / F_LO)).astype(np.int64)
        w = np.zeros(len(fc))
        for o in np.unique(octv):
            w[octv == o] = 1.0 / np.sum(octv == o)
        if TAPER_P > 0:                  # the very top counts less: hearing thins out above ~14 kHz
            w *= np.where(fc > F_TAPER, (F_TAPER / fc) ** TAPER_P, 1.0)
        w /= w.sum()
        third = np.floor(np.log2(fc / F_LO) * SC_BPO).astype(np.int64)
        starts3 = np.flatnonzero(np.r_[True, third[1:] != third[:-1]])
        _PLANS[key] = dict(lo=lo, starts=starts, w=w.astype(np.float32), fc=fc, starts3=starts3,
                           nbins=len(f))
    return _PLANS[key]


_WIN = {}


def _hann(n):
    if n not in _WIN:
        _WIN[n] = np.hanning(n + 1)[:n].astype(np.float32)          # periodic Hann
    return _WIN[n]


def _frames(xp, n, hop, F):
    """[K, M] -> its F frames of n samples, hop apart, as a strided VIEW (no copy). Made at the hop
    directly: a sliding_window_view of every sample cut down to every hop-th has the same frames,
    but its nominal size (K x M x n elements) passes 2**31 on a 32-bit runtime -- the browser's
    Python (pchkraft-synth/web/match) -- though it holds nothing (2026-10-05; same bits natively)"""
    s0, s1 = xp.strides
    return np.lib.stride_tricks.as_strided(xp, shape=(xp.shape[0], F, n), strides=(s0, hop * s1, s1),
                                           writeable=False)


def _band_power_np(x, n, sr):
    """x [K, N] float32 -> smoothed log-band power [K, F, nb] (Hann, hop n/2, centred frames)"""
    hop = n // 2
    p = _plan(n, sr)
    K, N = x.shape
    F = 1 + N // hop
    xp = np.zeros((K, (F - 1) * hop + n), np.float32)
    xp[:, n // 2:n // 2 + N] = x
    fr = _frames(xp, n, hop, F)
    S = _fft.rfft(fr * _hann(n), axis=-1, **_FFT_KW)
    P = S.real * S.real + S.imag * S.imag
    B = np.add.reduceat(P[..., p["lo"]:], p["starts"], axis=-1).astype(np.float32)
    L = RES_SMOOTH.get(n, 1)
    if L > 1:
        if _uf1 is not None:
            B = np.maximum(_uf1(B, L, axis=1, mode="nearest"), 0.0)
        else:                                                         # pragma: no cover
            h = L // 2
            Bp = np.concatenate([B[:, :1].repeat(h, 1), B, B[:, -1:].repeat(h, 1)], axis=1)
            B = np.mean([Bp[:, i:i + F] for i in range(L)], axis=0)
    return B


def _frame_energy_np(x):
    """x [K, N] -> mean square per frame [K, F] (ENV_N frames, hop ENV_HOP, centred): the squares
    summed per hop-long block, a frame the sum of its ENV_N / ENV_HOP blocks (2026-10-04: a
    float64 running sum over the whole take was 30 % of a score)"""
    K, N = x.shape
    F = 1 + N // ENV_HOP
    m = ENV_N // ENV_HOP
    xp = np.zeros((K, (F + m - 1) * ENV_HOP), np.float32)
    xp[:, ENV_N // 2:ENV_N // 2 + N] = x
    B = (xp * xp).reshape(K, F + m - 1, ENV_HOP).sum(axis=2, dtype=np.float64)
    S = B[:, :F].copy()
    for j in range(1, m):
        S += B[:, j:j + F]
    return (S / ENV_N).astype(np.float32)


class _NumpyFeatures:
    def __init__(self, sr, res):
        self.sr, self.res = sr, res

    def __call__(self, x, E=None):
        """(frame energies, band powers per resolution); E: the energies when already known"""
        return (_frame_energy_np(x) if E is None else E), [_band_power_np(x, n, self.sr) for n in self.res]


_POOL = []


def _pool():
    """two threads for a score's two halves (numpy lets go of the GIL in its FFTs and array work:
    4.5 -> 2.7 ms a candidate on 16; more threads bought nothing)"""
    if not _POOL:
        from concurrent.futures import ThreadPoolExecutor
        _POOL.append(ThreadPoolExecutor(2))
    return _POOL[0]


class _TorchFeatures:
    """The same features on a torch device (mps / cuda / cpu): the STFTs, the band pooling, the
    smoothing and the envelope. Target keeps the terms on the device too (keep=True) and moves only
    the K scores back; float32 throughout (MPS has no float64)."""

    def __init__(self, sr, res, device):
        import torch
        self.torch, self.sr, self.res = torch, sr, res
        self.dev = torch.device(device)
        self.win, self.idx, self.nb = {}, {}, {}
        for n in res:
            p = _plan(n, sr)
            self.win[n] = torch.as_tensor(_hann(n), device=self.dev)
            nb_bins = p["nbins"] - p["lo"]
            band_of = np.zeros(nb_bins, np.int64)
            band_of[p["starts"][1:]] = 1
            self.idx[n] = torch.as_tensor(np.cumsum(band_of), device=self.dev)
            self.nb[n] = len(p["starts"])

    def __call__(self, x, keep=False):
        torch = self.torch
        F_ = torch.nn.functional
        xt = torch.as_tensor(np.ascontiguousarray(x, np.float32), device=self.dev)
        K, N = xt.shape
        Fe = 1 + N // ENV_HOP
        x2 = F_.pad((xt * xt)[:, None, :], (ENV_N // 2, (Fe - 1) * ENV_HOP + ENV_N - N - ENV_N // 2))
        E = F_.avg_pool1d(x2, ENV_N, ENV_HOP)[:, 0, :Fe]
        Bs = []
        for n in self.res:
            p = _plan(n, self.sr)
            S = torch.stft(xt, n, n // 2, window=self.win[n], center=True, pad_mode="constant",
                           return_complex=True)                               # [K, bins, F]
            P = S.real * S.real + S.imag * S.imag
            B = torch.zeros((K, self.nb[n], P.shape[2]), device=self.dev, dtype=P.dtype)
            B.index_add_(1, self.idx[n], P[:, p["lo"]:, :])
            L = RES_SMOOTH.get(n, 1)
            if L > 1:
                B = F_.avg_pool1d(F_.pad(B, (L // 2, L // 2), mode="replicate"), L, 1)
            Bs.append(B.transpose(1, 2))
        if keep:
            return E, Bs
        out = [o.float().cpu().numpy() for o in [E] + Bs]
        return out[0], out[1:]


def _db(p, floor):
    return 10.0 * np.log10(np.maximum(p, floor))


def _time_weights(times, onset):
    w = np.ones_like(times)
    after = times >= onset - 0.01
    w[after] += ONSET_BOOST * np.exp(-np.maximum(times[after] - onset, 0.0) / ONSET_TAU)
    return (w / w.mean()).astype(np.float32)


def _smooth_len(hop, sr):
    """HOLD_SMOOTH in frames of `hop`, odd"""
    L = max(1, int(round(HOLD_SMOOTH * sr / hop)))
    return L + 1 - L % 2


def _hold_profile(x, sr, onset):
    """(t, w) of the TARGET x: how much each moment HOLDS. 0 through the attack (to the onset +
    HOLD_T0, then rising over HOLD_RAMP), and then by how still the note is: 1 where its band
    levels stand, 0 where they move HOLD_STEADY_DB_S or faster -- measured on their slow course
    (the HOLD_SMOOTH triangle), so a vibrato's or a tremolo's ripple counts as still and a fast
    decay, a swell or a sweep does not. The wobble term's frames; mod="hold"'s smoothing weight"""
    n, hop = 1024, 512
    B = _band_power_np(np.asarray(x, np.float32)[None], n, sr)[0]              # [F, nb]
    t = np.arange(B.shape[0]) * hop / sr
    floor = max(float(B.max()) * 10 ** (-FLOOR_DB / 10), 1e-20)
    L = 10.0 * np.log10(np.maximum(B, floor))
    Lm = _smooth_len(hop, sr)
    if _uf1 is not None:
        L = _uf1(_uf1(L, Lm, axis=0, mode="nearest"), Lm, axis=0, mode="nearest")
    rate = np.abs(np.gradient(L, t, axis=0)) if len(t) > 1 else np.zeros_like(L)
    loud = L >= L.max(axis=1, keepdims=True) - 40.0                # the bands that count, then
    r = (rate * loud).sum(axis=1) / np.maximum(loud.sum(axis=1), 1)
    steady = np.clip(1.0 - r / HOLD_STEADY_DB_S, 0.0, 1.0)
    ramp = np.clip((t - onset - HOLD_T0) / HOLD_RAMP, 0.0, 1.0)
    return t, (ramp * steady).astype(np.float32)


def _hold_beta(n_frames, hop, sr, prof):
    """the hold profile (t, w) at the frames of a feature of hop `hop`"""
    t, w = prof
    return np.interp(np.arange(n_frames) * hop / sr, t, w).astype(np.float32)


def _hold_smooth_np(A, hop, sr, prof):
    """frame powers A [K, F] or [K, F, nb] -> time-smoothed (two HOLD_SMOOTH boxcars) where the
    target holds (the profile, _hold_profile), as they were through its attack and its moves"""
    b = _hold_beta(A.shape[1], hop, sr, prof)
    if not b.any():
        return A
    L = _smooth_len(hop, sr)
    if _uf1 is not None:            # (running sums: round-off below 0 after deep silence -> clamp)
        S = np.maximum(_uf1(_uf1(A, L, axis=1, mode="nearest"), L, axis=1, mode="nearest"), 0.0)
    else:                                                             # pragma: no cover
        S = A
        for _ in range(2):
            h = L // 2
            P = np.concatenate([S[:, :1].repeat(h, 1), S, S[:, -1:].repeat(h, 1)], axis=1)
            S = np.mean([P[:, i:i + A.shape[1]] for i in range(L)], axis=0)
    return A + b.reshape((1, -1) + (1,) * (A.ndim - 2)) * (S - A)


def _hold_smooth_torch(A, hop, sr, prof, torch):
    """_hold_smooth_np on a torch tensor [K, F] or [K, F, nb]"""
    b = _hold_beta(A.shape[1], hop, sr, prof)
    if not b.any():
        return A
    F_ = torch.nn.functional
    L = _smooth_len(hop, sr)
    X = (A if A.ndim == 3 else A[..., None]).transpose(1, 2)               # [K, C, F]
    for _ in range(2):
        X = F_.avg_pool1d(F_.pad(X, (L // 2, L // 2), mode="replicate"), L, 1)
    S = torch.clamp(X.transpose(1, 2), min=0.0)
    if A.ndim == 2:
        S = S[..., 0]
    bt = torch.as_tensor(b, device=A.device).reshape((1, -1) + (1,) * (A.ndim - 2))
    return A + bt * (S - A)


_MOD_PLANS = {}


def _mod_plan(sr):
    """the wobble term's bands: bins [lo:hi] of the MOD_N STFT, reduceat starts, bin frequencies"""
    key = float(sr)
    if key not in _MOD_PLANS:
        f = np.fft.rfftfreq(MOD_N, 1.0 / sr)
        lo = max(int(np.searchsorted(f, MOD_F_LO)), 1)
        hi = int(np.searchsorted(f, min(MOD_F_HI, 0.45 * sr)))
        fb = f[lo:hi]
        band = np.floor(np.log2(fb / MOD_F_LO) * MOD_BPO).astype(np.int64)
        starts = np.flatnonzero(np.r_[True, band[1:] != band[:-1]])
        _MOD_PLANS[key] = dict(lo=lo, hi=hi, starts=starts, f=fb.astype(np.float32))
    return _MOD_PLANS[key]


def _mod_tracks_np(x, sr, frames=None):
    """x [K, N] -> per MOD_N frame and band: power [K, F, nb] and power-weighted mean frequency
    [K, F, nb] (Hz) -- a band's pitch, which a vibrato moves in every band that holds a partial.
    frames: a slice of the frames to compute (the target's held part), else all"""
    p = _mod_plan(sr)
    K, N = x.shape
    F = 1 + N // MOD_HOP
    xp = np.zeros((K, (F - 1) * MOD_HOP + MOD_N), np.float32)
    xp[:, MOD_N // 2:MOD_N // 2 + N] = x
    fr = _frames(xp, MOD_N, MOD_HOP, F)
    if frames is not None:
        fr = fr[:, frames]
    S = _fft.rfft(fr * _hann(MOD_N), axis=-1, **_FFT_KW)[..., p["lo"]:p["hi"]]
    P = (S.real * S.real + S.imag * S.imag).astype(np.float32)
    Pb = np.add.reduceat(P, p["starts"], axis=-1)
    Fb = np.add.reduceat(P * p["f"], p["starts"], axis=-1)
    return Pb, Fb / np.maximum(Pb, 1e-30)


def _mod_rate_bins(n_frames, sr):
    """the soft rate bins over the rfft of a wobble track of n_frames: [nrates, nf], each frequency's
    weights summing to 1 where the bins cover it (a rate between two centres splits between them)"""
    nfft = max(1024, 1 << int(np.ceil(np.log2(max(n_frames, 2)))))
    fm = np.fft.rfftfreq(nfft, MOD_HOP / sr)
    lf = np.log2(np.maximum(fm, 1e-3))
    W = np.exp(-0.5 * ((lf[None, :] - np.log2(MOD_RATES)[:, None]) / MOD_RATE_W) ** 2)
    s = W.sum(axis=0)
    W = np.where(s[None, :] > 0.05, W / np.maximum(s, 1e-30)[None, :], 0.0)
    return nfft, W.astype(np.float32)


def _mod_depths_np(Pb, Cb, floor, nfft, W, sr):
    """band power / pitch tracks over the held frames [K, T, nb] -> the RMS wobble per soft rate
    bin [K, nb, nrates, 2]: level in dB, pitch in cents / MOD_CENTS. A track's slow course (under
    ~2 Hz: the two HOLD_SMOOTH boxcars) is removed first -- a decay or a swell is not a wobble."""
    tracks = (10.0 * np.log10(np.maximum(Pb, floor)),
              1200.0 * np.log2(np.maximum(Cb, 1.0)) / MOD_CENTS)
    T = Pb.shape[1]
    w = np.hanning(T + 2)[1:-1].astype(np.float32)
    ww = float((w * w).sum())
    Ls = _smooth_len(MOD_HOP, sr)
    out = []
    for tr in tracks:
        if _uf1 is not None:
            slow = _uf1(_uf1(tr, Ls, axis=1, mode="nearest"), Ls, axis=1, mode="nearest")
        else:                                                         # pragma: no cover
            slow = tr.mean(axis=1, keepdims=True)
        r = (tr - slow) * w[None, :, None]
        R = np.fft.rfft(r, n=nfft, axis=1)
        Pw = (R.real * R.real + R.imag * R.imag).astype(np.float32)          # [K, nf, nb]
        tot = Pw.sum(axis=1)
        rms = np.sqrt((r * r).sum(axis=1) / ww)                               # [K, nb]
        share = np.einsum("rf,kfb->kbr", W, Pw) / np.maximum(tot, 1e-30)[..., None]
        out.append(rms[..., None] * np.sqrt(share))
    return np.stack(out, axis=-1)


class Target:
    """A target's features, computed once; `score` compares any number of candidates against them.

    Candidates are expected at the target's length (the matcher renders them at the target's own
    length, key and gate); a longer one is cut, a shorter one zero-padded (stopping early costs). A
    candidate with a non-finite sample scores +inf. `device` None (or "numpy") is the numpy path;
    "mps" / "cuda" / "cpu" run the features through torch on that device (validation: the two agree
    to about 1e-5 of a score).

    free_gain=True is for a RECORDING at an arbitrary level (dnasynth has no output-gain gene):
    each candidate is first scaled by the gain that lays its frame-RMS envelope on the target's
    (median dB difference over the target's top 40 dB), and gain_cost per dB of that gain is added
    back, so level still costs, at gain_cost instead of ~0.9 per dB. The default is fixed gain: a
    render against a render, or a recording already brought to the engine's level (normalize).

    mod=True is the modulation-aware score (see MOD_*): the wobble term `mod` (W_MOD) where the note
    holds. mod="hold" time-smooths the held part instead, "both" does both (ablations). The default
    (None: MOD_DEFAULT, False) is the score as it was, bit for bit."""

    def __init__(self, audio, sr=44100.0, device=None, free_gain=False, gain_cost=GAIN_COST,
                 mod=None):
        x = np.asarray(audio, np.float32).ravel()
        if x.size < 64:
            raise ValueError("target too short (%d samples)" % x.size)
        if not np.isfinite(x).all():
            raise ValueError("target has non-finite samples")
        self.sr = float(sr)
        self.n = x.size
        self.audio = x
        self.res_sizes = tuple(n for n in RES if n <= 2 * self.n)
        if device in (None, "numpy"):
            self.feat, self.chunk = _NumpyFeatures(self.sr, self.res_sizes), CHUNK
        else:
            self.feat, self.chunk = _TorchFeatures(self.sr, self.res_sizes, device), TORCH_CHUNK
        self.device = device
        if mod is None:
            mod = MOD_DEFAULT
        self.hold = mod in ("hold", "both")
        self.mod_term = mod in (True, "term", "both")
        E, Bs = self.feat(x[None])
        E = E[0]
        self.env_floor = max(float(E.max()) * 10 ** (-FLOOR_DB / 10), 1e-20)
        t_env = np.arange(E.size) * ENV_HOP / self.sr
        above = np.flatnonzero(E >= E.max() * 1e-3)            # the onset: within 30 dB of the top
        self.onset = float(t_env[above[0]]) if above.size else 0.0
        self.free_gain, self.gain_cost = bool(free_gain), float(gain_cost)
        self.gain_frames = np.flatnonzero(E >= E.max() * 10 ** (-GAIN_RANGE_DB / 10))
        floors = [max(float(B[0].max()) * 10 ** (-FLOOR_DB / 10), 1e-20) for B in Bs]
        self.hold_prof = _hold_profile(x, self.sr, self.onset) if (self.hold or self.mod_term) \
            else None
        if self.hold:
            E = _hold_smooth_np(E[None], ENV_HOP, self.sr, self.hold_prof)[0]
            Bs = [_hold_smooth_np(B, n // 2, self.sr, self.hold_prof)
                  for n, B in zip(self.res_sizes, Bs)]
        self.env_db = _db(E, self.env_floor)
        self.env_w = _time_weights(t_env, self.onset)
        self._mod = self._mod_target(x) if self.mod_term else None
        self.res = []
        for n, B, floor in zip(self.res_sizes, Bs, floors):
            B = B[0]
            p = _plan(n, self.sr)
            mag = np.sqrt(np.add.reduceat(B, p["starts3"], axis=-1))
            t = np.arange(B.shape[0]) * (n // 2) / self.sr
            self.res.append(dict(n=n, floor=floor, db=_db(B, floor), mag=mag, s3=p["starts3"],
                                 mag_norm=float(np.sqrt((mag.astype(np.float64) ** 2).sum())) + 1e-20,
                                 fw=p["w"], tw=_time_weights(t, self.onset)))
        self._t = None
        if isinstance(self.feat, _TorchFeatures):
            torch, dev = self.feat.torch, self.feat.dev
            tt = lambda a: torch.as_tensor(np.ascontiguousarray(a, np.float32), device=dev)  # noqa
            res_t = []
            for r in self.res:
                third = np.zeros(r["db"].shape[1], np.int64)
                third[r["s3"][1:]] = 1
                res_t.append(dict(db=tt(r["db"]), mag=tt(r["mag"]), fw=tt(r["fw"]), tw=tt(r["tw"]),
                                  idx3=torch.as_tensor(np.cumsum(third), device=dev),
                                  n3=r["mag"].shape[1]))
            self._t = dict(env_db=tt(self.env_db), env_w=tt(self.env_w), res=res_t)

    def _mod_target(self, x):
        """the target's wobble: its held frames (from the onset + MOD_T0, within MOD_RANGE_DB of
        the top, held at least MOD_STEADY by the hold profile; the longest run), the bands that
        count and their wobble per rate bin -- None when that run is shorter than MOD_MIN_S (a drum
        hit, a decaying key: nothing held to wobble)"""
        Pb, Cb = _mod_tracks_np(x[None], self.sr)
        Pb, Cb = Pb[0], Cb[0]
        t = np.arange(Pb.shape[0]) * MOD_HOP / self.sr
        tot = Pb.sum(axis=1)
        ok = ((t >= self.onset + MOD_T0) & (tot >= tot.max() * 10 ** (-MOD_RANGE_DB / 10))
              & (_hold_beta(len(t), MOD_HOP, self.sr, self.hold_prof) >= MOD_STEADY))
        idx = np.flatnonzero(ok)
        if not idx.size:
            return None
        runs = np.split(idx, np.flatnonzero(np.diff(idx) > 1) + 1)
        run = max(runs, key=len)
        if len(run) * MOD_HOP / self.sr < MOD_MIN_S:
            return None
        fr = slice(int(run[0]), int(run[-1]) + 1)
        floor = max(float(Pb.max()) * 10 ** (-FLOOR_DB / 10), 1e-30)
        band = Pb[fr].mean(axis=0)
        bands = np.flatnonzero(band >= band.max() * 10 ** (-MOD_BAND_DB / 10))
        nfft, W = _mod_rate_bins(fr.stop - fr.start, self.sr)
        D = _mod_depths_np(Pb[None, fr], Cb[None, fr], floor, nfft, W, self.sr)[0]
        return dict(frames=fr, floor=floor, bands=bands, nfft=nfft, W=W, D=D[bands])

    def _mod_score(self, c):
        """the wobble term of candidates c [k, n]: |wobble - the target's| summed over the rate
        bins and the two kinds, averaged over the bands that count"""
        m = self._mod
        out = np.zeros(len(c))
        for a in range(0, len(c), CHUNK):
            Pb, Cb = _mod_tracks_np(c[a:a + CHUNK], self.sr, m["frames"])
            D = _mod_depths_np(Pb, Cb, m["floor"], m["nfft"], m["W"], self.sr)
            out[a:a + CHUNK] = np.abs(D[:, m["bands"]] - m["D"][None]).sum(axis=(2, 3)).mean(axis=1)
        return out

    def _score_torch(self, x):
        """the three terms of a chunk, computed on the device; returns numpy [k] arrays"""
        torch = self.feat.torch
        E, Bs = self.feat(x, keep=True)
        if self.hold:
            E = _hold_smooth_torch(E, ENV_HOP, self.sr, self.hold_prof, torch)
            Bs = [_hold_smooth_torch(B, r["n"] // 2, self.sr, self.hold_prof, torch)
                  for r, B in zip(self.res, Bs)]
        t = self._t
        env = ((10 * torch.log10(torch.clamp(E, min=self.env_floor)) - t["env_db"]).abs()
               * t["env_w"]).mean(dim=1)
        spec = torch.zeros_like(env)
        sc = torch.zeros_like(env)
        for r, rt, B in zip(self.res, t["res"], Bs):
            d = (10 * torch.log10(torch.clamp(B, min=r["floor"])) - rt["db"]).abs()
            spec = spec + ((d @ rt["fw"]) * rt["tw"]).mean(dim=1)
            B3 = torch.zeros((B.shape[0], B.shape[1], rt["n3"]), device=B.device, dtype=B.dtype)
            B3.index_add_(2, rt["idx3"], B)
            dm = torch.sqrt(B3) - rt["mag"]
            sc = sc + torch.sqrt((dm * dm).sum(dim=(1, 2))) / r["mag_norm"]
        return [v.cpu().numpy().astype(np.float64) for v in (spec, sc, env)]

    def _fit_len(self, c):
        c = np.atleast_2d(np.asarray(c, np.float32))
        if c.shape[1] > self.n:
            c = c[:, :self.n]
        elif c.shape[1] < self.n:
            c = np.pad(c, ((0, 0), (0, self.n - c.shape[1])))
        return np.ascontiguousarray(c)

    def score(self, cands, terms=False):
        """cands [K, n] (or [n]) -> float32[K]; with terms=True also a dict of the three terms."""
        c = self._fit_len(cands)
        K = c.shape[0]
        bad = ~np.isfinite(c).all(axis=1)
        if bad.any():
            c = c.copy()
            c[bad] = 0.0
        gain_db = np.zeros(K)
        E_all = None                                     # numpy path: the energies, computed ONCE
        if self.free_gain:
            E_raw = _frame_energy_np(c) if self._t is None else None
            gain_db = self._best_gain(c, E_raw)
            c = (c * (10.0 ** (gain_db / 20.0))[:, None]).astype(np.float32)
            if E_raw is not None:                        # the energy at the gain: E(g x) = g^2 E(x)
                E_all = (E_raw * (10.0 ** (gain_db / 10.0))[:, None]).astype(np.float32)
        spec = np.zeros(K, np.float64)
        sc = np.zeros(K, np.float64)
        env = np.zeros(K, np.float64)

        def part(lo, hi):
            """the three terms of candidates lo..hi (numpy), in chunks"""
            for a in range(lo, hi, self.chunk):
                b = min(hi, a + self.chunk)
                E, Bs = self.feat(c[a:b], None if E_all is None else E_all[a:b])
                if self.hold:
                    E = _hold_smooth_np(E, ENV_HOP, self.sr, self.hold_prof)
                    Bs = [_hold_smooth_np(B, r["n"] // 2, self.sr, self.hold_prof)
                          for r, B in zip(self.res, Bs)]
                env[a:b] = (np.abs(_db(E, self.env_floor) - self.env_db) * self.env_w).mean(axis=1)
                for r, B in zip(self.res, Bs):
                    d = np.abs(_db(B, r["floor"]) - r["db"])                   # [k, F, nb]
                    spec[a:b] += (np.einsum("kfb,b->kf", d, r["fw"]) * r["tw"]).mean(axis=1)
                    dm = np.sqrt(np.add.reduceat(B, r["s3"], axis=-1)) - r["mag"]
                    sc[a:b] += np.sqrt((dm.astype(np.float64) ** 2).sum(axis=(1, 2))) / r["mag_norm"]

        halves = ((0, K // 2), (K // 2, K)) if K >= 4 else ((0, K),)   # two threads (the GIL lets go)
        if self._t is not None:
            for a in range(0, K, self.chunk):
                sp_, sc_, en_ = self._score_torch(c[a:a + self.chunk])
                spec[a:a + self.chunk], sc[a:a + self.chunk], env[a:a + self.chunk] = sp_, sc_, en_
        elif len(halves) == 2:
            list(_pool().map(lambda h: part(*h), halves))
        else:
            part(0, K)
        nres = max(len(self.res), 1)
        spec /= nres
        sc /= nres
        total = W_SPEC * spec + W_SC * sc + W_ENV * env + self.gain_cost * np.abs(gain_db) \
            * self.free_gain
        mod = None
        if self._mod is not None:
            if len(halves) == 2:
                mod = np.concatenate(list(_pool().map(lambda h: self._mod_score(c[h[0]:h[1]]), halves)))
            else:
                mod = self._mod_score(c)
            total = total + W_MOD * mod
        total[bad] = np.inf
        total = total.astype(np.float32)
        if terms:
            t = dict(spec=spec.astype(np.float32), sc=sc.astype(np.float32),
                     env=env.astype(np.float32), gain_db=gain_db.astype(np.float32))
            if self.mod_term:
                t["mod"] = (mod if mod is not None else np.zeros(K)).astype(np.float32)
            return total, t
        return total

    def _best_gain(self, c, E=None):
        """free_gain: per candidate, the gain (dB) that puts its frame-RMS envelope on the target's,
        the median difference over the target's frames within GAIN_RANGE_DB of its loudest (and
        the candidate's within 60 dB of its own), clamped to +-GAIN_MAX_DB (E: c's frame energies,
        when the caller has them)"""
        E = _frame_energy_np(c) if E is None else E
        if self.hold:
            E = _hold_smooth_np(E, ENV_HOP, self.sr, self.hold_prof)
        E = E[:, self.gain_frames]
        Ec = 10 * np.log10(np.maximum(E, 1e-30))
        ok = Ec >= Ec.max(axis=1, keepdims=True) - 60.0
        d = np.where(ok, self.env_db[self.gain_frames][None] - Ec, np.nan)
        with np.errstate(all="ignore"):
            g = np.nanmedian(d, axis=1) if d.size else np.zeros(len(c))
        g = np.where(np.isfinite(g), g, 0.0)
        return np.clip(g, -GAIN_MAX_DB, GAIN_MAX_DB)


def distance(a, b, sr=44100.0):
    """the fitness of b against a (a is the reference: its floors, onset and length are used)"""
    return float(Target(a, sr).score(np.asarray(b, np.float32)[None])[0])


LOUD_DB = -3.6          # the prior's median loudest-frame level (dBFS rms, 1024-sample frames)


def loudness(audio):
    """the loudest 1024-sample frame's rms, dBFS"""
    x = np.asarray(audio, np.float64).ravel()
    n = len(x) // 1024
    fr = x[:n * 1024].reshape(n, 1024) if n else x[None]
    return float(10 * np.log10(max((fr ** 2).mean(axis=1).max(), 1e-20)))


def normalize(audio, loud_db=LOUD_DB):
    """a recording scaled so its loudest frame sits at the engine's typical level (LOUD_DB, the
    median of prior renders), the level a fixed-gain Target expects a target at"""
    x = np.asarray(audio, np.float32)
    return (x * 10 ** ((loud_db - loudness(x)) / 20)).astype(np.float32)


# ============================================================================= validation
# `python3 -m dnasynth.fitness --validate [--quick]` -- the numbers docs/matcher/foundation.md reports.

RULER_DIR = "/Users/sansel/Projects/rsynth/eval"


def _ruler():
    import sys
    if RULER_DIR not in sys.path:
        sys.path.insert(0, RULER_DIR)
    import ruler                                        # rsynth's evaluation ruler (tf, bal, level)
    return ruler


def _spearman(a, b):
    from scipy.stats import spearmanr
    r = spearmanr(a, b).correlation
    return float(r) if np.isfinite(r) else 0.0


def _brickwall(x, sr, fc):
    X = np.fft.rfft(np.asarray(x, np.float64))
    X[np.fft.rfftfreq(len(x), 1 / sr) > fc] = 0
    return np.fft.irfft(X, len(x)).astype(np.float32)


def validate(n_mono=40, n_pairs=40, secs=2.5, gate_s=1.2, seed=0, device=None, verbose=True):
    """The fitness's own gate. Returns a dict of every number it measured (foundation.md)."""
    import time
    from . import core as D
    from . import prior as PR
    rng = np.random.default_rng(seed)
    out = {}
    R = None
    try:
        R = _ruler()
    except Exception as e:                               # pragma: no cover
        print("rsynth ruler unavailable (%s): skipping the agreement checks" % e)

    def say(*a):
        if verbose:
            print(*a, flush=True)

    def rnd(g, midi=48, seed_=1):
        return D.render(g, midi=midi, gate_s=gate_s, secs=secs, seed=seed_)

    # --- 1. identity
    Y = D.render_batch(PR.sample(8, rng), midi=48, gate_s=gate_s, secs=secs)
    out["identity_max"] = float(max(Target(y, device=device).score(y[None])[0] for y in Y))
    say("identity: max score over 8 prior renders = %.3g" % out["identity_max"])

    # --- 2. separation, and the known-verdict probes, on a plain subtractive patch at C3
    base = D.neutral()
    for k, v in dict(flt_cut=0.6, flt_res=0.3, flt_env=0.8, mod_dec=0.55, amp_dec=0.65,
                     amp_sus=0.5, amp_att=0.2).items():
        base[D.GENE_INDEX[k]] = v
    ref = rnd(base)
    T = Target(ref, device=device)

    def with_(**kw):
        g = base.copy()
        for k, v in kw.items():
            g[D.GENE_INDEX[k]] = v
        return g
    probes = {}
    for db in (0.5, 1, 3, 6, 12):
        probes["level -%g dB" % db] = ref * 10 ** (-db / 20)
    for dc in (0.01, 0.03, 0.1, 0.2):
        probes["cutoff +%.2f (%.2f oct)" % (dc, dc * np.log2(1000))] = rnd(with_(flt_cut=0.6 + dc))
    for da in (0.05, 0.1, 0.2, 0.4):
        probes["attack %.0f->%.0f ms" % (10 ** (4 * 0.2), 10 ** (4 * (0.2 + da)))] = \
            rnd(with_(amp_att=0.2 + da))
    for dd in (0.03, 0.1, 0.2):
        probes["decay %.2f->%.2f s" % (1e-3 * 10 ** 2.6, 1e-3 * 10 ** (4 * (0.65 - dd)))] = \
            rnd(with_(amp_dec=0.65 - dd))
    for st in (0.1, 0.25, 1.0, 12.0):
        probes["pitch +%g st" % st] = D.render(base, midi=48 + st, gate_s=gate_s, secs=secs)
    cut = ref.copy()
    cut[:int(0.03 * 44100)] = 0
    probes["attack cut (first 30 ms)"] = cut
    probes["time-reversed"] = ref[::-1].copy()
    names = list(probes)
    s = T.score(np.stack([probes[k] for k in names]))
    sep = {}
    for k, v in zip(names, s):
        r = R.score(ref, probes[k], 44100.0, align=False) if R else {"tf": np.nan, "level": np.nan}
        sep[k] = dict(fitness=float(v), ruler_tf=float(r["tf"]), ruler_level=float(r["level"]))
    # the band: brick-wall low-passes of a BRIGHT target (an open saw; the patch above has nothing
    # up there to lose)
    bright = D.neutral()
    for k, v in dict(amp_dec=0.65, amp_sus=0.5, amp_att=0.2).items():
        bright[D.GENE_INDEX[k]] = v
    refb = rnd(bright)
    Tb = Target(refb, device=device)
    for fc in (3000, 8000, 12000, 16000, 19000):
        z = _brickwall(refb, 44100.0, fc)
        r = R.score(refb, z, 44100.0, align=False) if R else {"tf": np.nan, "level": np.nan}
        sep["bright saw, lowpass %g kHz" % (fc / 1000)] = dict(
            fitness=float(Tb.score(z[None])[0]), ruler_tf=float(r["tf"]), ruler_level=float(r["level"]))
    out["separation"] = sep
    say("separation + probes (plain subtractive patch at C3; ruler = rsynth eval/ruler.py):")
    for k, v in sep.items():
        say("  %-28s fitness %7.3f   ruler tf %6.2f  level %6.2f" % (k, v["fitness"], v["ruler_tf"],
                                                                   v["ruler_level"]))

    # --- 3. the noise seed: noisy prior patches, other seeds vs small real changes
    G = PR.sample(600, rng)
    G = G[PR.active_mask(G)[:, D.GENE_INDEX["noise_lvl"]]][:20]
    ratios_s, ratios_m = [], []
    for g in G:
        act = PR.active_mask(g[None])[0]
        act[D.GENE_INDEX["b_ratio"]] = False
        midi = float(rng.integers(36, 72))
        r0 = D.render(g, midi=midi, gate_s=gate_s, secs=secs, seed=1)
        Tn = Target(r0, device=device)
        oth = np.stack([D.render(g, midi=midi, gate_s=gate_s, secs=secs, seed=q) for q in (2, 3, 4)])
        pp = []
        for amt in (0.03, 0.1):
            d = rng.standard_normal(D.N_GENES) * act
            d /= np.linalg.norm(d)
            pp.append(D.render(np.clip(g + amt * d, 0, 1).astype(np.float32), midi=midi,
                               gate_s=gate_s, secs=secs, seed=2))
        sc_ = Tn.score(np.vstack([oth, np.stack(pp)]))
        ratios_s.append(sc_[:3].mean() / sc_[3])
        ratios_m.append(sc_[:3].mean() / sc_[4])
    out["noise_seed_over_step_0p03_median"] = float(np.median(ratios_s))
    out["noise_seed_over_step_0p1_median"] = float(np.median(ratios_m))
    say("noise seed: %d noisy prior patches; re-render with another seed / a 0.03 gene step = %.2f "
        "(median), / a 0.1 step = %.2f" % (len(G), np.median(ratios_s), np.median(ratios_m)))

    # --- 4. monotone in-domain: random prior genomes, one random direction on the active genes
    deltas = np.array([0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.3])
    rhos = []
    for g in PR.sample(n_mono, rng):
        act = PR.active_mask(g[None])[0]
        act[D.GENE_INDEX["b_ratio"]] = False               # a plateau gene has no direction
        d = rng.standard_normal(D.N_GENES) * act
        if not np.any(d):
            continue
        d /= np.linalg.norm(d)
        P = np.clip(g[None] + deltas[:, None] * d[None], 0, 1).astype(np.float32)
        Yp = D.render_batch(np.vstack([g[None], P]), midi=float(rng.integers(36, 72)),
                            gate_s=gate_s, secs=secs)
        rhos.append(_spearman(deltas, Target(Yp[0], device=device).score(Yp[1:])))
    rhos = np.array(rhos)
    out.update(monotone_n=len(rhos), monotone_rho_mean=float(rhos.mean()),
               monotone_rho_median=float(np.median(rhos)),
               monotone_frac_rho_ge_0p9=float((rhos >= 0.9).mean()))
    say("monotone: %d genomes x %d step sizes (0.005..0.3), Spearman rho mean %.3f, median %.3f, "
        "%.0f%% of genomes >= 0.9" % (len(rhos), len(deltas), rhos.mean(), np.median(rhos),
                                      100 * (rhos >= 0.9).mean()))

    # --- 5. agreement with rsynth's ruler on perturbation pairs
    if R is not None:
        fit, tf, tfl, within = [], [], [], []
        t0 = time.perf_counter()
        for g in PR.sample(n_pairs, rng):
            act = PR.active_mask(g[None])[0]
            act[D.GENE_INDEX["b_ratio"]] = False
            idx = np.flatnonzero(act)
            pert = []
            for amt in (0.02, 0.05, 0.1, 0.2, 0.3):
                d = rng.standard_normal(D.N_GENES) * act
                d /= max(np.linalg.norm(d), 1e-9)
                pert.append(np.clip(g + amt * d, 0, 1))
            for _ in range(3):                                  # single-gene moves
                j = rng.choice(idx) if idx.size else D.GENE_INDEX["flt_cut"]
                p = g.copy()
                p[j] = np.clip(p[j] + rng.choice([-1, 1]) * rng.uniform(0.05, 0.3), 0, 1)
                pert.append(p)
            Yp = D.render_batch(np.vstack([g[None], np.array(pert, np.float32)]),
                                midi=float(rng.integers(36, 72)), gate_s=gate_s, secs=secs)
            s_ = Target(Yp[0], device=device).score(Yp[1:])
            rr = [R.score(Yp[0], y, 44100.0, align=False) for y in Yp[1:]]
            a_ = [r["tf"] for r in rr]
            h_ = [np.hypot(r["tf"], r["level"]) for r in rr]
            fit += list(s_)
            tf += a_
            tfl += h_
            within.append(_spearman(s_, h_))
        out.update(ruler_pairs=len(fit), ruler_rho_tf=_spearman(fit, tf),
                   ruler_rho_tf_level=_spearman(fit, tfl),
                   ruler_rho_within_target_mean=float(np.mean(within)))
        say("ruler agreement: %d pairs (%d targets x 8); Spearman vs tf %.3f, vs hypot(tf, level) "
            "%.3f; within a target (8 perturbations ranked) mean %.3f  (%.0f s)"
            % (len(fit), n_pairs, out["ruler_rho_tf"], out["ruler_rho_tf_level"],
               out["ruler_rho_within_target_mean"], time.perf_counter() - t0))

    # --- 6. speed: K = 64 two-second candidates
    Yc = D.render_batch(PR.sample(64, rng), midi=48, gate_s=1.0, secs=2.0)
    for dev in (None, "mps"):
        try:
            Ts = Target(Yc[0], device=dev)
        except Exception as e:                                          # pragma: no cover
            say("speed on %s: unavailable (%s)" % (dev, e))
            continue
        Ts.score(Yc[:8])
        t0 = time.perf_counter()
        for _ in range(3):
            Ts.score(Yc)
        dt = (time.perf_counter() - t0) / 3
        out["scores_per_s_K64_2s_%s" % (dev or "numpy")] = 64 / dt
        say("speed (%s): K=64 two-second candidates in %.3f s = %.0f scores/s"
            % (dev or "numpy", dt, 64 / dt))
    return out


def validate_odin(cache_dir=None, verbose=True):
    """OUT OF DOMAIN: Odin2 (the bench's synth) swept by its own knobs at C3 -- the fitness must
    order the sweep, and agree with rsynth's ruler, on audio our engine did not make. Each sweep
    moves one Odin2 parameter of a synthoct patch away from the patch's value, in growing steps."""
    from . import prior as PR
    R = _ruler()
    root = PR.synthoct_constants()["ROOT"]
    sweeps = {
        "pluck cutoff": ("pluck", "filter1_frequency", (800.0, 850.0, 950.0, 1100.0, 1400.0, 2000.0)),
        "pluck amp decay": ("pluck", "ampenv_decay", (1.2, 1.0, 0.8, 0.5, 0.3)),
        "bass resonance": ("bass", "filter1_resonance", (0.6, 0.5, 0.4, 0.25, 0.1)),
        "pad attack": ("pad", "ampenv_attack", (0.3, 0.25, 0.18, 0.1, 0.03)),
        "lead key-follow at C3": ("lead", "filter1_keyboard_follow", (1.0, 0.8, 0.5, 0.2, 0.0)),
    }
    out = {}
    for name, (patch, par, vals) in sweeps.items():
        ys = [PR.odin_note(patch, root, cache_dir, overrides={par: v}) for v in vals]
        ys = [normalize(y) for y in ys]
        T = Target(ys[0])
        s = T.score(np.stack(ys[1:]))
        tf = [R.score(ys[0], y, 44100.0, align=False)["tf"] for y in ys[1:]]
        steps = np.arange(1, len(vals))
        out[name] = dict(values=vals, fitness=[float(v) for v in s], ruler_tf=[float(v) for v in tf],
                         rho_steps=_spearman(steps, s), rho_ruler=_spearman(s, tf))
        if verbose:
            print("  %-22s %s: %s -> fitness %s (rho vs step %.2f); ruler tf %s (rho %.2f)"
                  % (name, par, vals, np.round(s, 2), out[name]["rho_steps"], np.round(tf, 2),
                     out[name]["rho_ruler"]), flush=True)
    return out


def tune(n_pairs=70, n_mono=50, n_noisy=30, seed=11, variants=None,
         weights=((0, 0.5), (1, 0.5), (3, 0.25), (3, 0.5), (3, 1.0), (6, 0.5)), verbose=True):
    """How the constants were chosen (foundation.md section 4): one rendered set -- n_pairs prior
    targets x 8 perturbations scored by rsynth's ruler, n_mono monotonicity sweeps, n_noisy noisy
    patches (3 other seeds + a 0.03 and a 0.1 step) -- then, per config variant (module constants
    overridden, then restored), the terms once and every (W_SC, W_ENV) weight pair on them.
    Prints ruler rho vs tf / vs hypot(tf, level) / within-target, monotone rho, seed floor / step."""
    import time
    from . import core as D
    from . import prior as PR
    R = _ruler()
    rng = np.random.default_rng(seed)
    secs, gate = 2.5, 1.2
    jr = D.GENE_INDEX["b_ratio"]

    def direction(g):
        act = PR.active_mask(g[None])[0]
        act[jr] = False
        d = rng.standard_normal(D.N_GENES) * act
        return d / max(np.linalg.norm(d), 1e-9), act
    pairs, mono, seeds = [], [], []
    t0 = time.perf_counter()
    for g in PR.sample(n_pairs, rng):
        pert = [np.clip(g + amt * direction(g)[0], 0, 1) for amt in (0.02, 0.05, 0.1, 0.2, 0.3)]
        idx = np.flatnonzero(direction(g)[1])
        for _ in range(3):
            p = g.copy()
            j = rng.choice(idx) if idx.size else D.GENE_INDEX["flt_cut"]
            p[j] = np.clip(p[j] + rng.choice([-1, 1]) * rng.uniform(0.05, 0.3), 0, 1)
            pert.append(p)
        Y = D.render_batch(np.vstack([g[None], np.array(pert, np.float32)]),
                           midi=float(rng.integers(36, 72)), gate_s=gate, secs=secs)
        rr = [R.score(Y[0], y, 44100.0, align=False) for y in Y[1:]]
        pairs.append((Y, np.array([r["tf"] for r in rr]), np.array([r["level"] for r in rr])))
    deltas = np.array([0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.3])
    for g in PR.sample(n_mono, rng):
        d, _ = direction(g)
        P = np.clip(g[None] + deltas[:, None] * d[None], 0, 1).astype(np.float32)
        mono.append(D.render_batch(np.vstack([g[None], P]), midi=float(rng.integers(36, 72)),
                                   gate_s=gate, secs=secs))
    Gn = PR.sample(600, rng)
    for g in Gn[PR.active_mask(Gn)[:, D.GENE_INDEX["noise_lvl"]]][:n_noisy]:
        midi = float(rng.integers(36, 72))
        ys = [D.render(g, midi=midi, gate_s=gate, secs=secs, seed=q) for q in (1, 2, 3, 4)]
        ys += [D.render(np.clip(g + amt * direction(g)[0], 0, 1).astype(np.float32), midi=midi,
                        gate_s=gate, secs=secs, seed=2) for amt in (0.03, 0.1)]
        seeds.append(np.stack(ys))
    if verbose:
        print("tune: set rendered and ruled in %.0f s" % (time.perf_counter() - t0), flush=True)
    variants = variants or {"current": {}}
    g_ = globals()
    out = {}
    for name, cfg in variants.items():
        saved = {k: g_[k] for k in cfg}
        g_.update(cfg)
        _PLANS.clear()
        try:
            Tp = [(Target(Y[0]).score(Y[1:], terms=True)[1], tf, lv) for Y, tf, lv in pairs]
            Tm = [Target(Y[0]).score(Y[1:], terms=True)[1] for Y in mono]
            Ts = [Target(Y[0]).score(Y[1:], terms=True)[1] for Y in seeds]
        finally:
            g_.update(saved)
            _PLANS.clear()
        for wsc, wenv in weights:
            comb = lambda t: t["spec"] + wsc * t["sc"] + wenv * t["env"]          # noqa: E731
            fit, tf, tfl, within = [], [], [], []
            for t, a, lv in Tp:
                s_ = comb(t)
                fit += list(s_)
                tf += list(a)
                tfl += list(np.hypot(a, lv))
                within.append(_spearman(s_, np.hypot(a, lv)))
            mono_r = [_spearman(np.arange(len(deltas)), comb(t)) for t in Tm]
            seed_r = [comb(t)[:3].mean() / comb(t)[3] for t in Ts]
            row = dict(rho_tf=_spearman(fit, tf), rho_tf_level=_spearman(fit, tfl),
                       within=float(np.mean(within)), mono=float(np.mean(mono_r)),
                       seed_over_step=float(np.median(seed_r)))
            out[(name, wsc, wenv)] = row
            if verbose:
                print("  %-12s W_SC %-3g W_ENV %-4g  ruler %.3f / %.3f / within %.3f   monotone %.3f"
                      "   seed floor / 0.03 step %.2f" % (name, wsc, wenv, row["rho_tf"],
                                                          row["rho_tf_level"], row["within"],
                                                          row["mono"], row["seed_over_step"]),
                      flush=True)
    return out


if __name__ == "__main__":
    import sys
    if "--tune" in sys.argv:
        tune(variants={"current": {}, "floor 60": {"FLOOR_DB": 60.0},
                       "no smoothing": {"RES_SMOOTH": {}}, "no taper": {"TAPER_P": 0.0},
                       "onset 2": {"ONSET_BOOST": 2.0},
                       "5 sizes": {"RES": (256, 512, 1024, 2048, 4096)}})
    elif "--odin" in sys.argv:
        validate_odin(cache_dir=sys.argv[sys.argv.index("--cache") + 1] if "--cache" in sys.argv
                      else None)
    elif "--validate" in sys.argv:
        q = "--quick" in sys.argv
        validate(n_mono=15 if q else 60, n_pairs=12 if q else 60)
    else:
        print(__doc__)
