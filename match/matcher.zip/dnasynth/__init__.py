"""dnasynth — the DNA synth: a 40-gene continuous voice designed as a prior for sound matching.

    from dnasynth import GENES, neutral, render, render_batch     # the batch (training)
    from dnasynth import Voice4, Reverb                           # the device-side API
"""
from .core import (GENES, GENE_INDEX, N_GENES, Reverb, Voice4, lane_name, neutral,  # noqa: F401
                   render, render_batch)
