"""DASHBOARD GROW's voice as a fixed-slot genome (engines.get("dashx")): the network for the dashboard.

Volo (2026-10-04): "we have to focus on dashboard, do we have network for it". growx (slots_full.py)
holds GROW's pieces; a dashboard voice is those pieces UNDERNEATH and the skeleton (`dash`) the five
screens drive. This genome has a slot for every piece a dashboard voice keeps underneath -- two tones,
six harmonic sines (an organ's drawbars), three inharmonic ones, an FM pair, the four operators, two
noise bands, a string, a pitch envelope, three EQ peaks (formants), the wavetable, the morph, phase
distortion, the low-pass gate, the inserts, the kit's effects and five matrix cells -- and the 24
skeleton genes last, always on. What the skeleton stands for (the main filter, vibrato, tremolo, the
chorus, the room, the LFO on the cutoff or the pulse width) has NO slot: one sound, one genome.

THE PRIOR is the dashboard template catalogue (dash_templates.py): a family is a template, its
voice built from a random "design sound" (a note in the template's register, a random envelope and
spectrum) and every gene jittered around it -- the network learns the template space and its family
head WHICH template a sound is.

    from dnasynth.grow import slots_dash as SD
    G, fam = SD.sample(64, rng, return_family=True)
    mods = SD.to_mods(G[0])                  # pieces + the dash piece: blocks.document plays it
"""
from __future__ import annotations

import json
from dataclasses import dataclass

import numpy as np

from . import blocks as BL
from . import dash as DS
from . import kit as KT

KT.install()
DS.install()

HARMONICS = (1, 2, 3, 4, 6, 8)
OFF, ON = 0.25, 0.75
_PART = [s for s in BL.KINDS["partial"] if s[0] != "tune"]                 # level, A D S R
_FM = [s for s in BL.KINDS["fm"] if s[0] != "tune"]                        # mratio .. R
SLOT_SPECS = {"tone": list(BL.KINDS["tone"]), "hp": _PART,
              "ip": [("ratio", "exp", 0.25, 16.0, 0.5)] + _PART,
              "fm": [("cratio", "exp", 0.25, 16.0, 1.0 / 3.0)] + _FM}
UNDER = ("fm4", "noise", "pluck", "pitchenv", "eq", "src:osc.table", "src:osc.morph", "src:osc.pd",
         "flt:filter.lpg", "hp:filter.hp1", "ins:filter.comb", "ins:shaper.fold", "ins:shaper.crush",
         "fx:fx.delay", "fx:fx.ensemble", "fx:fx.hall", "fx:fx.reverb", "fx:fx.phaser")
CELLS = ("cell:lfo>pos", "cell:lfo>wave", "cell:env2>wave", "cell:env1>wave", "cell:env2>color")
for _k in UNDER + CELLS:
    SLOT_SPECS[_k] = list(BL.KINDS[_k])
SHORT = {"src:osc.table": "table", "src:osc.morph": "morph", "src:osc.pd": "pd", "flt:filter.lpg": "lpg",
         "hp:filter.hp1": "hpf", "ins:filter.comb": "comb", "ins:shaper.fold": "fold", "ins:shaper.crush": "crush",
         "fx:fx.delay": "delay", "fx:fx.ensemble": "ensemble", "fx:fx.hall": "hall", "fx:fx.reverb": "reverb",
         "fx:fx.phaser": "phaser", "cell:lfo>pos": "clpos", "cell:lfo>wave": "clwave", "cell:env2>wave": "c2wave",
         "cell:env1>wave": "c1wave", "cell:env2>color": "c2color"}
LAYOUT = [("tone", 2), ("hp", len(HARMONICS)), ("ip", 3), ("fm", 1), ("fm4", 1), ("noise", 2), ("pluck", 1),
          ("pitchenv", 1), ("eq", 3)] + [(k, 1) for k in UNDER[5:]] + [(k, 1) for k in CELLS]


@dataclass(frozen=True)
class Gene:
    index: int
    name: str
    neutral: float
    bipolar: bool
    steps: int
    slot: str
    key: str


def _gene(idx, name, spec, slot, key):
    _, law, a, b, neu = spec
    steps = len(a) if law == "step" else 0
    if law == "norm" and a.steps > 1:                     # a kit selector: plateau tokens
        steps = int(a.steps)
        neu = (min(steps - 1, int(round(neu * (steps - 1)))) + 0.5) / steps
    return Gene(idx, name, float(np.float32(neu)), law == "bip", steps, slot, key)


def _build():
    genes, slots = [], []
    for kind, count in LAYOUT:
        for j in range(count):
            sid = "%s%d" % (SHORT.get(kind, kind), HARMONICS[j] if kind == "hp" else j)
            base = len(genes)
            genes.append(Gene(base, sid + "_on", OFF, False, 2, sid, "on"))
            for s in SLOT_SPECS[kind]:
                genes.append(_gene(len(genes), "%s_%s" % (sid, s[0]), s, sid, s[0]))
            slots.append((sid, kind, j, base, len(genes)))
    dash0 = len(genes)
    for s in BL.KINDS["dash"]:                            # the skeleton: always on, no token
        genes.append(_gene(len(genes), "dash_%s" % s[0], s, "dash", s[0]))
    return genes, slots, dash0


GENES, SLOTS, DASH0 = _build()
N_GENES = len(GENES)
GENE_INDEX = {g.name: g.index for g in GENES}
NEUTRAL = np.array([g.neutral for g in GENES], np.float32)
SELECTORS = {g.name: g.steps for g in GENES if g.steps}
LEGS = tuple(g.name for g in GENES if g.key == "shape")
SLOT_INDEX = {sid: (kind, j, a, b) for sid, kind, j, a, b in SLOTS}


# ------------------------------------------------------------------------------- genome <-> voice

def to_mods(g):
    """genome -> the dashboard voice: the slots that are on (layout order), then the dash piece"""
    g = np.asarray(g, np.float64)
    out = []
    for sid, kind, j, a, b in SLOTS:
        if g[a] < 0.5:
            continue
        v = g[a + 1:b]
        if kind == "hp":
            out.append(BL.Module("partial", np.concatenate([[0.5], v]), float(HARMONICS[j])))
        elif kind == "ip":
            out.append(BL.Module("partial", np.concatenate([[0.5], v[1:]]), float(BL.decode(SLOT_SPECS["ip"][0], v[0]))))
        elif kind == "fm":
            out.append(BL.Module("fm", np.concatenate([[0.5], v[1:]]), float(BL.decode(SLOT_SPECS["fm"][0], v[0]))))
        else:
            out.append(BL.Module(kind, v.copy()))
    if not any(BL.is_source(m.kind) for m in out):
        out.insert(0, BL.Module.new("partial", level=0.0))          # silent, valid
    out.append(BL.Module("dash", g[DASH0:].copy()))
    return out


def from_mods(mods):
    """a dashboard voice -> its genome (canonical): pieces into free slots of their kind (a partial
    within 1.2 % of a harmonic slot's number takes it, others the inharmonic slots), the dash piece's
    genes last; a piece with no slot -- or one the skeleton stands for -- is DROPPED"""
    g = NEUTRAL.astype(np.float64).copy()
    used = set()

    def free(kind):
        for sid, k, j, a, b in SLOTS:
            if k == kind and sid not in used:
                return sid, a, b
        return None
    for m in mods:
        if m.kind == "dash":
            g[DASH0:] = m.g
            continue
        p = m.p()
        if m.kind == "partial":
            r = m.ratio * 2.0 ** (p["tune"] / 1200.0)
            k = int(round(r))
            sid = "hp%d" % k
            if k in HARMONICS and abs(r / k - 1) < 0.012 and sid not in used:
                a, b = SLOT_INDEX[sid][2:]
                g[a], g[a + 1:b] = ON, m.g[1:]
                used.add(sid)
                continue
            f = free("ip")
            if f:
                sid, a, b = f
                g[a], g[a + 1] = ON, BL.encode(SLOT_SPECS["ip"][0], r)
                g[a + 2:b] = m.g[1:]
                used.add(sid)
        elif m.kind == "fm":
            f = free("fm")
            if f:
                sid, a, b = f
                g[a], g[a + 1] = ON, BL.encode(SLOT_SPECS["fm"][0], m.ratio * 2.0 ** (p["tune"] / 1200.0))
                g[a + 2:b] = m.g[1:]
                used.add(sid)
        elif m.kind in SLOT_SPECS:
            f = free(m.kind)
            if f:
                sid, a, b = f
                g[a], g[a + 1:b] = ON, m.g
                used.add(sid)
    return canonical(g[None])[0]


def canonical(G):
    """[B, N]: off slots at neutral, tokens at ON / OFF, interchangeable slots sorted (tones by
    detune, inharmonic sines and noise bands by their frequency, EQ peaks by centre), selectors on
    their plateau centres, every gene in 0..1"""
    G = np.clip(np.atleast_2d(np.asarray(G, np.float64)).copy(), 0.0, 1.0)
    keys = {"ip": 1, "tone": 1 + 3, "noise": 1 + 1, "eq": 1}          # the sort gene's offset in the slot
    for kind, count in LAYOUT:
        rows = [SLOT_INDEX[sid][2:] for sid, k, j, a, b in SLOTS if k == kind]
        for a, b in rows:
            on = G[:, a] >= 0.5
            G[:, a] = np.where(on, ON, OFF)
            G[~on, a + 1:b] = NEUTRAL[a + 1:b]
        if kind in keys and count > 1:
            off = keys[kind]
            blk = np.stack([G[:, a:b] for a, b in rows], 1)
            k = np.where(blk[:, :, 0] >= 0.5, blk[:, :, off], 2.0)
            o = np.argsort(k, axis=1, kind="stable")
            blk = np.take_along_axis(blk, o[:, :, None], 1)
            for i, (a, b) in enumerate(rows):
                G[:, a:b] = blk[:, i]
    for gn in GENES:
        if gn.steps and gn.key != "on":
            G[:, gn.index] = (np.minimum(np.floor(G[:, gn.index] * gn.steps), gn.steps - 1) + 0.5) / gn.steps
    return G.astype(np.float32)


def active_mask(G):
    """[B, N] bool: a slot's genes are heard when it is on (with its token); the skeleton always"""
    G = np.atleast_2d(np.asarray(G))
    M = np.zeros(G.shape, bool)
    for sid, kind, j, a, b in SLOTS:
        M[:, a:b] = (G[:, a] >= 0.5)[:, None]
    M[:, DASH0:] = True
    return M


# ------------------------------------------------------------------------------- the prior

class DesignSound:
    """a random sound a template is built for: what dash_templates reads off an analysis"""

    def __init__(self, rng, lo, hi, held=None):
        self.f0 = float(440.0 * 2 ** ((rng.uniform(lo, hi) - 69) / 12))
        held = rng.random() < 0.6 if held is None else held
        self.attack = float(np.exp(rng.uniform(np.log(0.002), np.log(0.6 if held else 0.02))))
        self.decay = float(np.exp(rng.uniform(np.log(0.08), np.log(4.0))))
        self.sustain = float(rng.uniform(0.3, 1.0)) if held else float(rng.uniform(0.0, 0.25))
        self.tail = float(np.exp(rng.uniform(np.log(0.05), np.log(3.0))))
        self.release = float(np.clip(2 * self.tail, 0.01, 12.0))
        self.centroid = float(self.f0 * np.exp(rng.uniform(np.log(1.5), np.log(12.0))))
        self.vib = float(rng.choice([0.0, 0.0, 12.0]))
        self.drop = float(rng.uniform(4, 18)) if rng.random() < 0.5 else 0.0
        self.drop_t = float(np.exp(rng.uniform(np.log(0.01), np.log(0.15))))
        self.gate, self.dur = 1.2, 2.5
        self.top = 0.0
        ks = np.array([1, 2, 3, 4, 5, 6, 8], float)
        tilt = rng.uniform(3, 12)
        lv = -tilt * np.log2(ks) - rng.uniform(0, 6, len(ks))
        self.pk = {"early": (ks * self.f0, lv), "held": (ks * self.f0, lv - 3.0)}
        self.noise = {"early": np.full(8, -60.0)}
        self.darkening = float(rng.uniform(0, 1.2))

    def partial_decay(self, fq):
        return 0.001, self.decay, self.sustain


REGISTER = {"bass": (28, 52), "lead": (55, 84), "pad": (45, 72), "brass": (48, 72), "keys": (45, 80),
            "bell": (55, 90), "pluck": (40, 80), "drum": (30, 60), "noise": (40, 80)}


def _templates():
    from . import dash_templates as DT
    return [b for b, _ in DT.CATALOGUE]


FAMILIES = None                                          # the templates' names, filled on first use
# THE WIDE PRIOR (2026-10-05): trained on the 23 templates alone, the network learned them (best of 8
# 3.12 on its own voices, the template 97.7 % right) and on the dev set's real sounds beat the default
# starts by little (one-stage screening, one code: median fit 4.39 against 4.47; growx, whose prior adds
# extras to every family, 4.15) -- so every template voice gets growx-style EXTRAS and part of its
# skeleton re-drawn, a FREE family adds dashboard voices no template describes, and the jitter is wider
WIDE = True
JITTER = 0.10


def _families():
    global FAMILIES
    if FAMILIES is None:
        FAMILIES = tuple(b.__name__ for b in _templates()) + (("free",) if WIDE else ())
    return FAMILIES


def _rand_slot(rng, g, sid):
    """slot sid on, its genes uniform over their travel (a selector on a random plateau)"""
    g[GENE_INDEX[sid + "_on"]] = ON
    a, b = SLOT_INDEX[sid][2:]
    for gn in GENES[a + 1:b]:
        g[gn.index] = (rng.integers(gn.steps) + 0.5) / gn.steps if gn.steps else rng.uniform(0, 1)


def _free_slot(g, kind):
    for sid, k, j, a, b in SLOTS:
        if k == kind and g[a] < 0.5:
            return sid
    return None


_DASH_NAMES = [s[0] for s in BL.KINDS["dash"]]


def _d(key):
    return DASH0 + _DASH_NAMES.index(key)


def _maybe(rng, g, p, kind, level=(0.1, 0.5)):
    if rng.random() < p:
        sid = _free_slot(g, kind)
        if sid:
            _rand_slot(rng, g, sid)
            if sid + "_level" in GENE_INDEX:
                g[GENE_INDEX[sid + "_level"]] = rng.uniform(*level)


def _skeleton(rng, g, p):
    """the skeleton's parts re-drawn, each with probability ~p: the filter's model, mode, cutoff and
    resonance, ENV 2, the LFO's targets and rate, the FX slot"""
    if rng.random() < p:
        g[_d("model")] = rng.uniform()
        g[_d("mode")] = 0.5 / 4 if rng.random() < 0.7 else rng.uniform()
    if rng.random() < p:
        g[_d("cut")], g[_d("res")] = rng.uniform(0.3, 1.0), rng.uniform(0.0, 0.8)
    if rng.random() < p:
        g[_d("fenv")] = np.clip(0.5 + rng.normal(0.15, 0.2), 0, 1)
        for k in ("f_att", "f_dec", "f_sus", "f_rel"):
            g[_d(k)] = rng.uniform(0, 1)
    for k in ("lfo_pitch", "lfo_cut", "lfo_pw", "lfo_amp"):
        if rng.random() < p / 3:
            g[_d(k)] = rng.uniform(0.05, 0.6)
            g[_d("lfo_rate")] = rng.uniform(0.1, 0.9)
            g[_d("lfo_shape")] = rng.uniform()
    if rng.random() < p:
        g[_d("fx_type")] = rng.uniform()
        g[_d("fx_rate")], g[_d("fx_depth")] = rng.uniform(), rng.uniform(0.1, 0.8)


def _extras(rng, g):
    """growx's habit on any family: an extra noise band, inharmonic sine, drawbar, FM pair or EQ peak,
    an insert, an effect underneath, a cell -- and the skeleton re-drawn in part"""
    _maybe(rng, g, 0.2, "noise")
    _maybe(rng, g, 0.15, "ip")
    _maybe(rng, g, 0.1, "hp")
    _maybe(rng, g, 0.1, "fm")
    _maybe(rng, g, 0.2, "eq", (0.0, 1.0))
    for kind, p in (("hp:filter.hp1", 0.08), ("ins:filter.comb", 0.04), ("ins:shaper.fold", 0.05),
                    ("ins:shaper.crush", 0.03), ("fx:fx.delay", 0.05), ("fx:fx.ensemble", 0.05), ("fx:fx.hall", 0.06),
                    ("fx:fx.reverb", 0.05), ("fx:fx.phaser", 0.04)) + tuple((c, 0.04) for c in CELLS):
        _maybe(rng, g, p, kind, (0.0, 1.0))
    _skeleton(rng, g, 0.3)


def _free(rng):
    """a dashboard voice no template describes: one to three sources of any kind, random skeleton"""
    g = NEUTRAL.astype(np.float64).copy()
    g[DASH0:] = DS.new().g
    for _ in range(int(rng.integers(1, 4))):
        sid = _free_slot(g, str(rng.choice(["tone", "tone", "hp", "ip", "fm", "fm4", "noise", "pluck",
                                            "src:osc.table", "src:osc.morph", "src:osc.pd"])))
        if sid:
            _rand_slot(rng, g, sid)
            if sid + "_level" in GENE_INDEX:
                g[GENE_INDEX[sid + "_level"]] = rng.uniform(0.4, 1.0)
    _extras(rng, g)
    _skeleton(rng, g, 0.6)
    return canonical(g[None])[0]


def _one(rng, f, jitter=None):
    """one random dashboard voice of template f (or the FREE family) -> genome"""
    jitter = JITTER if jitter is None else jitter
    if WIDE and f == len(_templates()):
        return _free(rng)
    from . import dash_templates as DT
    build = _templates()[f]
    fam = {"bass_sub": "bass", "bass_saw": "bass", "bass_fm": "bass", "bass_reese": "bass", "acid": "bass",
           "lead_saw": "lead", "lead_square": "lead", "lead_whistle": "lead", "pad_ensemble": "pad", "pad_pwm": "pad",
           "pad_wavetable": "pad", "choir": "pad", "brass": "brass", "epiano": "keys", "fm_bell": "bell",
           "organ": "keys", "mallet": "bell", "synth_pluck": "pluck", "string_pluck": "pluck", "kick": "drum",
           "snare": "drum", "hat": "drum", "wind": "noise"}.get(build.__name__, "pad")
    lo, hi = REGISTER[fam]
    held = None if fam in ("bass", "lead", "keys", "noise") else fam in ("pad", "brass")
    T = DesignSound(rng, lo, hi, held)
    F = DT.features(T) if hasattr(T, "noise") else {}
    F.update(vib=T.vib >= 6.0, long_tail=T.tail >= 0.6, drop=T.drop >= 2.0)
    voice = build(T, F)
    g = from_mods(voice).astype(np.float64)
    act = active_mask(g[None])[0]
    act[[i for i, gn in enumerate(GENES) if gn.key == "on"]] = False
    noise = rng.normal(0, jitter, N_GENES)
    g = np.where(act, np.clip(g + noise, 0, 1), g)
    if WIDE:
        _extras(rng, g)
    return canonical(g[None])[0]


FREE_P = 0.25                                            # the wide prior: a quarter of voices FREE


def sample(n, rng, return_family=False):
    nf = len(_families())
    fam = rng.integers(0, nf - 1 if WIDE else nf, n)
    if WIDE:
        fam = np.where(rng.random(n) < FREE_P, nf - 1, fam)
    G = np.stack([_one(rng, int(f)) for f in fam]).astype(np.float32)
    return (G, fam.astype(np.int64)) if return_family else G


def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1, threads=4):
    """B genomes -> float32[B, n], one note each (midi a scalar or one per genome), the device's path"""
    from ..graph import lib
    G = np.atleast_2d(np.asarray(G, np.float32))
    mm = np.broadcast_to(np.asarray(midi, np.float64), (len(G),))
    ss = (np.broadcast_to(np.asarray(seed, np.int64), (len(G),)) + np.arange(len(G))) & 0x7FFFFFFF
    docs, keys = [], []
    for g, m, s in zip(G, mm, ss):
        k, c = BL.key_cents(m)
        docs.append(json.dumps(BL.document(to_mods(g), cents=c, seed=int(s))).encode())
        keys.append(k)
    return lib.render_batch(docs, keys, vel, gate_s, secs, sr, threads)
