"""DASH TUNE: match a sound by turning an EXISTING dashboard synth's knobs (2026-10-06).

Volo: "add a third option: match on some existing synth, for now without network -- select a synth,
it must be a dashboard synth, so the algo can tune only the params from the dashboard, and
modulation (exclude the sensors, we don't need to tune them)".

The synth's GRAPH stays as it is. What moves:

  * its KNOBS -- every mod.macro the document's `dashboard` section names (SYNTH's knobs, ENV 1,
    ENV 2, FILTER, LFO, FX): the macro's `value`, 0..1 (a stepped macro -- a selector, a toggle --
    steps through its values; the engine quantises);
  * its MODULATION -- the matrix depth from each of the dashboard's own sources, ENV 1, ENV 2 and
    LFO, into each CONTINUOUS knob (selectors are never matrix destinations), -1..+1; a depth within
    DEAD of 0 is no cell.

Not moved: the four sensors (COMPASS, ACCEL, ROTATION, R-REEL -- their cells stay as the patch has
them), VELOCITY (one note at one velocity cannot tell a velocity depth from the knob's own value),
and everything not on the dashboard.

THE SEARCH (`budget` renders; the fitness GROW uses: the note from its onset, free gain):
  1. the patch as saved and each of its presets (a preset is an overlay of params and cells), scored;
  2. the best START_K starts: the knobs tuned, KNOB_FRAC of the budget each ((mu+lambda) GA, GROW's);
  3. the best one's MODULATION: every (knob, source) route probed at +-MOD_PROBE, the MOD_K best
     paying ones kept, then knobs and those depths tuned together (MOD_FRAC);
  4. a POLISH of the most sensitive values (GROW's: two stages, each its K most sensitive);
  5. a SETTLE: every moved value tried back at the start's, kept back while the fitness stays within
     SETTLE_TOL -- a knob the note cannot tell (a release it never reaches) stays the preset's.
A candidate whose FREE-running LFO reaches the sound is heard as LIVE_PHASES key presses (the LFO
caught at as many places, _live_variants) and scored by the worst of them: on the board the LFO runs
on between notes, so a depth that fits one phase only is a different sound on every press.
The alternatives B, C are the other starts after step 2. A chord is played as a chord (GROW's
chord mode). The result documents keep the graph, presets and dashboard; their knobs and cells are
the match, and a "Matched" preset -- the patch's new default -- states them.

numpy only: it runs in the browser too (pchkraft-synth web/match: the third builder)."""
from __future__ import annotations

import copy
import json
import time

import numpy as np

SR = 44100
TUNED_SOURCES = ("ENV 1", "ENV 2", "LFO")
SENSORS = ("COMPASS", "ACCEL", "ROTATION", "R-REEL")
DEAD = 0.03            # |depth| under this is no cell
START_K = 3            # starts tuned (the alternatives)
KNOB_FRAC = 0.12       # each start's knob tuning, a share of the budget
MOD_PROBE = 0.4        # a route's probes: this depth up and down
MOD_K = 6              # routes kept after the probes
MOD_FRAC = 0.3         # knobs + kept depths tuned together
POLISH_K = 16          # the polish's values at once
LIVE_PHASES = 3        # a FREE-running LFO in play: a candidate is heard as this many key presses (_live_variants)
SETTLE_FRAC = 0.12     # the budget kept for the settle: moved values the note cannot tell go back
SETTLE_TOL = 0.03      # ... when the fitness is no more than this worse in all (GROW's PRUNE_TOL)
VEL = 100 / 127
POOL = None            # (target(audio, cfg_json), score(docs_json, key, vel, gate, secs, sr, n)) in the browser


# ------------------------------------------------------------------------- the patch's space

def _nodes(doc):
    return {n["id"]: n for n in doc.get("nodes", [])}


def knobs(doc):
    """the dashboard's knob macros, in its screens' order, each once -> [(id, steps)]"""
    d = doc.get("dashboard") or {}
    ids = [k.get("macro") for k in ((d.get("synth") or {}).get("knobs") or []) if isinstance(k, dict)]
    for sec, keys in (("env1", ("attack", "decay", "sustain", "release")),
                      ("env2", ("attack", "decay", "sustain", "release")),
                      ("filter", ("type", "cutoff", "tune", "fm")), ("lfo", ("shape", "hz", "sync")),
                      ("fx", ("type", "rate", "depth", "sync"))):
        s = d.get(sec) or {}
        ids += [s.get(k) for k in keys]
    N = _nodes(doc)
    out, seen = [], set()
    for i in ids:
        if not i or i in seen or i not in N or N[i].get("type") != "mod.macro":
            continue
        seen.add(i)
        try:
            steps = int(float(N[i].get("params", {}).get("steps", 0) or 0))
        except (TypeError, ValueError):
            steps = 0
        out.append((i, steps))
    return out


def sources(doc):
    """the matrix's tuned sources (ENV 1, ENV 2, LFO by label) -> [(label, from)]"""
    out = []
    for s in ((doc.get("matrix") or {}).get("sources") or []):
        if s.get("label") in TUNED_SOURCES:
            out.append((s["label"], list(s["from"])))
    return out


class Space:
    """the knobs and the routes of one patch; a GENOME is their values in 0..1 (a depth d is
    (d + 1) / 2)"""

    def __init__(self, doc, mod=True):
        self.doc = doc
        self.knobs = knobs(doc)
        self.sources = sources(doc) if mod else []
        self.dests = [i for i, st in self.knobs if st < 2]
        self.routes = [(d, lab, frm) for d in self.dests for lab, frm in self.sources]
        self.n_knobs = len(self.knobs)
        self.n = self.n_knobs + len(self.routes)

    def names(self):
        return [k for k, _ in self.knobs] + ["%s > %s" % (lab, d) for d, lab, _ in self.routes]

    def genome(self, state):
        """a start state (a document with a preset applied) -> its genome"""
        N = _nodes(state)
        g = np.zeros(self.n)
        for j, (i, _) in enumerate(self.knobs):
            v = N[i].get("params", {}).get("value")
            g[j] = float(np.clip(_default_value() if v is None else float(v), 0.0, 1.0))
        cells = (state.get("matrix") or {}).get("cells") or {}
        for j, (d, lab, frm) in enumerate(self.routes):
            a = 0.0
            for e in ((cells.get(d) or {}).get("value") or []):
                if list(e.get("from", [])) == frm:
                    a = float(e.get("amount", 0.0))
            g[self.n_knobs + j] = (np.clip(a, -1.0, 1.0) + 1.0) / 2.0
        return g

    def apply(self, state, g, keep_presets=False):
        """a start state with genome g -> a document (presets dropped for rendering unless kept)"""
        d = copy.deepcopy(state)
        if not keep_presets:
            d.pop("presets", None)
        N = _nodes(d)
        for j, (i, _) in enumerate(self.knobs):
            N[i].setdefault("params", {})["value"] = float(round(float(g[j]), 6))
        if self.routes:
            mx = d.setdefault("matrix", {})
            cells = mx.setdefault("cells", {})
            order = [list(s["from"]) for s in (mx.get("sources") or [])]
            tuned = [frm for _, frm in self.sources]
            for dest in self.dests:
                old = [e for e in ((cells.get(dest) or {}).get("value") or []) if list(e.get("from", [])) not in tuned]
                new = []
                for j, (dd, lab, frm) in enumerate(self.routes):
                    if dd != dest:
                        continue
                    a = 2.0 * float(g[self.n_knobs + j]) - 1.0
                    if abs(a) >= DEAD:
                        new.append({"from": list(frm), "amount": float(round(a, 6))})
                rows = sorted(old + new, key=lambda e: order.index(list(e["from"])) if list(e["from"]) in order else 99)
                if rows or dest in cells:
                    cells[dest] = {"value": rows}
        return d


def _default_value():
    try:
        from . import kit as KT
        return float(KT.param("mod.macro", "value").default)
    except Exception:                                # noqa: BLE001 -- no registry: the macro's own 0
        return 0.0


def starts(doc):
    """the patch as saved and each preset applied (params + cells: the format's overlay rules)
    -> [(name, state)]"""
    out = [("as saved", copy.deepcopy(doc))]
    for p in doc.get("presets") or []:
        if p.get("default"):
            continue                                 # the saved graph already is the default
        s = copy.deepcopy(doc)
        N = _nodes(s)
        for nid, params in (p.get("params") or {}).items():
            if nid in N:
                N[nid].setdefault("params", {}).update(params)
        if p.get("matrix"):
            cells = s.setdefault("matrix", {}).setdefault("cells", {})
            for dest, kv in p["matrix"].items():
                cells[dest] = copy.deepcopy(kv)
        out.append((p.get("name", "preset"), s))
    return out


# ------------------------------------------------------------------------- rendering + scoring

def _free_lfos(doc):
    """the global LFOs on trig mode `free` (the lfo block's default) whose output reaches the sound -- a
    matrix cell or a mod link with a depth -> [node id]. The board's LFO keeps running between notes,
    so each key press catches it somewhere else; a render starts it at one place."""
    N = _nodes(doc)
    free = {i for i, n in N.items() if n.get("type") == "lfo"
            and str((n.get("params") or {}).get("mode", "free")).lower() in ("free", "0", "0.0")}
    if not free:
        return []
    live = set()
    for cell in ((doc.get("matrix") or {}).get("cells") or {}).values():
        for e in ((cell or {}).get("value") or []):
            frm = list(e.get("from") or [])
            if frm and frm[0] in free and abs(float(e.get("amount", 0.0) or 0.0)) >= DEAD:
                live.add(frm[0])
    for m in doc.get("mod") or []:
        frm, rng = list(m.get("from") or []), m.get("range")
        if frm and frm[0] in free and float(m.get("amount", 1.0) or 0.0) != 0.0 \
                and not (isinstance(rng, list) and len(rng) == 2 and rng[0] == rng[1]):
            live.add(frm[0])
    return sorted(live)


def _live_variants(doc, k=LIVE_PHASES):
    """the document as k key presses on a running instrument hear it: each free LFO in play restarted
    at phase j/k (a copy set to `retrig` at that phase -- the block's own way of placing the cycle at a
    note) and the random state moved (the seed: a sample+hold or drift LFO draws anew, as on each
    press). No free LFO in play: the document itself, one render.

    Why (2026-10-06, Volo: "each key press produces a different sound"): every render starts the LFO at
    the same place, so a slow LFO with depth was a hidden per-press offset the search fitted once --
    a Juno pad matched at 7.33 read 10.4-11.4 on every later press of the key on the board, a TB-303
    at 4.43 read 7.0 on two presses of six (eval/reach/webparity/liveplay.mjs + score_live.py). Heard
    at k phases, a candidate is scored by what the player gets, and only LFO depths that sound right
    wherever the wave is caught keep paying."""
    lfos = _free_lfos(doc)
    if not lfos:
        return [doc]
    seed = int(doc.get("seed", 0) or 0)
    out = []
    for j in range(k):
        v = copy.deepcopy(doc)
        N = _nodes(v)
        for i in lfos:
            p = N[i].setdefault("params", {})
            p["mode"] = "retrig"
            p["phase"] = round(j / k, 6)
        if j:
            v["seed"] = (seed + 7919 * j) % (2 ** 32)
        out.append(v)
    return out


def _without_lfo(state, space):
    """the state with every TUNED source's cells from a free LFO dropped (the sensors' and the graph's
    own links stay)"""
    d = copy.deepcopy(state)
    free = set(_free_lfos(d))
    tuned = [frm for _, frm in space.sources]
    for cell in ((d.get("matrix") or {}).get("cells") or {}).values():
        if cell and cell.get("value"):
            cell["value"] = [e for e in cell["value"]
                             if not (list(e.get("from") or []) in tuned and (e.get("from") or [""])[0] in free)]
    return d


class DocEvaluator:
    """documents -> distances against the target (GROW's fitness), counting renders; a chord is
    played as one (every key, the voices the patch has)"""

    def __init__(self, T, midi, gate_s, n, chord=None, threads=4):
        self.T, self.gate, self.n_s, self.threads = T, float(gate_s), int(n), threads
        self.key = int(round(float(midi)))            # a hand-made patch has no fine tune: the nearest key
        self.keys = [int(round(float(m))) for m in chord] if chord else None
        self.n = 0
        self.t_render = self.t_score = 0.0           # seconds spent rendering / in the fitness (GROW's timing line)
        if POOL is not None:
            mod = "both" if (T.hold and T.mod_term) else ("hold" if T.hold else bool(T.mod_term))
            POOL[0](np.asarray(T.audio, np.float32),
                    json.dumps(dict(sr=T.sr, free_gain=T.free_gain, gain_cost=T.gain_cost, mod=mod)))

    def score(self, docs):
        """each document's distance -- a free LFO in play: the WORST of its key presses
        (_live_variants). Not the mean: a mean lets a slow LFO through that helps some presses and
        hurts others (a Juno pad's LFO into ENV 1's attack: 8.2..9.5 press to press at a mean of 8.96),
        which is the very complaint; the worst keeps only depths that sound right wherever the wave
        is caught -- a vibrato or a PWM fast enough to cycle within the note"""
        groups = [_live_variants(d) for d in docs]
        flat = [v for g in groups for v in g]
        if len(flat) == len(docs):
            return self._score(flat)
        s = self._score(flat)
        out, i = np.empty(len(docs)), 0
        for j, g in enumerate(groups):
            out[j] = float(np.max(s[i:i + len(g)]))  # the WORST press: every press must be the match
            i += len(g)
        return out

    def _score(self, docs):
        from .. import fitness as FT
        from .build import SILENT
        t0 = time.perf_counter()
        texts = [json.dumps(d) for d in docs]
        self.n += len(texts)
        if POOL is not None:
            key = json.dumps(self.keys) if self.keys else float(self.key)
            t1 = time.perf_counter()
            r = POOL[1](json.dumps(texts), key, VEL, self.gate, self.n_s / SR, float(SR), self.n_s)
            t2 = time.perf_counter()
            self.t_render += (t1 - t0) + 0.5 * (t2 - t1)     # the pool renders AND scores: half each
            self.t_score += 0.5 * (t2 - t1)
            return np.array(r.to_py() if hasattr(r, "to_py") else r, np.float64)
        Y = self.render(texts)
        t1 = time.perf_counter()
        self.t_render += t1 - t0
        ok = np.abs(Y).max(axis=1) > 1e-7
        s = np.full(len(texts), SILENT)
        if ok.any():
            s[ok] = np.asarray(self.T.score(np.stack([FT.normalize(Y[i]) for i in np.flatnonzero(ok)])), np.float64)
        self.t_score += time.perf_counter() - t1
        return s

    def render(self, texts):
        from ..graph import lib as L
        Y = L.render_batch([t.encode() for t in texts], self.key, VEL, self.gate, self.n_s / SR, float(SR),
                           self.threads, chord=self.keys)
        return Y[:, :self.n_s]

    def note(self, doc, secs):
        """one note (or the chord) of a document, as the view plays it"""
        from ..graph import lib as L
        return L.render_note(json.dumps(doc).encode(), self.keys if self.keys else self.key, VEL, self.gate, secs)


# ------------------------------------------------------------------------- the search

def _ga(ev, space, state, v0, idx, n_renders, rng, pop=12, sigma=0.12, steps_sigma=0.3):
    """GROW's (mu+lambda) GA (build.tune) over genome indices idx -> (genome, distance); a stepped
    knob mutates wider (its values are steps apart)"""
    idx = np.asarray(idx)
    if idx.size == 0 or n_renders < pop:
        return v0, float(ev.score([space.apply(state, v0)])[0])
    wide = np.array([steps_sigma if (i < space.n_knobs and space.knobs[i][1] >= 2) else 1.0 for i in idx])
    P = [v0]
    while len(P) < pop:
        c = v0.copy()
        c[idx] = np.clip(c[idx] + rng.normal(0, 1.0, len(idx)) * np.where(wide < 1.0, wide, sigma), 0, 1)
        P.append(c)
    n0 = ev.n
    F = list(ev.score([space.apply(state, p) for p in P]))
    per = max(1.0, (ev.n - n0) / len(P))             # renders a candidate costs (a free LFO in play: several)
    gen = 0
    while gen == 0 or ev.n - n0 + per * pop <= n_renders:     # spent by RENDERS: one render a candidate is GROW's count
        sg = max(0.03, sigma * 0.85 ** gen)
        kids = []
        for _ in range(pop):
            a, b = (min(rng.choice(len(P), 2, replace=False), key=lambda i: F[i]) for _ in range(2))
            c = P[a].copy()
            x = rng.random(len(idx)) < 0.5
            c[idx[x]] = P[b][idx[x]]
            m = rng.random(len(idx)) < max(1.0 / len(idx), 0.25)
            if not m.any():
                m[rng.integers(len(idx))] = True
            step = np.where(wide < 1.0, wide, sg)[m]
            c[idx[m]] += rng.normal(0, 1.0, int(m.sum())) * step
            kids.append(np.clip(c, 0, 1))
        m0 = ev.n
        Fk = ev.score([space.apply(state, k) for k in kids])
        per = max(1.0, (ev.n - m0) / len(kids))
        gen += 1
        P, F = P + kids, F + list(Fk)
        keep, seen = [], set()
        for i in np.argsort(F):
            h = np.round(P[i][idx], 4).tobytes()
            if h not in seen:
                seen.add(h)
                keep.append(i)
            if len(keep) == pop:
                break
        P, F = [P[i] for i in keep], [F[i] for i in keep]
    b = int(np.argmin(F))
    return P[b], float(F[b])


def _sensitivity(ev, space, state, v, active, step=0.08):
    cand, who = [], []
    for i in active:
        for d in (-step, step):
            u = v.copy()
            u[i] = np.clip(u[i] + d, 0, 1)
            if u[i] != v[i]:
                cand.append(u)
                who.append(i)
    s0 = float(ev.score([space.apply(state, v)])[0])
    s = ev.score([space.apply(state, u) for u in cand]) if cand else []
    sens = np.zeros(space.n)
    best = (s0, v)
    for i, si, u in zip(who, s, cand):
        sens[i] = max(sens[i], abs(si - s0))
        if si < best[0]:
            best = (float(si), u)
    return sens, best


def _active(space, g):
    """the genome indices worth searching: every knob, and the routes that are on"""
    on = [space.n_knobs + j for j in range(len(space.routes)) if abs(2 * g[space.n_knobs + j] - 1) >= DEAD]
    return list(range(space.n_knobs)) + on


def dash_tune(audio, sr, midi, gate_s, doc, budget=5000, rng=None, chord=None, progress=None, mod=True,
              presets=True, threads=4):
    """an existing dashboard synth tuned to a note -> dict like build.grow's: alternatives (play_doc,
    score, family = the start, kinds = what moved), renders, onset, timing, chord"""
    from .. import fitness as FT
    from .. import match as MA
    t0 = time.perf_counter()
    rng = rng if rng is not None else np.random.default_rng(0)
    log_lines = []

    def log(s, frac=None):
        log_lines.append(s)
        if progress is not None:
            progress(s, min(1.0, ev.n / budget) if frac is None and "ev" in scope else (frac or 0.0))
    scope = {}
    if sr != SR:
        raise ValueError("44.1 kHz audio expected (match.to_mono_44k)")
    space = Space(doc, mod=mod)
    if not space.knobs:
        raise ValueError("this patch has no dashboard knobs to turn (a dashboard synth is needed)")
    x = np.asarray(audio, np.float32)
    onset = MA.estimate_onset(x)
    x = x[onset:]
    xt = FT.normalize(x)
    T = FT.Target(xt, SR, free_gain=True, gain_cost=MA.GAIN_COST, mod=MA.MOD)
    chord = [float(m) for m in chord] if chord is not None and len(chord) > 1 else None
    ev = DocEvaluator(T, midi, gate_s, len(xt), chord, threads)
    scope["ev"] = ev
    cents = 100 * (float(midi) - round(float(midi)))
    log("tuning %s: %d knobs%s; %s%s" % (
        doc.get("name", "the patch"), space.n_knobs,
        (", %d modulation routes (%s into the knobs; sensors untouched)" % (len(space.routes), ", ".join(
            lab for lab, _ in space.sources))) if space.routes else ", no modulation",
        ("chord " + " ".join("%.2f" % m for m in chord)) if chord else "MIDI %.2f" % float(midi),
        (" (played on the nearest key: %+.0f cents off)" % cents) if abs(cents) >= 5 else ""))
    if mod and any(lab == "LFO" for lab, _ in space.sources):
        N0 = _nodes(doc)
        if any(N0.get(frm[0], {}).get("type") == "lfo" and str((N0[frm[0]].get("params") or {}).get("mode", "free")).lower()
               in ("free", "0", "0.0") for lab, frm in space.sources if lab == "LFO"):
            log("the LFO free-runs on this synth: a candidate with LFO depth is heard as %d key presses "
                "(the LFO caught at %d places), its distance the worst of them" % (LIVE_PHASES, LIVE_PHASES))
    # 1. the starts -- each with a free LFO in play also WITHOUT its tuned LFO depths: the cheap path
    #    (one render a candidate); step 3 adds back an LFO depth that pays at every phase
    st = starts(doc) if presets else starts(dict(doc, presets=[]))
    st = st + [(nm + " no LFO", _without_lfo(s0, space)) for nm, s0 in st if _free_lfos(s0)]
    G = [space.genome(s) for _, s in st]
    S = ev.score([space.apply(s, g) for (_, s), g in zip(st, G)])
    order = list(np.argsort(S))
    for i in order[:min(len(order), 8)]:
        log("start %-22s %.3f" % (st[i][0][:22], S[i]))
    if len(order) > 8:
        n_nolfo = sum(1 for nm, _ in st if nm.endswith(" no LFO"))
        log("(%d starts scored: the patch as saved, %d presets%s; the best 8 above)" % (
            len(st), len(st) - 1 - n_nolfo, (" and %d of them without their LFO depth" % n_nolfo) if n_nolfo else ""))
    # 2. the knobs of the best starts
    tuned = []
    n_starts = min(START_K, len(order))
    for i in order[:START_K]:                        # fewer starts: each gets their share of the stage
        name, s = st[i]
        v, f = _ga(ev, space, s, G[i], list(range(space.n_knobs)), int(KNOB_FRAC * START_K * budget / n_starts), rng)
        f = min(f, float(S[i]))
        tuned.append((f, name, s, v))
        log("knobs from %-22s %.3f -> %.3f" % (name[:22], S[i], f))
    tuned.sort(key=lambda q: q[0])
    best_f, best_name, best_s, best_v = tuned[0]
    # 3. modulation: probe every route, keep the paying ones, tune with the knobs
    if space.routes and ev.n < budget * 0.85:
        cand, who = [], []
        for j in range(len(space.routes)):
            k = space.n_knobs + j
            for a in (MOD_PROBE, -MOD_PROBE):
                u = best_v.copy()
                u[k] = (np.clip(2 * u[k] - 1 + a, -1, 1) + 1) / 2
                cand.append(u)
                who.append((j, a))
        Fc = ev.score([space.apply(best_s, u) for u in cand])
        gain = {}
        for (j, a), f in zip(who, Fc):
            gain[j] = max(gain.get(j, 0.0), best_f - float(f))
        keep = [j for j in sorted(gain, key=lambda j: -gain[j]) if gain[j] > 0][:MOD_K]
        if keep:
            log("modulation: %d of %d routes pay (%s)" % (len(keep), len(space.routes), "; ".join(
                "%s>%s %+.3f" % (space.routes[j][1], space.routes[j][0], gain[j]) for j in keep[:4])))
            idx = list(range(space.n_knobs)) + [space.n_knobs + j for j in keep]
            seeds_v = best_v.copy()
            for j in keep:                                 # start each kept route at its better probe
                jj = [w for w in range(len(who)) if who[w][0] == j]
                w = min(jj, key=lambda w: Fc[w])
                seeds_v[space.n_knobs + j] = cand[w][space.n_knobs + j]
            v, f = _ga(ev, space, best_s, seeds_v, idx, int(MOD_FRAC * budget), rng)
            if f < best_f:
                best_f, best_v = f, v
            log("knobs + modulation %.3f" % best_f)
        else:
            log("modulation: no route pays")
    # 4. polish the most sensitive values (the settle's share kept)
    reserve = int(SETTLE_FRAC * budget)
    for stage in range(2):
        left = budget - reserve - ev.n
        act = _active(space, best_v)
        if left < 2 * len(act) + 48:
            break
        limit = ev.n + (left // 2 if stage == 0 else left)
        sens, (sb, vb) = _sensitivity(ev, space, best_s, best_v, act)
        if sb < best_f:
            best_f, best_v = sb, vb
        Sx = np.argsort(-sens)[:POLISH_K]
        Sx = Sx[sens[Sx] > 0]
        if Sx.size == 0:
            break
        v, f = _ga(ev, space, best_s, best_v, Sx, max(0, limit - ev.n), rng, pop=16, sigma=0.08)
        if f < best_f:
            best_f, best_v = f, v
        log("polish %d: %d values, %.3f (%d renders)" % (stage + 1, Sx.size, best_f, ev.n))
    # 5. SETTLE: a value the note does not tell goes back to where the start had it
    best_v, best_f = _settle(ev, space, best_s, best_v, best_f, best_name, log)
    finals = [(best_f, best_name, best_s, best_v)] + [q for q in tuned[1:]]
    alts = []
    for f, name, s, v in finals:
        d = _result_doc(space, s, v, doc)
        moved = _moved(space, space.genome(doc), v)
        alts.append(dict(play_doc=d, score=float(f), family="%s from %s" % (doc.get("name", "patch"), name),
                         kinds=[m[0] for m in moved], whys=[m[1] for m in moved]))
    alts.sort(key=lambda a: a["score"])
    return dict(alternatives=alts, renders=ev.n, onset=int(onset), chord=chord, log=log_lines,
                timing=dict(render_s=round(ev.t_render, 2), score_s=round(ev.t_score, 2),
                            total_s=round(time.perf_counter() - t0, 2)), evaluator=ev)


def _settle(ev, space, state, v, f, name, log):
    """every value the search moved from the start, tried back at the start's value: one batch of single
    reverts, then kept in order of what they cost while the fitness stays within SETTLE_TOL of `f`.

    Why (2026-10-06, Volo: "it configured knobs in a way that each key press produces a different
    sound"): a knob the note cannot hear drifts wherever the GA leaves it -- a Minimoog bass recorded
    0.04 s past its gate came back with ENV 2's release at ~10 s, so the next press of the key started
    with the filter still open (9.18 matched, 9.64-9.70 on every later press). Back where the preset's
    designer had them, those knobs play the way the synth plays."""
    g0 = space.genome(state)
    moved = [j for j in range(space.n) if abs(float(v[j]) - float(g0[j])) > 1e-6]
    if not moved:
        return v, f
    trials = []
    for j in moved:
        u = v.copy()
        u[j] = g0[j]
        trials.append(u)
    S1 = ev.score([space.apply(state, u) for u in trials])
    cur_v, cur_f, back = v.copy(), f, 0
    for o in np.argsort(S1):
        if S1[o] > f + SETTLE_TOL:
            break                                    # sorted: every later revert costs more alone
        u = cur_v.copy()
        u[moved[o]] = g0[moved[o]]
        fu = float(ev.score([space.apply(state, u)])[0])
        if fu <= f + SETTLE_TOL:
            cur_v, cur_f, back = u, fu, back + 1
    log("settle: %d of %d moved values back where %s had them (the note does not tell them), %.3f -> %.3f (%d renders)"
        % (back, len(moved), name, f, cur_f, ev.n))
    return cur_v, cur_f


def _moved(space, g0, g):
    """the knobs and routes a genome moved from the patch as saved -> [(name, 'a -> b')]"""
    out = []
    names = space.names()
    for i in range(space.n):
        a, b = float(g0[i]), float(g[i])
        if i >= space.n_knobs:
            a, b = 2 * a - 1, 2 * b - 1
            if abs(a) < DEAD and abs(b) < DEAD:
                continue
        if abs(a - b) >= 0.01:
            out.append((names[i], "%.2f -> %.2f" % (a, b)))
    return out


def _result_doc(space, state, g, original):
    """the matched patch: the graph and its dashboard as they were, the knobs and cells the match,
    and the presets kept -- under a new first preset "Matched" (default: true) that states every
    knob the bank touches, read from the matched graph (the format's default rule)"""
    d = space.apply(state, g, keep_presets=True)
    N = _nodes(d)
    bank = [p for p in (original.get("presets") or []) if not p.get("default")]
    old_default = next((p for p in (original.get("presets") or []) if p.get("default")), None)
    params = {}
    for p in bank + ([old_default] if old_default else []):
        for nid, kv in (p.get("params") or {}).items():
            if nid not in N:
                continue
            for k in kv:
                v = N[nid].get("params", {}).get(k)
                if v is None and old_default is not None:
                    v = (old_default.get("params") or {}).get(nid, {}).get(k)
                if v is not None:
                    params.setdefault(nid, {})[k] = v
    for i, _ in space.knobs:
        params.setdefault(i, {})["value"] = N[i]["params"]["value"]
    cells = (d.get("matrix") or {}).get("cells") or {}
    named = {dest for p in bank for dest in (p.get("matrix") or {})} | set(space.dests)
    matched = {"name": "Matched", "default": True, "params": params,
               "matrix": {dest: copy.deepcopy(cells.get(dest) or {"value": []}) for dest in sorted(named)}}
    d["presets"] = [matched] + [dict(p) for p in bank]
    d["name"] = "%s (matched)" % original.get("name", "patch")
    return d
