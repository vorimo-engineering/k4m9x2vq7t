"""DASHBOARD GROW: a grown voice that is always a DASHBOARD instrument (pchkraft-synth
docs/PATCH_FORMAT.md `dashboard`; analog 1 (dashboard) is the reference).

Volo (2026-10-04): "it must always use dashboard, see analog-1 synth ... the graph could be any,
only thing is all blocks still should be mapped, so dashboard is what will be available for user
to tune, but underneath there could be anything, and pretuned ... the graph always should have at
least 2 adsr, filter, fx, lfo ... lfo mapped through macro knobs".

So a dashboard voice is two layers:

  UNDERNEATH  whatever GROW grows -- sources with their own (pretuned) envelopes, a pitch
              envelope, inserts, EQ, hidden effects -- every knob at the value the match found;
  THE SKELETON the blocks the dashboard's five screens drive, one each, never pruned (the `dash`
              piece below): ENV 1 = the voice's amp envelope (a VCA after the filter), the main
              FILTER (ladder, SVF or Sallen-Key -- its `mode` the screen's TYPE -- or the acid or the
              18 dB, no TYPE), ENV 2
              on its cutoff (depth: the ENV amount macro), ONE LFO (global `lfo`, retriggered), and
              the FX SLOT (`fx.slot`: off | chorus | delay | pulser | reverb | tremolo).

and on top THE DASHBOARD, as analog 1 wires it (DESIGN D1-D12 of the dashboard spec): every knob a
`mod.macro`, wired with ordinary links to the real parameters -- each continuous target parked at
the bottom of its travel and the macro's value AT the matched value's place on that travel (the
link adds `1.0 x out`: the knob sweeps the whole range and starts exactly where the match put it);
selectors and toggles by range links. The LFO reaches the sound only THROUGH MACRO KNOBS: matrix
cells from the LFO source onto PITCH (vibrato), cutoff (the filter's wobble), PW (pulse-width
modulation) and VOL (tremolo). The matrix declares the eight standard sources in their fixed order
(ENV 1, ENV 2, COMPASS, VELOCITY, LFO, ACCEL, ROTATION, R-REEL), the four sensor blocks are there,
SYNTH holds up to eight knobs on the grown sources, the rest of the macros sit in a MORE group.

    from dnasynth.grow import dash
    dash.install()                          # the `dash` kind in blocks.KINDS
    mods = dash.dashify(mods, TA)           # GROW's filter / LFO / effect pieces folded into it
    doc = blocks.document(mods)             # a voice holding a `dash` piece -> its dashboard document
"""
from __future__ import annotations

import numpy as np

FILTERS = ("filter.ladder", "filter.svf", "filter.sk", "filter.acid", "filter.lp3")
MULTIMODE = ("filter.ladder", "filter.svf", "filter.sk")     # a MODE: the FILTER screen's TYPE knob
# the acid and the 18 dB have no mode: on the screen their TYPE slot is EMPTY (PATCH_FORMAT.md: a slot
# with nothing to drive is null, hidden on the device); the low-pass gate, the comb and the 1-pole
# high pass are not the screen's kind of filter and stay underneath
MODES = ("low pass", "high pass", "band pass", "notch")           # the screen's TYPE, by label
LFO_SHAPES = ("sine", "triangle", "saw up", "saw down", "square")  # the deterministic ones
LFO_ALL = ("sine", "triangle", "saw up", "saw down", "square", "sample+hold", "drift")
FX_TYPES = ("off", "chorus", "delay", "pulser", "reverb", "tremolo")
CUT_OCT = float(np.log2(18000.0 / 20.0))      # every dashboard filter's cutoff: 20 .. 18000 Hz
ENV_OCT = 6.0                                 # ENV 2 at full depth: +-6 octaves on the cutoff
PITCH_ST = 4.0                                # the PITCH macro's whole travel: -2 .. +2 semitones
VCA_MAX = 1.5                                 # util.amp level travel
FX_MIX = 0.6                                  # FX DEPTH drives depth 0..1 and mix 0..0.6 (analog 1)
ROOM_DECAY = True                             # a folded room's decay sets the slot's RATE (dashify; False: its size, before 2026-10-05)
SOURCES_8 = ("ENV 1", "ENV 2", "COMPASS", "VELOCITY", "LFO", "ACCEL", "ROTATION", "R-REEL")

# (name, law, a, b, neutral) as blocks.KINDS: the skeleton's knobs, searched like any piece's
DASH = (
    # ENV 1: the amp envelope of the whole voice (a VCA after the filter and the inserts)
    ("a_att", "exp", 0.001, 8.0, 0.0), ("a_dec", "exp", 0.002, 12.0, 0.55),
    ("a_sus", "lin", 0.0, 1.0, 1.0), ("a_rel", "exp", 0.002, 12.0, 0.45),
    # the FILTER
    # at rest the SVF (2026-10-04: a filter the sound never uses still costs the board -- the ladder
    # 1.0 a voice, the SVF 0.35 in the registry's units; a template or move that wants another sets it)
    ("model", "step", FILTERS, None, 1.5 / len(FILTERS)), ("mode", "step", MODES, None, 1 / 8),
    ("cut", "exp", 20.0, 18000.0, 1.0), ("res", "lin", 0.0, 0.95, 0.0), ("drive", "sq", 0.0, 1.0, 0.0),
    ("key", "lin", 0.0, 1.0, 0.5),
    # ENV 2 -> the cutoff (octaves)
    ("fenv", "bip", 1.5, ENV_OCT, 0.5), ("f_att", "exp", 0.001, 8.0, 0.0), ("f_dec", "exp", 0.002, 12.0, 0.5),
    ("f_sus", "lin", 0.0, 1.0, 0.5), ("f_rel", "exp", 0.002, 12.0, 0.45),
    # the LFO and where it reaches (through the macros): semitones, octaves, pulse width, level
    ("lfo_shape", "step", LFO_SHAPES, None, 0.1), ("lfo_rate", "exp", 0.05, 20.0, 0.75),
    ("lfo_pitch", "sq", 0.0, 1.0, 0.0), ("lfo_cut", "sq", 0.0, 3.0, 0.0), ("lfo_pw", "sq", 0.0, 0.45, 0.0),
    ("lfo_amp", "sq", 0.0, 0.5, 0.0),
    # the FX slot
    ("fx_type", "step", FX_TYPES, None, 1 / 12), ("fx_rate", "lin", 0.0, 1.0, 0.5),
    ("fx_depth", "lin", 0.0, 1.0, 0.5),
)
NAMES = tuple(s[0] for s in DASH)
# MODULATION OF THE MACRO KNOBS (Volo: "also you can use modulation of macro knobs"): a CELL piece,
# kind "cell:<source>><knob>", is one matrix cell -- ENV 1, ENV 2 or the LFO onto a knob -- with one
# gene, its depth in the knob's own travel (+-1, squared near zero). The knob is a ROLE, resolved
# on the voice's first source of the matching kind (the one SYNTH shows first)
CELL_SOURCES = {"env1": ("env1", "ENV 1"), "env2": ("env2", "ENV 2"), "lfo": ("lfo", "LFO")}
CELL_DESTS = ("cutoff", "resonance", "pitch", "vol", "wave", "pw", "fm", "feedback", "color", "pos",
              "shape", "warp", "damp")
CELL_GENE = (("amount", "bip", 2.0, 1.0, 0.5),)
# the SYNTH candidates of each source kind: (gene, label, icon) -- the build keeps the most audible
CANDS = {
    "tone": (("shape", "WAVE", "wave"), ("pw", "PW", "pw"), ("detune", "DETUNE", "detune")),
    "fm": (("index", "FM", "fm"), ("mfb", "FEEDBACK", "fm"), ("idec", "FM DECAY", "fm")),
    "noise": (("freq", "COLOR", "noise"), ("res", "NOISE Q", "noise")),
    "pluck": (("damp", "DAMP", "wave"), ("decay", "DECAY", "wave"), ("pick", "PICK", "wave"),
              ("stiff", "STIFF", "wave")),
    "src:osc.table": (("pos", "POS", "wave"), ("blend", "BLEND", "wave"), ("warp", "WARP", "wave"),
                      ("spread", "SPREAD", "detune")),
    "src:osc.morph": (("shape", "SHAPE", "wave"), ("spread", "SPREAD", "detune"), ("sub", "SUB", "volume"),
                      ("noise", "AIR", "noise")),
    "src:osc.pd": (("warp", "WARP", "wave"),),
    # four operators: the two modulators' depths (algorithm 4's stacks), the algorithm, the feedback
    "fm4": (("lev2", "MOD 1", "fm"), ("lev4", "MOD 2", "fm"), ("algo", "ALGO", "fm"), ("fb", "FEEDBACK", "fm")),
}
# a cell's knob role -> (source kind, gene) on the first such source
DEST_GENE = {"wave": ("tone", "shape"), "pw": ("tone", "pw"), "fm": ("fm", "index"), "feedback": ("fm", "mfb"),
             "color": ("noise", "freq"), "pos": ("src:osc.table", "pos"), "shape": ("src:osc.morph", "shape"),
             "warp": ("src:osc.pd", "warp"), "damp": ("pluck", "damp")}
FOLDED = ("filter", "vibrato", "tremolo", "chorus", "room")       # GROW's kinds the skeleton absorbs
GROUPS = dict(env1=("a_att", "a_dec", "a_sus", "a_rel"),
              filter=("model", "mode", "cut", "res", "drive", "key"),
              env2=("fenv", "f_att", "f_dec", "f_sus", "f_rel"),
              lfo=("lfo_shape", "lfo_rate", "lfo_pitch", "lfo_cut", "lfo_pw", "lfo_amp"),
              fx=("fx_type", "fx_rate", "fx_depth"))


def install():
    """the `dash` kind and the cell kinds in blocks.KINDS (idempotent)"""
    from . import blocks as BL
    BL.KINDS.setdefault("dash", DASH)
    for src in CELL_SOURCES:
        for dst in CELL_DESTS:
            BL.KINDS.setdefault("cell:%s>%s" % (src, dst), CELL_GENE)


def is_cell(kind):
    return kind.startswith("cell:")


def cell_parts(kind):
    """'cell:env2>wave' -> ('env2', 'wave')"""
    return tuple(kind[5:].split(">", 1))


def is_folded(kind, m=None):
    """a kind the skeleton absorbs: its filter, its LFO's targets, its effect (a chorus or a room
    already kept underneath -- the FX slot was taken -- stays there: marked by its `why`)"""
    if m is not None and m.why.startswith(HIDDEN):
        return False
    # the screen's filters (FILTERS) fold; the low-pass gate (a gate, no resonance), the comb and
    # the 1-pole high pass stay underneath, pretuned, before the dashboard's own
    return kind in FOLDED or (kind.startswith("flt:") and kind[4:] in FILTERS) or kind in ("mod:lfo>cut", "mod:lfo>pw")


HIDDEN = "underneath: "


def _gi(name):
    return NAMES.index(name)


def _has(block, key):
    """a block type has this parameter (the screen's TYPE needs a `mode`, its drive knob a `drive`)"""
    from . import kit as KT
    return KT.param(block, key) is not None


def _get(m, name):
    """a dash gene's physical value (a step gene's label)"""
    from . import blocks as BL
    return BL.decode(DASH[_gi(name)], m.g[_gi(name)])


def _set(m, name, v):
    """a dash gene from a physical value (a step gene from its label)"""
    from . import blocks as BL
    spec = DASH[_gi(name)]
    if spec[1] == "step":
        m.g[_gi(name)] = (spec[2].index(v) + 0.5) / len(spec[2])
    else:
        m.g[_gi(name)] = BL.encode(spec, v)


def new(TA=None, why="the dashboard: ENV 1, ENV 2, filter, LFO, FX"):
    """the skeleton at rest -- filter open, ENV 2 / LFO / FX off -- with ENV 1 from the analysis
    when there is one (the target's own attack, decay, sustain, release)"""
    from . import blocks as BL
    install()
    m = BL.Module.new("dash", why=why)
    if TA is not None:
        _set(m, "a_att", float(np.clip(TA.attack, 0.001, 8.0)))
        _set(m, "a_dec", float(np.clip(TA.decay, 0.002, 12.0)))
        _set(m, "a_sus", float(np.clip(TA.sustain, 0.0, 1.0)))
        _set(m, "a_rel", float(np.clip(TA.release, 0.002, 12.0)))
    return m


def dashify(mods, TA=None):
    """a GROW voice -> a dashboard voice: exactly one `dash` piece (made when missing), and every
    piece the skeleton stands for folded into it -- the main filter (svf / ladder / sk / the other
    kit filters as a ladder), vibrato and tremolo and the LFO modulations as the LFO's depths, the
    chorus or the room as the FX slot. A voice that held one source gives that source's envelope
    to ENV 1 (the source's own goes flat: the dashboard's envelope IS the note's); with several,
    ENV 1 stays open (sustain 1, release past every source's) and the sources keep theirs."""
    from . import blocks as BL
    install()
    have = [m for m in mods if m.kind == "dash"]
    d = have[0].copy() if have else new(TA)
    fresh = not have
    rest = [m.copy() for m in mods if m.kind != "dash" and not is_folded(m.kind, m)]
    for m in mods:
        if m.kind == "dash" or not is_folded(m.kind, m):
            continue
        if m.kind in ("chorus", "room") and _get(d, "fx_type") != "off":
            h = m.copy()                        # the FX slot is taken: this effect stays underneath
            h.why = HIDDEN + h.why
            rest.append(h)
            continue
        p = m.p()
        if m.kind == "filter" or m.kind.startswith("flt:"):
            block = "filter.svf" if m.kind == "filter" else m.kind[4:]
            _set(d, "model", block if block in FILTERS else "filter.ladder")
            if m.kind == "filter":
                mo = float(p["morph"])
                _set(d, "mode", "low pass" if mo < 0.25 else "band pass" if mo < 0.75 else "high pass")
            elif isinstance(p.get("mode"), str) and p["mode"] in MODES:
                _set(d, "mode", p["mode"])
            else:
                _set(d, "mode", "low pass")
            for a, b in (("cut", "cut"), ("cutoff", "cut"), ("res", "res"), ("key", "key"), ("fenv", "fenv"),
                         ("fatt", "f_att"), ("fdec", "f_dec"), ("fsus", "f_sus")):
                if a in p and isinstance(p[a], (int, float)):
                    lo, hi = {"cut": (20.0, 18000.0), "res": (0.0, 0.95)}.get(b, (None, None))
                    v = float(p[a]) if lo is None else float(np.clip(p[a], lo, hi))
                    _set(d, b, v)
            if "drive" in p and isinstance(p["drive"], (int, float)):
                _set(d, "drive", float(np.clip(p["drive"], 0.0, 1.0)))
        elif m.kind == "vibrato":
            _set(d, "lfo_rate", float(np.clip(p["rate"], 0.05, 20.0)))
            _set(d, "lfo_pitch", float(np.clip(p["depth"], 0.0, 1.0)))
            _set(d, "lfo_shape", "sine")
        elif m.kind == "tremolo":
            _set(d, "lfo_rate", float(np.clip(p["rate"], 0.05, 20.0)))
            _set(d, "lfo_amp", float(np.clip(p["depth"] / 2.0, 0.0, 0.5)))
            _set(d, "lfo_shape", "sine")
        elif m.kind == "mod:lfo>cut":
            _set(d, "lfo_rate", float(np.clip(p["rate"], 0.05, 20.0)))
            _set(d, "lfo_cut", float(np.clip(abs(p["depth"]), 0.0, 3.0)))
            if p.get("shape") in LFO_SHAPES:
                _set(d, "lfo_shape", p["shape"])
        elif m.kind == "mod:lfo>pw":
            _set(d, "lfo_rate", float(np.clip(p["rate"], 0.05, 20.0)))
            _set(d, "lfo_pw", float(np.clip(p["depth"], 0.0, 0.45)))
        elif m.kind == "chorus":
            _set(d, "fx_type", "chorus")
            _set(d, "fx_rate", float(np.clip(np.log(p["rate"] / 0.05) / np.log(160.0), 0.0, 1.0)))
            _set(d, "fx_depth", float(np.clip(p["mix"], 0.0, 1.0)))
        elif m.kind == "room":
            # the slot's reverb: RATE is the tail, a 0.3 .. 8 s decay on an exponential travel (fxs_exp,
            # pchkraft-core/synth/nodes/n_fxslot_impl.h), DEPTH the room size and, on the dashboard, the
            # wet level (mix = FX_MIX x depth). The room's DECAY goes to RATE (2026-10-05: its size went
            # there -- a 1.5 s tail for every room, so a 6 s organ room never paid)
            _set(d, "fx_type", "reverb")
            _set(d, "fx_rate", float(np.clip(np.log(max(float(p["decay"]), 0.3) / 0.3) / np.log(8.0 / 0.3), 0.0, 1.0))
                 if ROOM_DECAY else float(np.clip(p["size"], 0.0, 1.0)))
            _set(d, "fx_depth", float(np.clip(p["mix"] / FX_MIX, 0.0, 1.0)))
    srcs = [m for m in rest if BL.is_source(m.kind)]
    if fresh and srcs:
        envs = [m for m in srcs if "att" in m.names() and "sus" in m.names()]
        if len(srcs) == 1 and envs:
            q = envs[0].p()
            _set(d, "a_att", float(np.clip(q["att"], 0.001, 8.0)))
            _set(d, "a_dec", float(np.clip(q["dec"], 0.002, 12.0)))
            _set(d, "a_sus", float(np.clip(q["sus"], 0.0, 1.0)))
            _set(d, "a_rel", float(np.clip(q["rel"], 0.002, 12.0)))
            for name, v in (("att", 0.001), ("sus", 1.0), ("rel", 12.0)):
                envs[0].g[envs[0].names().index(name)] = BL.encode(BL.KINDS[envs[0].kind][envs[0].names().index(name)], v)
        else:
            rels = [r for r in (BL.release_of(m) for m in srcs) if r is not None]
            _set(d, "a_att", 0.001)
            _set(d, "a_sus", 1.0)
            _set(d, "a_rel", float(np.clip(max(rels) if rels else 0.45, 0.002, 12.0)))
    return rest + [d]


# ------------------------------------------------------------------------------- the document

def _param(block, key):
    from . import kit as KT
    return KT.types()[block].param(key)


def _norm(block, key, v):
    p = _param(block, key)
    return float(np.clip(p.from_file(v) if isinstance(v, str) else p.normalise(float(v)), 0.0, 1.0))


def _bottom(block, key):
    """a parameter's value at the bottom of its travel (where a macro parks it)"""
    p = _param(block, key)
    return p.to_file(0.0)


def document(mods, cents=0.0, name="grown", seed=1, voices=1) -> dict:
    """the DASHBOARD document of a voice holding a `dash` piece: the underneath graph
    (blocks.document of every other piece), the skeleton spliced in (filter after the mix, the
    VCA after the inserts, the FX slot before the output), then the dashboard on top"""
    from . import blocks as BL
    from . import kit as KT
    dm = [m for m in mods if m.kind == "dash"][0]
    under = [m for m in mods if m.kind != "dash" and not is_cell(m.kind)]
    cells = [m for m in mods if is_cell(m.kind)]
    doc = BL.document(under, cents=cents, name=name, seed=seed, voices=voices, _no_dash=True)
    levels = {int(k): tuple(v) for k, v in doc.pop("_levels", {}).items()}
    p = dm.p()
    N = {n["id"]: n for n in doc["nodes"]}
    audio = doc["audio"]
    mod = doc["mod"]
    nodes = doc["nodes"]
    out_node = nodes.pop([i for i, n in enumerate(nodes) if n["id"] == "out"][0])
    # ---- where to splice: the last mixer's output, the first global block (or the output)
    mixers = sorted([n["id"] for n in nodes if n["id"].startswith("mx")], key=lambda s: int(s[2:]))
    mx = mixers[-1]
    # the global chain blocks.document builds: EQs, kit effects, the chorus and the room ("cho", "rvb":
    # a chorus or a room kept underneath when the FX slot is taken -- missed here, the VCA landed
    # after a global block and the patch did not compile, 2026-10-04)
    glob = [n["id"] for n in nodes if n["id"].startswith(("eq", "fx")) or n["id"] in ("cho", "rvb")]
    g0 = glob[0] if glob else "out"
    block = p["model"]
    first_osc = None
    for i, m in enumerate(under):
        if BL.is_source(m.kind) and m.kind != "noise":
            first_osc = "s%d" % i
            break
    # 1. the FILTER after the mix (ENV 2 and the keytracking on its cutoff)
    fprm = dict(cutoff=float(p["cut"]), res=float(p["res"]), fm=0.0)
    if block in MULTIMODE:
        fprm["mode"] = p["mode"]
    if _has(block, "drive"):
        fprm["drive"] = float(p["drive"])
    if block == "filter.ladder":
        fprm["model"] = "transistor"
    if block == "filter.svf":
        fprm["morph"] = 0.0
    new_nodes = [dict(id="filt", type=block, params=fprm),
                 dict(id="ktr", type="util.scale", params=dict(gain=float(p["key"]), offset=0.0)),
                 dict(id="env2", type="env.adsr", params=dict(attack=float(p["f_att"]), decay=float(p["f_dec"]),
                                                             sustain=float(p["f_sus"]), release=float(p["f_rel"]))),
                 dict(id="e2s", type="util.scale", params=dict(gain=float(p["fenv"]) / ENV_OCT, offset=0.0)),
                 dict(id="env1", type="env.adsr", params=dict(attack=float(p["a_att"]), decay=float(p["a_dec"]),
                                                             sustain=float(p["a_sus"]), release=float(p["a_rel"]))),
                 dict(id="vca", type="util.amp", params=dict(level=1.0)),
                 dict(id="lfo", type="lfo", params=dict(shape=p["lfo_shape"], rate=float(p["lfo_rate"]), depth=1.0,
                                                       fade=0.0, mode="retrig", phase=0.0, sync="off")),
                 dict(id="fx", type="fx.slot", params=dict(type=p["fx_type"], rate=float(p["fx_rate"]),
                                                          depth=float(p["fx_depth"]),
                                                          mix=float(FX_MIX * p["fx_depth"]), sync="off"))]
    a2 = []
    for e in audio:
        if e[0] == mx and e[1] == "out":
            a2.append(["filt", "l", e[2], e[3]])
        else:
            a2.append(e)
    a2 += [[mx, "out", "filt", "l"], ["kbd", "pitch", "ktr", "in"], ["ktr", "out", "filt", "cutoff"],
           ["env2", "out", "e2s", "in"]]
    if first_osc is not None:                   # FLT FM: the first oscillator into the filter's fm (at 0)
        port = KT.types()[N[first_osc]["type"]].outputs[0].key
        a2.append([first_osc, port, "filt", "fm"])
    mod.append({"from": ["e2s", "out"], "to": ["filt", "cutoff"], "amount": ENV_OCT / CUT_OCT})
    # 2. the VCA (ENV 1) after the voice's chain: every edge into the first global block (or the
    #    output) now leaves the VCA
    into = [e for e in a2 if e[2] == g0]
    srcs = {(e[0], e[1]) for e in into}
    a3 = [e for e in a2 if e[2] != g0]
    for s, port in sorted(srcs):
        a3.append([s, port, "vca", "l"])
    a3 += [["env1", "out", "vca", "gain"]]
    for e in into:
        a3.append(["vca", "l", e[2], e[3]])
    # 3. the FX slot before the output
    into = [e for e in a3 if e[2] == "out"]
    a4 = [e for e in a3 if e[2] != "out"]
    for e in into:
        a4.append([e[0], e[1], "fx", e[3]])
    a4 += [["fx", "l", "out", "l"], ["fx", "r", "out", "r"]]
    # de-duplicate (the mono VCA feeds both sides of a stereo block once each)
    seen, audio = set(), []
    for e in a4:
        t = tuple(e)
        if t not in seen:
            seen.add(t)
            audio.append(e)
    nodes += new_nodes
    nodes.append(out_node)
    doc["audio"] = audio
    doc["mod"] = mod
    return decorate(doc, under, dm, cents, cells, levels)


def knob_target(under, i, gene, levels):
    """a SYNTH candidate (source index in `under`, gene) -> the (node, param) its macro drives:
    the source's level is the mixer input it arrives on (blocks.document's map: the main mixer, or
    the sub-mixer of the sources that share its envelope); a kit oscillator's genes are its own knob
    keys"""
    m = under[i]
    s = "s%d" % i
    if gene == "level":
        return levels.get(i)
    if m.kind.startswith("src:"):
        return (s, gene)
    if m.kind == "fm4":
        if gene.startswith("lev"):
            return ("og%d_%s" % (i, gene[3:]), "gain")
        return {"algo": (s, "algo"), "fb": ("o%d_2" % i, "feedback")}.get(gene)
    return {"tone": {"shape": (s, "shape"), "pw": (s, "pw"), "detune": (s, "fine")},
            "fm": {"index": ("pm%d" % i, "level"), "mfb": ("m%d" % i, "feedback"), "idec": ("ie%d" % i, "decay")},
            "noise": {"freq": ("f%d" % i, "cutoff"), "res": ("f%d" % i, "res")},
            "pluck": {"damp": (s, "damp"), "decay": (s, "decay"), "pick": (s, "pick"), "stiff": (s, "stiff")},
            }.get(m.kind, {}).get(gene)


def dest_of(under, role):
    """a cell's knob role -> (source index, gene, label, icon) on the voice's first source of its
    kind, or None (the skeleton's roles -- cutoff, resonance, pitch, vol -- are not sources)"""
    if role not in DEST_GENE:
        return None
    kind, gene = DEST_GENE[role]
    for i, m in enumerate(under):
        if m.kind == kind:
            lab = [c for c in CANDS[kind] if c[0] == gene][0]
            return (i, gene, lab[1], lab[2])
    return None


def _pitched(doc):
    """the pitch parameters a PITCH knob moves: (node, param, travel in semitones)"""
    from . import kit as KT
    out = []
    for n in doc["nodes"]:
        t = n["type"]
        if t in ("osc.va", "osc.string"):
            out.append((n["id"], "tune", 48.0))
        elif t == "osc.op":
            out.append((n["id"], "ratio", 12.0 * float(np.log2(16.0 / 0.25))))
        elif t in KT.KIT and KT.KIT[t].get("tune"):
            out.append((n["id"], KT.KIT[t]["tune"], 48.0))
    return out


def decorate(doc, under, dm, cents=0.0, cells=(), levels=None):
    """the dashboard over a spliced document: the macros (each continuous target parked at the
    bottom of its travel, the macro AT the matched value: link amount 1.0; selectors by range
    links), the LFO's depths as matrix cells on PITCH / cutoff / PW / VOL, the eight sources, the
    sensors, the SYNTH knobs on the sources, the MORE group, the `dashboard` section"""
    from . import blocks as BL
    nodes, audio, mod = doc["nodes"], doc["audio"], doc["mod"]
    N = {n["id"]: n for n in nodes}
    p = dm.p()
    macros = []

    def macro(mid, value, **kw):
        prm = dict(value=float(np.clip(value, 0.0, 1.0)))
        prm.update(kw)
        n = dict(id=mid, type="mod.macro", params=prm)
        nodes.insert(0, n)
        N[mid] = n
        macros.append(mid)
        return mid

    def own(mid, nid, key, amount=1.0):
        """macro -> a continuous parameter: parked at the bottom, the macro adds amount x out"""
        t = N[nid]["type"]
        v = N[nid]["params"].get(key, _param(t, key).default)
        N[nid]["params"][key] = _bottom(t, key)
        mod.append({"from": [mid, "out"], "to": [nid, key], "amount": float(amount)})
        return _norm(t, key, v)

    def sel(mid, nid, key, labels, value_label, steps):
        """macro -> a selector over `labels` (a range link: the macro's steps are its positions)"""
        k = labels.index(value_label)
        macro(mid, k / (len(labels) - 1), steps=str(steps))
        mod.append({"from": [mid, "out"], "to": [nid, key], "range": [labels[0], labels[-1]]})
        N[nid]["params"].pop(key, None)

    # ---- ENV 1 / ENV 2
    for env, tag in (("env1", "1"), ("env2", "2")):
        for key, short in (("attack", "A"), ("decay", "D"), ("sustain", "S"), ("release", "R")):
            mid = short + tag
            macro(mid, 0.0)
            N[mid]["params"]["value"] = own(mid, env, key)
    # ---- FILTER: type (its mode), cutoff, tune (resonance), fm
    blk = N["filt"]["type"]
    if blk in MULTIMODE:
        labels = [lb for lb in _param(blk, "mode").enums][:4]
        sel("filter mode", "filt", "mode", labels, p["mode"] if p["mode"] in labels else labels[0], 4)
    macro("cutoff", 0.0)
    N["cutoff"]["params"]["value"] = own("cutoff", "filt", "cutoff")
    macro("resonance", 0.0)
    N["resonance"]["params"]["value"] = own("resonance", "filt", "res")
    macro("FLT FM", 0.0)
    N["FLT FM"]["params"]["value"] = own("FLT FM", "filt", "fm")
    more = []
    if _has(blk, "drive"):
        macro("filter drive", 0.0)
        N["filter drive"]["params"]["value"] = own("filter drive", "filt", "drive")
        more.append("filter drive")
    # ENV 2's depth (bipolar: the middle is none) and the keytracking: util.scale gains -4 .. 4
    macro("ENV amount", 0.5 + float(p["fenv"]) / (2.0 * ENV_OCT), offset=-0.5)
    N["e2s"]["params"]["gain"] = 0.0
    mod.append({"from": ["ENV amount", "out"], "to": ["e2s", "gain"], "amount": 0.25})
    macro("key tracking", float(p["key"]))
    N["ktr"]["params"]["gain"] = 0.0
    mod.append({"from": ["key tracking", "out"], "to": ["ktr", "gain"], "amount": 0.125})
    more += ["ENV amount", "key tracking"]
    # ---- the LFO: shape, hz, sync
    sel("SHAPE1", "lfo", "shape", list(LFO_ALL), p["lfo_shape"], 7)
    macro("RATE1", 0.0)
    N["RATE1"]["params"]["value"] = own("RATE1", "lfo", "rate")
    sel("LFO SYNC", "lfo", "sync", ["off", "on"], "off", 2)
    # ---- the FX slot: type, rate, depth (+ mix), sync
    sel("FX TYPE", "fx", "type", list(FX_TYPES), p["fx_type"], 6)
    macro("FX RATE", float(p["fx_rate"]))
    mod.append({"from": ["FX RATE", "out"], "to": ["fx", "rate"], "range": [0.0, 1.0]})
    macro("FX DEPTH", float(p["fx_depth"]))
    mod.append({"from": ["FX DEPTH", "out"], "to": ["fx", "depth"], "range": [0.0, 1.0]})
    mod.append({"from": ["FX DEPTH", "out"], "to": ["fx", "mix"], "range": [0.0, FX_MIX]})
    for k in ("rate", "depth", "mix"):
        N["fx"]["params"].pop(k, None)
    sel("FX SYNC", "fx", "sync", ["off", "on"], "off", 2)
    # ---- VOL (the VCA's level, the tremolo's target) and PITCH (every oscillator, the vibrato's)
    macro("VOL", 1.0 / VCA_MAX)
    N["vca"]["params"]["level"] = 0.0
    mod.append({"from": ["VOL", "out"], "to": ["vca", "level"], "amount": 1.0})
    more.append("VOL")
    pitched = _pitched(doc)
    if pitched:
        macro("PITCH", 0.5, offset=-0.5)
        for nid, key, travel in pitched:
            mod.append({"from": ["PITCH", "out"], "to": [nid, key], "amount": PITCH_ST / travel})
    # ---- SYNTH: up to eight knobs on the grown sources -- the ones the build CHOSE as the most
    #      audible (choose_synth, kept in dm.extra["synth"]), or while it still searches the first
    #      source's character and the others' levels
    feeds = levels or {}
    synth, owners = [], {}

    def knob(label, target, icon, in_synth=True):
        """the macro on a (node, param): reused when one owns it, made otherwise (its id the label,
        made unique); on SYNTH while there is room, else in MORE -> its id"""
        if target is None or target[0] not in N:
            return None
        if target in owners:
            mid = owners[target]
        else:
            mid = label
            while mid in N:
                mid += "'"
            if N[target[0]]["type"] == "util.scale" and target[1] == "gain":
                # a DEPTH (an operator's output level): x0 .. x2 of the matched one, the knob in the
                # middle -- a whole -4 .. 4 travel would turn the envelope upside down below 0
                g = float(N[target[0]]["params"].pop("gain", 1.0))
                macro(mid, 0.5)
                mod.append({"from": [mid, "out"], "to": [target[0], "gain"], "range": [0.0, max(2.0 * g, 1e-3)]})
            else:
                macro(mid, 0.0)
                N[mid]["params"]["value"] = own(mid, target[0], target[1])
            owners[target] = mid
        on = any(k["macro"] == mid for k in synth)
        if in_synth and not on and len(synth) < 8:
            synth.append(dict(macro=mid, icon=icon, label=label))
            if mid in more:
                more.remove(mid)
        elif not on and mid not in more:
            more.append(mid)
        return mid

    def group_knob(label, members, icon):
        """ONE knob over several sources' levels, PROPORTIONAL: a bipolar macro (the middle is the
        matched mix) adding 2 x level x out onto each level -- x0 at one end, x2 at the other, every
        ratio between them kept (the partials of an organ, the bands of a breath)"""
        mid = label
        while mid in N:
            mid += "'"
        macro(mid, 0.5, offset=-0.5)
        n = 0
        for i in members:
            t = feeds.get(i)
            if t is None or t[0] not in N:
                continue
            lv = float(N[t[0]]["params"].get(t[1], 0.0))
            if lv > 0.0:
                mod.append({"from": [mid, "out"], "to": [t[0], t[1]], "amount": 2.0 * lv})
                n += 1
        if n and len(synth) < 8:
            synth.append(dict(macro=mid, icon=icon, label=label))
        elif n:
            more.append(mid)

    chosen = dm.extra.get("synth")
    srcs = [(i, m) for i, m in enumerate(under) if BL.is_source(m.kind)]
    G = groups(under)
    if chosen is not None:
        for i, gene, label, icon in chosen:
            if i < 0:
                if gene in G:
                    group_knob(label, G[gene], icon)
            elif i < len(under):
                knob(label, knob_target(under, i, gene, feeds), icon)
    else:
        for i, m in srcs[:1]:
            for gene, label, icon in CANDS.get(m.kind, ())[:2]:
                if gene != "detune":
                    knob(label, knob_target(under, i, gene, feeds), icon)
        grouped = {j for g in G.values() for j in g}
        n_lv = 0
        for j, (i, m) in enumerate(srcs[1:], start=2):
            if i not in grouped and n_lv < MAX_LEVELS:
                knob("VOL %d" % j, knob_target(under, i, "level", feeds), "volume")
                n_lv += 1
        for name, members in G.items():
            group_knob({"harmonics": "HARMONICS", "noise": "NOISE"}[name], members,
                       {"harmonics": "wave", "noise": "noise"}[name])
    if pitched:
        if len(synth) < 8 and chosen is None:
            synth.append(dict(macro="PITCH", icon="tune", label="PITCH"))
        else:
            more.append("PITCH")
    # ---- the matrix: the eight standard sources; the cells -- the LFO's depths on PITCH, cutoff,
    #      PW, VOL, and every cell piece (ENV 1 / ENV 2 / LFO onto a knob) -- summed per (knob, source)
    sensors = [dict(id="compass", type="sense.compass", params={}), dict(id="motion", type="sense.accel", params={}),
               dict(id="tilt", type="sense.rotation", params={}), dict(id="reel", type="sense.reel", params={})]
    nodes[0:0] = sensors
    sources = [{"from": ["env1", "out"], "label": "ENV 1"}, {"from": ["env2", "out"], "label": "ENV 2"},
               {"from": ["compass", "out"], "label": "COMPASS"}, {"from": ["kbd", "vel"], "label": "VELOCITY"},
               {"from": ["lfo", "out"], "label": "LFO"}, {"from": ["motion", "out"], "label": "ACCEL"},
               {"from": ["tilt", "out"], "label": "ROTATION"}, {"from": ["reel", "out"], "label": "R-REEL"}]
    order = [s_["from"][0] for s_ in sources]
    depth = {}                                           # (macro, source node) -> amount

    def cell(mid, src, amount):
        if mid is not None and mid in N and abs(amount) > 1e-9:
            depth[(mid, src)] = depth.get((mid, src), 0.0) + float(amount)

    cell("PITCH" if pitched else None, "lfo", float(p["lfo_pitch"]) / PITCH_ST)
    cell("cutoff", "lfo", float(p["lfo_cut"]) / CUT_OCT)
    if "PW" not in N:
        t = dest_of(under, "pw")
        if t is not None and float(p["lfo_pw"]) > 0:
            knob(t[2], knob_target(under, t[0], t[1], feeds), t[3])
    pw_mid = owners.get(knob_target(under, dest_of(under, "pw")[0], "pw", feeds)) if dest_of(under, "pw") else None
    cell(pw_mid, "lfo", float(p["lfo_pw"]) / 0.9)
    cell("VOL", "lfo", float(p["lfo_amp"]) / VCA_MAX)
    for c in cells:
        src, role = cell_parts(c.kind)
        amount = float(c.p()["amount"])
        fixed = {"cutoff": "cutoff", "resonance": "resonance", "vol": "VOL", "pitch": "PITCH" if pitched else None}
        if role in fixed:
            mid = fixed[role]
        else:
            t = dest_of(under, role)
            mid = knob(t[2], knob_target(under, t[0], t[1], feeds), t[3]) if t is not None else None
        cell(mid, CELL_SOURCES[src][0], amount)
    for mid, _ in list(depth):                           # a modulated knob is SEEN: SYNTH, when there is room
        if mid in more and len(synth) < 8 and all(k["macro"] != mid for k in synth):
            more.remove(mid)
            synth.append(dict(macro=mid, icon={"PITCH": "tune", "VOL": "volume"}.get(mid, "wave"), label=mid))
    cells_doc = {}
    for (mid, src), amount in sorted(depth.items(), key=lambda kv: order.index(kv[0][1])):
        cells_doc.setdefault(mid, {"value": []})["value"].append(
            {"from": [src, "out"], "amount": float("%.6g" % amount)})
    doc["matrix"] = {"sources": sources, "cells": cells_doc}
    doc["dashboard"] = {
        "pos": [-1600, -1600],
        "synth": {"layout": "grid8", "picture": None, "knobs": synth},
        "env1": {"attack": "A1", "decay": "D1", "sustain": "S1", "release": "R1"},
        "env2": {"attack": "A2", "decay": "D2", "sustain": "S2", "release": "R2"},
        "fx": {"type": "FX TYPE", "rate": "FX RATE", "depth": "FX DEPTH", "sync": "FX SYNC"},
        "filter": {"type": "filter mode" if blk in MULTIMODE else None, "cutoff": "cutoff", "tune": "resonance",
                   "fm": "FLT FM"},
        "lfo": {"shape": "SHAPE1", "hz": "RATE1", "sync": "LFO SYNC"},
    }
    doc["groups"] = [{"id": "more", "name": "MORE", "nodes": [m for m in more if m in N or m in macros],
                      "panel": [], "ports": {"in": [], "out": []}, "pos": [-2200, -1600], "size": [536, 248]}]
    doc["author"] = "dnasynth dashboard grow"
    layout(doc)
    return doc


DASH_POS = (-1584, -1600)             # where analog 1 (dashboard) keeps its dashboard block
MORE_POS, MORE_SIZE = (-2184, -1608), (536, 248)
BAND = (-2472, -24, -1000)            # the signal blocks: x from .. to, top row's y (analog 1's band)


def layout(doc):
    """canvas positions in analog 1's arrangement (the board lays out only a patch with NO
    positions, and never a group): the signal blocks in a band by signal depth, keyboard left,
    output right; the dashboard above them, the MORE group beside it with its knobs inside, the
    sensors on the right"""
    nodes = doc["nodes"]
    knobs = {n["id"] for n in nodes if n["type"] == "mod.macro"}
    sens = [n for n in nodes if n["type"].startswith("sense.")]
    sig = [n for n in nodes if n["id"] not in knobs and not n["type"].startswith("sense.")]
    ids = [n["id"] for n in sig]
    succ = {i: set() for i in ids}
    for e in doc["audio"]:
        if e[0] in succ and e[2] in succ and e[0] != e[2]:
            succ[e[0]].add(e[2])
    for m in doc.get("mod", []):
        a, b = m["from"][0], m["to"][0]
        if a in succ and b in succ and a != b:
            succ[a].add(b)
    depth = {i: 0 for i in ids}
    for _ in range(len(ids)):
        moved = False
        for a in ids:
            for b in succ[a]:
                if depth[b] < depth[a] + 1 <= len(ids):
                    depth[b] = depth[a] + 1
                    moved = True
        if not moved:
            break
    if "out" in depth:                                   # the output last, alone
        depth["out"] = max(depth.values()) + (0 if sum(1 for v in depth.values() if v == depth["out"]) == 1 else 1)
    ncol = max(depth.values()) + 1
    x0, x1, y0 = BAND
    dx = (x1 - x0) / max(1, ncol - 1)
    rows = {}
    for n in sig:
        c = depth[n["id"]]
        r = rows.get(c, 0)
        rows[c] = r + 1
        n["pos"] = [int(round(x0 + c * dx)), int(y0 + 130 * r)]
    for k, n in enumerate(sens):
        n["pos"] = [216, DASH_POS[1] + 160 * k]
    more = set(doc.get("groups", [{}])[0].get("nodes", [])) if doc.get("groups") else set()
    km = [n for n in nodes if n["id"] in knobs and n["id"] in more]
    kd = [n for n in nodes if n["id"] in knobs and n["id"] not in more]
    for k, n in enumerate(km):
        n["pos"] = [MORE_POS[0] + 16 + 128 * (k % 4), MORE_POS[1] + 40 + 100 * (k // 4)]
    for k, n in enumerate(kd):
        n["pos"] = [DASH_POS[0] + 128 * (k % 8), DASH_POS[1] + 40 + 100 * (k // 8)]
    doc["dashboard"]["pos"] = list(DASH_POS)
    for g in doc.get("groups", []):
        g["pos"], g["size"] = list(MORE_POS), list(MORE_SIZE)


def describe(m):
    """the skeleton in a player's words"""
    p = m.p()
    out = ["%s %s%.0f Hz res %.2f" % (p["model"].split(".")[1], (p["mode"] + " ") if p["model"] in MULTIMODE else "",
                                       p["cut"], p["res"]),
           "ENV1 A %.3f D %.2f S %.2f R %.2f" % (p["a_att"], p["a_dec"], p["a_sus"], p["a_rel"])]
    if abs(p["fenv"]) > 1e-6:
        out.append("ENV2 %+.1f oct" % p["fenv"])
    lfo = [n for n, k in (("pitch", "lfo_pitch"), ("cut", "lfo_cut"), ("pw", "lfo_pw"), ("amp", "lfo_amp")) if p[k] > 1e-6]
    if lfo:
        out.append("LFO %.2f Hz -> %s" % (p["lfo_rate"], "/".join(lfo)))
    if p["fx_type"] != "off":
        out.append("FX %s" % p["fx_type"])
    return " · ".join(out)


def in_use(d):
    """which of the skeleton's parts a dash piece plays: the filter (closed, resonant, enveloped
    or not a low pass), ENV 2, the LFO's four targets, the FX slot"""
    p = d.p()
    return dict(filter=p["cut"] < 15000.0 or p["res"] > 0.1 or abs(p["fenv"]) > 0.05
                or (p["model"] in MULTIMODE and p["mode"] != "low pass"),
                vibrato=p["lfo_pitch"] > 1e-6, tremolo=p["lfo_amp"] > 1e-6, lfo_cut=p["lfo_cut"] > 1e-6,
                lfo_pw=p["lfo_pw"] > 1e-6, fx=p["fx_type"] != "off")


def view(mods):
    """a dashboard voice as GROW's analysis reads a voice: its pieces in order, then the dash
    piece as the GROW pieces it stands for (a filter only once the filter is in use, vibrato when
    the LFO reaches the pitch, ...) -> (the view, how many of its pieces are real)"""
    from . import blocks as BL
    from . import kit as KT
    real = [m for m in mods if m.kind != "dash"]
    ds = [m for m in mods if m.kind == "dash"]
    if not ds:
        return list(mods), len(mods)
    d = ds[0]
    p, u = d.p(), in_use(d)
    pseudo = []
    if u["filter"]:
        if p["model"] == "filter.svf":
            f = BL.Module.new("filter", why="the dashboard's filter", cut=p["cut"], res=min(p["res"], 0.95),
                              morph={"low pass": 0.0, "band pass": 0.5, "high pass": 1.0}.get(p["mode"], 0.5),
                              fenv=p["fenv"], fatt=p["f_att"], fdec=p["f_dec"], fsus=p["f_sus"], key=p["key"])
        else:
            KT.install()
            kind = "flt:" + p["model"]
            f = BL.Module.new(kind, why="the dashboard's filter", fenv=p["fenv"], fatt=p["f_att"], fdec=p["f_dec"],
                              fsus=p["f_sus"], key=p["key"])
            for k, v in (("cutoff", p["cut"]), ("res", p["res"]), ("drive", p["drive"]), ("mode", p["mode"])):
                if k in f.names():
                    f.g[f.names().index(k)] = BL.encode(BL.KINDS[kind][f.names().index(k)], v)
        pseudo.append(f)
    rate = float(np.clip(p["lfo_rate"], 0.5, 12.0))
    if u["vibrato"]:
        pseudo.append(BL.Module.new("vibrato", why="the dashboard's LFO", rate=rate, depth=p["lfo_pitch"]))
    if u["tremolo"]:
        pseudo.append(BL.Module.new("tremolo", why="the dashboard's LFO", rate=rate, depth=2.0 * p["lfo_amp"]))
    if u["lfo_cut"]:
        KT.install()
        pseudo.append(BL.Module.new("mod:lfo>cut", why="the dashboard's LFO", rate=p["lfo_rate"], depth=p["lfo_cut"]))
    if u["lfo_pw"]:
        KT.install()
        pseudo.append(BL.Module.new("mod:lfo>pw", why="the dashboard's LFO", rate=p["lfo_rate"], depth=p["lfo_pw"]))
    if p["fx_type"] == "chorus":
        pseudo.append(BL.Module.new("chorus", why="the dashboard's FX"))
    elif p["fx_type"] == "reverb":
        pseudo.append(BL.Module.new("room", why="the dashboard's FX"))
    return real + pseudo, len(real)


def tune_genes(d):
    """the dash genes worth searching (indices into its genes): ENV 1 always; the filter and
    ENV 2 once the filter is in use; the LFO's rate and shape and each depth once any depth is
    on; the FX slot's once it is on"""
    u = in_use(d)
    names = list(GROUPS["env1"])
    if u["filter"]:
        model = _get(d, "model")             # no gene the filter cannot hear: a mode / a drive it lacks
        names += [k for k in GROUPS["filter"] if not ((k == "mode" and model not in MULTIMODE)
                                                      or (k == "drive" and not _has(model, "drive")))]
        names += list(GROUPS["env2"])
    lfo = [k for k, on in (("lfo_pitch", u["vibrato"]), ("lfo_amp", u["tremolo"]), ("lfo_cut", u["lfo_cut"]),
                           ("lfo_pw", u["lfo_pw"])) if on]
    if lfo:
        names += ["lfo_shape", "lfo_rate"] + lfo
    if u["fx"]:
        names += list(GROUPS["fx"])
    return np.array([_gi(n) for n in names], int)


def flat_env_genes(m):
    """a source's own envelope when it is FLAT (the dashboard's ENV 1 carries the note): its
    attack, sustain and release genes, held out of a search so ENV 1 stays the note's envelope"""
    from . import blocks as BL
    if not BL.is_source(m.kind) or not {"att", "sus", "rel"} <= set(m.names()):
        return []
    q = m.p()
    if q["att"] <= 0.0011 and q["sus"] >= 0.999 and q["rel"] >= 11.9:
        return [m.names().index(k) for k in ("att", "dec", "sus", "rel")]
    return []


OFF = dict(fenv=0.5, lfo_pitch=0.0, lfo_cut=0.0, lfo_pw=0.0, lfo_amp=0.0)   # each part's off gene


def open_filter(d):
    """the skeleton's filter at rest (open, no resonance, no envelope): what stays when a filter
    with no mode takes the sound's filtering underneath"""
    e = d.copy()
    for k in ("cut", "res", "drive", "fenv", "key"):
        e.g[_gi(k)] = DASH[_gi(k)][4]
    e.g[_gi("mode")] = DASH[_gi("mode")][4]
    return e


def prune(ev, mods, score, tol, log):
    """the dashboard's own PRUNE: every part of the skeleton the polished voice still has on --
    each LFO depth, ENV 2's depth, the FX slot -- switched off when the fitness without it is no
    worse than `tol` (a depth the polish nudged to 0.06 % is a modulation the player would see on
    the grid and never hear)"""
    while True:
        i = [j for j, m in enumerate(mods) if m.kind == "dash"][0]
        d = mods[i]
        trials = []
        for k, off in OFF.items():
            if abs(d.g[_gi(k)] - off) > 1e-12:
                e = d.copy()
                e.g[_gi(k)] = off
                trials.append((k, e))
        if _get(d, "fx_type") != "off":
            e = d.copy()
            _set(e, "fx_type", "off")
            trials.append(("fx", e))
        if not trials:
            return mods, score
        s = ev.score([mods[:i] + [e] + mods[i + 1:] for _, e in trials])
        j = int(np.argmin(s))
        if s[j] > score + tol:
            return mods, score
        log("prune: dashboard %s off  fitness %.3f -> %.3f" % (trials[j][0], score, s[j]))
        mods = mods[:i] + [trials[j][1]] + mods[i + 1:]
        score = float(s[j])


# ------------------------------------------------------------------------------- the knobs worth a place

AUDIBLE = 0.4                         # a knob whose +-STEP moves the voice less than this is not shown
KNOB_STEP = 0.2                       # how far each candidate is moved (gene travel)
PER_SOURCE = 3                        # at most this many SYNTH knobs on one source
MAX_LEVELS = 2                        # ... and at most this many single-source level knobs (VOL n)
GROUP_SPAN = 0.5                      # a group knob's audibility probe: its sources' levels x(1 -+ this)


def groups(under):
    """the GROUP knobs a voice has: HARMONICS -- every partial but a first-source fundamental --
    when there are two or more; NOISE -- every noise band but a first-source one -> {name: [source
    indices]}"""
    from . import blocks as BL
    first = next((i for i, m in enumerate(under) if BL.is_source(m.kind)), None)
    part = [i for i, m in enumerate(under) if m.kind == "partial" and i != first]
    noise = [i for i, m in enumerate(under) if m.kind == "noise" and i != first]
    out = {}
    if len(part) >= 2:
        out["harmonics"] = part
    if noise:
        out["noise"] = noise
    return out


def choose_synth(ev, mods, k=8):
    """the SYNTH knobs worth a place on the dashboard: every candidate knob of the grown sources
    (CANDS, and the level of every source after the first) moved +-KNOB_STEP of its travel and
    scored by how far the voice moves -- the matcher's own distance, against the matched voice --
    the most audible first, at most PER_SOURCE a source, none under AUDIBLE; the knobs a cell
    piece modulates ahead of all (a modulation is seen) -> [(source index, gene, label, icon)],
    also kept in the dash piece's extra["synth"]"""
    from . import blocks as BL
    from .. import fitness as FT
    upos = [j for j, m in enumerate(mods) if m.kind != "dash" and not is_cell(m.kind)]
    under = [mods[j] for j in upos]
    srcs = [i for i, m in enumerate(under) if BL.is_source(m.kind)]
    cands = []
    for rank, i in enumerate(srcs, start=1):
        m = under[i]
        suffix = "" if rank == 1 else " %d" % rank
        for gene, label, icon in CANDS.get(m.kind, ()):
            if gene not in m.names():
                continue
            if gene == "detune" and sum(q.kind == "tone" for q in under) < 2:
                continue                                 # one tone's detune is only its pitch
            cands.append((i, gene, label + suffix, icon))
        grouped = {j for g in groups(under).values() for j in g}
        if rank > 1 and "level" in m.names() and i not in grouped:
            cands.append((i, "level", "VOL" + suffix, "volume"))
    G = groups(under)
    for name, members in G.items():
        cands.append((-1, name, {"harmonics": "HARMONICS", "noise": "NOISE"}[name],
                      {"harmonics": "wave", "noise": "noise"}[name]))
    dm = [m for m in mods if m.kind == "dash"][0]
    modded = []
    for c in [m for m in mods if is_cell(m.kind)]:
        t = dest_of(under, cell_parts(c.kind)[1])
        if t is not None and t not in modded:
            modded.append(t)
    if not cands:
        dm.extra["synth"] = list(modded)
        return dm.extra["synth"]
    Y0, ok0 = ev.render([mods])
    if not ok0[0]:
        dm.extra["synth"] = list(modded)
        return dm.extra["synth"]
    T0 = FT.Target(Y0[0], 44100, free_gain=True)
    variants, who = [], []
    for c in cands:
        if c[0] < 0:                                     # a group knob: its sources' levels scaled together
            for f in (1.0 - GROUP_SPAN, 1.0 + GROUP_SPAN):
                v = [q.copy() for q in mods]
                for i in G[c[1]]:
                    q = v[upos[i]]
                    j = q.names().index("level")
                    q.g[j] = float(np.clip(q.g[j] * np.sqrt(f), 0.0, 1.0))   # level = gene^2
                variants.append(v)
                who.append(c)
            continue
        m = mods[upos[c[0]]]
        j = m.names().index(c[1])
        for d in (-KNOB_STEP, KNOB_STEP):
            g = float(np.clip(m.g[j] + d, 0.0, 1.0))
            if g != m.g[j]:
                v = [q.copy() for q in mods]
                v[upos[c[0]]].g[j] = g
                variants.append(v)
                who.append(c)
    Y, ok = ev.render(variants)
    sc = np.full(len(variants), 10.0)
    if ok.any():
        sc[ok] = np.asarray(T0.score(Y[ok]), np.float64)
    aud = {}
    for c, x in zip(who, sc):
        aud[c] = max(aud.get(c, 0.0), float(x))
    out, per = list(modded), {}
    for t in modded:
        per[t[0]] = per.get(t[0], 0) + 1
    n_lv = 0
    for c in sorted(aud, key=lambda c: -aud[c]):
        if len(out) >= k or aud[c] < AUDIBLE:
            break
        if any(o[0] == c[0] and o[1] == c[1] for o in out) or (c[0] >= 0 and per.get(c[0], 0) >= PER_SOURCE):
            continue
        if c[1] == "level":
            if n_lv >= MAX_LEVELS:                       # a panel of volume knobs says nothing
                continue
            n_lv += 1
        out.append(c)
        per[c[0]] = per.get(c[0], 0) + 1
    dm.extra["synth"] = out
    dm.extra["audible"] = {"%s" % c[2]: round(aud[c], 3) for c in aud}
    return out


def dests(under):
    """the cell roles a voice can take: the skeleton's always, a source role when it has one"""
    from . import blocks as BL
    out = ["cutoff", "resonance", "vol"]
    if any(BL.is_pitched(m.kind) for m in under):
        out.append("pitch")
    out += [r for r in DEST_GENE if dest_of(under, r) is not None]
    return out


def cell_moves(TA, R, mods, rng=None, explore=1):
    """the cells a sound asks for, as GROW moves (lists of pieces): a timbre that darkens (or
    brightens) over the note -> ENV 2 / ENV 1 onto WAVE, FM, COLOR, POS, SHAPE, WARP, FEEDBACK; a
    brightness that wobbles -> the LFO onto them, at the wobble's rate (the LFO's rate rides along
    as a depth-0 PWM piece, which folds into the skeleton); and `explore` random cells"""
    from . import blocks as BL
    install()
    under = [m for m in mods if m.kind != "dash" and not is_cell(m.kind)]
    have = {m.kind for m in mods if is_cell(m.kind)}
    roles = dests(under)
    timbre = [r for r in ("wave", "fm", "color", "pos", "shape", "warp", "feedback") if r in roles]
    out = []

    def add(src, role, amount, why, pri, extra=()):
        kind = "cell:%s>%s" % (src, role)
        if role in roles and kind not in have:
            out.append((pri, [BL.Module.new(kind, why=why, amount=amount)] + list(extra)))

    dk = float(TA.darkening - R.darkening)
    if abs(dk) > 0.2:
        sign = 1.0 if dk > 0 else -1.0
        why = "the timbre %s %.2f oct more than the voice's" % ("darkens" if dk > 0 else "brightens", abs(dk))
        for r in timbre:
            add("env2", r, 0.3 * sign, why, 10.0 * abs(dk))
            add("env1", r, 0.3 * sign, why, 8.0 * abs(dk))
    if TA.bwob >= 0.05 and R.bwob < 0.5 * TA.bwob:
        rate = float(np.clip(TA.bwob_rate, 0.05, 20.0))
        setter = BL.Module.new("mod:lfo>pw", why="the LFO at the wobble's rate", rate=rate, depth=0.0)
        for r in timbre:
            add("lfo", r, 0.15, "brightness wobbles %.2f oct at %.1f Hz" % (TA.bwob, TA.bwob_rate),
                30.0 * TA.bwob, [setter.copy()])
    if rng is not None and explore:
        pool = ["cell:%s>%s" % (s_, r) for s_ in CELL_SOURCES for r in roles
                if "cell:%s>%s" % (s_, r) not in have]
        for kind in rng.choice(pool, min(explore, len(pool)), replace=False) if pool else ():
            out.append((1.0, [BL.Module.new(str(kind), why="explore: %s" % kind,
                                            amount=float(rng.choice([-0.3, 0.3])))]))
    out.sort(key=lambda q: -q[0])
    return [m for _, m in out]
