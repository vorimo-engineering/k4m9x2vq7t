"""What a note is made of, read the way the builder needs it -- and, from a target and the voice
grown so far, the moves worth trying next.

NOT a cleaning step: the fitness always compares the untouched sound (a flute's breath, a piano's
hammer, a tom's stick and a hat's hiss ARE the sound; the noise piece exists to make them). The
analysis SPLITS the spectrum instead: a peak standing PEAK_DB over the local median floor is a
sinusoid (it places partials and FM carriers: ratio, level, decay); the floor, third-octave band
by band, is the noise (it places noise bands). A long window reads the held part (close partials
apart), a short one the attack.

Every measure is taken the same way on the target and on the current render, so a move is
proposed by a DIFFERENCE (what the target has and the voice does not), never by an absolute
reading of the target alone.
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import median_filter, uniform_filter1d

from .blocks import FM4_PAIR_SINES, FM4_TWO_STACKS, MAX_OF, PITCHED, SOURCES, Module, encode, is_pitched

SR = 44100
N_LONG, HOP_LONG = 8192, 2048                    # 5.4 Hz bins: partials apart
N_DEC, HOP_DEC = 2048, 512                       # a partial's level over time
N_TRK, HOP_TRK = 4096, 441                       # the pitch track, 10 ms
PEAK_DB = 10.0                                   # a sinusoid stands this far over the floor
RANGE_DB = 45.0                                  # peaks within this of the loudest are read
MISS_DB = 6.0                                    # this far under the target's level = missing
EARLY_S = 0.25                                   # the attack window (and a short note's all)
FLOOR_HZ = 250.0                                 # the floor's median is never narrower than this
BANDS = 40.0 * 2.0 ** (np.arange(27) / 3.0)      # third-octave centres, 40 Hz .. 16 kHz
ENV_HOP = 220                                    # 5 ms


def _spec(x, t0, t1, n=N_LONG, hop=HOP_LONG):
    """mean power spectrum (dB) of x between t0 and t1 s, Hann frames of n (zero-padded)"""
    a = int(t0 * SR)
    seg = np.asarray(x[a:max(int(t1 * SR), a + 1)], np.float64)
    if len(seg) < n:
        seg = np.pad(seg, (0, n - len(seg)))
    w = np.hanning(n)
    P = np.mean([np.abs(np.fft.rfft(seg[i:i + n] * w)) ** 2
                 for i in range(0, len(seg) - n + 1, hop)], axis=0)
    return 10.0 * np.log10(P + 1e-20)


def _floor(S, n=N_LONG):
    """the noise floor under a dB spectrum: a third-octave median on a log-frequency grid, but never
    narrower than FLOOR_HZ -- at 65 Hz a third of an octave is three bins, narrower than a sine's own
    Hann lobe, and the fundamental became its own floor: DX7 BASS 1 (32.7 Hz) read with its three
    strongest partials missing, DX7 MARIMBA and TIMPANI without a fundamental, a GM kick without a
    body (2026-10-03)"""
    f = np.fft.rfftfreq(n, 1.0 / SR)
    lf = np.log2(np.maximum(f, 10.0))
    grid = np.arange(np.log2(20.0), np.log2(SR / 2), 1.0 / 48)
    a = np.interp(lf, grid, median_filter(np.interp(grid, lf, S), size=17, mode="nearest"))
    return np.minimum(a, median_filter(S, size=int(round(FLOOR_HZ * n / SR)) | 1, mode="nearest"))


def _peaks(S, F, n=N_LONG, f_lo=25.0):
    """sinusoids: local maxima PEAK_DB over the floor and within RANGE_DB of the loudest ->
    (freq Hz, level dB) by level, parabolically refined"""
    f = np.fft.rfftfreq(n, 1.0 / SR)
    i = np.flatnonzero((S[1:-1] > S[:-2]) & (S[1:-1] >= S[2:])) + 1
    i = i[(S[i] > F[i] + PEAK_DB) & (S[i] > S.max() - RANGE_DB) & (f[i] > f_lo)]
    a, b, c = S[i - 1], S[i], S[i + 1]
    d = 0.5 * (a - c) / np.where(np.abs(a - 2 * b + c) < 1e-9, -1e-9, a - 2 * b + c)
    d = np.clip(d, -0.5, 0.5)
    fq, lv = f[i] + d * SR / n, b - 0.25 * (a - c) * d
    o = np.argsort(-lv)[:40]
    return fq[o], lv[o]


def _level_at(S, fq, n=N_LONG, tol=2):
    k = int(round(fq * n / SR))
    return float(S[max(0, k - tol):k + tol + 1].max()) if 0 <= k < len(S) else -200.0


def _bands(S, n=N_LONG):
    """third-octave band levels (dB, power mean) of a dB spectrum"""
    f = np.fft.rfftfreq(n, 1.0 / SR)
    P = 10.0 ** (S / 10.0)
    out = np.empty(len(BANDS))
    for j, c in enumerate(BANDS):
        m = (f >= c * 2 ** (-1 / 6)) & (f < c * 2 ** (1 / 6))
        out[j] = 10.0 * np.log10(P[m].mean() + 1e-20) if m.any() else -200.0
    return out


class Sound:
    """the measures of one note (target or render), on the same windows"""

    def __init__(self, x, f0, gate_s):
        x = np.asarray(x, np.float64)
        self.x, self.f0, self.gate = x, float(f0), float(gate_s)
        self.dur = len(x) / SR
        # envelope, 5 ms
        e = np.sqrt(np.maximum(uniform_filter1d(x * x, 2 * ENV_HOP)[::ENV_HOP], 0.0) + 1e-20)
        self.env = 20.0 * np.log10(e / e.max())
        self.t = np.arange(len(e)) * ENV_HOP / SR
        # the attack ends where the level first comes within 3 dB of its top (not at the top: on a
        # held tone the top is anywhere -- a 2.5 s sine peaked at 2.3 s and hid its vibrato; and not
        # within 1 dB: a DX7 E.PIANO's body swells 2 dB after the strike, read as a 0.65 s attack)
        ip = int(np.flatnonzero(self.env >= -3.0)[0])
        self.attack = max(0.001, self.t[ip])
        g = min(len(e) - 1, int(self.gate * SR / ENV_HOP))
        if self.gate - self.attack > 0.15:
            seg = self.env[int(0.6 * g):g + 1]
            self.sus_db = float(np.median(seg)) if seg.size else -60.0
        else:
            self.sus_db = -60.0
        self.sustain = float(10 ** (self.sus_db / 20)) if self.sus_db > -40 else 0.0
        target = (self.sus_db if self.sustain > 0 else -60.0)
        half = 0.5 * target                               # half way (dB) from the peak to the sustain
        after = np.flatnonzero(self.env[ip:] <= half)
        self.decay = float(np.clip((after[0] if after.size else len(e) - ip) * ENV_HOP / SR * 2.5, 0.01, 12.0))
        tail = self.env[g:]
        drop = np.flatnonzero(tail <= tail[0] - 30.0) if tail.size else np.array([])
        self.tail = float(drop[0] * ENV_HOP / SR) if drop.size else float(tail.size * ENV_HOP / SR)
        self.release = float(np.clip(2.0 * self.tail, 0.01, 12.0))
        # spectra: the attack and the held part (a short note: the attack window is all)
        t_hold = (max(EARLY_S, self.attack + 0.05), max(self.gate, EARLY_S + 0.2))
        self.windows = {"early": (0.0, min(EARLY_S + 0.1, self.dur))}
        if t_hold[1] - t_hold[0] > 0.2 and t_hold[0] < self.dur:
            self.windows["held"] = (t_hold[0], min(t_hold[1], self.dur))
        self.S, self.F, self.pk, self.noise, self.band = {}, {}, {}, {}, {}
        for w, (a, b) in self.windows.items():
            S = _spec(x, a, b)
            F = _floor(S)
            self.S[w], self.F[w] = S, F
            self.pk[w] = _peaks(S, F)
            self.noise[w] = _bands(F)
            self.band[w] = _bands(S)
        self.top = max(float(self.S[w].max()) for w in self.S)
        # the first 30 ms over 2 kHz against the whole early window: a click
        self.click = self._hf(0.0, 0.03) - self._hf(0.0, min(0.3, self.dur))
        self._pitch_track()
        self._wobble()
        c_e = self._centroid(self.S["early"])
        c_h = self._centroid(self.S["held"]) if "held" in self.S else c_e
        self.darkening = float(np.log2(c_e / c_h))         # octaves the brightness falls
        self.centroid = c_e

    def _hf(self, a, b):
        S = _spec(self.x, a, b, n=1024, hop=256)
        f = np.fft.rfftfreq(1024, 1.0 / SR)
        return float(10 * np.log10(np.mean(10 ** (S[f > 2000] / 10)) + 1e-20))

    @staticmethod
    def _centroid(S, n=N_LONG):
        f = np.fft.rfftfreq(n, 1.0 / SR)
        P = 10 ** (S / 10)
        return float((f * P).sum() / (P.sum() + 1e-20) + 1.0)

    def _frames(self, t0, t1, n=N_TRK, hop=HOP_TRK, nfft=None):
        """(time of the frame's centre, dB spectrum) of Hann frames of n, zero-padded to nfft"""
        a, b = int(t0 * SR), int(t1 * SR)
        x = self.x
        w = np.hanning(n)
        nfft = nfft or n
        out = []
        for i in range(a, max(a + 1, b - n), hop):
            seg = x[i:i + n]
            if len(seg) < n:
                break
            out.append(((i + n / 2) / SR, 20 * np.log10(np.abs(np.fft.rfft(seg * w, nfft)) + 1e-12)))
        return out

    def _track(self, frames, lo, hi, n=N_TRK):
        f = np.fft.rfftfreq(n, 1.0 / SR)
        m = np.flatnonzero((f >= lo) & (f <= hi))
        if m.size < 3:
            return np.array([]), np.array([]), np.array([])
        T, Fq, L = [], [], []
        for t, S in frames:
            k = m[int(np.argmax(S[m]))]
            if 0 < k < len(S) - 1:
                a, b, c = S[k - 1], S[k], S[k + 1]
                den = a - 2 * b + c
                d = 0.5 * (a - c) / den if abs(den) > 1e-9 else 0.0
                T.append(t)
                Fq.append(f[k] + float(np.clip(d, -0.5, 0.5)) * SR / n)
                L.append(b)
        return np.array(T), np.array(Fq), np.array(L)

    def _pitch_track(self):
        """the fall of the strongest low peak over the first 0.4 s (a drum's pitch sweep)"""
        self.drop, self.drop_t = 0.0, 0.05
        # SHORT frames (23 ms, zero-padded to 8192 for the frequency): a 93 ms frame smeared a GM
        # low tom's fall to 2.5 st where the search then found 9.8 (2026-10-03)
        fr = self._frames(0.0, min(0.45, self.dur), n=1024, hop=128, nfft=8192)
        T, Fq, L = self._track(fr, 0.7 * self.f0, 8.0 * self.f0, n=8192)
        if T.size < 8:
            return
        ok = L > L.max() - 30.0
        T, Fq = T[ok], Fq[ok]
        if T.size < 8:
            return
        late = Fq[T >= min(0.1, T[-1] * 0.6)]
        f_end = float(np.median(late)) if late.size else float(Fq[-1])
        st = 12.0 * np.log2(Fq / f_end)
        # a fall that is exponential in semitones, fitted and read at the onset: a frame of 23 ms
        # sees a 30 ms fall already half gone (12 st read as 7.5 from the first frames)
        m = (st > 0.3) & (T <= T[0] + 0.15)
        if m.sum() >= 3:
            k, c = np.polyfit(T[m], np.log(st[m]), 1, w=np.sqrt(st[m]))
            if k < 0:
                self.drop = float(np.clip(np.exp(c), 0.0, 36.0))
                self.drop_t = float(np.clip(-1.0 / k, 0.003, 2.0))
                return
        self.drop = float(max(0.0, np.median(st[:3])))

    def _wobble(self):
        """vibrato (cents of the strongest of harmonics 1..6, detrended) and level wobble (dB). A held
        part of LONG_HOLD or more is detrended by a straight line instead of a 0.5 s average, the
        brightness and level rates read down to 0.25 Hz: a slow LFO (the analog strings' 0.35..0.55 Hz
        pulse width) has cycles to read on a long note, where on a 1.2 s one it is an envelope's
        bend (results.md section 29)"""
        self.vib, self.vib_rate, self.wob, self.wob_rate = 0.0, 5.0, 0.0, 1.0
        self.bwob, self.bwob_rate = 0.0, 1.0
        a = max(0.2, self.attack + 0.1)
        b = min(self.gate, self.dur)
        if b - a < 0.6:
            return
        slow = b - a >= LONG_HOLD

        def detrend(y, win):
            if slow:
                t = np.arange(len(y), dtype=np.float64)
                return y - np.polyval(np.polyfit(t, y, 1), t)
            return y - uniform_filter1d(y, win, mode="nearest")
        # 93 ms frames zero-padded to 16384 (2.7 Hz bins): a semitone either side of a 220 Hz
        # harmonic held two 10.8 Hz bins, too few to track (a 30-cent vibrato read as none)
        nf = 16384
        fr = self._frames(a, b, nfft=nf)
        if len(fr) < 40:
            return
        lv = [np.mean([S[int(round(h * self.f0 * nf / SR))] for _, S in fr])
              if h * self.f0 < 0.45 * SR else -300.0 for h in range(1, 7)]
        h = 1 + int(np.argmax(lv))
        T, Fq, _ = self._track(fr, h * self.f0 * 2 ** (-1 / 12), h * self.f0 * 2 ** (1 / 12), n=nf)
        if T.size >= 40:
            c = 1200.0 * np.log2(Fq / (h * self.f0))
            c = c - uniform_filter1d(c, 50, mode="nearest")
            self.vib = float(np.sqrt(np.mean(c * c)))
            self.vib_rate = self._rate(c, 2.0, 12.0)
        f = np.fft.rfftfreq(nf, 1.0 / SR)
        cen = []
        for _, S in fr:
            P = 10 ** (S / 10)
            cen.append(np.log2((f * P).sum() / (P.sum() + 1e-20) + 1.0))
        cen = np.asarray(cen)
        if cen.size >= 40:
            cen = detrend(cen, 50)
            self.bwob = float(np.sqrt(np.mean(cen * cen)))             # octaves rms
            self.bwob_rate = self._rate(cen, 0.25 if slow else 0.3, 12.0)
        e = self.env[int(a * SR / ENV_HOP):int(b * SR / ENV_HOP)]
        if e.size >= 100:
            e = detrend(e, 100)
            self.wob = float(np.sqrt(np.mean(e * e)))
            self.wob_rate = self._rate(e[::2], 0.25 if slow else 0.5, 12.0)

    @staticmethod
    def _rate(c, lo, hi, fs=100.0):
        F = np.abs(np.fft.rfft(c * np.hanning(len(c))))
        f = np.fft.rfftfreq(len(c), 1.0 / fs)
        m = (f >= lo) & (f <= hi)
        return float(f[m][np.argmax(F[m])]) if m.any() else 5.0

    def partial_decay(self, fq):
        """(attack, decay, sustain) of the sinusoid at fq, read off its own level track"""
        fr = self._frames(0.0, self.dur, n=N_DEC, hop=HOP_DEC)
        if len(fr) < 3:
            return self.attack, self.decay, self.sustain
        k = int(round(fq * N_DEC / SR))
        lv = np.array([S[max(0, k - 1):k + 2].max() for _, S in fr])
        t = np.array([t for t, _ in fr]) + N_DEC / 2 / SR
        ip = int(np.argmax(lv))
        rel = lv - lv[ip]
        g = np.flatnonzero(t >= self.gate)
        sus_db = float(np.median(rel[max(ip, int(0.6 * (g[0] if g.size else len(t)))):(g[0] if g.size else len(t))])) \
            if (g.size and g[0] > ip + 2) else -60.0
        sus = float(10 ** (sus_db / 20)) if sus_db > -40 else 0.0
        below = np.flatnonzero(rel[ip:] <= 0.5 * (sus_db if sus > 0 else -40.0))
        dec = float(np.clip((t[ip + below[0]] - t[ip]) * 2.5 if below.size else self.decay, 0.01, 12.0))
        return max(0.001, float(t[ip] - t[0])), dec, sus


def harmonic_shape(T):
    """an osc.va shape to start a tone from: sine when the harmonics are faint, square-ish when
    the odd ones lead, else saw"""
    w = "held" if "held" in T.S else "early"
    S = T.S[w]
    h = [_level_at(S, k * T.f0) for k in range(1, 9) if k * T.f0 < 0.45 * SR]
    if len(h) < 3:
        return 2 / 3
    h = np.array(h) - h[0]
    if np.max(h[1:]) < -30.0:
        return 0.0
    odd, even = h[2::2], h[1::2]
    if odd.size and even.size and np.mean(odd) - np.mean(even) > 10.0:
        return 1.0
    return 2 / 3


def fm_ratio(r):
    """a modulator ratio -> (the nearest plateau, the fine detune in %)"""
    from .blocks import FM_RATIOS
    p = min(FM_RATIOS, key=lambda q: abs(np.log(max(r, 1e-3) / q)))
    return p, float(np.clip(100.0 * (r / p - 1.0), -3.0, 3.0))


def fm_explain(T, w="early", n_top=6, tol=0.01):
    """the FM pairs that sound most of the note's peaks -> [(weight, peaks explained, carrier,
    modulator)], best first. Candidates come from pairs of the n_top loudest peaks a < b (a carrier c
    and a modulator m sound |c + k m|: (c, m) = ((b + a)/2, (b - a)/2) or the other way, m snapped to
    a plateau); each is scored by the level-weighted count of peaks within tol of some |c + k m|,
    k = -6..6. DX7 TUB BELLS: 1 : 3.5 explains all eleven of its peaks"""
    fq, lv = T.pk[w]
    if fq.size < 2:
        return []
    r = fq / T.f0
    wt = 10 ** ((lv - T.top) / 20)
    idx = np.argsort(-lv)[:n_top]
    cands = set()
    for i in idx:
        for j in idx:
            if r[j] <= r[i]:
                continue
            a, b = r[i], r[j]
            for c, m in (((b + a) / 2, (b - a) / 2), ((b - a) / 2, (b + a) / 2)):
                if 0.25 <= c <= 16.0 and 0.45 <= m <= 16.5:
                    pl, mf = fm_ratio(m)
                    cands.add((round(c, 4), pl, round(mf, 3)))
    out = []
    for c, pl, mf in cands:
        m = pl * (1 + mf / 100)
        sb = np.abs(c + np.arange(-6, 7)[:, None] * m)
        hit = np.min(np.abs(r[None, :] / np.maximum(sb, 1e-6) - 1), axis=0) < tol
        out.append((float((wt * hit).sum()), int(hit.sum()), c, pl, mf))
    out.sort(key=lambda q: (-q[0], q[2]))
    return out


def _coarse_fine(r):
    """a ratio -> (the DX7 coarse step nearest it, the fine detune in %, within +-50)"""
    from .blocks import FM_RATIOS
    c = min(FM_RATIOS, key=lambda q: abs(np.log(max(r, 1e-3) / q)))
    return c, float(np.clip(100.0 * (r / c - 1.0), -50.0, 50.0))


def fm4_start(T, fallback=False):
    """FOUR OPERATORS started on the analysis: the two FM pairs that sound the most peaks
    (fm_explain), each a stack of algorithm 4 (2 -> 1, 4 -> 3) -- a carrier's envelope its own
    peak's decay and its level by how much of the note its pair explains, a modulator's envelope
    the note's decay (the brightness falls with it) -> [one fm4 piece], or None when fewer than two
    pairs sound three peaks each (a single pair is the `fm` start's). fallback (a recipe that asks
    for four operators): one pair and two sines on the loudest other peaks (algorithm 6), or four
    sines on the four loudest (8)"""
    pairs = []
    for wgt, k, c, pl, mf in fm_explain(T)[:12]:
        if k >= 3 and all(abs(c - q[0]) > 0.02 or abs(pl - q[1]) > 0.02 for q in pairs):
            pairs.append((c, pl, mf, wgt))
        if len(pairs) == 2:
            break
    if len(pairs) < 2:
        return _fm4_fallback(T, pairs) if fallback else None
    phys = dict(algo=FM4_TWO_STACKS, fb=0.0, level=0.8)
    top = max(q[3] for q in pairs)
    for (c, pl, mf, wgt), (kc, km) in zip(pairs, ((1, 2), (3, 4))):
        rc, fc = _coarse_fine(c)
        att, dec, sus = T.partial_decay(c * T.f0)
        phys.update({"rat%d" % kc: rc, "fin%d" % kc: fc, "lev%d" % kc: float(np.clip(np.sqrt(wgt / top), 0.2, 1.0)),
                     "att%d" % kc: att, "dec%d" % kc: dec, "sus%d" % kc: sus, "rel%d" % kc: T.release})
        rm, fm_ = _coarse_fine(pl * (1.0 + mf / 100.0))
        phys.update({"rat%d" % km: rm, "fin%d" % km: fm_, "lev%d" % km: 0.5, "att%d" % km: 0.001,
                     "dec%d" % km: max(T.decay, 0.05), "sus%d" % km: 0.3, "rel%d" % km: T.release})
    return [Module.new("fm4", why="start: four operators, FM pairs %.2f : %.2f and %.2f : %.2f" % (
        pairs[0][0], pairs[0][1] * (1 + pairs[0][2] / 100), pairs[1][0], pairs[1][1] * (1 + pairs[1][2] / 100)), **phys)]


FM4_STACK2 = ("algo", "rat3", "fin3", "lev3", "att3", "dec3", "sus3", "rel3", "rat4", "fin4", "lev4", "att4", "dec4",
              "sus4", "rel4", "level")


def fm4_upgrades(T, R, mods):
    """FOUR OPERATORS GROWN FROM A PAIR (2026-10-04: a four-operator START never won -- 31 genes
    from scratch screened 10..20 on every dev sound): the voice's first FM pair becomes stack 1 of
    algorithm 4 -- its ratios, envelopes and feedback, its index as the modulator's depth (1 : 1,
    measured: the pair's spectrum within ~1 dB) -- and stack 2 is the next FM pair the analysis
    proposes for the peaks the render R lacks -> [Replace] whose `tune_only` names what a step
    tunes: stack 2, the algorithm, the level (the tuned pair stays as it was)"""
    if any(m.kind == "fm4" for m in mods):
        return []
    i = next((j for j, m in enumerate(mods) if m.kind == "fm"), None)
    if i is None:
        return []
    news = [mv[0] for mv in moves(T, R, mods) if not isinstance(mv, Replace) and len(mv) == 1 and mv[0].kind == "fm"]
    if not news:
        return []
    o, q = mods[i].p(), news[0].p()
    c1 = mods[i].ratio * 2.0 ** (o["tune"] / 1200.0)
    m1 = o["mratio"] * (1.0 + o["mfine"] / 100.0)
    c2 = news[0].ratio * 2.0 ** (q["tune"] / 1200.0)
    m2 = q["mratio"] * (1.0 + q["mfine"] / 100.0)
    phys = dict(algo=FM4_TWO_STACKS, fb=o["mfb"], level=float(min(1.0, 1.5 * o["level"])))
    for k, r, lev, env in ((1, c1, 1.0, (o["att"], o["dec"], o["sus"], o["rel"])),
                           (2, m1, min(1.0, o["index"]), (0.001, o["idec"], o["isus"], o["rel"])),
                           (3, c2, float(np.clip(q["level"] / max(o["level"], 1e-3), 0.05, 1.0)),
                            (q["att"], q["dec"], q["sus"], q["rel"])),
                           (4, m2, min(1.0, q["index"]), (0.001, q["idec"], q["isus"], q["rel"]))):
        rc, fc = _coarse_fine(r)
        phys.update({"rat%d" % k: rc, "fin%d" % k: fc, "lev%d" % k: lev, "att%d" % k: env[0], "dec%d" % k: env[1],
                     "sus%d" % k: env[2], "rel%d" % k: env[3]})
    up = Replace(i, Module.new("fm4", why="four operators: the FM pair x%.2f : %.2f and %s" % (c1, m1, news[0].why), **phys))
    up.tune_only = FM4_STACK2
    return [up]


def _fm4_fallback(T, pairs):
    """four operators on fewer than two pairs: the pair (carrier 1, modulator 2) and sines 3 and 4
    on the loudest peaks it does not sound (algorithm 6), or four sines (8)"""
    w = "held" if "held" in T.pk else "early"
    fq, lv = T.pk[w]
    peaks = [(float(f / T.f0), float(l)) for f, l in sorted(zip(fq, lv), key=lambda q: -q[1]) if 0.25 <= f / T.f0 <= 16.0]
    phys, ops = dict(fb=0.0, level=0.8), []
    if pairs:
        c, pl, mf, _ = pairs[0]
        phys["algo"] = FM4_PAIR_SINES
        ops = [(1, c, 0.8, None), (2, pl * (1.0 + mf / 100.0), 0.5, "mod")]
        sb = [abs(c + k * pl * (1.0 + mf / 100.0)) for k in range(-6, 7)]
        peaks = [q for q in peaks if min(abs(q[0] / max(b, 1e-6) - 1) for b in sb) > 0.01]
        free = (3, 4)
    else:
        phys["algo"] = 8.0
        free = (1, 2, 3, 4)
    for k, (r, l) in zip(free, peaks):
        ops.append((k, r, float(np.clip(10 ** ((l - T.top + 6) / 20), 0.05, 1.0)), None))
    if not ops:
        return None
    for k, r, lev, role in ops:
        rc, fc = _coarse_fine(r)
        if role == "mod":
            att, dec, sus = 0.001, max(T.decay, 0.05), 0.3
        else:
            att, dec, sus = T.partial_decay(r * T.f0)
        phys.update({"rat%d" % k: rc, "fin%d" % k: fc, "lev%d" % k: lev, "att%d" % k: att, "dec%d" % k: dec,
                     "sus%d" % k: sus, "rel%d" % k: T.release})
    for k in range(1, 5):
        if not any(q[0] == k for q in ops):
            phys["lev%d" % k] = 0.0                     # an operator nothing asked for is silent
    return [Module.new("fm4", why="start: four operators, %s" % ("a pair and sines" if pairs else "four sines"), **phys)]


def swept_body(T, why):
    """a sine at the note falling from T.drop semitones above it: a drum's body, which the
    sinusoid reading cannot see (a sweep is no peak) -- the pitch envelope needs a pitched source
    to act on, so the two come as one move"""
    return [Module.new("partial", 1.0, why=why, att=0.001, dec=max(T.decay, 0.05), sus=0.0, rel=T.release),
            Module.new("pitchenv", why=why, depth=T.drop, pdec=T.drop_t)]


def templates(T):
    """whole small voices, one per FAMILY of sound, as starts: what growth cannot reach by adding
    one piece at a time. A saw is a string section or a brass only WITH its filter (2026-10-03: a
    bare saw lost the start to FM on DX7 STRINGS 1, BRASS 1, ORCHESTRA, VOICE 1, and a voice that
    only grows never turns into a filtered saw) -> [(name, pieces)], each started where the
    analysis read the note"""
    env = dict(att=T.attack, dec=T.decay, sus=T.sustain, rel=T.release)
    shape = harmonic_shape(T)
    shape = 2 / 3 if shape == 0.0 else shape
    flt = dict(cut=float(np.clip(2.5 * T.centroid, 100.0, 16000.0)), res=0.15, morph=0.0,
               fenv=float(np.clip(1.0 + 2.0 * max(T.darkening, 0.0), 0.5, 6.0)), fatt=T.attack,
               fdec=max(T.decay, 0.05), fsus=0.3, key=0.5)
    out = [("subtractive", [Module.new("tone", why="template: subtractive (a saw through a filter)", shape=shape, **env),
                            Module.new("filter", why="template: subtractive", **flt)]),
           ("ensemble", [Module.new("tone", why="template: ensemble (two detuned saws, a chorus)", shape=shape,
                                    detune=-9.0, level=0.6, **env),
                         Module.new("tone", why="template: ensemble", shape=shape, detune=9.0, level=0.6, **env),
                         Module.new("filter", why="template: ensemble", **flt),
                         Module.new("chorus", why="template: ensemble", rate=0.6, depth=0.5, mix=0.4)])]
    # additive: the harmonic peaks, each with its own decay
    w = "held" if "held" in T.pk else "early"
    harm = []
    for f, l in zip(*T.pk[w]):
        r = f / T.f0
        k = int(round(r))
        if 1 <= k <= 16 and abs(r / k - 1) < 0.012 and k not in [h for h, _ in harm]:
            harm.append((k, l))
    if len(harm) >= 3:
        mods = []
        for k, l in sorted(harm[:6]):
            att, dec, sus = T.partial_decay(k * T.f0)
            mods.append(Module.new("partial", float(k), why="template: additive, harmonic %d" % k,
                                   level=float(np.clip(10 ** ((l - T.top + 6) / 20), 0.03, 1.0)), att=att, dec=dec,
                                   sus=sus, rel=T.release))
        out.append(("additive", mods))
    # bell (modal): the loudest INHARMONIC peaks of the attack, each with its own decay
    inh = []
    for f, l in zip(*T.pk["early"]):
        r = f / T.f0
        k = max(1, int(round(r)))
        if 0.25 <= r <= 16.0 and abs(r / k - 1) >= 0.012 and all(abs(r / q - 1) > 0.01 for q, _ in inh):
            inh.append((r, l))
    if len(inh) >= 2:
        mods = []
        for r, l in inh[:3]:
            att, dec, sus = T.partial_decay(r * T.f0)
            mods.append(Module.new("partial", float(r), why="template: bell, partial x%.3f" % r,
                                   level=float(np.clip(10 ** ((l - T.top + 6) / 20), 0.03, 1.0)), att=att, dec=dec,
                                   sus=sus, rel=T.release))
        out.append(("bell", mods))
    # drum: a body (falling when the note falls) and a click
    if T.drop >= 1.0 or (T.sustain == 0.0 and T.decay < 0.6):
        body = swept_body(T, "template: drum body") if T.drop >= 1.0 else [
            Module.new("partial", 1.0, why="template: drum body", att=0.001, dec=max(T.decay, 0.05), sus=0.0, rel=T.release)]
        out.append(("drum", body + [Module.new("noise", why="template: drum click", freq=5000.0, res=0.1, morph=1.0,
                                               level=0.4, att=0.001, dec=0.02, sus=0.0, rel=0.02)]))
    # the FULL KIT's families (kit.py): the analog filters, the wavetable, the morph, phase
    # distortion, a pulse-width-modulated string machine
    from . import kit as KT
    KT.install()
    kflt = dict(cutoff=float(np.clip(2.5 * T.centroid, 100.0, 16000.0)), res=0.2,
                fenv=float(np.clip(1.0 + 2.0 * max(T.darkening, 0.0), 0.5, 6.0)), fatt=T.attack,
                fdec=max(T.decay, 0.05), fsus=0.3, key=0.5)
    for name, block in (("analog", "filter.ladder"), ("acid", "filter.acid"), ("ms20", "filter.sk")):
        out.append((name, [Module.new("tone", why="template: %s (a saw through %s)" % (name, block), shape=shape, **env),
                           Module.new("flt:" + block, why="template: " + name, **kflt)]))
    out.append(("wavetable", [Module.new("src:osc.table", why="template: wavetable", pos=0.5, **env),
                              Module.new("filter", why="template: wavetable", **flt)]))
    out.append(("morph", [Module.new("src:osc.morph", why="template: morph oscillator", **env)]))
    out.append(("pd", [Module.new("src:osc.pd", why="template: phase distortion", warp=0.5, **env)]))
    out.append(("pwm", [Module.new("tone", why="template: PWM strings", shape=1.0, pw=0.3, **env),
                        Module.new("mod:lfo>pw", why="template: PWM strings", rate=0.8, depth=0.15),
                        Module.new("filter", why="template: PWM strings", **flt),
                        Module.new("fx:fx.ensemble", why="template: PWM strings")]))
    # noise in two bands: the body at the centroid and the air above it
    if T.noise["early"][-6:].max() > T.noise["early"].max() - 30.0:
        out.append(("noise2", [Module.new("noise", why="template: noise at the centroid",
                                          freq=float(np.clip(T.centroid, 60.0, 15000.0)), res=0.2, **env),
                               Module.new("noise", why="template: noise air", freq=8000.0, res=0.1, morph=1.0,
                                          level=0.3, **env)]))
    return out


def starts(T, templates_on=True):
    """the first voices to try (each a list of pieces), started where the analysis read the note:
    single sources, the structures read off the sound (FM pairs that explain its peaks, a falling
    body), and -- templates_on -- the hand-written family templates"""
    env = dict(att=T.attack, dec=T.decay, sus=T.sustain, rel=T.release)
    w = "held" if "held" in T.pk else "early"
    fq, lv = T.pk[w]
    out = [[Module.new("tone", why="start: harmonic source", shape=harmonic_shape(T), **env)],
           [Module.new("partial", 1.0, why="start: a sine at the note", **env)]]
    if fq.size:
        r = float(fq[0] / T.f0)
        if 0.25 <= r <= 16.0 and abs(r - 1.0) > 0.02:
            out.append([Module.new("partial", r, why="start: the loudest peak, x%.3f" % r, **env)])
        out.append([Module.new("fm", r if 0.25 <= r <= 16.0 else 1.0, why="start: FM on the loudest peak",
                               index=0.6, idec=T.decay, isus=0.3, **env)])
    seen = set()
    for wgt, k, c, pl, mf in fm_explain(T)[:6]:
        if len(seen) == 2:
            break
        if k >= 3 and (c, pl) not in seen:
            seen.add((c, pl))
            out.append([Module.new("fm", c, why="start: FM %.2f : %.2f explains %d peaks" % (c, pl * (1 + mf / 100), k),
                                   mratio=pl, mfine=mf, index=0.6, idec=T.decay, isus=0.3, **env)])
    if T.drop >= 1.0:
        out.append(swept_body(T, "start: a body falling %.1f st in %.0f ms" % (T.drop, 1000 * T.drop_t)))
    out.append([Module.new("noise", why="start: noise at the centroid %.0f Hz" % T.centroid,
                           freq=float(np.clip(T.centroid, 60.0, 15000.0)), res=0.2, **env)])
    out.append([Module.new("pluck", why="start: a plucked string", decay=float(np.clip(T.decay * 2, 0.05, 20.0)),
                           rel=T.release)])
    return out + ([mods for _, mods in templates(T)] if templates_on else [])


class Replace:
    """a move that swaps the piece at `index` for `piece` (its role kept: the same envelope and
    level for a source, the same cutoff, resonance and envelope for a filter)"""

    def __init__(self, index, piece):
        self.index, self.piece = index, piece
        self.kind, self.why = piece.kind, piece.why

    def __iter__(self):                       # read like an add move's pieces where only kinds are read
        return iter([self.piece])


def _carry(old, kind, why):
    """a new piece of `kind` with every physical value `old` has under the same name (svf cut -> cutoff)"""
    names = [sp[0] for sp in __import__("dnasynth.grow.blocks", fromlist=["KINDS"]).KINDS[kind]]
    p = old.p()
    if "cut" in p:
        p["cutoff"] = p["cut"]
    if "cutoff" in p and "cut" in names:
        p["cut"] = p["cutoff"]
    return Module.new(kind, why=why, **{k: v for k, v in p.items() if k in names and not isinstance(v, str)})


BULK_PARTIALS = 6                    # a bulk move's partials at most
REVERB_TAIL = 0.6                    # a tail (30 dB under, after the gate) this long gets a room offered
LONG_HOLD = 3.0                      # a held part this long (s) is read for SLOW wobbles too (Sound._wobble)
PITCHED_KINDS = ("tone", "partial", "fm", "pluck", "src:osc.table", "src:osc.morph", "src:osc.pd")


def source_swaps(mods, rng=None, first=2):
    """ANOTHER KIND OF OSCILLATOR in a pitched source's place (the first `first` of them): its
    envelope and level carried (_carry), its analysed ratio kept, a full-kit oscillator started
    where kit_moves starts one -- so a build that began as a sine can become an FM pair or a
    wavetable without being rebuilt (rng: the order they are offered in, varied per step)"""
    from . import kit as KT
    KT.install()
    out = []
    for i in [i for i, m in enumerate(mods) if is_pitched(m.kind)][:first]:
        old = mods[i]
        for kind in PITCHED_KINDS:
            if kind == old.kind:
                continue
            m = _carry(old, kind, "swap the %s for %s" % (old.kind, kind))
            m.ratio = old.ratio
            extra = dict(pos=0.5) if kind == "src:osc.table" else dict(warp=0.5) if kind == "src:osc.pd" else {}
            for k, v in extra.items():
                m.g[m.names().index(k)] = encode(KINDS_OF(kind)[m.names().index(k)], v)
            out.append(Replace(i, m))
    if rng is not None and out:
        out = [out[j] for j in rng.permutation(len(out))]
    return out


def kit_moves(T, R, mods, rng=None, explore=3):
    """the FULL KIT's moves (kit.py): another filter type where a filter is proposed or present,
    another oscillator where a tone is, the modulations a measured wobble names, effect variants,
    and `explore` random kit pieces each step (any block can be tried without a trigger)"""
    from . import kit as KT
    KT.install()
    out = []
    have = [m.kind for m in mods]
    main = [i for i, m in enumerate(mods) if m.kind == "filter" or m.kind.startswith("flt:")]
    if main:                                            # replace the main filter by every other type
        old = mods[main[0]]
        for kind in ("filter",) + KT.KINDS_BY_ROLE["flt"]:
            if kind != old.kind:
                out.append((8.0, Replace(main[0], _carry(old, kind, "replace %s by %s" % (old.kind, kind)))))
    tones = [i for i, m in enumerate(mods) if m.kind == "tone"]
    if tones:                                           # another oscillator in the first tone's place
        old = mods[tones[0]]
        for kind in KT.KINDS_BY_ROLE["src"]:
            extra = dict(pos=0.5) if kind == "src:osc.table" else dict(warp=0.5) if kind == "src:osc.pd" else {}
            m = _carry(old, kind, "replace the tone by %s" % kind)
            for k, v in extra.items():
                m.g[m.names().index(k)] = encode(KINDS_OF(kind)[m.names().index(k)], v)
            out.append((6.0, Replace(tones[0], m)))
    has_flt = bool(main)
    if T.bwob >= 0.05 and R.bwob < 0.5 * T.bwob:
        if has_flt and "mod:lfo>cut" not in have:
            out.append((40.0 * T.bwob + 5, [Module.new("mod:lfo>cut", why="brightness wobbles %.2f oct at %.1f Hz" % (
                T.bwob, T.bwob_rate), rate=float(np.clip(T.bwob_rate, 0.05, 20.0)),
                depth=float(np.clip(2.0 * T.bwob, 0.1, 4.0)))]))
        if any(m.kind in ("src:osc.table", "src:osc.morph") for m in mods) and "mod:lfo>pos" not in have:
            out.append((30.0 * T.bwob + 4, [Module.new("mod:lfo>pos", why="brightness wobbles: the wavetable's position",
                                                       rate=float(np.clip(T.bwob_rate, 0.05, 20.0)), depth=0.2)]))
        if any(m.kind == "tone" for m in mods) and "mod:lfo>pw" not in have:
            out.append((30.0 * T.bwob + 4, [Module.new("mod:lfo>pw", why="brightness wobbles: pulse-width modulation",
                                                       rate=float(np.clip(T.bwob_rate, 0.05, 20.0)), depth=0.15)]))
    if T.darkening - R.darkening > 0.3 and any(m.kind in ("src:osc.table", "src:osc.morph") for m in mods) \
            and "mod:env>pos" not in have:
        out.append((5.0, [Module.new("mod:env>pos", why="the timbre darkens: an envelope on the position",
                                     depth=-0.4, att=0.001, dec=max(T.decay, 0.05), sus=0.3)]))
    if T.tail - R.tail > 0.25:                          # the room's alternatives
        for kind in ("fx:fx.hall", "fx:fx.reverb"):
            if kind not in have:
                out.append((3.0 * (T.tail - R.tail), [Module.new(kind, why="tail %.2f s vs %.2f s" % (T.tail, R.tail))]))
    elif T.tail >= REVERB_TAIL and not any(k in have for k in ("room", "fx:fx.reverb", "fx:fx.hall")):
        out.append((2.0 + T.tail, [Module.new("fx:fx.hall", why="a %.1f s tail: a hall, not the release?" % T.tail)]))
    if T.wob >= 1.0 and R.wob < 0.5 * T.wob:            # the chorus's alternatives
        for kind in ("fx:fx.ensemble", "fx:fx.phaser"):
            if kind not in have:
                out.append((1.2 * T.wob, [Module.new(kind, why="level wobble %.1f dB" % T.wob)]))
    w = "held" if "held" in T.band and "held" in R.band else "early"
    lo = R.band[w][:4] - T.band[w][:4]                  # the render too heavy below ~70 Hz
    if lo.max() >= 8.0 and not any(m.kind == "hp:filter.hp1" for m in mods):
        j = int(np.argmax(lo < 3.0)) if (lo < 3.0).any() else 4
        out.append((lo.max(), [Module.new("hp:filter.hp1", why="the render %.0f dB too heavy under %.0f Hz" % (
            lo.max(), BANDS[j]), cutoff=float(BANDS[j]))]))
    if rng is not None and explore:                     # any kit piece, without a trigger
        pool = [k for r in ("ins", "fx", "hp") for k in KT.KINDS_BY_ROLE[r] if k not in have]
        if has_flt:
            pool += [k for k in ("mod:lfo>cut",) if k not in have]
        if not has_flt:
            pool += list(KT.KINDS_BY_ROLE["flt"])
        if pool:
            for k in rng.choice(pool, min(explore, len(pool)), replace=False):
                init = dict(cutoff=float(np.clip(2.5 * T.centroid, 100.0, 16000.0))) if str(k).startswith("flt:") else {}
                out.append((1.0, [Module.new(str(k), why="explore: %s" % k, **init)]))
    return out


def KINDS_OF(kind):
    from .blocks import KINDS
    return KINDS[kind]


def moves(T, R, mods, rng=None):
    """what the target has and the render R of `mods` lacks -> candidate pieces, best first (an add
    move is a list of pieces; a Replace swaps one); the full kit's moves (kit_moves) beside the
    analysis's own"""
    have = {}
    for m in mods:
        have[m.kind] = have.get(m.kind, 0) + 1
    from .blocks import is_pitched
    pitched = any(is_pitched(m.kind) for m in mods)
    out = []                                             # (priority, Module)
    # 1. missing sinusoids, in either window
    seen = []
    for w in T.pk:
        if w not in R.S:
            continue
        for fq, lv in zip(*T.pk[w]):
            r = fq / T.f0
            if not 0.25 <= r <= 16.0 or any(abs(fq / s - 1) < 0.01 for s in seen):
                continue
            have_db = _level_at(R.S[w], fq)
            deficit = lv - have_db
            rel = lv - T.top
            if deficit < MISS_DB or rel < -40.0:
                continue
            # by the ENERGY missing (target minus render, relative to the loudest peak): a strong
            # harmonic half-made outranks a faint one wholly absent (the drawbar organ's 15th
            # harmonic, absent, -35 dB, went before its strong 8th, 2026-10-03)
            miss = 10.0 * np.log10(max(10 ** (lv / 10) - 10 ** (have_db / 10), 1e-30)) - T.top
            seen.append(fq)
            near = max(1, int(round(r)))
            harm = abs(r / near - 1.0) < 0.012
            att, dec, sus = T.partial_decay(fq)
            why = "%s peak at %.0f Hz (x%.3f%s) %.0f dB under the target's" % (
                w, fq, r, ", harmonic %d" % near if harm else ", inharmonic", deficit)
            m = Module.new("partial", float(near if harm else r), why=why, att=att, dec=dec, sus=sus,
                           rel=T.release, level=float(np.clip(10 ** ((rel + 6) / 20), 0.05, 1.0)))
            out.append((40.0 + miss, m))
    parts = sorted(out, key=lambda q: -q[0])
    out = parts[:2] if have.get("partial", 0) < MAX_OF["partial"] else []
    # BULK: the biggest missing partials as ONE move (Volo, 2026-10-04: "give ability to grow build
    # fully by itself") -- what the additive template did by hand, read off this sound: a drawbar
    # organ's six harmonics are one step, not six, and none of them alone may pay its way
    room = MAX_OF["partial"] - have.get("partial", 0)
    if len(parts) >= 3 and room >= 3:
        bulk = [q[1].copy() for q in parts[:min(BULK_PARTIALS, room)]]
        bulk[0].why = "bulk: the %d biggest missing partials (%s)" % (len(bulk), bulk[0].why)
        out.append((parts[0][0] + 1.0, bulk))
    inh = [q for q in parts if "inharmonic" in q[1].why]
    if len(inh) >= 3 and have.get("fm", 0) < MAX_OF["fm"]:
        c = inh[0][1]
        spacing = sorted(abs(q[1].ratio - c.ratio) for q in inh[1:4])
        mr, mf = fm_ratio(float(np.clip(spacing[0] if spacing else 1.0, 0.25, 16.0)))
        out.append((inh[0][0], Module.new("fm", c.ratio, why="inharmonic cluster around x%.3f (sideband "
                                          "spacing x%.3f)" % (c.ratio, mr * (1 + mf / 100)), mratio=mr, mfine=mf,
                                          index=0.5,
                                          **{k: v for k, v in c.p().items() if k in ("att", "dec", "sus", "rel")})))
    # FM pairs from PAIRS of missing peaks: a carrier c and a modulator m sound c - m and c + m
    # first, so peaks a < b missing together are (c, m) = ((b + a) / 2, (b - a) / 2) or the
    # other way round -- a DX7 e-piano's tine is harmonics 13 and 15 missing, a 1 : 14 pair
    if have.get("fm", 0) < MAX_OF["fm"] and len(parts) >= 2:
        pairs = []
        top = parts[:4]
        for i in range(len(top)):
            for j in range(i + 1, len(top)):
                (pa, ma), (pb, mb) = top[i], top[j]
                a, b = sorted((ma.ratio, mb.ratio))
                for c, m in (((b + a) / 2, (b - a) / 2), ((b - a) / 2, (b + a) / 2)):
                    if 0.25 <= c <= 16.0 and 0.45 <= m <= 16.5:
                        pl, mf = fm_ratio(m)
                        if abs(np.log(pl * (1 + mf / 100) / m)) < 0.01:
                            pairs.append((pa + pb, c, pl, mf, a, b, ma))
        pairs.sort(key=lambda q: -q[0])
        for pri, c, pl, mf, a, b, ma in pairs[:2]:
            out.append((0.5 * pri, Module.new("fm", c, why="peaks x%.2f and x%.2f missing together: FM %.2f : %.2f" % (
                a, b, c, pl * (1 + mf / 100)), mratio=pl, mfine=mf, index=0.4,
                **{k: v for k, v in ma.p().items() if k in ("att", "dec", "sus", "rel")})))
    # a voice with no pitched source, for a target that has sinusoids or a falling pitch: the
    # families it lacks, as whole moves (a noise start won DX7 BASS 1 by 0.3 and no single partial
    # could then beat an EQ on the noise; a GM kick's body never came: no peak to read, 2026-10-03)
    if not pitched:
        if T.drop >= 1.0:
            out.append((60.0, swept_body(T, "a body falling %.1f st in %.0f ms, the voice has no pitch" % (
                T.drop, 1000 * T.drop_t))))
        n_pk = max(len(T.pk[w][0]) for w in T.pk)
        if n_pk >= 3:
            env = dict(att=T.attack, dec=T.decay, sus=T.sustain, rel=T.release)
            out.append((50.0, Module.new("tone", why="%d sinusoids, the voice has no pitched source" % n_pk,
                                         shape=harmonic_shape(T), level=0.6, **env)))
            w = "held" if "held" in T.pk else "early"
            r = float(T.pk[w][0][0] / T.f0) if T.pk[w][0].size else 1.0
            out.append((45.0, Module.new("fm", r if 0.25 <= r <= 16.0 else 1.0, why="%d sinusoids: FM on the "
                                         "loudest" % n_pk, index=0.6, idec=T.decay, isus=0.3, level=0.6, **env)))
    # 2. missing noise: the floor, band by band (contiguous missing bands make one band)
    if have.get("noise", 0) < MAX_OF["noise"]:
        for w in T.noise:
            if w not in R.noise:
                continue
            d = T.noise[w] - R.noise[w]
            ok = (d >= MISS_DB) & (T.noise[w] >= T.noise[w].max() - 40.0)
            if not ok.any():
                continue
            j = int(np.argmax(np.where(ok, d, -1e9)))
            lo = hi = j
            while lo > 0 and ok[lo - 1]:
                lo -= 1
            while hi < len(ok) - 1 and ok[hi + 1]:
                hi += 1
            c = float(np.sqrt(BANDS[lo] * BANDS[hi]))
            width = (hi - lo + 1) / 3.0                      # octaves
            morph = 0.0 if lo == 0 else (1.0 if hi == len(ok) - 1 else 0.5)
            fast = w == "early" and "held" in T.noise
            env = dict(att=0.001, dec=0.05, sus=0.0, rel=0.05) if fast else \
                dict(att=T.attack, dec=T.decay, sus=T.sustain, rel=T.release)
            out.append((float(d[j]) - 3.0, Module.new(
                "noise", why="%s noise %.0f-%.0f Hz, %.0f dB under the target's" % (
                    w, BANDS[lo] * 2 ** (-1 / 6), BANDS[hi] * 2 ** (1 / 6), d[j]),
                freq=c, res=float(np.clip(0.75 - 0.25 * width, 0.05, 0.8)), morph=morph,
                level=0.3, **env)))
    # 3. a click: a first 30 ms over 2 kHz the render lacks
    if T.click - R.click >= MISS_DB and have.get("noise", 0) < MAX_OF["noise"]:
        out.append((T.click - R.click, Module.new("noise", why="attack click %.0f dB over the render's" % (
            T.click - R.click), freq=5000.0, res=0.1, morph=1.0, level=0.4, att=0.001, dec=0.02,
            sus=0.0, rel=0.02)))
    # 4. a pitch sweep
    if pitched and "pitchenv" not in have and T.drop >= 1.0 and R.drop < 0.5 * T.drop:
        out.append((3.0 * T.drop, Module.new("pitchenv", why="pitch falls %.1f st in %.0f ms" % (
            T.drop, 1000 * T.drop_t), depth=T.drop, pdec=T.drop_t)))
    # 5. vibrato
    if pitched and "vibrato" not in have and T.vib >= 6.0 and R.vib < 0.5 * T.vib:
        out.append((T.vib / 2.0, Module.new("vibrato", why="vibrato %.0f cents rms at %.1f Hz" % (
            T.vib, T.vib_rate), rate=T.vib_rate, depth=float(np.clip(T.vib * 1.41 / 100.0, 0.0, 1.0)),
            fade=0.0)))
    # 6. level wobble on a steady pitch: detuned voices beating, or a chorus
    if T.wob >= 1.0 and R.wob < 0.5 * T.wob:
        src = [m for m in mods if m.kind in ("tone", "partial")]
        if src and have.get(src[0].kind, 0) < MAX_OF[src[0].kind]:
            c = src[0].copy()
            beat = T.wob_rate
            cents = float(np.clip(1200 * np.log2(1 + beat / max(T.f0, 1.0)), 1.0, 45.0))
            names = c.names()
            if c.kind == "tone":
                c.g[names.index("detune")] = Module.new("tone", detune=cents).g[names.index("detune")]
            else:
                c.g[names.index("tune")] = Module.new("partial", tune=cents).g[names.index("tune")]
            c.why = "level beats %.1f dB at %.1f Hz: a copy %.1f cents off" % (T.wob, beat, cents)
            out.append((2.0 * T.wob, c))
        if "tremolo" not in have:
            pp = 2.0 * np.sqrt(2.0) * T.wob                  # a sine's peak-to-peak from its rms
            out.append((2.5 * T.wob, Module.new("tremolo", why="level wobble %.1f dB at %.1f Hz" % (
                T.wob, T.wob_rate), rate=float(np.clip(T.wob_rate, 0.5, 12.0)),
                depth=float(np.clip(1.0 - 10 ** (-pp / 20.0), 0.02, 0.95)))))
        if "chorus" not in have:
            out.append((1.5 * T.wob, Module.new("chorus", why="level wobble %.1f dB at %.1f Hz" % (
                T.wob, T.wob_rate), rate=float(np.clip(T.wob_rate / 2, 0.05, 8.0)), depth=0.5, mix=0.4)))
    # 7. brightness: a filter that closes over the note, or a static one
    if "filter" not in have:
        dk = T.darkening - R.darkening
        excess = R.centroid / T.centroid
        if dk > 0.3 or excess > 1.4:
            pri = 6.0 * max(dk, np.log2(excess))
            why = "target darkens %.1f oct more / render %.1fx brighter" % (dk, excess)
            f0 = Module.new("filter", why=why, cut=float(np.clip(2.5 * T.centroid, 60.0, 16000.0)),
                            fenv=float(np.clip(dk * 1.5, 0.0, 6.0)), fdec=T.decay, fsus=0.3, res=0.1)
            out.append((pri, f0))
            from . import kit as KT
            KT.install()
            for kind in KT.KINDS_BY_ROLE["flt"]:
                out.append((0.9 * pri, _carry(f0, kind, why + " (%s)" % kind[4:])))
    # 8. an EQ peak where the band levels differ most
    if have.get("eq", 0) < MAX_OF["eq"]:
        w = "held" if "held" in T.band and "held" in R.band else "early"
        d = T.band[w] - R.band[w]
        ok = T.band[w] >= T.band[w].max() - 40.0
        if ok.any():
            j = int(np.argmax(np.where(ok, np.abs(d), -1)))
            if abs(d[j]) >= 4.0:
                out.append((abs(d[j]) - 2.0, Module.new("eq", why="band %.0f Hz %+.0f dB" % (BANDS[j], d[j]),
                                                        freq=float(BANDS[j]), gain=float(np.clip(d[j], -18, 18)),
                                                        q=2.0)))
    # 9. a tail the voice's release does not make
    reverb = any(k in have for k in ("room", "fx:fx.reverb", "fx:fx.hall"))
    if "room" not in have and T.tail - R.tail > 0.25:
        out.append((4.0 * (T.tail - R.tail), Module.new("room", why="tail %.2f s vs %.2f s" % (T.tail, R.tail),
                                                        decay=float(np.clip(T.tail * 2, 0.1, 20.0)), mix=0.3)))
    elif not reverb and T.tail >= REVERB_TAIL:
        # A LONG TAIL MAY BE THE ROOM (2026-10-04): the analysis reads a tail as the release, so a long
        # envelope stands in for the reverb and "the render's tail is shorter" never fires -- Wave
        # Pad's preset reverb moves the fitness 9.5, and GROW never tried one. On a single note a room
        # and a long release cannot be told apart by their decay (results.md section 29): offered
        # whenever the tail is long, kept only if it pays
        out.append((3.0 + T.tail, Module.new("room", why="a %.1f s tail: the room, not the release?" % T.tail,
                                             decay=float(np.clip(T.tail * 2, 0.1, 20.0)), mix=0.3)))
    out += kit_moves(T, R, mods, rng)
    out.sort(key=lambda q: -q[0])
    return [m if isinstance(m, (list, Replace)) else [m] for _, m in out]
