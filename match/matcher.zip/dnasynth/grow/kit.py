"""The FULL KIT: the pchkraft-core/synth blocks GROW may build with beyond its first twelve, read
from the engine's own registry (pchkraft-synth's pchsynth.graph on the same library: every knob's
range, curve, choices and whether a modulation can reach it; every port).

A kit block becomes a piece KIND of blocks.py at install(): its searched knobs are genes whose law
is the ENGINE'S OWN knob law ("norm": the gene is the knob's normalised position, its value the
engine's pcks_param_map of it -- the designer's knob travel, so a gene step is a knob step), its
other knobs are pinned (KIT[...]["fixed"]: a per-note random knob -- drift, jitter -- is held at 0:
one recorded note cannot pin down a random draw, DNA v2's lesson). The kinds and where blocks.py's
document puts them:

    src:<osc>      a source beside tone / partial / fm / noise / pluck: its own ADSR amp, a mixer input
    flt:<filter>   THE main filter after the mix (instead of filter.svf), with its own ADSR on the
                   cutoff (+-6 oct) and key tracking into its cutoff input
    hp:filter.hp1  a high pass after the main filter
    ins:<block>    a post insert after the filters (comb, wavefolder, bitcrusher)
    fx:<fx>        a global effect, in a fixed order with the EQ, the chorus and the room
    mod:<what>     a modulator and its one destination: lfo>cut (an LFO on the main filter's
                   cutoff), lfo>pw (on the first tone's pulse width), lfo>pos / env>pos (on the
                   first wavetable's position or the first morph's shape)

    from dnasynth.grow import kit
    kit.install()                        # registers the kinds in blocks.KINDS (idempotent)
    kit.KINDS_BY_ROLE["flt"]             # ('flt:filter.ladder', ...)
"""
from __future__ import annotations

import os
import sys

import numpy as np

from . import ENGINE

PKS = os.path.expanduser("~/Projects/PchKraft/pchkraft-synth")
os.environ.setdefault("PCKSG_LIB", ENGINE)          # the registry from the SAME library GROW renders with

# role, the searched knobs, the pinned ones; for a source: its audio out port, its pitch knobs
KIT = {
    "osc.morph": dict(role="src", out="l", search=("shape", "spread", "voices", "sub", "noise", "nmod", "range"),
                      fixed=dict(tune=0.0, drift=0.0, jitter=0.0, alias=0.0, width=1.0), tune="tune", fine="fine"),
    "osc.table": dict(role="src", out="out", search=("bank", "pos", "blend", "shape", "warp", "voices", "spread"),
                      fixed=dict(tune=0.0, phase=0.0, width=1.0), tune="tune", fine="fine"),
    "osc.pd": dict(role="src", out="out", search=("warp", "window"), fixed={}, tune=None, fine=None),
    "filter.ladder": dict(role="flt", search=("cutoff", "res", "drive", "model", "mode"), fixed=dict(fm=0.0),
                          cut="cutoff", cv="cutoff"),
    "filter.sk": dict(role="flt", search=("cutoff", "res", "drive", "mode"), fixed=dict(fm=0.0), cut="cutoff", cv="cutoff"),
    "filter.lp3": dict(role="flt", search=("cutoff", "res", "drive"), fixed=dict(fm=0.0), cut="cutoff", cv="cutoff"),
    # the acid filter's accent and its decay act only through the accent GATE input, which nothing
    # here drives (a deaf knob in a search is noise): left out
    "filter.acid": dict(role="flt", search=("cutoff", "res", "body", "drive"), fixed=dict(fm=0.0),
                        cut="cutoff", cv="cutoff"),
    "filter.lpg": dict(role="flt", search=("cutoff", "lag", "blend"), fixed={}, cut="cutoff", cv=None),
    "filter.hp1": dict(role="hp", search=("cutoff",), fixed={}),
    "filter.comb": dict(role="ins", search=("freq", "feedback", "damp"), fixed={}, cv="freq"),
    "shaper.fold": dict(role="ins", search=("amount", "mode"), fixed={}),
    "shaper.crush": dict(role="ins", search=("bits", "rate", "mix"), fixed={}),
    "fx.delay": dict(role="fx", search=("time", "feedback", "tone", "mix"), fixed={}),
    "fx.phaser": dict(role="fx", search=("rate", "depth", "centre", "feedback", "mix"), fixed={}),
    "fx.ensemble": dict(role="fx", search=("mode", "mix"), fixed={}),
    "fx.hall": dict(role="fx", search=("decay", "size", "damp", "mix"), fixed=dict(width=1.0)),
    "fx.reverb": dict(role="fx", search=("size", "damp", "mix"), fixed={}),
}
FX_ORDER = ("fx.ensemble", "fx.phaser", "fx.delay", "fx.hall", "fx.reverb")   # within the global chain
# the modulators: (block, its knobs searched, its depth gene, destination role)
MODS = {
    "lfo>cut": dict(block="lfo.voice", depth=("depth", "bip", 1.5, 4.0, 0.5), dest="flt"),     # octaves
    "lfo>pw": dict(block="lfo.voice", depth=("depth", "sq", 0.0, 0.45, 0.5), dest="pw"),       # width
    "lfo>pos": dict(block="lfo.voice", depth=("depth", "sq", 0.0, 0.5, 0.5), dest="pos"),      # position
    "env>pos": dict(block="env.adsr", depth=("depth", "bip", 1.5, 1.0, 0.5), dest="pos"),
}
LFO_GENES = (("shape", "step", ("sine", "triangle", "saw up", "saw down", "square"), None, 0.1),
             ("rate", "exp", 0.05, 20.0, 0.75), ("fade", "lin", 0.0, 2.0, 0.0))
ENVM_GENES = (("att", "exp", 0.001, 8.0, 0.3), ("dec", "exp", 0.002, 12.0, 0.6),
              ("sus", "lin", 0.0, 1.0, 0.5), ("rel", "exp", 0.002, 12.0, 0.45))
FENV = (("fenv", "bip", 1.5, 6.0, 0.5), ("fatt", "exp", 0.001, 8.0, 0.0), ("fdec", "exp", 0.002, 12.0, 0.5),
        ("fsus", "lin", 0.0, 1.0, 0.5), ("key", "lin", 0.0, 1.0, 0.5))

_TYPES = {}
KINDS_BY_ROLE = {}


def types():
    """block type -> pchsynth NodeType (the registry), loaded once"""
    if not _TYPES:
        if PKS not in sys.path:
            sys.path.insert(0, PKS)
        from pchsynth import graph as G
        for nt in G.TYPES:
            _TYPES[nt.type] = nt
    return _TYPES


def param(block, key):
    return types()[block].param(key)


def install():
    """register every kit kind in blocks.KINDS (gene specs: the searched knobs at the engine's own
    law, then the role's own genes); idempotent"""
    from . import blocks as BL
    if KINDS_BY_ROLE:
        return
    T = types()
    for block, k in KIT.items():
        nt = T[block]
        specs = []
        for key in k["search"]:
            p = nt.param(key)
            specs.append((key, "norm", p, None, float(p.default_norm)))
        role = k["role"]
        if role == "src":
            specs += [("level", "sq", 0.0, 1.0, 0.8)] + list(BL.ENV)
        elif role == "flt":
            specs += list(FENV if k.get("cv") else FENV[:4])
        elif role == "ins" and k.get("cv"):
            specs += [("key", "lin", 0.0, 1.0, 1.0)]
        name = "%s:%s" % (role, block)
        BL.KINDS[name] = tuple(specs)
        KINDS_BY_ROLE.setdefault(role, []).append(name)
    for m, k in MODS.items():
        g = LFO_GENES if k["block"] == "lfo.voice" else ENVM_GENES
        BL.KINDS["mod:" + m] = tuple(g) + (k["depth"],)
        KINDS_BY_ROLE.setdefault("mod", []).append("mod:" + m)
    for r in KINDS_BY_ROLE:
        KINDS_BY_ROLE[r] = tuple(KINDS_BY_ROLE[r])


def block_of(kind):
    return kind.split(":", 1)[1] if ":" in kind else None


def role_of(kind):
    return kind.split(":", 1)[0] if ":" in kind else None


def cut_travel(block, key="cutoff"):
    """octaves of a frequency knob's travel (an exponential knob: a modulation amount in octaves /
    this is its normalised depth)"""
    p = param(block, key)
    return float(np.log2(p.max / p.min))
