"""GROW LAB: the matcher that builds its own graph, by eye and by ear.

    python3 -m dnasynth.grow.lab            (or double-click run_grow_lab.command)

THE LAYOUT (one thing at a time, each at full size):

  top bar     the sound (a searchable list: the bench's 69 notes) or Open your own; GROW and
              its budget; ▶ the target, ▶ the chosen voice; Graph | Compare | Web synth | Log
  left        the VOICES, stacked: A (the best) B C D -- four families the builder grew -- and
              REF, the current matcher's match of a bench note; one click chooses (and plays) one,
              and every view follows
  main        GRAPH      the chosen voice as a signal flow (sources -> mix -> filter -> inserts ->
                         effects -> out, the modulators above with arrows to what they move), each
                         block with its key settings; beside it every block's knobs and WHY the
                         builder added it (click one: it lights up in the flow)
              COMPARE    the waveforms over each other, the two spectrograms, the long-term spectra
                         (the target, the voice, the current matcher), the band differences
              WEB SYNTH  pchkraft-synth's full web synth (a private bundle of its current sources,
                         build/websynth) with the chosen voice loaded: its own board, knobs, keys
              LOG        the build, step by step (shown while growing)
  bottom      a keyboard for the chosen voice (computer keys a w s e d f t g y h u j k, z / x
              an octave); hidden under the web synth, which has its own

Growing runs in a CHILD PROCESS (spawn), so the search never holds the GIL the live audio needs;
the live voice is the chosen document compiled once on PchKraft's graph engine (8 voices), played
by the app's AudioEngine. Every note plays at one loudness (fitness.normalize), and every card's
DISTANCE is the same number for all of them (the matcher's fitness against the note), so an A / B
compares sounds, not levels or rulers.
"""
from __future__ import annotations

import functools
import json
import math
import multiprocessing as mp
import os
import queue
import subprocess
import sys
import tempfile
import time
import traceback

import numpy as np

from . import ENGINE                                   # noqa: F401  (the graph library: before lib loads)

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
REACH = os.path.join(ROOT, "eval", "reach")
PKS = os.path.expanduser("~/Projects/PchKraft/pchkraft-synth")
WEB = os.path.join(ROOT, "build", "websynth", "web", "build", "pchkraft-synth.html")
SR = 44100
SETS = (("one-shots", "targets", "results_b5000_s0.json"),
        ("sustained", "targets_wide", "results_targets_wide_b5000_s0.json"),
        ("analog", "targets_analog", "results_targets_analog_b5000_s0.json"))
KEYMAP = "awsedftgyhujk"
RECDIR = os.path.join(ROOT, "recordings")             # every microphone take, as matched
REC_MAX_S = 10.0           # a take stops itself after this
REC_KEEP_S = 6.0           # ... and keeps at most this from the note's onset
REC_TAIL_DB = 45.0         # the note ends where its 20 ms level falls this far under its peak
REC_CLICK_S = 0.15         # a take stopped by hand loses its last 150 ms: the click of the Stop button
REC_QUIET_DB = -45.0       # a take whose loudest 50 ms is under this (dBFS) is flagged as too quiet


def trim_take(x, sr=SR):
    """a microphone take -> the note: mono 44.1 kHz (match.to_mono_44k: DC out), from its onset to
    its end, +0.2 s, at most REC_KEEP_S. A room is never silent, so both are taken against the
    take's own FLOOR (its quietest tenth of frames): the onset is the first 128-sample frame
    within match.ONSET_DB of the peak AND 15 dB over the floor (match.estimate_onset alone takes
    room noise 46 dB down for the note), less 5 ms; the end is where the 20 ms level falls
    REC_TAIL_DB under the peak or to 6 dB over the floor, whichever is higher"""
    from .. import match as MA
    x = MA.to_mono_44k(np.asarray(x, np.float32), sr)
    L, st = MA._frames_db(x, 128, 32)
    on_thr = max(L.max() - MA.ONSET_DB, float(np.percentile(L, 10)) + 15.0)
    x = x[max(0, int(st[int(np.argmax(L >= on_thr))]) - int(0.005 * SR)):]
    hop = int(0.02 * SR)
    n = len(x) // hop
    if n < 2:
        return x
    rms = np.sqrt(np.mean(x[:n * hop].reshape(n, hop) ** 2, axis=1) + 1e-20)
    thr = max(rms.max() * 10 ** (-REC_TAIL_DB / 20), 2.0 * float(np.percentile(rms, 10)))
    loud = np.flatnonzero(rms > thr)
    if not loud.size:            # no floor under the note (a file that is all note: 2 x its quietest
        return x[:int(REC_KEEP_S * SR)]   # tenth tops its peak) -- the whole of it (2026-10-05)
    end = min(len(x), (int(loud[-1]) + 1) * hop + int(0.2 * SR))
    return x[:min(end, int(REC_KEEP_S * SR))]


def node_line(n):
    """an engine node's key knobs, one short line (the Engine nodes view)"""
    t, q = n["type"], n.get("params", {})
    g = lambda k, d=0.0: q.get(k, d)                                       # noqa: E731
    try:
        if t == "env.adsr":
            return "A %s  D %s  S %.2f  R %s" % (_t(g("attack", .004)), _t(g("decay", .35)), g("sustain", .7),
                                                _t(g("release", .4)))
        if t.startswith("filter."):
            return " · ".join(x for x in ("%s" % _hz(g("cutoff", g("freq", 1000))),
                                          ("res %.2f" % g("res")) if "res" in q else "",
                                          str(q.get("mode", "")) if isinstance(q.get("mode"), str) else "") if x)
        if t == "osc.va":
            sh = g("shape", 0.67)
            return "%s%s%s" % ("sine" if sh < 0.15 else "triangle" if sh < 0.5 else "saw" if sh < 0.83 else
                               "pulse %.0f %%" % (100 * g("pw", 0.5)),
                               (" · oct %+d" % g("octave")) if g("octave") else "",
                               (" · %+.2f st" % g("tune")) if abs(g("tune")) > 0.005 else "")
        if t == "util.amp":
            return "level %.2f" % g("level", 1.0)
        if t == "util.mixer":
            return " ".join("%s %.2f" % (k, g(k, 1.0)) for k in "abcd" if k in q)
        if t == "util.scale":
            return "× %.2f %+.2f" % (g("gain", 1.0), g("offset"))
        if t == "dyn.comp":
            return "makeup %+.1f dB" % g("makeup") if g("ratio", 1.0) == 1.0 else "ratio %.1f" % g("ratio", 1.0)
        if t == "lfo.voice" or t == "lfo":
            return "%s %.2f Hz" % (q.get("shape", ""), g("rate", 5.0))
        if t == "out.stereo":
            return "level %.2f" % g("level", 0.8)
        keys = [k for k in q if not isinstance(q[k], (list, dict))][:3]
        return " · ".join("%s %s" % (k, knob_text(k, q[k])) for k in keys)
    except Exception:
        return ""


def bench_sounds():
    out = []
    for label, d, _ in SETS:
        p = os.path.join(REACH, d, "manifest.json")
        if os.path.exists(p):
            for t in json.load(open(p))["targets"]:
                out.append((label, t, os.path.join(REACH, d)))
    return out


def _knobs(m):
    """a piece's knobs by name: physical values, a kit selector by its label"""
    from .blocks import KINDS
    out = {}
    for spec, (k, v) in zip(KINDS[m.kind], m.p().items()):
        if spec[1] == "norm" and spec[2].steps > 1:
            out[k] = str(spec[2].to_file(float(np.clip(m.g[[sp[0] for sp in KINDS[m.kind]].index(k)], 0, 1))))
        else:
            out[k] = v if isinstance(v, str) else float(v)
    return out


NET = os.path.join(ROOT, "checkpoints", "growx", "model_best.pt")     # the full kit's network
VA_NET = os.path.join(ROOT, "checkpoints", "va", "model_best.pt")     # the analog template's tuner
DASH_NET = os.path.join(ROOT, "checkpoints", "dashx", "model_best.pt")  # the dashboard network (Dashboard GROW)
BUILDERS = ("GROW (analysis, full kit)", "Analog template (its network)",
            "Dashboard GROW (a dashboard instrument)")


def _chord_of(x, gate_s):
    """the notes an opened or recorded sound plays together (notes.estimate_notes): a list of two or
    more fractional MIDI notes, or None for one note (or none clear)"""
    from .. import notes as NO
    ns = NO.estimate_notes(x, SR, gate_s)
    return [float(n["midi"]) for n in ns] if len(ns) > 1 else None


def _dash_worker(audio, sr, midi, gate_s, budget, seed, use_net, polish_k, templates, library, exclude_doc, chord, q):
    """DASHBOARD GROW (grow/dash.py): GROW whose every voice is a dashboard instrument"""
    _grow_worker(audio, sr, midi, gate_s, budget, seed, use_net, polish_k, templates, library, exclude_doc, chord, q,
                 dashboard=True)


def _grow_worker(audio, sr, midi, gate_s, budget, seed, use_net, polish_k, templates, library, exclude_doc, chord, q,
                 dashboard=False):
    """chord: the notes the sound plays together (None: one note) -- GROW plays every voice on all of
    them (build.grow chord=), and the voices' notes here are that chord too"""
    try:
        sys.path.insert(0, ROOT)
        from dnasynth.grow import build as GB
        model = None
        net = DASH_NET if dashboard and os.path.exists(DASH_NET) else NET    # Dashboard GROW: its own, once trained
        if use_net and os.path.exists(net):
            q.put(("log", "loading the network (%s)" % os.path.relpath(net, ROOT)))
            from dnasynth import model as MO
            model = MO.load(net)
        from dnasynth.graph import lib as L
        from dnasynth.grow import blocks as BL
        from dnasynth import fitness as FT
        last = [0.0]

        def progress(line, frac):
            q.put(("log", line))
            now = time.perf_counter()
            if now - last[0] > 0.2:
                last[0] = now
                q.put(("progress", float(frac)))
        r = GB.grow(audio, sr, midi, gate_s, budget=int(budget), rng=np.random.default_rng(seed),
                    progress=progress, name="grown", model=model, dashboard=dashboard, polish_k=int(polish_k),
                    templates=bool(templates), library=bool(library), exclude_doc=exclude_doc, chord=chord)
        k, _ = BL.key_cents(midi)
        play = k if not chord or len(chord) < 2 else BL.chord_keys(midi, chord)
        alts = []
        for a in r["alternatives"]:
            y = L.render_note(json.dumps(a["play_doc"]).encode(), play, 100 / 127, gate_s, len(audio) / sr)
            alts.append(dict(play_doc=a["play_doc"], score=a["score"], family=a["family"],
                             kinds=[m.kind for m in a["mods"]], whys=[m.why for m in a["mods"]],
                             params=[_knobs(m) for m in a["mods"]],
                             ratios=[float(m.ratio) for m in a["mods"]],
                             audio=FT.normalize(y) if np.abs(y).max() > 1e-7 else y))
        q.put(("done", dict(alternatives=alts, renders=r["renders"])))
    except Exception:
        q.put(("error", traceback.format_exc()))


def _template_worker(audio, sr, midi, gate_s, budget, seed, use_net, polish_k, templates, library, exclude_doc, chord, q):
    """the ANALOG TEMPLATE's matcher, in the child process: its tuner network's proposals (the
    latest best checkpoint, read afresh each run), the template's search (graph/match.py bound to
    graph/analog.py), the best and three alternatives as playable documents"""
    try:
        sys.path.insert(0, ROOT)
        from dnasynth.graph import analog as A
        from dnasynth.graph import lib as L
        from dnasynth.graph import match as GM
        from dnasynth.grow import blocks as BL
        from dnasynth import fitness as FT
        model = None
        if use_net and os.path.exists(VA_NET):
            q.put(("log", "loading the analog template's tuner (%s)" % os.path.relpath(VA_NET, ROOT)))
            from dnasynth import model as MO
            model = MO.load(VA_NET)
        elif use_net:
            q.put(("log", "no tuner network yet (%s): the template's search alone" % os.path.relpath(VA_NET, ROOT)))
        M = GM.bound_to(A)
        last = [0.0, ""]

        def progress(stage, frac):
            if stage != last[1]:
                last[1] = stage
                q.put(("log", stage))
            now = time.perf_counter()
            if now - last[0] > 0.2:
                last[0] = now
                q.put(("progress", float(frac)))
        r = M.match(audio, sr, midi=midi, gate_s=gate_s, model=model, budget=int(budget),
                    rng=np.random.default_rng(seed), progress=progress, trim=False)
        k, c = BL.key_cents(r["midi"])
        alts = []
        for i, (g, sc) in enumerate(zip(r["alternatives"], r["scores"])):
            play = BL.playable(A.document(g, name="analog template %s" % "ABCD"[i], seed=1, cents=c),
                               r["midi"], r["gate_s"])
            y = L.render_note(json.dumps(play).encode(), k, 100 / 127, r["gate_s"], len(audio) / sr)
            what = A.describe(g)
            q.put(("log", "  %s  %.3f  %s" % ("ABCD"[i], float(sc), what)))
            alts.append(dict(play_doc=play, score=float(sc), family="analog template", kinds=[], whys=[],
                             params=[], ratios=[], parts=what.split(" · "),
                             nograph="the analog template's voice:\n%s\n\nEngine nodes shows it node for node" % what,
                             audio=FT.normalize(y) if np.abs(y).max() > 1e-7 else y))
        q.put(("done", dict(alternatives=alts, renders=int(r["renders"]))))
    except Exception:
        q.put(("error", traceback.format_exc()))


# ------------------------------------------------------------------------------- pictures

def _lut():
    """a 256-colour ramp, black -> violet -> orange -> pale yellow (the spectrograms)"""
    anchors = np.array([[0, 0, 4], [40, 11, 84], [101, 21, 110], [159, 42, 99], [212, 72, 66],
                        [245, 125, 21], [250, 193, 39], [252, 255, 164]], np.float64)
    x = np.linspace(0, 1, len(anchors))
    t = np.linspace(0, 1, 256)
    return np.stack([np.interp(t, x, anchors[:, c]) for c in range(3)], 1).astype(np.uint8)


LUT = _lut()


def spectrogram_rgb(y, sr=SR, rows=240, f0=30.0, f1=16000.0, n=2048, hop=256, top_db=None):
    """an RGB image [rows, frames, 3] of y's spectrogram on a log-frequency axis (dB, 80 dB range,
    0 dB at `top_db` or y's own top) and the top used"""
    y = np.asarray(y, np.float64)
    if len(y) < n:
        y = np.pad(y, (0, n - len(y)))
    w = np.hanning(n)
    fr = np.array([np.abs(np.fft.rfft(y[i:i + n] * w)) for i in range(0, len(y) - n + 1, hop)])
    S = 20 * np.log10(fr + 1e-9)
    f = np.fft.rfftfreq(n, 1 / sr)
    grid = np.geomspace(f0, f1, rows)
    idx = np.clip(np.searchsorted(f, grid), 1, len(f) - 1)
    img = S[:, idx].T[::-1]
    top = float(img.max()) if top_db is None else top_db
    v = np.clip((img - (top - 80.0)) / 80.0, 0, 1)
    return LUT[(v * 255).astype(np.uint8)], top


# ------------------------------------------------------------------------------- block words

def _hz(f):
    return ("%.0f Hz" % f) if f < 1000 else ("%.1f kHz" % (f / 1000))


def _t(s):
    return ("%.0f ms" % (1000 * s)) if s < 1 else ("%.2f s" % s)


def _n(v, fmt="%.2f"):
    """a knob value in `fmt` if it is a number, as it is if it is a selector's label (_knobs turns
    a kit selector -- the morph shape, the PD warp, a filter's mode -- into its label)"""
    return fmt % v if isinstance(v, (int, float, np.integer, np.floating)) else str(v)


def safe_paint(fn):
    """a paintEvent that raises must not leave its QPainter active: PySide only prints the error,
    the traceback keeps the frame -- and the painter -- alive, and Qt then segfaults in the next
    backing-store flush (2026-10-04: QPaintDevice::devicePixelRatio, null) or at exit
    (QPainter::~QPainter). The error is printed and the frame's locals dropped, so the painter's
    destructor ends it before Qt flushes."""
    @functools.wraps(fn)
    def run(self, ev):
        try:
            fn(self, ev)
        except Exception:
            tb = sys.exc_info()[2]
            traceback.print_exc()
            traceback.clear_frames(tb)
            del tb
    return run


def block_title(kind, prm, ratio):
    """a block's name as a player reads it"""
    if kind == "tone":
        sh = prm.get("shape", 0.67)
        return "VA osc · %s" % ("sine" if sh < 0.15 else "triangle" if sh < 0.5 else "saw" if sh < 0.83 else "pulse")
    if kind == "partial":
        return "Sine ×%.3g" % (ratio * 2 ** (prm.get("tune", 0) / 1200))
    if kind == "fm":
        return "FM pair %.3g : %.3g" % (ratio, prm.get("mratio", 1) * (1 + prm.get("mfine", 0) / 100))
    if kind == "fm4":
        return "4-op FM · algo %.1f" % prm.get("algo", 4)
    if kind == "noise":
        return "Noise · %s" % _hz(prm.get("freq", 0))
    if kind == "pluck":
        return "String (pluck)"
    if kind == "filter":
        return "SVF filter · %s" % _hz(prm.get("cut", 0))
    if kind.startswith("flt:"):
        return "%s filter · %s" % ({"ladder": "Ladder", "sk": "MS-20", "lp3": "18 dB", "acid": "Acid 303",
                                    "lpg": "Low-pass gate"}.get(kind[11:], kind[11:]), _hz(prm.get("cutoff", 0)))
    if kind.startswith("cell:"):
        src, role = kind[5:].split(">", 1)
        return "%s → %s" % ({"env1": "ENV 1", "env2": "ENV 2", "lfo": "LFO"}.get(src, src), role.upper())
    if kind == "dash":
        return "Dashboard · %s %s" % ({"filter.ladder": "ladder", "filter.svf": "SVF", "filter.sk": "MS-20",
                                       "filter.acid": "Acid 303", "filter.lp3": "18 dB"}.get(
            prm.get("model"), prm.get("model", "")), _hz(prm.get("cut", 18000)))
    names = {"src:osc.table": "Wavetable", "src:osc.morph": "Morph osc", "src:osc.pd": "Phase distortion",
             "hp:filter.hp1": "High pass", "ins:filter.comb": "Comb", "ins:shaper.fold": "Wavefolder",
             "ins:shaper.crush": "Bitcrusher", "fx:fx.delay": "Delay", "fx:fx.phaser": "Phaser",
             "fx:fx.ensemble": "Ensemble", "fx:fx.hall": "Hall", "fx:fx.reverb": "Reverb", "mod:lfo>cut": "LFO",
             "mod:lfo>pw": "LFO", "mod:lfo>pos": "LFO", "mod:env>pos": "Envelope", "pitchenv": "Pitch envelope",
             "vibrato": "Vibrato LFO", "tremolo": "Tremolo", "drive": "Drive", "eq": "EQ peak",
             "chorus": "Chorus", "room": "Room"}
    return names.get(kind, kind)


def block_detail(kind, prm):
    """a block's key settings: [the sound's settings, its envelope] (one or two short lines)"""
    env = ("A %s  D %s  S %.2f  R %s" % (_t(prm["att"]), _t(prm["dec"]), prm["sus"], _t(prm.get("rel", 0))))\
        if "att" in prm and "sus" in prm else ""
    level = ("level %.2f" % prm["level"]) if "level" in prm else ""
    if kind in ("tone", "partial", "pluck") or kind.startswith("src:"):
        extra = {"src:osc.table": "bank %s · pos %s" % (prm.get("bank", ""), _n(prm.get("pos", 0))),
                 "src:osc.morph": "shape %s · voices %s" % (_n(prm.get("shape", 0)), _n(prm.get("voices", ""), "%.3g")),
                 "src:osc.pd": "warp %s · %s" % (_n(prm.get("warp", 0)), _n(prm.get("window", ""))),
                 "pluck": "decay %s · damp %.2f" % (_t(prm.get("decay", 0)), prm.get("damp", 0)),
                 "tone": "octave %+d · detune %+.0f ct" % (prm.get("oct", 0), prm.get("detune", 0))}.get(kind, "")
        return [" · ".join(x for x in (extra, level) if x), env]
    if kind == "fm":
        return ["index %.2f · feedback %.2f · %s" % (prm.get("index", 0), prm.get("mfb", 0), level), env]
    if kind == "fm4":
        ops = " ".join("%.3g" % (prm.get("rat%d" % k, 1) * (1 + prm.get("fin%d" % k, 0) / 100)) for k in range(1, 5))
        return ["ratios %s · feedback %.2f · %s" % (ops, prm.get("fb", 0), level),
                "levels %s" % " ".join("%.2f" % prm.get("lev%d" % k, 0) for k in range(1, 5))]
    if kind == "noise":
        return ["res %.2f · %s" % (prm.get("res", 0), level), env]
    if kind == "dash":
        lfo = [n for n, k in (("pitch", "lfo_pitch"), ("cut", "lfo_cut"), ("pw", "lfo_pw"), ("amp", "lfo_amp"))
               if isinstance(prm.get(k), (int, float)) and prm[k] > 1e-6]
        return ["%s · res %s · ENV2 %s oct · FX %s" % (prm.get("mode", ""), _n(prm.get("res", 0)),
                                                      _n(prm.get("fenv", 0), "%+.1f"), prm.get("fx_type", "off")),
                "ENV1 A %s D %s S %s R %s%s" % (_t(prm.get("a_att", 0)), _t(prm.get("a_dec", 0)), _n(prm.get("a_sus", 1)),
                                                _t(prm.get("a_rel", 0)),
                                                ("  · LFO %s Hz → %s" % (_n(prm.get("lfo_rate", 0)), "/".join(lfo))) if lfo else "")]
    if kind == "filter" or kind.startswith("flt:"):
        extra = " · ".join("%s %s" % (k, prm[k]) for k in ("model", "mode") if k in prm and isinstance(prm[k], str))
        return ["res %s · key %s%s" % (_n(prm.get("res", 0)), _n(prm.get("key", 0)), (" · " + extra) if extra else ""),
                "env %+.1f oct  A %s  D %s  S %.2f" % (prm.get("fenv", 0), _t(prm.get("fatt", 0)), _t(prm.get("fdec", 0)),
                                                      prm.get("fsus", 0))]
    if kind.startswith("mod:"):
        if "rate" in prm:
            return "%s %s Hz · depth %s" % (prm.get("shape", ""), _n(prm.get("rate", 0)), _n(prm.get("depth", 0), "%+.2f"))
        return "depth %s · %s" % (_n(prm.get("depth", 0), "%+.2f"), env)
    if kind == "pitchenv":
        return "%+.1f st · %s" % (prm.get("depth", 0), _t(prm.get("pdec", 0)))
    if kind == "vibrato":
        return "%.1f Hz · %.2f st" % (prm.get("rate", 0), prm.get("depth", 0))
    if kind == "tremolo":
        return "%.1f Hz · depth %.2f" % (prm.get("rate", 0), prm.get("depth", 0))
    if kind == "eq":
        return "%s · %+.1f dB · Q %.1f" % (_hz(prm.get("freq", 0)), prm.get("gain", 0), prm.get("q", 0))
    if kind in ("room", "fx:fx.hall"):
        return "decay %s · mix %s" % (_t(prm.get("decay", 0)), _n(prm.get("mix", 0)))
    keys = [k for k in prm if k not in ("att", "dec", "sus", "rel", "level")][:3]
    return " · ".join("%s %s" % (k, knob_text(k, prm[k])) for k in keys)


def knob_text(name, val):
    """a knob's value as a player reads it: a selector's label, seconds, Hz, cents, semitones"""
    if isinstance(val, str):
        return val
    if name in ("att", "dec", "rel", "fatt", "fdec", "pdec", "decay", "idec", "fade", "time", "adecay", "lag"):
        return _t(val / 1000.0) if name == "lag" else _t(val)
    if name in ("cut", "cutoff", "freq", "centre", "rate") and name != "rate":
        return _hz(val)
    if name == "rate":
        return "%.2f Hz" % val
    if name in ("detune", "tune", "fine"):
        return "%+.1f ct" % val
    if name in ("depth",) and abs(val) > 1.5:
        return "%+.1f st" % val
    if name in ("fenv",):
        return "%+.2f oct" % val
    if name == "gain":
        return "%+.1f dB" % val
    return "%.3g" % val


def block_role(kind):
    from .blocks import is_source
    if is_source(kind):
        return "src"
    if kind == "filter" or kind.startswith("flt:") or kind == "dash":
        return "flt"
    if kind in ("drive", "tremolo") or kind.startswith(("hp:", "ins:")):
        return "ins"
    if kind in ("eq", "chorus", "room") or kind.startswith("fx:"):
        return "fx"
    return "mod"


def main():
    from PySide6.QtCore import QPointF, QRectF, QThread, QTimer, QUrl, Qt, Signal
    from PySide6.QtGui import QBrush, QFont, QImage, QPainter, QPainterPath, QPen
    from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QCompleter, QFileDialog, QFrame,
                                   QHBoxLayout, QLabel, QMainWindow, QPlainTextEdit, QProgressBar, QPushButton,
                                   QSizePolicy, QSpinBox, QSplitter, QStackedWidget, QTreeWidget, QTreeWidgetItem,
                                   QVBoxLayout, QWidget)
    import soundfile as sf
    from .. import fitness as FT
    from .. import match as MA
    from ..graph import lib as L
    from ..ui import theme
    from ..ui.audio import AudioEngine
    from ..ui.widgets import Keyboard, SpectrumView, WaveView, long_term_spectrum, _envelope
    from . import blocks as BL

    ROLE_COL = {"src": theme.GROUP["osc"], "flt": theme.GROUP["filter"], "ins": theme.GROUP["amp"],
                "fx": theme.GROUP["space"], "mod": theme.GROUP["mod"]}

    # --------------------------------------------------------------- the child process
    class GrowJob(QThread):
        log = Signal(str)
        progress = Signal(float)
        done = Signal(object)
        failed = Signal(str)

        def __init__(self, args, target=None):
            super().__init__()
            self.args, self.proc, self._stop = args, None, False
            self.target = target or _grow_worker

        def cancel(self):
            self._stop = True

        def run(self):
            ctx = mp.get_context("spawn")
            q = ctx.Queue()
            self.proc = ctx.Process(target=self.target, args=self.args + (q,), daemon=True)
            self.proc.start()
            while True:
                if self._stop:
                    self.proc.terminate()
                    self.failed.emit("cancelled")
                    return
                try:
                    msg = q.get(timeout=0.1)
                except queue.Empty:
                    if not self.proc.is_alive():
                        self.failed.emit("the builder stopped (exit code %s)" % self.proc.exitcode)
                        return
                    continue
                if msg[0] == "log":
                    self.log.emit(msg[1])
                elif msg[0] == "progress":
                    self.progress.emit(msg[1])
                elif msg[0] == "done":
                    self.done.emit(msg[1])
                    return
                elif msg[0] == "error":
                    self.failed.emit(msg[1])
                    return

    # --------------------------------------------------------------- the voice cards (left)
    class VoiceCard(QWidget):
        clicked = Signal(int)

        def __init__(self, index, title):
            super().__init__()
            self.index, self.title = index, title
            self.v = None
            self.selected = False
            self.setFixedHeight(92)
            self.setCursor(Qt.PointingHandCursor)

        def set_voice(self, v):
            self.v = v
            self.update()

        def mousePressEvent(self, e):
            if self.v is not None:
                self.clicked.emit(self.index)

        @safe_paint
        def paintEvent(self, _):
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
            sel = self.selected and self.v is not None
            p.setBrush(QBrush(theme.qc(theme.PANEL2 if sel else theme.PANEL)))
            p.setPen(QPen(theme.qc(theme.ACCENT if sel else theme.EDGE), 2 if sel else 1))
            p.drawRoundedRect(r, 9, 9)
            f = QFont(self.font())
            f.setPointSize(17 if len(self.title) == 1 else 12)
            f.setBold(True)
            p.setFont(f)
            p.setPen(theme.qc(theme.ACCENT if sel else (theme.TEXT if self.v is not None else theme.FAINT)))
            p.drawText(QRectF(12, 6, 60, 26), Qt.AlignLeft | Qt.AlignVCenter, self.title)
            f.setPointSize(10)
            f.setBold(False)
            p.setFont(f)
            if self.v is None:
                p.setPen(theme.qc(theme.FAINT))
                p.drawText(r.adjusted(60, 0, -10, 0), Qt.AlignVCenter | Qt.AlignLeft, "—")
                p.end()
                return
            v = self.v
            p.setPen(theme.qc(theme.TEXT))
            if v.get("dist") is not None:
                p.drawText(QRectF(60, 8, r.width() - 70, 16), Qt.AlignRight, "distance %.2f" % v["dist"])
            p.setPen(theme.qc(theme.DIM))
            p.drawText(QRectF(12, 30, r.width() - 22, 16), Qt.AlignLeft, v.get("label", ""))
            a = v.get("audio")
            if a is not None and len(a):
                w, top, hh = r.width() - 24, 52.0, r.height() - 58
                lo, hi = _envelope(a, int(w))
                peak = max(float(np.abs(a).max()), 1e-6)
                path = QPainterPath()
                path.moveTo(12, top + hh / 2)
                for i, x in enumerate(hi):
                    path.lineTo(12 + i, top + hh / 2 - x / peak * hh / 2)
                for i in range(len(lo) - 1, -1, -1):
                    path.lineTo(12 + i, top + hh / 2 - lo[i] / peak * hh / 2)
                col = theme.TRUTH if self.title == "REF" else theme.ACCENT
                p.setPen(QPen(theme.qc(col, 200), 1))
                p.setBrush(QBrush(theme.qc(col, 60)))
                p.drawPath(path)
            p.end()

    # --------------------------------------------------------------- GRAPH: the flow
    class Flow(QWidget):
        """the chosen voice as a signal flow, each block with its key settings; click a block"""
        picked = Signal(int)

        def __init__(self):
            super().__init__()
            self.v = None
            self.hi = None
            self.hit = []                       # [(QRectF, item index)]
            self.setMinimumSize(560, 360)
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        def set_voice(self, v, hi=None):
            self.v, self.hi = v, hi
            self.update()

        def mousePressEvent(self, e):
            for r, i in self.hit:
                if r.contains(e.position()):
                    self.hi = i
                    self.picked.emit(i)
                    self.update()
                    return

        @safe_paint
        def paintEvent(self, _):
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            p.fillRect(self.rect(), theme.qc(theme.PANEL2))
            W, H = float(self.width()), float(self.height())
            self.hit = []
            v = self.v
            if not v or not v.get("kinds"):
                p.setPen(theme.qc(theme.DIM))
                f = QFont(self.font())
                f.setPointSize(13)
                p.setFont(f)
                p.drawText(self.rect(), Qt.AlignCenter, v["nograph"] if v and v.get("nograph") else
                           "pick a sound and press GROW — the voice the matcher builds appears here")
                p.end()
                return
            items = list(enumerate(zip(v["kinds"], v["params"], v["ratios"])))
            src = [it for it in items if block_role(it[1][0]) == "src"]
            chain = [it for it in items if block_role(it[1][0]) in ("flt", "ins", "fx")]
            mods = [it for it in items if block_role(it[1][0]) == "mod"]
            # the geometry: sources, mix, the chain (wrapping), out; modulators in a band on top
            M, gx = 22.0, 30.0
            MIXW, OUTW = 86.0, 74.0
            n_big = 1 + min(len(chain), 4)                       # sources + up to four chain blocks a row
            bw = max(200.0, min(300.0, (W - 2 * M - MIXW - OUTW - (n_big + 1) * gx) / n_big))
            bh = 84.0
            per_row = max(1, int((W - 2 * M - bw - MIXW - 2 * gx) // (bw + gx)))
            band = 118.0 if mods else 20.0
            # where the chain's blocks land (row, x), wrapping at the right edge: a dry run first
            place, x_, row_ = [], M + bw + gx + MIXW + gx, 0
            for i, it in chain + [(None, ("out", {}, 1.0))]:
                wdt = OUTW if i is None else bw
                if x_ + wdt > W - M + 1 and place:
                    x_, row_ = M + bw + gx + MIXW + gx, row_ + 1
                place.append((x_, row_, wdt))
                x_ += wdt + gx
            rows = row_ + 1
            src_h = len(src) * (bh + 12) - 12
            body_h = max(src_h, rows * (bh + 40) - 40)
            y0 = band + max(0.0, (H - band - 40 - body_h) / 2)
            boxes = {}

            def box(key, r, title, detail, col, idx=None, prm=None):
                sel = idx is not None and idx == self.hi
                p.setBrush(QBrush(theme.qc(theme.PANEL)))
                p.setPen(QPen(theme.qc(theme.ACCENT if sel else theme.EDGE), 2.5 if sel else 1))
                p.drawRoundedRect(r, 9, 9)
                p.setPen(Qt.NoPen)
                p.setBrush(QBrush(theme.qc(col)))
                p.drawRoundedRect(QRectF(r.x(), r.y(), 6, r.height()), 3, 3)
                f = QFont(self.font())
                f.setPointSize(12)
                f.setBold(True)
                p.setFont(f)
                p.setPen(theme.qc(theme.TEXT))
                p.drawText(QRectF(r.x() + 14, r.y() + 8, r.width() - 22, 22), Qt.AlignLeft | Qt.AlignVCenter,
                           p.fontMetrics().elidedText(title, Qt.ElideRight, int(r.width() - 22)))
                tw = r.width() - (84 if prm and ("att" in prm or "fatt" in prm) else 22)
                lines = detail if isinstance(detail, (list, tuple)) else ([detail] if detail else [])
                f.setPointSize(10)
                f.setBold(False)
                p.setFont(f)
                p.setPen(theme.qc(theme.DIM))
                for j, line in enumerate(lines[:2]):
                    p.drawText(QRectF(r.x() + 14, r.y() + 34 + j * 20, tw, 18), Qt.AlignLeft | Qt.AlignVCenter,
                               p.fontMetrics().elidedText(line, Qt.ElideRight, int(tw)))
                if prm and ("att" in prm or "fatt" in prm):       # the envelope's shape, small
                    a_, d_, s_ = (prm["att"], prm["dec"], prm["sus"]) if "att" in prm else (prm["fatt"], prm["fdec"], prm["fsus"])
                    ex = QRectF(r.right() - 70, r.y() + 36, 58, r.height() - 46)
                    tot = a_ + d_ + 0.25 * (a_ + d_ + 0.05) + 0.3
                    xa = ex.x() + ex.width() * min(a_ / tot, 0.45)
                    xd = xa + ex.width() * min(d_ / tot, 0.5)
                    xs = ex.x() + ex.width() * 0.82
                    path = QPainterPath()
                    path.moveTo(ex.x(), ex.bottom())
                    path.lineTo(xa, ex.top())
                    path.quadTo(xa + (xd - xa) * 0.25, ex.bottom() - (ex.height()) * s_, xd, ex.bottom() - ex.height() * s_)
                    path.lineTo(xs, ex.bottom() - ex.height() * s_)
                    path.lineTo(ex.right(), ex.bottom())
                    p.setPen(QPen(theme.qc(col), 1.4))
                    p.setBrush(QBrush(theme.qc(col, 40)))
                    p.drawPath(path)
                boxes[key] = r
                if idx is not None:
                    self.hit.append((r, idx))
                return r

            def arrow(r1, r2):
                p.setPen(QPen(theme.qc(theme.DIM), 1.4))
                x1, y1 = r1.right(), r1.center().y()
                x2, y2 = r2.left(), r2.center().y()
                if x2 < x1:                                  # a wrap: down, then along
                    x1, y1 = r1.center().x(), r1.bottom()
                    x2, y2 = r2.center().x(), r2.top()
                    path = QPainterPath()
                    path.moveTo(x1, y1)
                    path.cubicTo(x1, (y1 + y2) / 2, x2, (y1 + y2) / 2, x2, y2)
                    p.setBrush(Qt.NoBrush)
                    p.drawPath(path)
                    p.setBrush(QBrush(theme.qc(theme.DIM)))
                    p.drawPolygon([QPointF(x2 - 4, y2 - 7), QPointF(x2, y2), QPointF(x2 + 4, y2 - 7)])
                    return
                path = QPainterPath()
                path.moveTo(x1, y1)
                path.cubicTo((x1 + x2) / 2, y1, (x1 + x2) / 2, y2, x2, y2)
                p.setBrush(Qt.NoBrush)
                p.drawPath(path)
                p.setBrush(QBrush(theme.qc(theme.DIM)))
                p.drawPolygon([QPointF(x2 - 7, y2 - 4), QPointF(x2, y2), QPointF(x2 - 7, y2 + 4)])

            main_y = y0 + max(0.0, (src_h - bh) / 2) if rows == 1 else y0
            sy = (main_y + bh / 2 - src_h / 2) if rows == 1 else y0
            for j, (i, (k, prm, rt)) in enumerate(src):
                box(("b", i), QRectF(M, sy + j * (bh + 12), bw, bh), block_title(k, prm, rt), block_detail(k, prm),
                    ROLE_COL["src"], i, prm)
            mx = M + bw + gx
            mix = box("mix", QRectF(mx, main_y, MIXW, bh), "Mix", "%d source%s" % (len(src), "s" if len(src) != 1 else ""),
                      theme.DIM)
            for i, _ in src:
                arrow(boxes[("b", i)], mix)
            last = mix
            for (i, (k, prm, rt)), (x, row, wdt) in zip(chain + [(None, ("out", {}, 1.0))], place):
                y = main_y + row * (bh + 40)
                if i is None:
                    r = box("out", QRectF(x, y, OUTW, bh), "Out", "", theme.DIM)
                else:
                    r = box(("b", i), QRectF(x, y, bw, bh), block_title(k, prm, rt), block_detail(k, prm),
                            ROLE_COL[block_role(k)], i, prm)
                arrow(last, r)
                last = r
            # the modulators: above what they move
            used = []
            for i, (k, prm, rt) in mods:
                if k in ("pitchenv", "vibrato"):
                    tg = [boxes[("b", j)] for j, (kk, _, _) in src if BL.is_pitched(kk)]
                elif k == "mod:lfo>cut":
                    tg = [boxes[("b", j)] for j, (kk, _, _) in chain if block_role(kk) == "flt"][:1]
                else:
                    tg = [boxes[("b", j)] for j, (kk, _, _) in src if kk in ("tone", "src:osc.table", "src:osc.morph")][:1]
                cx = (sum(t.center().x() for t in tg) / len(tg)) if tg else W / 2
                mw = bw * 0.9
                xx = max(M, min(W - M - mw, cx - mw / 2))
                while any(abs(xx - u) < mw + 10 for u in used):
                    xx += mw + 12
                used.append(xx)
                r = box(("b", i), QRectF(xx, 14, mw, bh - 14), block_title(k, prm, rt), block_detail(k, prm),
                        theme.GROUP["lfo"] if ("lfo" in k or k == "vibrato") else theme.GROUP["mod"], i)
                p.setPen(QPen(theme.qc(theme.GROUP["mod"], 190), 1.3, Qt.DashLine))
                for t in tg:
                    p.drawLine(QPointF(r.center().x(), r.bottom()), QPointF(t.center().x(), t.top()))
                tgt = {"pitchenv": "pitch", "vibrato": "pitch", "mod:lfo>cut": "cutoff", "mod:lfo>pw": "pulse width",
                       "mod:lfo>pos": "position", "mod:env>pos": "position"}.get(k, "")
                f = QFont(self.font())
                f.setPointSize(9)
                p.setFont(f)
                p.setPen(theme.qc(theme.GROUP["mod"]))
                p.drawText(QRectF(r.x(), r.bottom() + 3, r.width(), 16), Qt.AlignHCenter, "→ " + tgt)
            f = QFont(self.font())
            f.setPointSize(10)
            p.setFont(f)
            p.setPen(theme.qc(theme.DIM))
            p.drawText(QRectF(M, H - 26, W - 2 * M, 18), Qt.AlignLeft,
                       "%d blocks  ·  distance %s  ·  family %s  ·  click a block for its knobs and why" % (
                           len(items), "%.2f" % v["dist"] if v.get("dist") is not None else "-", v.get("family", "")))
            p.end()

    # --------------------------------------------------------------- COMPARE pieces
    class Spectro(QWidget):
        def __init__(self):
            super().__init__()
            self.imgs = []
            self.setMinimumHeight(200)
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        def set_pair(self, items):
            self.imgs = []
            top = None
            for y, cap in items:
                if y is None:
                    continue
                rgb, t = spectrogram_rgb(y, top_db=top)
                top = t if top is None else top
                rgb = np.ascontiguousarray(rgb)
                h, w, _ = rgb.shape
                self.imgs.append((QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy(), cap))
            self.update()

        @safe_paint
        def paintEvent(self, _):
            p = QPainter(self)
            p.fillRect(self.rect(), theme.qc(theme.PANEL2))
            n = max(1, len(self.imgs))
            gap = 10
            wcol = (self.width() - gap * (n + 1)) / n
            for i, (qi, cap) in enumerate(self.imgs):
                r = QRectF(gap + i * (wcol + gap), 24, wcol, self.height() - 30)
                p.drawImage(r, qi)
                p.setPen(theme.qc(theme.TEXT))
                p.drawText(QRectF(r.x(), 4, r.width(), 18), Qt.AlignLeft, cap)
                p.setPen(theme.qc(theme.DIM, 220))
                for fr, lab in ((100, "100 Hz"), (1000, "1 kHz"), (10000, "10 kHz")):
                    yy = r.y() + r.height() * (1 - math.log(fr / 30.0) / math.log(16000 / 30.0))
                    p.drawText(QRectF(r.x() + 4, yy - 8, 60, 14), Qt.AlignLeft, lab)
            if not self.imgs:
                p.setPen(theme.qc(theme.FAINT))
                p.drawText(self.rect(), Qt.AlignCenter, "pick a sound")
            p.end()

    class BandDiff(QWidget):
        BANDS = 40.0 * 2.0 ** (np.arange(27) / 3.0)

        def __init__(self):
            super().__init__()
            self.d = None
            self.setMinimumHeight(140)
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        def set_pair(self, x, y):
            if x is None or y is None:
                self.d = None
            else:
                fx, dx = long_term_spectrum(x)
                fy, dy = long_term_spectrum(y)
                bx = np.interp(np.log(self.BANDS), np.log(fx), dx)
                by = np.interp(np.log(self.BANDS), np.log(fy), dy)
                self.d = np.where(bx > bx.max() - 60, by - bx, np.nan)
            self.update()

        @safe_paint
        def paintEvent(self, _):
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            p.fillRect(self.rect(), theme.qc(theme.PANEL2))
            w, h = self.width(), self.height()
            mid = h / 2
            p.setPen(theme.qc(theme.EDGE))
            p.drawLine(0, int(mid), w, int(mid))
            p.setPen(theme.qc(theme.DIM))
            p.drawText(QRectF(8, 4, w - 16, 16), Qt.AlignLeft,
                       "band by band: the voice minus the note  (up = too loud, down = missing; ±18 dB)")
            if self.d is not None:
                n = len(self.d)
                bw = (w - 20) / n
                for i, v in enumerate(self.d):
                    if not np.isfinite(v):
                        continue
                    hh = float(np.clip(v, -18, 18)) / 18 * (h / 2 - 24)
                    col = theme.ACCENT if abs(v) < 3 else (theme.SOURCE if v > 0 else theme.TRUTH)
                    p.fillRect(QRectF(10 + i * bw + 1, mid - max(hh, 0), bw - 2, abs(hh)), theme.qc(col))
                for i in range(0, n, 3):
                    f = self.BANDS[i]
                    p.drawText(QRectF(10 + i * bw - 6, h - 17, 50, 14), Qt.AlignLeft,
                               ("%.0f" % f) if f < 1000 else ("%.0fk" % (f / 1000)))
            p.end()

    # --------------------------------------------------------------- the window
    def node_col(t):
        if t.startswith("osc."):
            return theme.GROUP["osc"]
        if t.startswith("filter."):
            return theme.GROUP["filter"]
        if t.startswith(("env.", "mod.")):
            return theme.GROUP["mod"]
        if t.startswith("lfo"):
            return theme.GROUP["lfo"]
        if t.startswith(("fx.", "eq.", "dyn.")):
            return theme.GROUP["space"]
        if t.startswith("shaper."):
            return theme.GROUP["amp"]
        if t == "note.keyboard":
            return theme.GROUP["key"]
        return theme.DIM

    AUDIO_PORTS = {"l", "r", "in", "a", "b", "c", "d"}

    class NodeGraph(QWidget):
        """the chosen voice's patch document drawn node for node -- the graph the web synth, the
        designer and the board load (every oscillator, envelope, amplifier, mixer, scale and makeup
        stage the Parts view folds into one box), laid out by signal depth; click a node"""
        picked = Signal(str)

        def __init__(self):
            super().__init__()
            self.doc, self.msg, self.sel = None, "", None
            self.full = None                      # the whole document (self.doc may hide the knobs)
            self.show_knobs = False               # a dashboard's macros and sensors: hidden unless asked
            self.hit = []
            self.setMinimumSize(560, 360)
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        def set_doc(self, doc, msg=""):
            self.full, self.msg, self.sel = doc, msg, None
            self.doc = doc if (doc is None or self.show_knobs) else self._without_knobs(doc)
            self.update()

        def set_show_knobs(self, on):
            self.show_knobs = bool(on)
            self.set_doc(self.full, self.msg)

        @staticmethod
        def _without_knobs(doc):
            """the document without its knob layer (mod.macro, sense.*): the graph that makes the
            sound; the count of what was hidden in `hidden`"""
            knob = {n["id"] for n in doc["nodes"] if n["type"] == "mod.macro" or n["type"].startswith("sense.")}
            if not knob:
                return doc
            return dict(doc, nodes=[n for n in doc["nodes"] if n["id"] not in knob],
                        audio=[a for a in doc["audio"] if a[0] not in knob and a[2] not in knob],
                        mod=[m for m in doc.get("mod", []) if m["from"][0] not in knob and m["to"][0] not in knob],
                        hidden=len(knob))

        def mousePressEvent(self, e):
            for r, nid in self.hit:
                if r.contains(e.position()):
                    self.sel = nid
                    self.picked.emit(nid)
                    self.update()
                    return

        def layout_cols(self):
            """node id -> (column, row): the longest audio path from a source; a source sits just
            before the first node it feeds, a modulator (only mod links) before what it moves;
            rows ordered by their inputs' rows (two barycentre sweeps)"""
            d = self.doc
            ids = [n["id"] for n in d["nodes"]]
            succ = {i: [] for i in ids}
            pred = {i: [] for i in ids}
            for s_, _, t_, _ in d["audio"]:
                if s_ in succ and t_ in succ and s_ != t_ and t_ not in succ[s_]:
                    succ[s_].append(t_)
                    pred[t_].append(s_)
            mod_to = {}
            for m in d.get("mod", []):
                a, b = m["from"][0], m["to"][0]
                if a in succ and b in succ and a != b:
                    mod_to.setdefault(a, []).append(b)
            depth = {i: 0 for i in ids}
            for _ in range(len(ids)):
                moved = False
                for s_ in ids:
                    for t_ in succ[s_]:
                        if depth[t_] < depth[s_] + 1 <= len(ids):
                            depth[t_] = depth[s_] + 1
                            moved = True
                if not moved:
                    break
            for _ in range(2):
                for i in ids:
                    if pred[i]:
                        continue
                    nxt = succ[i] or mod_to.get(i, [])
                    if nxt:
                        depth[i] = max(0, min(depth[t_] for t_ in nxt) - 1)
            cols = {}
            for i in ids:
                cols.setdefault(depth[i], []).append(i)
            row = {}
            for c in sorted(cols):
                for k, i in enumerate(cols[c]):
                    row[i] = k
            ins = {i: pred[i] + [a for a, bs in mod_to.items() for b in bs if b == i] for i in ids}
            for _ in range(2):
                for c in sorted(cols):
                    key = lambda i: (np.mean([row[j] for j in ins[i]]) if ins[i] else row[i])   # noqa: E731
                    cols[c].sort(key=key)
                    for k, i in enumerate(cols[c]):
                        row[i] = k
            return {i: (depth[i], row[i]) for i in ids}, cols

        @safe_paint
        def paintEvent(self, _):
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            p.fillRect(self.rect(), theme.qc(theme.PANEL2))
            W, H = float(self.width()), float(self.height())
            self.hit = []
            d = self.doc
            if not d:
                p.setPen(theme.qc(theme.DIM))
                f = QFont(self.font())
                f.setPointSize(13)
                p.setFont(f)
                p.drawText(self.rect(), Qt.AlignCenter, self.msg or "pick a voice: its patch, node for node, appears here")
                p.end()
                return
            pos, cols = self.layout_cols()
            BW, BH, M, TOP, FOOT = 150.0, 46.0, 16.0, 14.0, 34.0
            nc = max(cols) + 1                           # signal depth levels
            nr = max(len(v) for v in cols.values())      # the widest level
            # left -> right (levels are columns) or top -> bottom (levels are rows): the larger one
            GX, GY = 44.0, 12.0
            hw, hh = 2 * M + nc * BW + (nc - 1) * GX, TOP + nr * (BH + GY) - GY + FOOT
            VX, VY = 14.0, 34.0
            vw, vh = 2 * M + nr * (BW + VX) - VX, TOP + nc * (BH + VY) - VY + FOOT + 16
            sh = min(1.0, W / hw, H / hh)
            sv = min(1.0, W / vw, H / vh)
            self.vertical = vert = sv > sh * 1.05
            sc = max(0.4, sv if vert else sh)
            p.save()
            p.scale(sc, sc)
            w_, h_ = W / sc, H / sc
            rect = {}
            if not vert:
                x0 = M + max(0.0, (w_ - hw) / 2)
                for c, members in cols.items():
                    colh = len(members) * (BH + GY) - GY
                    y0 = TOP + max(0.0, (h_ - FOOT - TOP - colh) / 2)
                    for i in members:
                        rect[i] = QRectF(x0 + c * (BW + GX), y0 + pos[i][1] * (BH + GY), BW, BH)
            else:
                y0 = TOP + 16 + max(0.0, (h_ - vh) / 2)
                for c, members in cols.items():
                    roww = len(members) * (BW + VX) - VX
                    x0 = max(M, (w_ - roww) / 2)
                    for i in members:
                        rect[i] = QRectF(x0 + pos[i][1] * (BW + VX), y0 + c * (BH + VY), BW, BH)
            nodes = {n["id"]: n for n in d["nodes"]}
            small = QFont(self.font())
            small.setPointSize(9)

            def curve(a, b, pen, label=None, to_top=False):
                if vert:
                    return curve_v(a, b, pen, label, to_top)
                x1, y1 = a.right(), a.center().y()
                if to_top:
                    x2, y2 = b.center().x(), b.top()
                elif b.left() > a.right():
                    x2, y2 = b.left(), b.center().y()
                else:                                          # back or within a column: under it
                    x1, y1 = a.center().x(), a.bottom()
                    x2, y2 = b.center().x(), b.bottom()
                path = QPainterPath()
                path.moveTo(x1, y1)
                if to_top:
                    path.cubicTo(x1 + 30, y1, x2, y2 - 40, x2, y2)
                elif x2 > x1:
                    path.cubicTo((x1 + x2) / 2, y1, (x1 + x2) / 2, y2, x2, y2)
                else:
                    path.cubicTo(x1, y1 + 40, x2, y2 + 40, x2, y2)
                p.setPen(pen)
                p.setBrush(Qt.NoBrush)
                p.drawPath(path)
                if label:
                    p.setFont(small)
                    p.setPen(pen.color())
                    if to_top:
                        p.drawText(QRectF(x2 - 70, y2 - 15, 140, 13), Qt.AlignHCenter, label)
                    else:
                        p.drawText(QRectF(x2 - 64, y2 - 15, 60, 13), Qt.AlignRight, label)

            def curve_v(a, b, pen, label, side):
                """top -> bottom: a wire from a's bottom into b's top; a modulation (side) from a's
                right edge into b's right edge, bowed out to the right"""
                path = QPainterPath()
                if side:
                    x1, y1 = a.right(), a.center().y()
                    x2, y2 = b.right(), b.center().y()
                    bow = max(x1, x2) + 46
                    path.moveTo(x1, y1)
                    path.cubicTo(bow, y1, bow, y2, x2, y2)
                elif b.top() > a.bottom():
                    x1, y1 = a.center().x(), a.bottom()
                    x2, y2 = b.center().x(), b.top()
                    path.moveTo(x1, y1)
                    path.cubicTo(x1, (y1 + y2) / 2, x2, (y1 + y2) / 2, x2, y2)
                else:                                          # back up, or along a level: by the left
                    x1, y1 = a.left(), a.center().y()
                    x2, y2 = b.left(), b.center().y()
                    path.moveTo(x1, y1)
                    path.cubicTo(x1 - 40, y1, x2 - 40, y2, x2, y2)
                p.setPen(pen)
                p.setBrush(Qt.NoBrush)
                p.drawPath(path)
                if label:
                    p.setFont(small)
                    p.setPen(pen.color())
                    if side:
                        p.drawText(QRectF(x2 + 4, y2 - 14, 120, 13), Qt.AlignLeft, label)
                    else:
                        p.drawText(QRectF(x2 + 3, y2 - 13, 90, 12), Qt.AlignLeft, label)

            seen = set()
            for s_, sp, t_, tp in d["audio"]:
                if s_ not in rect or t_ not in rect:
                    continue
                ctl = tp not in AUDIO_PORTS
                key = (s_, t_, tp if ctl else "audio")
                if key in seen:
                    continue
                seen.add(key)
                pen = QPen(theme.qc(theme.GROUP["mod"] if ctl else theme.DIM, 200 if ctl else 230), 1.1 if ctl else 1.5)
                curve(rect[s_], rect[t_], pen, tp if ctl else None)
            for m in d.get("mod", []):
                a, b = m["from"][0], m["to"][0]
                if a in rect and b in rect:
                    pen = QPen(theme.qc(theme.GROUP["mod"], 220), 1.2, Qt.DashLine)
                    curve(rect[a], rect[b], pen, "%s %+.2f" % (m["to"][1], m["amount"]), to_top=True)
            f = QFont(self.font())
            for i, r in rect.items():
                n = nodes[i]
                sel = i == self.sel
                p.setBrush(QBrush(theme.qc(theme.PANEL)))
                p.setPen(QPen(theme.qc(theme.ACCENT if sel else theme.EDGE), 2.4 if sel else 1))
                p.drawRoundedRect(r, 8, 8)
                p.setPen(Qt.NoPen)
                p.setBrush(QBrush(theme.qc(node_col(n["type"]))))
                p.drawRoundedRect(QRectF(r.x(), r.y(), 5, r.height()), 2.5, 2.5)
                f.setPointSize(11)
                f.setBold(True)
                p.setFont(f)
                p.setPen(theme.qc(theme.TEXT))
                p.drawText(QRectF(r.x() + 12, r.y() + 5, r.width() - 18, 19), Qt.AlignLeft | Qt.AlignVCenter,
                           p.fontMetrics().elidedText(n["type"], Qt.ElideRight, int(r.width() - 18)))
                f.setPointSize(9)
                f.setBold(False)
                p.setFont(f)
                p.setPen(theme.qc(theme.DIM))
                p.drawText(QRectF(r.x() + 12, r.y() + 25, r.width() - 18, 16), Qt.AlignLeft | Qt.AlignVCenter,
                           p.fontMetrics().elidedText("%s  %s" % (i, node_line(n)), Qt.ElideRight, int(r.width() - 18)))
                self.hit.append((QRectF(r.x() * sc, r.y() * sc, r.width() * sc, r.height() * sc), i))
            p.restore()
            f.setPointSize(10)
            p.setFont(f)
            p.setPen(theme.qc(theme.DIM))
            p.drawText(QRectF(14, H - 24, W - 28, 18), Qt.AlignLeft,
                       "%d engine nodes  ·  %d wires  ·  %d modulations%s  ·  the patch the web synth loads, node for node"
                       "  ·  click a node" % (len(d["nodes"]), len(d["audio"]), len(d.get("mod", [])),
                                              ("  ·  + %d dashboard knobs and sensors (tick 'knobs')" % d["hidden"])
                                              if d.get("hidden") else ""))
            p.end()

    class Lab(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("GROW lab — the matcher builds its own graph")
            self.resize(1440, 920)
            self.audio = AudioEngine()
            self.sounds = bench_sounds()
            self.cur = None
            self.voices = [None] * 5           # A B C D, REF
            self.sel = None
            self.base = 48
            self.held = {}
            self.job = None
            self.web = None
            self.web_ready = False
            self.T = None
            self._rec = None                   # the microphone's input stream while recording
            self._rec_dev = "the default input"
            self._rec_chunks = []
            self._rec_lvl = 0.0

            w = QWidget()
            self.setCentralWidget(w)
            col = QVBoxLayout(w)
            col.setContentsMargins(12, 10, 12, 8)
            col.setSpacing(8)
            # ---- top bar 1: the sound, GROW
            top = QHBoxLayout()
            self.pick = QComboBox()
            self.pick.setEditable(True)
            self.pick.setInsertPolicy(QComboBox.NoInsert)
            self.pick.setMinimumWidth(380)
            for label, t, d in self.sounds:
                self.pick.addItem("%s  ·  %s" % (t["name"], label))
            comp = QCompleter([self.pick.itemText(i) for i in range(self.pick.count())])
            comp.setCaseSensitivity(Qt.CaseInsensitive)
            comp.setFilterMode(Qt.MatchContains)
            self.pick.setCompleter(comp)
            self.pick.setCurrentIndex(-1)
            self.pick.lineEdit().setPlaceholderText("search a sound… (69 bench notes)")
            self.pick.activated.connect(self._pick)
            comp.activated.connect(lambda text: self._pick(self.pick.findText(text)))
            top.addWidget(self.pick)
            b_open = QPushButton("Open note…")
            b_open.clicked.connect(self._open)
            top.addWidget(b_open)
            self.b_rec = QPushButton("●  Rec")
            self.b_rec.setToolTip("record ONE note from the microphone and match it (macOS asks for the "
                                  "microphone the first time); takes are kept in recordings/")
            self.b_rec.clicked.connect(self._rec_toggle)
            top.addWidget(self.b_rec)
            self.info = QLabel("")
            self.info.setStyleSheet("color: %s; padding-left: 10px;" % theme.DIM)
            top.addWidget(self.info, 1)
            top.addWidget(QLabel("renders"))
            self.budget = QSpinBox()
            self.budget.setRange(1000, 60000)
            self.budget.setSingleStep(1000)
            self.budget.setValue(15000)
            top.addWidget(self.budget)
            top.addWidget(QLabel("polish genes"))
            self.polish_k = QSpinBox()
            self.polish_k.setRange(4, 400)
            self.polish_k.setValue(20)
            self.polish_k.setToolTip("GROW's final polish searches this many of the voice's most sensitive genes at once\n"
                                     "(two stages, each picking them afresh). 20: where search stays reliable on a few\n"
                                     "thousand renders; more genes want more renders")
            top.addWidget(self.polish_k)
            from PySide6.QtWidgets import QCheckBox as _QCB2
            self.use_tmpl = _QCB2("templates")
            self.use_tmpl.setChecked(True)
            self.use_tmpl.setToolTip("GROW starts from its 13 family templates as well as single sources\n"
                                     "(off: it builds every structure by itself -- pairs, bulk partials,\n"
                                     "swaps, the beam)")
            top.addWidget(self.use_tmpl)
            self.use_lib = _QCB2("library")
            self.use_lib.setChecked(False)              # off by default: unbenched, and it cost self-recovery
            self.use_lib.setToolTip("GROW also starts from the structures of the 6 pchkraft-synth presets that sound\n"
                                    "nearest (grow/library.py: 62 recipes from 88 patches; a bench sound never starts\n"
                                    "from the instrument that made it)")
            self.use_tmpl.toggled.connect(self.use_lib.setEnabled)
            top.addWidget(self.use_lib)
            from PySide6.QtWidgets import QCheckBox
            self.builder = QComboBox()
            self.builder.addItems(BUILDERS)
            self.builder.setToolTip("GROW: the analysis builds the graph piece by piece (full kit)\n"
                                    "Analog template: the template's own network picks its parts and knobs, "
                                    "the search polishes (checkpoints/va)")
            top.addWidget(self.builder)
            self.use_net = QCheckBox("network")
            self.use_net.setToolTip("GROW: start from the full-kit network's proposals (checkpoints/growx) as well\n"
                                    "Analog template: seed the search with its tuner network (checkpoints/va)")
            self.use_net.setChecked(os.path.exists(NET))
            self.use_net.setEnabled(os.path.exists(NET))
            top.addWidget(self.use_net)
            self.b_grow = QPushButton("GROW")
            self.b_grow.setMinimumWidth(130)
            self.b_grow.setStyleSheet("QPushButton { font-weight: 700; color: %s; }" % theme.ACCENT)
            self.b_grow.clicked.connect(self._grow)
            top.addWidget(self.b_grow)
            col.addLayout(top)
            # ---- top bar 2: listen, views, out
            bar = QHBoxLayout()
            self.b_target = QPushButton("▶  the note")
            self.b_voice = QPushButton("▶  voice")
            b_stop = QPushButton("■")
            self.b_target.clicked.connect(self._play_target)
            self.b_voice.clicked.connect(self._play_voice)
            b_stop.clicked.connect(self.audio.stop_playback)
            for b in (self.b_target, self.b_voice, b_stop):
                bar.addWidget(b)
            bar.addSpacing(24)
            self.views = QButtonGroup(self)
            self.view_btns = []
            for i, name in enumerate(("Graph", "Compare", "Web synth", "Log")):
                b = QPushButton(name)
                b.setCheckable(True)
                b.setMinimumWidth(104)
                self.views.addButton(b, i)
                self.view_btns.append(b)
                bar.addWidget(b)
            self.views.idClicked.connect(self._view)
            bar.addStretch(1)
            self.b_designer = QPushButton("Open in designer")
            self.b_designer.clicked.connect(self._designer)
            self.b_export = QPushButton("Export patch…")
            self.b_export.clicked.connect(self._export)
            bar.addWidget(self.b_designer)
            bar.addWidget(self.b_export)
            col.addLayout(bar)
            self.bar = QProgressBar()
            self.bar.setRange(0, 1000)
            self.bar.setTextVisible(False)
            self.bar.setMaximumHeight(4)
            col.addWidget(self.bar)
            # ---- body: the voices | the view
            body = QHBoxLayout()
            body.setSpacing(12)
            left = QVBoxLayout()
            left.setSpacing(8)
            cap = QLabel("VOICES")
            cap.setStyleSheet("color: %s; font-weight: 600; letter-spacing: 1px;" % theme.DIM)
            left.addWidget(cap)
            self.cards = []
            for i, title in enumerate(("A", "B", "C", "D", "REF")):
                c = VoiceCard(i, title)
                c.clicked.connect(self._choose)
                self.cards.append(c)
                if title == "REF":
                    sep = QLabel("benchmark: the old matcher\n(dnasynth's own engine — not a web-synth patch)")
                    sep.setStyleSheet("color: %s; padding-top: 8px;" % theme.DIM)
                    left.addWidget(sep)
                left.addWidget(c)
            left.addStretch(1)
            lw = QWidget()
            lw.setLayout(left)
            lw.setFixedWidth(232)
            body.addWidget(lw)
            self.stack = QStackedWidget()
            # GRAPH: the flow | the blocks
            gs = QSplitter(Qt.Horizontal)
            gl = QWidget()
            gv = QVBoxLayout(gl)
            gv.setContentsMargins(0, 0, 0, 0)
            gv.setSpacing(6)
            gm = QHBoxLayout()
            self.gmode = QButtonGroup(self)
            self.gmode_btns = []
            for i, name in enumerate(("Parts", "Engine nodes")):
                b = QPushButton(name)
                b.setCheckable(True)
                b.setMinimumWidth(128)
                self.gmode.addButton(b, i)
                self.gmode_btns.append(b)
                gm.addWidget(b)
            self.gmode.idClicked.connect(self._graph_mode)
            from PySide6.QtWidgets import QCheckBox as _QCB
            self.show_knobs = _QCB("knobs")
            self.show_knobs.setToolTip("Engine nodes: show a dashboard voice's macro knobs and sensors too")
            self.show_knobs.toggled.connect(lambda on: self.nodes.set_show_knobs(on))
            gm.addWidget(self.show_knobs)
            self.gmode_hint = QLabel("")
            self.gmode_hint.setStyleSheet("color: %s; padding-left: 8px;" % theme.DIM)
            gm.addWidget(self.gmode_hint, 1)
            gv.addLayout(gm)
            self.gstack = QStackedWidget()
            self.flow = Flow()
            self.flow.picked.connect(self._pick_block)
            self.gstack.addWidget(self.flow)
            self.nodes = NodeGraph()
            self.nodes.picked.connect(self._pick_node)
            self.gstack.addWidget(self.nodes)
            gv.addWidget(self.gstack, 1)
            self.gmode_btns[0].setChecked(True)
            gs.addWidget(gl)
            from PySide6.QtWidgets import QTextBrowser
            self.blocks = QTextBrowser()
            self.blocks.setOpenLinks(False)
            self.blocks.anchorClicked.connect(lambda url: self._select_block(int(url.toString().split(":")[1])))
            self.blocks.setMinimumWidth(320)
            gs.addWidget(self.blocks)
            gs.setSizes([960, 340])
            self.hi = None
            self.stack.addWidget(gs)
            # COMPARE
            cw = QWidget()
            cl = QVBoxLayout(cw)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(8)
            self.wave = WaveView("the note (orange) and the voice (teal)", min_h=130)
            self.spectro = Spectro()
            low = QHBoxLayout()
            self.spec = SpectrumView()
            self.bands = BandDiff()
            low.addWidget(self.spec, 1)
            low.addWidget(self.bands, 1)
            cl.addWidget(self.wave, 2)
            cl.addWidget(self.spectro, 3)
            cl.addLayout(low, 2)
            self.stack.addWidget(cw)
            # WEB SYNTH
            self.webw = QWidget()
            wl = QVBoxLayout(self.webw)
            wl.setContentsMargins(0, 0, 0, 0)
            self.web_hint = QLabel("pchkraft-synth's web synth loads here the first time")
            self.web_hint.setStyleSheet("color: %s;" % theme.DIM)
            wl.addWidget(self.web_hint)
            self.stack.addWidget(self.webw)
            # LOG
            self.log = QPlainTextEdit()
            self.log.setReadOnly(True)
            f = QFont("Menlo")
            f.setPointSize(11)
            self.log.setFont(f)
            self.stack.addWidget(self.log)
            body.addWidget(self.stack, 1)
            col.addLayout(body, 1)
            # ---- bottom: the keyboard
            self.kb = Keyboard(24, 96)
            self.kb.noteOn.connect(lambda m, v: self._on(m, v))
            self.kb.noteOff.connect(self._off)
            self.kb.setFixedHeight(64)
            col.addWidget(self.kb)
            self.status = QLabel("pick a sound (type to search), then GROW · keys a w s e d f t g y h u j k play the voice, z / x an octave")
            self.status.setStyleSheet("color: %s;" % theme.DIM)
            col.addWidget(self.status)
            self._view(0)
            self._refresh()
            if self.audio.error:
                self.status.setText("no audio device: %s" % self.audio.error)

        # ---- views
        def _view(self, i):
            self.view_btns[i].setChecked(True)
            self.stack.setCurrentIndex(i)
            self.kb.setVisible(i != 2)
            if i == 2 and self.web is None:
                self._web_init()

        # ---- sounds
        def _pick(self, index):
            if index is None or index < 0:
                return
            label, t, d = self.sounds[index]
            x, sr = sf.read(os.path.join(d, t["file"]), dtype="float32")
            from .library import doc_of_source
            self._set_sound(dict(name=t["name"], file=t["file"], dir=d, set=label,
                                 exclude_doc=doc_of_source(t.get("source"))), x, float(t["midi"]), float(t["gate_s"]))

        def _open(self):
            p, _ = QFileDialog.getOpenFileName(self, "A note", os.path.expanduser("~"),
                                               "Audio (*.wav *.aif *.aiff *.flac *.mp3 *.m4a)")
            if not p:
                return
            x, sr = sf.read(p, dtype="float32", always_2d=True)
            x = MA.to_mono_44k(x.mean(axis=1), sr)
            x = x[MA.estimate_onset(x):]
            midi, _ = MA.estimate_pitch(x)
            gate, _ = MA.estimate_gate(x)
            chord = _chord_of(x, gate)
            self.pick.setCurrentIndex(-1)
            self.pick.lineEdit().setText(os.path.basename(p))
            self._set_sound(dict(name=os.path.basename(p), file=None, dir=None, set="your note"), x,
                            float(chord[0] if chord else midi), float(gate), chord)

        def _set_sound(self, meta, x, midi, gate, chord=None):
            self.audio.all_off()
            xn = FT.normalize(np.asarray(x, np.float32))
            self.cur = dict(meta, audio=xn, midi=midi, gate=gate, chord=chord)
            self.T = FT.Target(xn, SR, free_gain=True, gain_cost=MA.GAIN_COST)
            self.base = int(12 * np.floor(midi / 12))
            names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
            k = int(round(midi))
            what = ("chord " + " ".join("%s%d" % (names[int(round(m)) % 12], int(round(m)) // 12 - 1) for m in chord)
                    if chord else "%s %d%s" % (names[k % 12], k // 12 - 1,
                                               (" %+.0f ct" % (100 * (midi - k))) if abs(midi - k) > 0.01 else ""))
            self.info.setText("%s  ·  held %.2f s  ·  %.2f s long  ·  %s" % (what, gate, len(xn) / SR, meta.get("set", "")))
            self.voices = [None] * 5
            od = self._outdir()
            if od and os.path.exists(os.path.join(od, "grow_patch.json")):      # the bench's grown voice as A
                self.voices[0] = self._voice_from_doc(json.load(open(os.path.join(od, "grow_patch.json"))),
                                                      "bench's grown voice (small kit)")
            if od and os.path.exists(os.path.join(od, "v1e_lean.wav")):
                y, _ = sf.read(os.path.join(od, "v1e_lean.wav"), dtype="float32")
                y = FT.normalize(y[:len(xn)])
                self.voices[4] = dict(audio=y, dist=self._dist(y), label="old matcher · not a patch", family="old matcher",
                                      kinds=[], play_doc=None,
                                      nograph="the current matcher's voice is not a graph:\nit is dnasynth's own 57-gene engine (v1e)")
            self.log.setPlainText("")
            self.sel = 0 if self.voices[0] else (4 if self.voices[4] else None)
            self._show()

        def _dist(self, y):
            if self.T is None or y is None:
                return None
            y = np.pad(np.asarray(y, np.float32), (0, max(0, self.T.n - len(y))))[:self.T.n]
            return float(self.T.score(y[None])[0])

        def _voice_from_doc(self, doc, label):
            k, _ = BL.key_cents(self.cur["midi"])
            ch = self.cur.get("chord")
            play = BL.chord_keys(self.cur["midi"], ch) if ch else k
            y = L.render_note(json.dumps(doc).encode(), play, 100 / 127, self.cur["gate"], len(self.cur["audio"]) / SR)
            y = FT.normalize(y) if np.abs(y).max() > 1e-7 else y
            n = sum(1 for nd in doc["nodes"] if nd["type"] not in ("note.keyboard", "env.adsr", "util.amp", "util.mixer",
                                                                   "util.scale", "out.stereo", "dyn.comp"))
            return dict(play_doc=doc, audio=y, dist=self._dist(y), label="%s · %d blocks" % (label, n), family="bench",
                        kinds=[], nograph="the bench's grown voice (small kit) — press GROW to build A B C D on the full\n"
                                          "kit and see each voice block by block; the web synth shows this one's graph now")

        def _outdir(self):
            c = self.cur
            return os.path.join(REACH, "out", c["file"][:-4]) if c and c.get("file") else None

        # ---- the chosen voice everywhere
        def _show(self):
            c = self.cur
            for i, card in enumerate(self.cards):
                card.set_voice(self.voices[i])
                card.selected = (i == self.sel)
                card.update()
            v = self.voices[self.sel] if self.sel is not None else None
            # graph
            self.hi = None
            self.flow.set_voice(v)
            doc = v.get("play_doc") if v else None
            self.nodes.set_doc(doc, "" if doc else ((v or {}).get("nograph") or ""))
            if doc:
                nparts = len(v.get("kinds") or [])
                self.gmode_btns[1].setText("Engine nodes (%d)" % len(doc["nodes"]))
                self.gmode_hint.setText(("%d parts = %d engine nodes: a part is a block with its own envelope, "
                                         "amp or scale; the patch adds keyboard, mixer, makeup, out" % (nparts, len(doc["nodes"])))
                                        if nparts else "%d engine nodes" % len(doc["nodes"]))
            else:
                self.gmode_btns[1].setText("Engine nodes")
                self.gmode_hint.setText("")
            self._details()
            # compare
            sigs = [(c["audio"], theme.SOURCE)] if c else []
            if v is not None and c:
                sigs.append((v["audio"][:len(c["audio"])], theme.TRUTH if self.sel == 4 else theme.ACCENT))
            self.wave.set_signals(sigs, SR, secs=len(c["audio"]) / SR if c else None)
            self.wave.set_marks([(c["gate"], theme.DIM, "note off")] if c else [])
            curves = []
            if c:
                fr, d = long_term_spectrum(c["audio"])
                curves.append((fr, d, theme.SOURCE, "the note"))
            if self.voices[4] is not None and self.sel != 4:
                fr, d = long_term_spectrum(self.voices[4]["audio"])
                curves.append((fr, d, theme.TRUTH, "old matcher"))
            if v is not None:
                fr, d = long_term_spectrum(v["audio"])
                curves.append((fr, d, theme.TRUTH if self.sel == 4 else theme.ACCENT, self._name()))
            self.spec.set_curves(curves, "long-term spectra")
            self.spectro.set_pair([(c["audio"] if c else None, "the note"),
                                   (v["audio"] if v is not None else None, self._name())])
            self.bands.set_pair(c["audio"] if c else None, v["audio"] if v is not None else None)
            # live
            if v is not None and v.get("play_doc") is not None:
                self.audio.set_document(v["play_doc"], gain_db=0.0)
                self._web_load()
            self._refresh()

        def _name(self):
            if self.sel is None:
                return ""
            return "REF — the old matcher (benchmark)" if self.sel == 4 else "voice %s — %s" % ("ABCD"[self.sel], self.voices[self.sel]["family"])

        def _refresh(self):
            v = self.voices[self.sel] if self.sel is not None else None
            live = v is not None and v.get("play_doc") is not None
            self.b_voice.setEnabled(v is not None)
            self.b_voice.setText("▶  %s" % ("REF" if self.sel == 4 else "voice %s" % "ABCD"[self.sel]) if v is not None else "▶  voice")
            self.b_designer.setEnabled(live)
            self.b_export.setEnabled(live)
            self.b_target.setEnabled(self.cur is not None)
            self.b_grow.setEnabled(self.cur is not None)

        def _choose(self, i):
            if self.voices[i] is not None:
                self.sel = i
                self._show()
                self._play_voice()

        def _graph_mode(self, i):
            self.gmode_btns[i].setChecked(True)
            self.gstack.setCurrentIndex(i)

        def _pick_node(self, nid):
            """an engine node's knobs and wires, beside the Engine nodes view"""
            v = self.voices[self.sel] if self.sel is not None else None
            doc = v.get("play_doc") if v else None
            n = next((x for x in (doc or {}).get("nodes", []) if x["id"] == nid), None)
            if n is None:
                return
            esc = lambda t: str(t).replace("&", "&amp;").replace("<", "&lt;")           # noqa: E731
            rows = "".join("<tr><td style='color:%s;padding-right:12px'>%s</td><td>%s</td></tr>" % (
                theme.DIM, esc(k), esc(knob_text(k, val) if isinstance(val, (int, float)) else val))
                for k, val in n.get("params", {}).items())
            ins = ["%s.%s → %s" % (a[0], a[1], a[3]) for a in doc["audio"] if a[2] == nid]
            outs = ["%s → %s.%s" % (a[1], a[2], a[3]) for a in doc["audio"] if a[0] == nid]
            mi = ["%s.%s → %s %+.3f" % (m["from"][0], m["from"][1], m["to"][1], m["amount"])
                  for m in doc.get("mod", []) if m["to"][0] == nid]
            mo = ["→ %s.%s %+.3f" % (m["to"][0], m["to"][1], m["amount"]) for m in doc.get("mod", []) if m["from"][0] == nid]
            html = "<h3 style='margin:0'>%s</h3><p style='color:%s;margin-top:2px'>node %s</p><table>%s</table>" % (
                esc(n["type"]), theme.DIM, esc(nid), rows or "<tr><td>(no knobs)</td></tr>")
            for title, xs in (("in", ins), ("out", outs), ("modulated by", mi), ("modulates", mo)):
                if xs:
                    html += "<p><b>%s</b><br>%s</p>" % (title, "<br>".join(esc(x) for x in xs))
            self.blocks.setHtml(html)

        # ---- the microphone: one note, trimmed, analysed, kept, matched
        def _rec_toggle(self):
            if self._rec is None:
                self._rec_start()
            else:
                self._rec_stop()

        def _rec_start(self):
            try:
                import sounddevice as sd
                self.audio.all_off()
                self.audio.stop_playback()
                self._rec_chunks, self._rec_lvl = [], 0.0

                def cb(indata, frames, t, status):
                    x = indata[:, 0].copy()
                    self._rec_chunks.append(x)
                    self._rec_lvl = max(self._rec_lvl, float(np.abs(x).max()))

                st = sd.InputStream(samplerate=SR, channels=1, dtype="float32", blocksize=1024, callback=cb)
                st.start()
                try:
                    self._rec_dev = str(sd.query_devices(kind="input")["name"])
                except Exception:
                    self._rec_dev = "the default input"
            except Exception as e:
                self.status.setText("no microphone: %s" % e)
                return
            self._rec = st
            self._rec_t0 = time.time()
            self.b_rec.setText("■  Stop")
            self.b_rec.setStyleSheet("QPushButton { color: #ff6b6b; font-weight: 700; }")
            self._rec_timer = QTimer(self)
            self._rec_timer.timeout.connect(self._rec_tick)
            self._rec_timer.start(100)
            self._rec_tick()

        def _rec_tick(self):
            if self._rec is None:
                return
            secs = time.time() - self._rec_t0
            lvl, self._rec_lvl = self._rec_lvl, 0.0
            db = 20.0 * np.log10(max(lvl, 1e-6))
            bars = int(max(0, min(20, (db + 60.0) / 3.0)))
            self.info.setText("● REC  %.1f s   %s  %s" % (secs, "▮" * bars + "▯" * (20 - bars),
                                                        ("%.0f dB" % db) if lvl > 1e-6 else "silent"))
            self.status.setText("recording from %s — play or sing ONE note, then press ■ Stop (it stops by itself "
                                "at %d s)" % (self._rec_dev, REC_MAX_S))
            if secs >= REC_MAX_S:
                self._rec_stop(auto=True)

        def _rec_halt(self):
            st, self._rec = self._rec, None
            if st is None:
                return False
            self._rec_timer.stop()
            self.b_rec.setText("●  Rec")
            self.b_rec.setStyleSheet("")
            try:
                st.stop()
                st.close()
            except Exception:
                pass
            return True

        def _rec_stop(self, auto=False):
            if not self._rec_halt():
                return
            x = np.concatenate(self._rec_chunks) if self._rec_chunks else np.zeros(0, np.float32)
            self._rec_chunks = []
            if not auto:                                 # the Stop button's click, in the mic
                x = x[:max(0, len(x) - int(REC_CLICK_S * SR))]
            if len(x) < int(0.2 * SR) or np.abs(x).max() < 1e-4:
                self.info.setText("")
                self.status.setText("the microphone gave silence — on macOS allow it under System Settings → Privacy "
                                    "& Security → Microphone for the app that started the lab (Terminal, or Claude)")
                return
            x = trim_take(x, SR)
            midi, _ = MA.estimate_pitch(x)
            gate, _ = MA.estimate_gate(x)
            chord = _chord_of(x, gate)
            midi = chord[0] if chord else midi
            os.makedirs(RECDIR, exist_ok=True)
            path = os.path.join(RECDIR, time.strftime("take_%Y%m%d_%H%M%S.wav"))
            sf.write(path, x, SR, subtype="FLOAT")
            name = time.strftime("take %H:%M:%S")
            self.pick.setCurrentIndex(-1)
            self.pick.lineEdit().setText(name)
            self._set_sound(dict(name=name, file=None, dir=None, set="your recording", path=path), x, float(midi), float(gate),
                            chord)
            h = int(0.05 * SR)
            loud = 20.0 * np.log10(max(float(np.sqrt((x[:len(x) // h * h].reshape(-1, h) ** 2).mean(axis=1)).max())
                                       if len(x) >= h else float(np.abs(x).max()), 1e-9))
            if loud < REC_QUIET_DB:
                self.status.setText("a very quiet take (its loudest 50 ms at %.0f dBFS) from %s — sing or play closer "
                                    "to the microphone, or pick another input in System Settings → Sound" % (loud, self._rec_dev))
            else:
                self.status.setText("recorded %.2f s → %s · ▶ the note to hear it, then GROW"
                                    % (len(x) / SR, os.path.relpath(path, ROOT)))

        def _pick_block(self, i):
            self.hi = i
            self._details()

        def _select_block(self, i):
            self.hi = i
            self.flow.set_voice(self.voices[self.sel], i)
            self._details()

        def _details(self):
            """every block of the chosen voice with WHY it is there; the selected one with its knobs"""
            v = self.voices[self.sel] if self.sel is not None else None
            if not v or not v.get("kinds"):
                self.blocks.setHtml("<div style='color:%s; padding:10px'>%s</div>" % (
                    theme.DIM, (v or {}).get("nograph", "").replace("\n", "<br>") if v else
                    "pick a sound and press GROW"))
                return
            css = ("<style>body{color:%s;font-size:13px} .b{padding:8px 10px;margin:0 0 6px 0;border-radius:6px}"
                   " .t{font-weight:600;font-size:14px} .w{color:%s;margin-top:3px} td{padding:1px 10px 1px 0}"
                   " a{text-decoration:none;color:%s}</style>" % (theme.TEXT, theme.DIM, theme.TEXT))
            parts = [css, "<div style='color:%s;margin:2px 0 8px 2px'>%d blocks — click one for its knobs</div>" % (
                theme.DIM, len(v["kinds"]))]
            for i, (k, why, prm, rt) in enumerate(zip(v["kinds"], v["whys"], v["params"], v["ratios"])):
                col = ROLE_COL[block_role(k)]
                bg = theme.PANEL if i == self.hi else theme.PANEL2
                knobs = ""
                if i == self.hi:
                    rows = "".join("<tr><td style='color:%s'>%s</td><td>%s</td></tr>" % (
                        theme.DIM, n, knob_text(n, val)) for n, val in prm.items())
                    knobs = "<table style='margin-top:6px'>%s</table>" % rows
                parts.append("<div class='b' style='background:%s;border-left:4px solid %s'>"
                             "<a href='block:%d'><span class='t'>%s</span></a>"
                             "<div class='w'>%s</div>%s</div>" % (bg, col, i, block_title(k, prm, rt), why, knobs))
            self.blocks.setHtml("".join(parts))

        # ---- playback
        def _play(self, y):
            self.audio.stop_playback()
            if y is not None:
                self.audio.play(FT.normalize(np.asarray(y, np.float32)) * 0.5)

        def _play_target(self):
            if self.cur:
                self._play(self.cur["audio"])

        def _play_voice(self):
            v = self.voices[self.sel] if self.sel is not None else None
            if v is not None:
                self._play(v["audio"])

        def _live(self):
            v = self.voices[self.sel] if self.sel is not None else None
            return v is not None and v.get("play_doc") is not None

        def _on(self, m, vel=0.8):
            if self._live():
                self.audio.note_on(m, vel)

        def _off(self, m):
            if self._live():
                self.audio.note_off(m)

        def keyPressEvent(self, e):
            t = e.text().lower()
            if e.isAutoRepeat() or not t or self.pick.lineEdit().hasFocus():
                return
            if t == "z":
                self.base = max(12, self.base - 12)
            elif t == "x":
                self.base = min(96, self.base + 12)
            elif t in KEYMAP and t not in self.held:
                m = self.base + KEYMAP.index(t)
                self.held[t] = m
                self._on(m)
            self.status.setText("keys from C%d — a w s e d f t g y h u j k, z / x an octave" % (self.base // 12 - 1))

        def keyReleaseEvent(self, e):
            t = e.text().lower()
            if e.isAutoRepeat() or t not in self.held:
                return
            self._off(self.held.pop(t))

        # ---- growing
        def _grow(self):
            if self.cur is None:
                return
            if self.job is not None:
                self.job.cancel()
                return
            b = self.builder.currentIndex()
            tmpl = b == 1
            self.log.setPlainText(("matching %s with the analog template — %d renders\n" if tmpl else
                                   "growing %s as a DASHBOARD instrument — %d renders\n" if b == 2 else
                                   "growing %s — %d renders, the full kit\n") % (self.cur["name"], self.budget.value()))
            self._view(3)
            self.b_grow.setText("Cancel")
            self.bar.setValue(0)
            self.t0 = time.perf_counter()
            self.job = GrowJob((self.cur["audio"], SR, self.cur["midi"], self.cur["gate"], self.budget.value(), 0,
                                bool(self.use_net.isChecked()), int(self.polish_k.value()),
                                bool(self.use_tmpl.isChecked()), bool(self.use_lib.isChecked()),
                                self.cur.get("exclude_doc"), self.cur.get("chord")),
                               _template_worker if tmpl else _dash_worker if b == 2 else _grow_worker)
            self.job.log.connect(lambda s: self.log.appendPlainText(s))
            self.job.progress.connect(self._progress)
            self.job.done.connect(self._grown)
            self.job.failed.connect(self._failed)
            self.job.start()

        def _progress(self, f):
            self.bar.setValue(int(1000 * f))
            self.status.setText("growing… %d %%" % int(100 * f))

        def _release(self):
            j, self.job = self.job, None
            if j is not None:
                j.wait(5000)

        def _grown(self, r):
            self._release()
            self.b_grow.setText("GROW")
            self.bar.setValue(1000)
            self.log.appendPlainText("\nGROWN in %.0f s (%d renders)" % (time.perf_counter() - self.t0, r["renders"]))
            alts = r["alternatives"][:4]
            for i, a in enumerate(alts):
                a["dist"] = self._dist(a["audio"])
                fam = a["family"].replace("src:osc.", "").replace("flt:filter.", "")
                n = len(a.get("parts") or a["kinds"])
                a["label"] = "%s · %d %s%s" % (fam, n, "part" if a.get("parts") else "block", "" if n == 1 else "s")
                self.log.appendPlainText("  %s  %-16s distance %.3f  %s" % ("ABCD"[i], a["family"], a["dist"],
                                                                         " · ".join(a.get("parts") or a["kinds"])))
            self.voices[:4] = alts + [None] * (4 - len(alts))
            self.sel = 0
            self._view(0)
            self._graph_mode(1 if alts and alts[0].get("parts") else 0)
            self._show()
            self.status.setText("A is the closest; click B C D (and REF) to hear the other families · keys play the chosen voice")

        def _failed(self, msg):
            self._release()
            self.b_grow.setText("GROW")
            self.log.appendPlainText("\n" + msg)

        # ---- the web synth
        def _web_init(self):
            try:
                from PySide6.QtWebEngineCore import QWebEngineSettings
                from PySide6.QtWebEngineWidgets import QWebEngineView
            except Exception as e:
                self.web_hint.setText("no Qt WebEngine: %s" % e)
                return
            if not os.path.exists(WEB):
                self.web_hint.setText("the web synth bundle is missing: %s" % WEB)
                return
            self.web = QWebEngineView()
            st = self.web.settings()
            st.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
            st.setAttribute(QWebEngineSettings.PlaybackRequiresUserGesture, False)
            self.web.loadFinished.connect(self._web_loaded)
            self.webw.layout().addWidget(self.web, 1)
            self.web_hint.setText("pchkraft-synth's web synth with the chosen voice loaded — click once inside it to start its audio")
            self.web.setUrl(QUrl.fromLocalFile(WEB))

        def _web_loaded(self, ok):
            def poll(n=0):
                def got(v):
                    if v:
                        self.web_ready = True
                        self._web_load()
                    elif n < 80:
                        QTimer.singleShot(250, lambda: poll(n + 1))
                self.web.page().runJavaScript("!!window.__growApp", 0, got)
            poll()

        def _web_load(self):
            v = self.voices[self.sel] if self.sel is not None else None
            if self.web is None or not self.web_ready or v is None or v.get("play_doc") is None:
                return
            name = "%s %s" % (self._name(), (self.cur or {}).get("name", ""))
            js = "window.__growApp.loadPatchObject(%s, %s)" % (json.dumps(v["play_doc"]), json.dumps(name))
            self.web.page().runJavaScript(js)

        # ---- out
        def _designer(self):
            v = self.voices[self.sel] if self.sel is not None else None
            if not v or v.get("play_doc") is None:
                return
            fd, p = tempfile.mkstemp(prefix="grown_", suffix=".json")
            with os.fdopen(fd, "w") as fh:
                json.dump(v["play_doc"], fh, indent=1)
            subprocess.Popen([sys.executable, "-m", "pchsynth", "--patch", p], cwd=PKS)
            self.status.setText("opened in pchkraft-synth's designer: %s" % p)

        def _export(self):
            v = self.voices[self.sel] if self.sel is not None else None
            if not v or v.get("play_doc") is None:
                return
            p, _ = QFileDialog.getSaveFileName(self, "Export the patch", os.path.expanduser("~/grown.json"),
                                               "Patch document (*.json)")
            if p:
                with open(p, "w") as fh:
                    json.dump(v["play_doc"], fh, indent=1)
                self.status.setText("exported %s" % p)

        def closeEvent(self, e):
            self._rec_halt()
            if self.job is not None:
                self.job.cancel()
                self.job.wait(5000)
            self.audio.close()
            super().closeEvent(e)

    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("GROW Lab")                  # the menu bar and the Dock (GROW Lab.app)
    app.setApplicationDisplayName("GROW Lab")
    icon = os.environ.get("GROW_LAB_ICON") or os.path.join(ROOT, "assets", "grow_lab_1024.png")
    if os.path.exists(icon):
        from PySide6.QtGui import QIcon
        app.setWindowIcon(QIcon(icon))
    app.setStyleSheet(theme.STYLESHEET + """
        QPushButton:checked { background: %(panel2)s; color: %(accent)s; border: 1px solid %(accent)s; }
        QTreeWidget { background: %(panel2)s; border: 1px solid %(edge)s; border-radius: 6px; }
        QTreeWidget::item { padding: 3px 2px; }
        QHeaderView::section { background: %(panel)s; color: %(dim)s; border: none; padding: 4px; }
        QComboBox { padding: 4px 8px; }
    """ % dict(edge=theme.EDGE, panel=theme.PANEL, panel2=theme.PANEL2, dim=theme.DIM, accent=theme.ACCENT))
    win = Lab()
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
