"""GROW: a matcher that builds its own graph (2026-10-03).

Where v1 tunes one fixed voice and DNA v2 one fixed graph, GROW starts from a single source and
adds pchkraft-synth blocks one at a time -- a sine partial at a ratio the analysis read off the
target, an FM pair, a band of noise, a pluck, a pitch envelope, a vibrato, a filter, an EQ peak,
a chorus, a room -- each only when the matcher's fitness says it buys more than it costs. Every
step searches a handful of genes (the regime where search recovers patches exactly: memory
`pchsynth-dimensionality-is-the-wall`), and the order of the steps -- the biggest thing still
missing first -- decides which block does what, so the swapped-twin symmetry of a free graph
never arises. The result is a format-1 patch document: it plays on the board, iOS and the web.

    blocks.py    the pieces (each a few existing pchkraft-core/synth blocks + genes 0..1) and the
                 patch document of a list of them
    analyse.py   what a note is made of: its sinusoidal peaks above the noise floor, the floor
                 band by band, the envelope, the pitch track, the wobble, the tail -- and, from a
                 target and the current render, the moves worth trying
    build.py     the builder: start, grow, polish

The graph library is a COPY of pchkraft-core's build of 2026-09-30 (build/engines/
libpcksg_1003.dylib, the engine the device runs today), set as DN_PCKSG_LIB before dnasynth.graph's
binding loads -- unless the process loaded that binding first (then its library wins).
"""
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ENGINE = os.path.join(_ROOT, "build", "engines", "libpcksg_1003.dylib")
os.environ.setdefault("DN_PCKSG_LIB", ENGINE)
