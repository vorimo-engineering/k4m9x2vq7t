"""The pieces a grown voice is made of, and the patch document of a list of them.

A piece (Module) is a kind, a few genes in 0..1 and -- for a sine partial or an FM carrier -- the
ratio the analysis read off the target. Every piece is built from existing pchkraft-core/synth
blocks; nothing here is DSP. The skeleton every grown voice shares (so a document is always
valid and two growths of one sound are comparable):

    sources (tone / partial / fm / noise / pluck / fm4), each through its own amp envelope (a
    four-operator piece: its operators' own envelopes)
      -> mixers (four inputs each, chained)
      -> [filter: filter.svf with its own envelope and key tracking] -> [drive]      per voice
      -> [eq.peak ...] -> [fx.chorus] -> [fx.room] -> out.stereo                      global
    modulators: [pitch envelope], [vibrato] -> the pitch of every pitched oscillator

A gene law maps 0..1 to the block's physical value; `encode` is its inverse, used to start a
piece where the analysis measured it (a partial's decay, a noise band's centre).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import numpy as np

CUT_OCT = float(np.log2(18000.0 / 20.0))     # filter.svf cutoff travel (exponential), octaves
OP_OCT = float(np.log2(16.0 / 0.25))         # osc.op ratio travel (exponential), octaves
TUNE_ST = 48.0                               # osc.va / osc.string tune travel, semitones
RATIO_CT = 60.0                              # a partial's / carrier's tune gene: +-60 cents
DZ = 0.04                                    # dead zone of a bipolar gene
OUT_LEVEL = 0.3                              # out.stereo level: headroom below its soft limiter
KEY_MIN = 0.02                               # a keytracking gain under this gets no util.scale at all

FM_RATIOS = (0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0,
             13.0, 14.0, 15.0, 16.0)

# (name, law, a, b, neutral): lin a..b | exp a..b | sq 0..b (squared) | bip +-b (power a, dead
# zone) | step over the tuple a
ENV = (("att", "exp", 0.001, 8.0, 0.0), ("dec", "exp", 0.002, 12.0, 0.55),
       ("sus", "lin", 0.0, 1.0, 0.7), ("rel", "exp", 0.002, 12.0, 0.45))
KINDS = {
    # osc.va: the analog shapes (sine 0, triangle 1/3, saw 2/3, pulse 1, continuous)
    "tone": (("shape", "lin", 0.0, 1.0, 2 / 3), ("pw", "lin", 0.05, 0.5, 1.0),
             ("oct", "step", (-2, -1, 0, 1, 2), None, 0.5), ("detune", "bip", 2.0, 50.0, 0.5),
             ("level", "sq", 0.0, 1.0, 0.8)) + ENV,
    # osc.op as a pure sine at the analysed ratio (+-RATIO_CT)
    "partial": (("tune", "lin", -RATIO_CT, RATIO_CT, 0.5), ("level", "sq", 0.0, 1.0, 0.6)) + ENV,
    # two osc.op: the carrier at the analysed ratio, phase-modulated by the modulator through an
    # amp whose level is the index (cycles) and whose gain is the index envelope
    # the modulator's ratio on plateaus (a DX7's coarse ratios: an e-piano's tine is 14:1 exactly,
    # and a continuous ratio near it is an inharmonic clang), then a fine detune +-3 % (bells)
    "fm": (("tune", "lin", -RATIO_CT, RATIO_CT, 0.5), ("mratio", "step", FM_RATIOS, None, 0.075),
           ("mfine", "lin", -3.0, 3.0, 0.5), ("mfb", "sq", 0.0, 1.3, 0.0),
           ("index", "sq", 0.0, 1.5, 0.5), ("idec", "exp", 0.002, 12.0, 0.5),
           ("isus", "lin", 0.0, 1.0, 0.3), ("level", "sq", 0.0, 1.0, 0.7)) + ENV,
    # osc.noise -> filter.svf (morph: low pass 0 .. band pass .. high pass 1)
    "noise": (("colour", "lin", 0.0, 1.0, 0.5), ("freq", "exp", 20.0, 18000.0, 0.7),
              ("res", "lin", 0.0, 0.95, 0.3), ("morph", "lin", 0.0, 1.0, 0.5),
              ("level", "sq", 0.0, 1.0, 0.5)) + ENV,
    # osc.string: a noise burst in a loop one period long
    "pluck": (("decay", "exp", 0.05, 20.0, 0.45), ("damp", "lin", 0.0, 1.0, 0.35),
              ("pick", "lin", 0.0, 0.5, 0.5), ("colour", "lin", 0.0, 1.0, 0.5),
              ("stiff", "lin", 0.0, 1.0, 0.0), ("level", "sq", 0.0, 1.0, 0.8),
              ("rel", "exp", 0.002, 12.0, 0.45)),
    # env.ahd -> the pitch of every pitched oscillator (semitones; a drum's fall is negative)
    "pitchenv": (("depth", "bip", 2.0, 24.0, 0.5), ("pdec", "exp", 0.002, 2.0, 0.4)),
    # lfo.voice (sine, re-triggered) -> the same pitches
    "vibrato": (("rate", "exp", 0.5, 12.0, 0.7), ("depth", "sq", 0.0, 1.0, 0.3),
                ("fade", "lin", 0.0, 2.0, 0.1)),
    # filter.svf after the mix: its own ADSR on the cutoff (octaves), key tracking
    "filter": (("cut", "exp", 20.0, 18000.0, 0.75), ("res", "lin", 0.0, 0.95, 0.15),
               ("morph", "lin", 0.0, 1.0, 0.0), ("fenv", "bip", 1.5, 6.0, 0.5),
               ("fatt", "exp", 0.001, 8.0, 0.0), ("fdec", "exp", 0.002, 12.0, 0.5),
               ("fsus", "lin", 0.0, 1.0, 0.5), ("key", "lin", 0.0, 1.0, 0.5)),
    # lfo.voice (sine) dipping a voice amp after the filter: amplitude modulation (a DX7 vibe)
    "tremolo": (("rate", "exp", 0.5, 12.0, 0.6), ("depth", "sq", 0.0, 1.0, 0.5)),
    "drive": (("amount", "sq", 0.0, 1.0, 0.4),),
    # eq.peak (global): a resonance or a hole the sources do not make
    "eq": (("freq", "exp", 20.0, 18000.0, 0.6), ("gain", "lin", -24.0, 24.0, 0.5),
           ("q", "exp", 0.3, 10.0, 0.4)),
    "chorus": (("rate", "exp", 0.05, 8.0, 0.5), ("depth", "lin", 0.0, 1.0, 0.5),
               ("mix", "lin", 0.0, 1.0, 0.4)),
    "room": (("decay", "exp", 0.1, 20.0, 0.4), ("size", "lin", 0.0, 1.0, 0.5),
             ("damp", "lin", 0.0, 1.0, 0.35), ("mix", "sq", 0.0, 1.0, 0.4)),
}
# FOUR OPERATORS (2026-10-04, Volo: "make sure templates has all our available oscillators"):
# util.opmix -- eight four-operator algorithms on one continuous knob; measured (operators 1..4):
# 1-2 a chain into 1, 3 two modulators into 1, 4 TWO STACKS (2 -> 1, 4 -> 3), 5 three into 1, 6 a
# pair and two sines, 7 one modulator on three carriers, 8 four sines -- four osc.op, each one's
# level its OWN envelope (env.adsr -> util.scale, the gain its output level -> the operator's level,
# parked at 0: pchkraft-synth's pk-dx7 wiring), each ratio a DX7 coarse step times a fine detune
# (exactly 0 in its dead zone, +-50 % at the ends: any ratio between two steps), feedback on 2
FM4_TWO_STACKS, FM4_PAIR_SINES = 4.0, 6.0


def _fm4_specs():
    out = [("algo", "lin", 1.0, 8.0, (FM4_TWO_STACKS - 1.0) / 7.0)]
    for k in range(1, 5):
        out += [("rat%d" % k, "step", FM_RATIOS, None, 0.075), ("fin%d" % k, "bip", 2.0, 50.0, 0.5),
                ("lev%d" % k, "sq", 0.0, 1.0, 0.8 if k in (1, 3) else 0.6),
                ("att%d" % k, "exp", 0.001, 8.0, 0.0), ("dec%d" % k, "exp", 0.002, 12.0, 0.55),
                ("sus%d" % k, "lin", 0.0, 1.0, 0.7), ("rel%d" % k, "exp", 0.002, 12.0, 0.45)]
    return tuple(out) + (("fb", "sq", 0.0, 1.3, 0.0), ("level", "sq", 0.0, 1.0, 0.8))


KINDS["fm4"] = _fm4_specs()
SOURCES = ("tone", "partial", "fm", "noise", "pluck", "fm4")
PITCHED = ("tone", "partial", "fm", "pluck", "fm4")
def is_source(kind):
    """a sound source: the first five kinds, or a kit oscillator (src:...)"""
    return kind in SOURCES or kind.startswith("src:")


def is_pitched(kind):
    return kind in PITCHED or kind.startswith("src:")


# how many of a kind a voice may hold (the skeleton has one slot for the rest)
MAX_OF = dict(tone=4, partial=12, fm=3, noise=3, pluck=1, eq=3, fm4=1)


def release_of(m):
    """a source's longest release, s (a four-operator piece: its operators'), or None"""
    p = m.p()
    if "rel" in p:
        return float(p["rel"])
    if m.kind == "fm4":
        return max(float(p["rel%d" % k]) for k in range(1, 5))
    return None


def _bip(g, power):
    x = 2.0 * min(1.0, max(0.0, float(g))) - 1.0
    a = abs(x) - DZ
    if a <= 0.0:
        return 0.0
    y = (a / (1.0 - DZ)) ** power
    return -y if x < 0 else y


def decode(spec, g):
    """one gene (0..1) -> its physical value"""
    _, law, a, b, _ = spec
    g = min(1.0, max(0.0, float(g)))
    if law == "lin":
        return a + g * (b - a)
    if law == "exp":
        return a * (b / a) ** g
    if law == "sq":
        return b * g * g
    if law == "bip":
        return b * _bip(g, a)
    if law == "step":
        return a[min(len(a) - 1, int(g * len(a)))]
    if law == "norm":                                   # a kit knob: the engine's own law (kit.py)
        return float(a.physical(g))
    raise ValueError(law)


def encode(spec, v):
    """the inverse of decode: the gene that gives physical value v (clamped to the travel)"""
    _, law, a, b, _ = spec
    if law == "lin":
        return float(np.clip((v - a) / (b - a), 0.0, 1.0))
    if law == "exp":
        return float(np.clip(np.log(max(v, 1e-12) / a) / np.log(b / a), 0.0, 1.0))
    if law == "sq":
        return float(np.clip(np.sqrt(max(v, 0.0) / b), 0.0, 1.0))
    if law == "bip":
        y = min(1.0, abs(v) / b) ** (1.0 / a)
        x = DZ + y * (1.0 - DZ) if y > 0 else 0.0
        return float(np.clip(0.5 + 0.5 * np.sign(v) * x, 0.0, 1.0))
    if law == "step":
        i = int(np.argmin([abs(v - q) for q in a]))
        return (i + 0.5) / len(a)
    if law == "norm":
        return float(np.clip(a.from_file(v) if isinstance(v, str) else a.normalise(float(v)), 0.0, 1.0))
    raise ValueError(law)


def _kit_params(block, m):
    """a kit piece's block knobs for the document: the searched ones from the genes (the file's
    form: a number, or a selector's label), the pinned ones"""
    from . import kit as KT
    k = KT.KIT[block]
    nt = KT.types()[block]
    out = {}
    for spec, g in zip(KINDS[m.kind], m.g):
        if spec[1] == "norm":
            out[spec[0]] = spec[2].to_file(float(np.clip(g, 0.0, 1.0)))
    for key, v in k["fixed"].items():
        out[key] = nt.param(key).to_file(nt.param(key).normalise(v))
    return out


@dataclass
class Module:
    kind: str
    g: np.ndarray                                   # genes 0..1, in KINDS[kind] order
    ratio: float = 1.0                              # partial / fm carrier: the analysed ratio
    why: str = ""                                   # what the analysis saw (the build log)
    extra: dict = field(default_factory=dict)       # a piece's own data (the dashboard's chosen knobs)

    @staticmethod
    def new(kind, ratio=1.0, why="", **phys):
        """a piece at its neutral genes, with the named PHYSICAL values set (encode)"""
        spec = KINDS[kind]
        g = np.array([s[4] for s in spec], np.float64)
        for k, v in phys.items():
            i = [s[0] for s in spec].index(k)
            g[i] = encode(spec[i], v)
        return Module(kind, g, float(ratio), why)

    def copy(self):
        import copy as _copy
        return Module(self.kind, self.g.copy(), self.ratio, self.why, _copy.deepcopy(self.extra))

    def p(self):
        """the physical values, by gene name"""
        return {s[0]: decode(s, x) for s, x in zip(KINDS[self.kind], self.g)}

    def names(self):
        return [s[0] for s in KINDS[self.kind]]


def _split_cents(c):
    """cents -> (semitones, fine within +-50)"""
    st = int(np.floor(c / 100.0 + 0.5))
    return st, float(c - 100.0 * st)


def document(mods, cents=0.0, name="grown", seed=1, voices=1, _no_dash=False) -> dict:
    """the format-1 patch document of a list of pieces (physical values; one voice for matching,
    more to play). cents: the patch's fine tuning (the graph plays keys; a note between two keys
    is its nearest key and this). A voice holding a `dash` piece is a DASHBOARD voice: its
    document is dash.document's (this one builds what lies underneath)"""
    if not _no_dash and any(m.kind == "dash" for m in mods):
        from . import dash as DS
        return DS.document(mods, cents=cents, name=name, seed=seed, voices=voices)
    nodes = [dict(id="kbd", type="note.keyboard", params={})]
    audio, links = [], {}
    pitched = []                                     # (node id, param, travel in semitones)
    srcs = []                                        # (index, node, port, level, envelope or None)
    flat_ok = _no_dash                               # a dashboard voice: ENV 1 carries the note

    def own_env(i, att, dec, sus, rel):
        """a source's envelope as a key (None: FLAT on a dashboard voice -- no ADSR, no amp)"""
        e = (float(att), float(dec), float(sus), float(rel))
        if flat_ok and e[0] <= 0.0011 and e[2] >= 0.999 and e[3] >= 11.9:
            return None
        return e

    def env(eid, p, att=None, dec=None, sus=None, rel=None):
        nodes.append(dict(id=eid, type="env.adsr", params=dict(
            attack=float(p["att"] if att is None else att), decay=float(p["dec"] if dec is None else dec),
            sustain=float(p["sus"] if sus is None else sus), release=float(p["rel"] if rel is None else rel))))

    def amp(i, src, port="out"):
        nodes.append(dict(id="a%d" % i, type="util.amp", params=dict(level=1.0)))
        audio.append([src, port, "a%d" % i, "l"])
        audio.append(["e%d" % i, "out", "a%d" % i, "gain"])
        return ("a%d" % i, "l")

    mod_of = {}
    for m in mods:
        mod_of.setdefault(m.kind, []).append(m)
    for i, m in enumerate(mods):
        p, s = m.p(), "s%d" % i
        if m.kind == "tone":
            st, fine = _split_cents(cents + p["detune"])
            nodes.append(dict(id=s, type="osc.va", params=dict(
                shape=float(p["shape"]), pw=float(p["pw"]), octave=int(p["oct"]), tune=float(st),
                fine=fine, keytrack=1.0)))
            pitched.append((s, "tune", TUNE_ST))
            srcs.append((i, s, "out", p["level"], own_env(i, p["att"], p["dec"], p["sus"], p["rel"])))
        elif m.kind in ("partial", "fm"):
            r = m.ratio * 2.0 ** (p["tune"] / 1200.0)
            st, fine = _split_cents(cents)
            r = float(np.clip(r * 2.0 ** (st / 12.0), 0.25, 16.0))
            nodes.append(dict(id=s, type="osc.op", params=dict(ratio=r, fine=fine, level=1.0,
                                                             feedback=0.0, kscale=0.0)))
            pitched.append((s, "ratio", 12.0 * OP_OCT))
            if m.kind == "fm":
                mr = float(np.clip(p["mratio"] * (1.0 + p["mfine"] / 100.0) * 2.0 ** (st / 12.0), 0.25, 16.0))
                nodes.append(dict(id="m%d" % i, type="osc.op", params=dict(
                    ratio=mr, fine=fine, level=1.0, feedback=float(p["mfb"]), kscale=0.0)))
                pitched.append(("m%d" % i, "ratio", 12.0 * OP_OCT))
                nodes.append(dict(id="pm%d" % i, type="util.amp", params=dict(level=float(p["index"]))))
                env("ie%d" % i, p, att=0.001, dec=p["idec"], sus=p["isus"])
                audio += [["m%d" % i, "out", "pm%d" % i, "l"], ["ie%d" % i, "out", "pm%d" % i, "gain"],
                          ["pm%d" % i, "l", s, "pm"]]
            srcs.append((i, s, "out", p["level"], own_env(i, p["att"], p["dec"], p["sus"], p["rel"])))
        elif m.kind == "fm4":
            st, fine = _split_cents(cents)
            nodes.append(dict(id=s, type="util.opmix", params=dict(algo=float(p["algo"]))))
            for k in range(1, 5):
                o, e, g = "o%d_%d" % (i, k), "oe%d_%d" % (i, k), "og%d_%d" % (i, k)
                r = float(np.clip(p["rat%d" % k] * (1.0 + p["fin%d" % k] / 100.0) * 2.0 ** (st / 12.0), 0.25, 16.0))
                nodes.append(dict(id=o, type="osc.op", params=dict(ratio=r, fine=fine, level=0.0, kscale=0.0,
                                                                 feedback=float(p["fb"]) if k == 2 else 0.0)))
                env(e, p, att=p["att%d" % k], dec=p["dec%d" % k], sus=p["sus%d" % k], rel=p["rel%d" % k])
                nodes.append(dict(id=g, type="util.scale", params=dict(gain=float(p["lev%d" % k]), offset=0.0)))
                audio += [[e, "out", g, "in"], [o, "out", s, "abcd"[k - 1]], [s, "pm%d" % k, o, "pm"]]
                links[(g, "out", o, "level")] = 1.0
                pitched.append((o, "ratio", 12.0 * OP_OCT))
            srcs.append((i, s, "out", p["level"], None))      # its operators' envelopes ARE its envelope
        elif m.kind == "noise":
            nodes.append(dict(id=s, type="osc.noise", params=dict(colour=float(p["colour"]),
                                                                level=1.0, mode="tilt")))
            nodes.append(dict(id="f%d" % i, type="filter.svf", params=dict(
                cutoff=float(p["freq"]), res=float(p["res"]), mode="morph", morph=float(p["morph"]))))
            audio.append([s, "out", "f%d" % i, "l"])
            srcs.append((i, "f%d" % i, "l", p["level"], own_env(i, p["att"], p["dec"], p["sus"], p["rel"])))
        elif m.kind.startswith("src:"):
            from . import kit as KT
            block = m.kind[4:]
            k = KT.KIT[block]
            params = _kit_params(block, m)
            st, fine = _split_cents(cents)
            if k.get("tune"):
                params[k["tune"]] = float(st)
            if k.get("fine"):
                params[k["fine"]] = fine
            nodes.append(dict(id=s, type=block, params=params))
            if k.get("tune"):
                pitched.append((s, k["tune"], TUNE_ST))
            srcs.append((i, s, k["out"], p["level"], own_env(i, p["att"], p["dec"], p["sus"], p["rel"])))
        elif m.kind == "pluck":
            st, fine = _split_cents(cents)
            nodes.append(dict(id=s, type="osc.string", params=dict(
                decay=float(p["decay"]), damp=float(p["damp"]), pick=float(p["pick"]),
                colour=float(p["colour"]), stiff=float(p["stiff"]), tune=float(st), fine=fine)))
            pitched.append((s, "tune", TUNE_ST))
            srcs.append((i, s, "out", p["level"], own_env(i, 0.001, 12.0, 1.0, p["rel"])))
    if not srcs:
        raise ValueError("a voice needs a source")

    def chain(prefix, ins):
        """mixers of four inputs, chained (a later mixer takes the one before on its input a) ->
        (the last one's output, where each input's level sits: (mixer, input))"""
        prev, k, todo, placed = None, 0, list(ins), []
        while todo:
            mid = "%s%d" % (prefix, k)
            take = todo[:4 - (1 if prev else 0)]
            todo = todo[len(take):]
            lv = {c: 0.0 for c in "abcd"}
            row = ([(prev[0], prev[1], 1.0)] if prev else []) + take
            for c, (nid, port, level) in zip("abcd", row):
                lv[c] = float(level)
                audio.append([nid, port, mid, c])
            placed += [(mid, c) for c in "abcd"[len(row) - len(take):len(row)]]
            nodes.append(dict(id=mid, type="util.mixer", params=lv))
            prev, k = (mid, "out"), k + 1
        return prev, placed

    # THE ENVELOPES, SHARED. Sources whose envelopes are IDENTICAL are mixed first and pass ONE amp
    # under ONE envelope -- three oscillators on one envelope are one ADSR and one VCA, as a person
    # patches them (build.merge_envelopes makes close envelopes identical when the sound allows);
    # a FLAT envelope on a dashboard voice is none at all; a source with its own keeps it, as before
    units, order = {}, []
    for q in srcs:
        key = None if q[4] is None else tuple(round(x, 9) for x in q[4])
        if key not in units:
            units[key] = []
            order.append(key)
        units[key].append(q)
    levels, outs = {}, []                            # source -> (mixer, input) holding its level
    for key in order:
        mem = units[key]
        if key is None:
            outs += [(node, port, level, i) for i, node, port, level, _ in mem]
            continue
        i0 = mem[0][0]
        env("e%d" % i0, None, *mem[0][4])
        if len(mem) == 1:
            outs.append(amp(i0, mem[0][1], mem[0][2]) + (mem[0][3], i0))
            continue
        sub_out, placed = chain("sm%d_" % i0, [(node, port, level) for _, node, port, level, _ in mem])
        for q, where in zip(mem, placed):
            levels[q[0]] = where
        outs.append(amp(i0, sub_out[0], sub_out[1]) + (1.0, None))
    last, placed = chain("mx", [(nid, port, level) for nid, port, level, _ in outs])
    for (_, _, _, i), where in zip(outs, placed):
        if i is not None:
            levels[i] = where
    if "filter" in mod_of:
        p = mod_of["filter"][0].p()
        nodes += [dict(id="flt", type="filter.svf", params=dict(cutoff=float(p["cut"]), res=float(p["res"]),
                                                                mode="morph", morph=float(p["morph"]))),
                  dict(id="fe", type="env.adsr", params=dict(attack=float(p["fatt"]), decay=float(p["fdec"]),
                                                             sustain=float(p["fsus"]), release=0.3))]
        audio.append([last[0], last[1], "flt", "l"])
        if p["key"] >= KEY_MIN:                      # no scaler for a tracking that does nothing
            nodes.append(dict(id="ks", type="util.scale", params=dict(gain=float(p["key"]), offset=0.0)))
            audio += [["kbd", "pitch", "ks", "in"], ["ks", "out", "flt", "cutoff"]]
        links[("fe", "out", "flt", "cutoff")] = p["fenv"] / CUT_OCT
        last = ("flt", "l")
    kit_flt = [m for m in mods if m.kind.startswith("flt:")]
    main_cut = ("flt", "cutoff", CUT_OCT) if "filter" in mod_of else None
    if "filter" not in mod_of and kit_flt:
        from . import kit as KT
        m = kit_flt[0]
        block, p = m.kind[4:], m.p()
        k = KT.KIT[block]
        nodes.append(dict(id="flt", type=block, params=_kit_params(block, m)))
        audio.append([last[0], last[1], "flt", "l"])
        nodes.append(dict(id="fe", type="env.adsr", params=dict(attack=float(p["fatt"]), decay=float(p["fdec"]),
                                                                sustain=float(p["fsus"]), release=0.3)))
        links[("fe", "out", "flt", k["cut"])] = p["fenv"] / KT.cut_travel(block, k["cut"])
        if k.get("cv") and p["key"] >= KEY_MIN:
            nodes.append(dict(id="ks", type="util.scale", params=dict(gain=float(p["key"]), offset=0.0)))
            audio += [["kbd", "pitch", "ks", "in"], ["ks", "out", "flt", k["cv"]]]
        main_cut = ("flt", k["cut"], KT.cut_travel(block, k["cut"]))
        last = ("flt", "l")
    if "drive" in mod_of:
        nodes.append(dict(id="drv", type="shaper.drive", params=dict(amount=float(mod_of["drive"][0].p()["amount"]))))
        audio.append([last[0], last[1], "drv", "l"])
        last = ("drv", "l")
    for j, m in enumerate([m for m in mods if m.kind.startswith(("hp:", "ins:"))]):
        from . import kit as KT
        block = KT.block_of(m.kind)
        nid = "ins%d" % j
        nodes.append(dict(id=nid, type=block, params=_kit_params(block, m)))
        audio.append([last[0], last[1], nid, "l"])
        if KT.KIT[block].get("cv") and m.kind.startswith("ins:") and m.p()["key"] >= KEY_MIN:
            nodes.append(dict(id="kc%d" % j, type="util.scale", params=dict(gain=float(m.p()["key"]), offset=0.0)))
            audio += [["kbd", "pitch", "kc%d" % j, "in"], ["kc%d" % j, "out", nid, KT.KIT[block]["cv"]]]
        last = (nid, "l")
    if "tremolo" in mod_of:
        p = mod_of["tremolo"][0].p()
        nodes += [dict(id="trm", type="lfo.voice", params=dict(shape="sine", rate=float(p["rate"]), depth=1.0,
                                                              fade=0.0, mode="retrig")),
                  dict(id="vamp", type="util.amp", params=dict(level=1.0))]
        audio.append([last[0], last[1], "vamp", "l"])
        links[("trm", "uni", "vamp", "level")] = -float(p["depth"]) / 1.5    # util.amp level travel 0..1.5
        last = ("vamp", "l")
    for kind, pid, ptype, param in (("pitchenv", "pe", "env.ahd", None), ("vibrato", "vib", "lfo.voice", None)):
        if kind not in mod_of:
            continue
        p = mod_of[kind][0].p()
        if kind == "pitchenv":
            nodes.append(dict(id=pid, type=ptype, params=dict(attack=0.001, hold=0.0, decay=float(p["pdec"]),
                                                             loop="off")))
            st = p["depth"]
        else:
            nodes.append(dict(id=pid, type=ptype, params=dict(shape="sine", rate=float(p["rate"]), depth=1.0,
                                                             fade=float(p["fade"]), mode="retrig")))
            st = p["depth"]
        for nid, param, travel in pitched:
            links[(pid, "out", nid, param)] = st / travel
    # the global chain: mono in on both sides of the first block
    chain = []
    for j, m in enumerate(mod_of.get("eq", [])):
        p = m.p()
        nodes.append(dict(id="eq%d" % j, type="eq.peak", params=dict(freq=float(p["freq"]), gain=float(p["gain"]),
                                                                    q=float(p["q"]))))
        chain.append("eq%d" % j)
    kit_fx = [m for m in mods if m.kind.startswith("fx:")]
    if kit_fx:
        from . import kit as KT
        for j, m in enumerate(sorted(kit_fx, key=lambda q: KT.FX_ORDER.index(q.kind[3:]))):
            nodes.append(dict(id="fx%d" % j, type=m.kind[3:], params=_kit_params(m.kind[3:], m)))
            chain.append("fx%d" % j)
    if "chorus" in mod_of:
        p = mod_of["chorus"][0].p()
        nodes.append(dict(id="cho", type="fx.chorus", params=dict(rate=float(p["rate"]), depth=float(p["depth"]),
                                                                  mix=float(p["mix"]))))
        chain.append("cho")
    if "room" in mod_of:
        p = mod_of["room"][0].p()
        nodes.append(dict(id="rvb", type="fx.room", params=dict(decay=float(p["decay"]), size=float(p["size"]),
                                                                damp=float(p["damp"]), width=1.0, mix=float(p["mix"]))))
        chain.append("rvb")
    # headroom: out.stereo's soft limiter must never shape a grown voice (six partials at full
    # level reached it at 1.0, 2026-10-03); the matcher reads the level free anyway
    nodes.append(dict(id="out", type="out.stereo", params=dict(level=OUT_LEVEL, width=1.0)))
    if chain:
        audio += [[last[0], last[1], chain[0], "l"], [last[0], last[1], chain[0], "r"]]
        for a, b in zip(chain, chain[1:]):
            audio += [[a, "l", b, "l"], [a, "r", b, "r"]]
        audio += [[chain[-1], "l", "out", "l"], [chain[-1], "r", "out", "r"]]
    else:
        audio += [[last[0], last[1], "out", "l"], [last[0], last[1], "out", "r"]]
    kit_mod = [m for m in mods if m.kind.startswith("mod:")]
    if kit_mod:
        from . import kit as KT
        src_ids = {id(m): "s%d" % i for i, m in enumerate(mods)}
        for j, m in enumerate(kit_mod):
            k, p = KT.MODS[m.kind[4:]], m.p()
            dest = None
            if k["dest"] == "flt" and main_cut:
                dest = (main_cut[0], main_cut[1], p["depth"] / main_cut[2])
            elif k["dest"] == "pw":
                t = [q for q in mods if q.kind == "tone"]
                dest = (src_ids[id(t[0])], "pw", p["depth"] / 0.9) if t else None
            elif k["dest"] == "pos":
                t = [q for q in mods if q.kind in ("src:osc.table", "src:osc.morph")]
                dest = (src_ids[id(t[0])], "pos" if t[0].kind == "src:osc.table" else "shape", p["depth"]) if t else None
            if dest is None:
                continue
            mid = "km%d" % j
            if k["block"] == "lfo.voice":
                nodes.append(dict(id=mid, type="lfo.voice", params=dict(shape=str(p["shape"]), rate=float(p["rate"]),
                                                                       depth=1.0, fade=float(p["fade"]), mode="retrig")))
            else:
                nodes.append(dict(id=mid, type="env.adsr", params=dict(attack=float(p["att"]), decay=float(p["dec"]),
                                                                      sustain=float(p["sus"]), release=float(p["rel"]))))
            links[(mid, "out", dest[0], dest[1])] = links.get((mid, "out", dest[0], dest[1]), 0.0) + float(dest[2])
    mod = [{"from": [a, b], "to": [c, d], "amount": float(v)} for (a, b, c, d), v in links.items()
           if abs(v) > 1e-9]
    doc = {"format": 1, "name": name, "author": "dnasynth grow", "sample_rate": 44100,
           "seed": int(seed) & 0xFFFFFFFF,
           "voice": {"mode": "poly", "max_voices": int(voices), "glide": 0, "glide_mode": "legato", "bend": 2},
           "nodes": nodes, "audio": audio, "mod": mod}
    if _no_dash:                                     # for dash.document: where each source's level sits
        doc["_levels"] = {i: list(w) for i, w in levels.items()}
    return doc


PLAY_PEAK = 0.5                              # a playable patch's note at its key peaks at -6 dBFS
PLAY_VOICES = 8
MAKEUP_MAX_DB = 24.0                         # dyn.comp's makeup range (at 1 : 1 a clean gain)


def playable(doc, midi, gate_s, peak=PLAY_PEAK, voices=PLAY_VOICES):
    """a grown document made to PLAY (the lab, the designer, the web, the device): `voices` voices
    (the matcher's are single-voice) and a LEVEL -- the matcher reads loudness free, so a grown
    voice can come out 60 dB down (GM closed hat peaked at 0.001, 2026-10-03). The note at its
    key is rendered and raised to `peak`: out.stereo's level first (up to 1.5), then dyn.comp
    stages at ratio 1 : 1 (threshold 0 dB: a clean makeup gain, checked sample for sample) before
    the output, +24 dB each. Works on any document (an existing makeup stage is raised further)."""
    from ..graph import lib
    d = json.loads(json.dumps(doc))
    d["voice"] = dict(d.get("voice") or {}, mode="poly", max_voices=int(voices))
    k, _ = key_cents(midi)
    y = lib.render_note(json.dumps(d).encode(), k, 100 / 127, float(gate_s), float(gate_s) + 1.5)
    pk = float(np.abs(y).max())
    if pk < 1e-9:
        return d
    out = [n for n in d["nodes"] if n["id"] == "out"][0]
    lv = float(out["params"].get("level", OUT_LEVEL))
    want = lv * peak / pk
    out["params"]["level"] = float(min(want, 1.5))
    rest = 20.0 * np.log10(want / out["params"]["level"])
    for n in [n for n in d["nodes"] if n["type"] == "dyn.comp" and n["id"].startswith("mk")]:
        add = min(rest, MAKEUP_MAX_DB - float(n["params"].get("makeup", 0.0)))
        n["params"]["makeup"] = float(n["params"].get("makeup", 0.0) + max(add, 0.0))
        rest -= max(add, 0.0)
    j = sum(1 for n in d["nodes"] if n["id"].startswith("mk"))
    while rest > 0.01:
        mid = "mk%d" % j
        d["nodes"].insert(len(d["nodes"]) - 1, dict(id=mid, type="dyn.comp", params=dict(
            threshold=0.0, ratio=1.0, attack=10.0, release=120.0, knee=0.0, makeup=float(min(rest, MAKEUP_MAX_DB)))))
        if out.get("pos"):                         # a laid-out patch (a dashboard voice): under the output
            d["nodes"][-2]["pos"] = [out["pos"][0], out["pos"][1] + 140 * (j + 1)]
        rest -= MAKEUP_MAX_DB
        into = [a for a in d["audio"] if a[2] == "out"]
        d["audio"] = [a for a in d["audio"] if a[2] != "out"]
        for a in into:
            d["audio"].append([a[0], a[1], mid, a[3]])
        d["audio"] += [[mid, "l", "out", "l"], [mid, "r", "out", "r"]]
        j += 1
    return d


def key_cents(midi):
    """a fractional note -> (the key the graph plays, the cents the patch is tuned by)"""
    k = int(np.floor(float(midi) + 0.5))
    return k, 100.0 * (float(midi) - k)


def chord_keys(midi, chord):
    """a chord (fractional MIDI notes) played with `midi` as the patch's note -> the keys its notes
    sit on: one fine tuning for all of them, the patch's (a keyboard plays every key of a chord at
    one tuning; key_cents(midi) is the document's)"""
    _, c = key_cents(midi)
    return [int(round(float(m) - c / 100.0)) for m in chord]


def render_batch(voices, midi, gate_s, secs, vel=100 / 127, threads=4, seed=1, chord=None):
    """B grown voices (lists of Modules) -> float32[B, n], one note each, the device's path.
    chord: fractional MIDI notes played together instead (the documents get as many voices)"""
    from ..graph import lib
    k, c = key_cents(midi)
    if chord is None:
        docs = [json.dumps(document(v, cents=c, seed=seed)).encode() for v in voices]
        return lib.render_batch(docs, k, vel, gate_s, secs, 44100.0, threads)
    keys = chord_keys(midi, chord)
    docs = [json.dumps(document(v, cents=c, seed=seed, voices=len(keys))).encode() for v in voices]
    return lib.render_batch(docs, k, vel, gate_s, secs, 44100.0, threads, chord=keys)


def describe(mods):
    """one line per piece, physical values (the build log)"""
    out = []
    for m in mods:
        p = m.p()
        r = (" x%.3f" % (m.ratio * 2.0 ** (p["tune"] / 1200.0))) if m.kind in ("partial", "fm") else ""
        out.append("%-8s%s  %s%s" % (m.kind, r, " ".join("%s %s" % (k, v if isinstance(v, str) else "%.3g" % v)
                                                           for k, v in p.items()),
                                     ("   <- " + m.why) if m.why else ""))
    return out
