"""The builder: start from one source, grow a piece at a time, polish.

    from dnasynth.grow import build
    r = build.grow(audio, 44100, midi=48.0, gate_s=1.2, budget=5000)
    r["mods"]        # the pieces, in the order they were added (each with why it is there)
    r["doc"]         # the patch document (format 1): plays on the board, iOS, the web
    r["score"], r["renders"], r["log"]

START   every first voice (a tone, a sine at the note, a sine on the loudest peak, FM on it, a
        body with a pitch fall when the note falls, noise at the centroid, a pluck), started where
        the analysis read the note, screened SCREEN_N renders each; the best REFINE tuned START_N
        more. The best, and the best of ANOTHER first kind within FOCUS of it, are the stalks.
GROW    each stalk in turn: analyse.moves lists what the target has and the stalk's render lacks
        (a move is a piece, or two that only work together: a drum's body and its pitch fall); the
        first MAX_MOVES are each added and tuned alone (the new genes and every source's level,
        MOVE_N renders); the best stays if it lowers the fitness by more than COST_ABS per piece +
        COST_REL x the fitness (a piece must earn its place: the voice stays small, cheap on the
        board). A stalk stops when no move pays or it falls FOCUS behind the leader; growth stops
        with POLISH_MIN renders left. The best stalk is polished.
POLISH  every gene of the grown voice ranked by sensitivity at the best (one step each way); the
        K_POLISH most sensitive searched together (a GA), re-ranked at half the rest.
PRUNE   a piece the polished voice does not need (the fitness without it no worse than COST_ABS)
        goes, one at a time: the voice that ships is as small as the sound allows.

The fitness is the matcher's own (fitness.Target, match.MOD: the wobble term, free gain); every
render is scaled to the target's level first (fitness.normalize, as the target is: a voice's level
is a knob of its own). The target is onset-trimmed as match.match trims it.
"""
from __future__ import annotations

import json
import time

import numpy as np

from .. import fitness as FT
from .. import match as MA
from . import analyse as AN
from . import blocks as BL

SR = 44100
SCREEN_N = 40                                    # every first voice, briefly (the full kit has ~20)
SCREEN_N1, SCREEN_KEEP = 16, 0                   # SCREEN_KEEP > 0: more starts than that -> all 16 renders, the
#   best SCREEN_KEEP the rest. OFF (2026-10-05): at 10 it took Dashboard GROW's dev-set median fit 4.47 ->
#   4.71 (one code, one seed; 541 screening renders against 678) -- 16 renders rank untuned starts badly
DASH_KEEP_TEMPLATES = ("additive", "morph", "pd", "noise2")   # GROW templates a dashboard template does not cover
DASH_NET_TOP = 8                                 # with the dashboard network: its top families' templates only
DASH_NET_TEMPLATES = False                       # the dashboard network switches the dashboard templates on
DASH_TEMPLATES = False                           # the dashboard templates as starts without the dashboard network
#   (2026-10-04, dev set: hand-seeded they help a few sounds -- DX7 E.PIANO 1 6.16 -> 5.29 -- but not on
#   average: median fit 4.50 / 4.63 against 4.47, mean 4.89 / 4.83 against 4.71. 2026-10-05, one code,
#   one-stage screening: picked by the dashboard network's family head they are worse again -- median fit
#   4.67, tf 5.71, mean 4.87 / 5.57 against the network alone's 4.39 / 5.49, 4.67 / 5.21: they win the
#   screen on 10 of 18 sounds and finish behind -- a designed instrument screens well and grows badly)
MAX_CANDS = 12                                   # a growth step's candidates (successive halving)
HALVE_N1, HALVE_KEEP, HALVE_N2 = 24, 4, 72
ALT_N = 150                                      # renders each alternative (B C D) is tuned
REFINE = 4                                       # the best of this many families, tuned START_N more
START_N = 140
BEAM = 1                                         # builds kept alive at once (2026-10-04: a beam of 2 at 5 000
                                                 # renders spread the growth thin -- dev set median 4.76 against
                                                 # 4.48 with one build, the Oct 3 GROW's 4.42; grow(beam=N) to try)
KIDS = 2                                         # children a build offers each step (its best paying moves)
FOCUS_BEAM = 1.3                                 # a build this far behind the best leaves the beam
PAIR_TOP, PAIRS = 3, 3                           # the top single moves paired; at most this many pairs a step
SWAPS = 4                                        # source swaps tried a step
FOCUS = 1.15                                     # a stalk this far behind the leader stops (1.25 split the
                                                 # budget too often: marimba 6.3 -> 8.5, 2026-10-03)
MOVE_N = 96
POLISH_MIN = 1200
MAX_MOVES = 5
MAX_STEPS = 14
# a piece stays when it buys more than COST_ABS (per piece) + COST_REL x the fitness: LOW, because a
# piece that buys little now can open the way for one that buys much (DX7 VOICE 1 stopped after one
# step at 0.03 + 1 %, an EQ worth 0.06 refused, where the path through it reached 3.04 against 5.11;
# 2026-10-03) -- PRUNE (PRUNE_TOL) takes out at the end what the voice turned out not to need
COST_ABS, COST_REL = 0.01, 0.003
PRUNE_TOL = 0.03
MERGE_TOL = 0.05                                 # a shared envelope may cost this much fitness ...
MERGE_REL, MERGE_ALL_REL = 0.02, 0.03            # ... or this share of the voice's (a pair / all at once)
MERGE_DIST = 0.3                                 # envelopes this close (rms over their 4 genes) are tried as one
                                                 # (0.15 until 2026-10-04: 0.3 on the dev set kept the fit -- median
                                                 # 4.47 both, tf 5.47 -> 5.40 -- and cut the cost a voice 2.39 -> 2.23,
                                                 # envelopes 4.7 -> 4.3, amps 3.5 -> 3.1, for 46 more renders in 18)
K_POLISH = 20
SPACE_SLOT = False                               # a room move's own candidate place each step: OFF (2026-10-04,
                                                 # 24 analog sounds: the reverb found on 5 of 7 reverb presets,
                                                 # 3 false of 17, but median fit 4.44 -> 4.59, tf 5.49 -> 6.01,
                                                 # +6 % time -- it takes a candidate's place every step)
ROOM_RELEASE = False                             # a move's first reverb shortens the dry releases (_room_release):
ROOM_REL = (0.15, 0.05, 0.6)                     # ... to this part of each, clipped to (s). OFF (2026-10-05):
#   with the dashboard room's decay folded right (dash.dashify) a room on the long release pays at once
#   (tuned 24 renders: String Pad 13.00 -> 11.51, Air Sweep 16.82 -> 15.37, Organ 15.83 -> 15.56); the
#   short release starts at 29..34 and needs ~96 renders to catch up -- the halving's 24 drop it
ROOM_STARTS = 0                                  # a long tail: the best this many screened starts copied with
ROOM_MIXES = (0.4, 0.6, 0.8, 1.0)                #   a hall from the start (_room_start; on trial, 2026-10-05)
SILENT = 1e3                                     # the score of a render with no sound


def flat(mods):
    return np.concatenate([m.g for m in mods]) if mods else np.zeros(0)


def _level_genes(mods):
    """the flat indices of every source's level gene"""
    out, i = [], 0
    for m in mods:
        if BL.is_source(m.kind):
            out.append(i + m.names().index("level"))
        i += len(m.g)
    return np.array(out, int)


def unflat(mods, v):
    out, i = [], 0
    for m in mods:
        c = m.copy()
        c.g = np.clip(np.asarray(v[i:i + len(m.g)], np.float64), 0.0, 1.0)
        i += len(m.g)
        out.append(c)
    return out


class Evaluator:
    """renders voices, scales them to the target's level, scores them; counts renders. chord: the
    notes played together (fractional MIDI): every voice is rendered and scored as that chord, and
    heard() -- what the analysis reads -- is the voice on `midi` alone"""

    def __init__(self, T, midi, gate_s, n, threads=4, chord=None):
        self.T, self.midi, self.gate, self.n_s = T, float(midi), float(gate_s), int(n)
        self.threads = threads
        self.chord = None if chord is None else [float(m) for m in chord]
        self.n = 0
        self.t_render = self.t_score = 0.0           # seconds spent rendering / in the fitness

    def render(self, voices):
        t0 = time.perf_counter()
        Y = BL.render_batch(voices, self.midi, self.gate, self.n_s / SR, threads=self.threads, chord=self.chord)
        self.n += len(voices)
        Y = Y[:, :self.n_s]
        ok = np.abs(Y).max(axis=1) > 1e-7
        out = np.zeros_like(Y)
        for i in np.flatnonzero(ok):
            out[i] = FT.normalize(Y[i])
        self.t_render += time.perf_counter() - t0
        return out, ok

    def score(self, voices):
        Y, ok = self.render(voices)
        t0 = time.perf_counter()
        s = np.full(len(voices), SILENT)
        if ok.any():
            s[ok] = np.asarray(self.T.score(Y[ok]), np.float64)
        self.t_score += time.perf_counter() - t0
        return s

    def heard(self, mods):
        """one render of mods at the level the fitness compares it (its free gain applied); with a
        chord, the voice on `midi` alone, normalised as the analysis's isolated note is"""
        if self.chord is not None:
            y = BL.render_batch([mods], self.midi, self.gate, self.n_s / SR, threads=1)[0, :self.n_s]
            self.n += 1
            return FT.normalize(y) if np.abs(y).max() > 1e-7 else y
        Y, ok = self.render([mods])
        if not ok[0]:
            return Y[0]
        _, terms = self.T.score(Y[:1], terms=True)
        return Y[0] * 10 ** (float(terms["gain_db"][0]) / 20)


def tune(ev, mods, idx, n_renders, rng, pop=12, sigma=0.12, seeds=()):
    """a (mu+lambda) GA over the genes idx of the flattened voice -> (mods, score)"""
    idx = np.asarray(idx)
    v0 = flat(mods)
    P = [v0] + [np.asarray(s, np.float64) for s in seeds]
    while len(P) < pop:
        c = v0.copy()
        c[idx] = np.clip(c[idx] + rng.normal(0, sigma, len(idx)), 0, 1)
        P.append(c)
    F = list(ev.score([unflat(mods, p) for p in P]))
    gens = max(1, (n_renders - len(P)) // pop)
    for gen in range(gens):
        sg = max(0.03, sigma * 0.85 ** gen)
        kids = []
        for _ in range(pop):
            a, b = (min(rng.choice(len(P), 2, replace=False), key=lambda i: F[i]) for _ in range(2))
            c = P[a].copy()
            x = rng.random(len(idx)) < 0.5
            c[idx[x]] = P[b][idx[x]]
            m = rng.random(len(idx)) < max(1.0 / len(idx), 0.25)
            if not m.any():
                m[rng.integers(len(idx))] = True
            c[idx[m]] += rng.normal(0, sg, int(m.sum()))
            kids.append(np.clip(c, 0, 1))
        Fk = ev.score([unflat(mods, k) for k in kids])
        P, F = P + kids, F + list(Fk)
        keep, seen = [], set()
        for i in np.argsort(F):
            h = np.round(P[i][idx], 4).tobytes()
            if h not in seen:
                seen.add(h)
                keep.append(i)
            if len(keep) == pop:
                break
        P, F = [P[i] for i in keep], [F[i] for i in keep]
    b = int(np.argmin(F))
    return unflat(mods, P[b]), float(F[b])


def _sensitivity(ev, mods, step=0.08):
    v = flat(mods)
    cand, who = [], []
    for i in range(len(v)):
        for d in (-step, step):
            u = v.copy()
            u[i] = np.clip(u[i] + d, 0, 1)
            if u[i] != v[i]:
                cand.append(u)
                who.append(i)
    s0 = ev.score([mods])[0]
    s = ev.score([unflat(mods, u) for u in cand])
    sens = np.zeros(len(v))
    best = (s0, v)
    for i, si, u in zip(who, s, cand):
        sens[i] = max(sens[i], abs(si - s0))
        if si < best[0]:
            best = (si, u)
    return sens, best


def polish(ev, mods, score, budget, rng, log, k=K_POLISH):
    for stage in range(2):
        left = budget - ev.n
        if left < 4 * len(flat(mods)) + 64:
            break
        limit = ev.n + (left // 2 if stage == 0 else left)
        sens, (sb, vb) = _sensitivity(ev, mods)
        if sb < score:
            mods, score = unflat(mods, vb), sb
        S = np.argsort(-sens)[:max(1, int(k))]
        S = S[sens[S] > 0]
        if S.size == 0:
            break
        n = max(0, limit - ev.n)
        mods2, s2 = tune(ev, mods, S, n, rng, pop=16, sigma=0.08)
        if s2 < score:
            mods, score = mods2, s2
        log("polish %d: %d genes searched, fitness %.3f (%d renders)" % (stage + 1, S.size, score, ev.n))
    return mods, score


ENV_GENES = ("att", "dec", "sus", "rel")


def _env_idx(m):
    """a source's own ADSR genes (indices), or None"""
    if not BL.is_source(m.kind) or not set(ENV_GENES) <= set(m.names()):
        return None
    return [m.names().index(k) for k in ENV_GENES]


def merge_envelopes(ev, mods, score, tol, log, dash=False):
    """CLOSE ENVELOPES BECOME ONE. blocks.document gives sources with identical envelopes one ADSR
    and one amp; the search tunes each source's envelope on its own, so they are never identical.
    Here the closest pair (rms over the four genes, under MERGE_DIST) is tried on the louder one's
    envelope and kept when the fitness is no worse than `tol`, until no pair merges. On a dashboard
    voice whose sources then share ONE envelope, that envelope is also tried as ENV 1's (the
    sources go flat: no ADSR, no amp; ENV 1 is the note's)"""
    # ONE ENVELOPE FOR EVERY SOURCE first (an organ's drawbars, a pad's oscillators): the loudest
    # source's, in one render; the pairs only when that costs too much
    srcs = [(j, m) for j, m in enumerate(mods) if _env_idx(m) is not None]
    distinct = {m.g[_env_idx(m)].tobytes() for _, m in srcs}
    if len(distinct) > 1:
        keep = max(srcs, key=lambda q: q[1].p().get("level", 1.0))[0]
        cand = [q.copy() for q in mods]
        for j, m in srcs:
            cand[j].g[_env_idx(cand[j])] = mods[keep].g[_env_idx(mods[keep])]
        s_ = float(ev.score([cand])[0])
        if s_ <= score + max(tol, MERGE_ALL_REL * score):
            log("merge: all %d sources share %s's envelope  fitness %.3f -> %.3f" % (len(srcs), mods[keep].kind, score, s_))
            mods, score = cand, s_
    tried = set()
    while True:
        srcs = [(j, m) for j, m in enumerate(mods) if _env_idx(m) is not None]
        pairs = []
        for a in range(len(srcs)):
            for b in range(a + 1, len(srcs)):
                (ja, ma), (jb, mb) = srcs[a], srcs[b]
                ga, gb = ma.g[_env_idx(ma)], mb.g[_env_idx(mb)]
                if np.array_equal(ga, gb) or (ja, jb) in tried:
                    continue
                d = float(np.sqrt(np.mean((ga - gb) ** 2)))
                if d < MERGE_DIST:
                    pairs.append((d, ja, jb))
        if not pairs:
            break
        _, ja, jb = min(pairs)
        tried.add((ja, jb))
        la, lb = mods[ja].p().get("level", 1.0), mods[jb].p().get("level", 1.0)
        keep, give = (ja, jb) if la >= lb else (jb, ja)
        cand = [q.copy() for q in mods]
        cand[give].g[_env_idx(cand[give])] = mods[keep].g[_env_idx(mods[keep])]
        s = float(ev.score([cand])[0])
        if s <= score + max(tol, MERGE_REL * score):
            log("merge: %s shares %s's envelope  fitness %.3f -> %.3f" % (mods[give].kind, mods[keep].kind, score, s))
            mods, score = cand, s
    if dash:
        from . import dash as DS
        srcs = [(j, m) for j, m in enumerate(mods) if _env_idx(m) is not None and not DS.flat_env_genes(m)]
        if srcs and all(np.array_equal(m.g[_env_idx(m)], srcs[0][1].g[_env_idx(srcs[0][1])]) for _, m in srcs):
            q = srcs[0][1].p()
            cand = [m.copy() for m in mods]
            d = [m for m in cand if m.kind == "dash"][0]
            for name, v in (("a_att", q["att"]), ("a_dec", q["dec"]), ("a_sus", q["sus"]), ("a_rel", q["rel"])):
                DS._set(d, name, float(np.clip(v, DS.DASH[DS._gi(name)][2], DS.DASH[DS._gi(name)][3])))
            for j, _ in srcs:
                m = cand[j]
                for name, v in (("att", 0.001), ("sus", 1.0), ("rel", 12.0)):
                    m.g[m.names().index(name)] = BL.encode(BL.KINDS[m.kind][m.names().index(name)], v)
            s = float(ev.score([cand])[0])
            if s <= score + max(tol, MERGE_REL * score):
                log("merge: the shared envelope is ENV 1's (%d sources flat)  fitness %.3f -> %.3f" % (len(srcs), score, s))
                mods, score = cand, s
    return mods, score


def prune(ev, mods, score, log):
    """drop every piece the polished voice does not need: one render without each (the last
    source never); a piece goes when the fitness without it is no worse than PRUNE_TOL (a partial
    the polish turned down to level 0 is dead weight on the board)"""
    while len(mods) > 1:
        cands = [i for i, m in enumerate(mods)
                 if m.kind != "dash"                    # a dashboard voice's skeleton stays
                 and not (BL.is_source(m.kind) and sum(BL.is_source(q.kind) for q in mods) == 1)]
        if not cands:
            break
        s = ev.score([[m for j, m in enumerate(mods) if j != i] for i in cands])
        j = int(np.argmin(s))
        if s[j] > score + PRUNE_TOL:
            break
        log("prune: - %s  fitness %.3f -> %.3f" % (mods[cands[j]].kind, score, s[j]))
        mods = [m for i, m in enumerate(mods) if i != cands[j]]
        score = float(s[j])
    return mods, score


def _apply(mods, c):
    """a move on a voice -> (the new voice, the flat indices of the genes to tune: the new or
    swapped pieces', and every source's level beside them -- the mix re-balances)"""
    if isinstance(c, AN.Replace):
        m2 = [q.copy() for q in mods]
        m2[c.index] = c.piece.copy()
        a = len(flat(mods[:c.index]))
        names = m2[c.index].names()
        only = getattr(c, "tune_only", None)            # an upgrade tunes what it added, not what it kept
        own = np.array([a + names.index(n) for n in only], int) if only else np.arange(a, a + len(names))
        return m2, np.unique(np.concatenate([own, _level_genes(m2)]))
    m2 = mods + [q.copy() for q in c]
    return m2, np.concatenate([np.arange(len(flat(mods)), len(flat(m2))), _level_genes(mods)])


def _tune_idx(mods, dash=False):
    """the flat genes a whole-voice search moves: all of them -- or, on a DASHBOARD voice, the
    skeleton's active parts (dash.tune_genes) and every other piece's genes but a source's FLAT
    envelope (ENV 1 carries the note)"""
    if not dash:
        return np.arange(len(flat(mods)))
    from . import dash as DS
    out, i = [], 0
    for m in mods:
        if m.kind == "dash":
            out += [i + k for k in DS.tune_genes(m)]
        else:
            skip = set(DS.flat_env_genes(m))
            out += [i + k for k in range(len(m.g)) if k not in skip]
        i += len(m.g)
    return np.array(sorted(out), int)


def _apply_dash(mods, c):
    """a move on a DASHBOARD voice. The analysis proposed it on the voice's view (dash.view: the
    skeleton seen as the GROW pieces it stands for, after the real pieces), so a Replace past the
    real pieces replaces a part of the skeleton; every move is folded back by dash.dashify ->
    (the new voice, the genes to tune: new or changed pieces', the skeleton genes it moved or
    switched on, every source's level)"""
    from . import dash as DS
    real = [m for m in mods if m.kind != "dash"]
    d0 = [m for m in mods if m.kind == "dash"][0]
    only = getattr(c, "tune_only", None) if isinstance(c, AN.Replace) else None
    if isinstance(c, AN.Replace):
        if c.index < len(real):
            r2 = [q.copy() for q in real]
            r2[c.index] = c.piece.copy()
            m2 = DS.dashify(r2 + [d0.copy()])
        else:
            view, _ = DS.view(mods)
            was = view[c.index].kind
            d = d0.copy()
            if (was == "filter" or was.startswith("flt:")) and not DS.is_folded(c.piece.kind, c.piece):
                d = DS.open_filter(d)           # a filter the screen cannot hold (a gate, a comb) REPLACES its own: it opens
            m2 = DS.dashify([q.copy() for q in real] + [d, c.piece.copy()])
    else:
        m2 = DS.dashify([q.copy() for q in real] + [d0.copy()] + [q.copy() for q in c])
    d1, idx, i = m2[-1], [], 0
    for j, m in enumerate(m2[:-1]):
        if j >= len(real) or m.kind != real[j].kind or not np.array_equal(m.g, real[j].g):
            skip = set(DS.flat_env_genes(m))
            if only and isinstance(c, AN.Replace) and j == c.index:
                skip |= {k for k, n in enumerate(m.names()) if n not in only}
            idx += [i + k for k in range(len(m.g)) if k not in skip]
        i += len(m.g)
    if ROOM_RELEASE and not isinstance(c, AN.Replace) and _reverb(m2) and not _reverb(mods):
        idx += _room_release(m2)
    moved = set(np.flatnonzero(np.abs(d1.g - d0.g) > 1e-12).tolist())
    if moved:
        moved |= set(DS.tune_genes(d1).tolist()) - set(DS.tune_genes(d0).tolist())
        idx += [i + k for k in sorted(moved)]
    return m2, np.unique(np.concatenate([np.array(idx, int), _level_genes(m2)]))


def _reverb(mods):
    """the voice has a reverb: the dashboard's FX slot on reverb, a room, a hall, a reverb"""
    from . import dash as DS
    return any(m.kind in ("room", "fx:fx.hall", "fx:fx.reverb")
               or (m.kind == "dash" and DS._get(m, "fx_type") == "reverb") for m in mods)


def _room_release(m2):
    """A ROOM FOR THE RELEASE (2026-10-05): the analysis reads a reverb's tail as the release, so a
    voice meets its first reverb with a long envelope already making that tail; the reverb on top
    makes it longer and is refused (24 analog sounds: the reverb on 0 of the 7 reverb presets). The
    move that brings it shortens the dry releases it now stands for -- ENV 1's, every source's own
    (not a flat one) -- in place -> their flat indices, tuned with it"""
    from . import dash as DS

    def short(r):
        return float(np.clip(ROOM_REL[0] * r, ROOM_REL[1], ROOM_REL[2]))
    idx, i = [], 0
    for m in m2:
        if m.kind == "dash":
            DS._set(m, "a_rel", short(DS._get(m, "a_rel")))      # in the skeleton's moved genes
        elif BL.is_source(m.kind) and not DS.flat_env_genes(m):
            for k, n in enumerate(m.names()):
                if n == "rel" or (n.startswith("rel") and n[3:].isdigit()):
                    spec = BL.KINDS[m.kind][k]
                    m.g[k] = BL.encode(spec, short(BL.decode(spec, m.g[k])))
                    idx.append(i + k)
        i += len(m.g)
    return idx


def _room_start(ev, v, TA):
    """ROOM STARTS (2026-10-05): a long tail may be the room, and a voice that has grown around a
    long release never takes one (results.md section 30) -- so a screened start is copied with the
    room from the start: the kit's HALL underneath the dashboard (decay twice the tail's 30 dB time,
    in seconds), the dry releases short (_room_release), the hall's mix the best of ROOM_MIXES; it
    is screened like any start and competes with its own original in the family refine. Not the
    FX slot: its reverb tops out at a 0.6 mix (FX DEPTH drives mix 0..0.6, analog 1's) and an 8 s
    tail -- the scan took the top on every reverb preset and still lost (Organ 16.53 -> 17.57; with
    the hall 13.02, String Pad 13.60 -> 11.64, Hyper Saw 15.25 -> 12.14, screened 40 renders)"""
    from . import dash as DS
    m2 = [m.copy() for m in v]
    _room_release(m2)
    decay = float(np.clip(2.0 * TA.tail, 0.3, 20.0))
    cands = []
    for mx in ROOM_MIXES:
        c = [m.copy() for m in m2]
        c.insert(len(c) - 1, BL.Module.new("fx:fx.hall", why="a room for the release: a %.1f s tail" % TA.tail,
                                           decay=decay, mix=float(mx)))
        cands.append(DS.dashify(c))
    return cands[int(np.argmin(ev.score(cands)))]


def _label(c):
    return ("~" + c.kind) if isinstance(c, AN.Replace) else "+".join(q.kind for q in c)


UNIQUE = ("filter", "vibrato", "tremolo", "pitchenv", "chorus", "room", "drive")


def _pairable(a, b):
    """two moves that can be one: no two of a one-per-voice kind, no two filters, no two of one
    modulation or effect"""
    ka, kb = {q.kind for q in a}, {q.kind for q in b}
    if ka & kb & set(UNIQUE):
        return False
    flt = lambda ks: any(k == "filter" or k.startswith("flt:") for k in ks)        # noqa: E731
    if flt(ka) and flt(kb):
        return False
    return not any(k.startswith(("mod:", "cell:", "fx:", "hp:", "ins:")) for k in ka & kb)


def candidates(TA, R, mods, rng, dash=False):
    """a build's moves this step, for GROW TO BUILD BY ITSELF (Volo, 2026-10-04): the analysis's
    single moves (and the full kit's), PAIRS of its top ones (two pieces tuned together cross a
    valley one piece cannot: a saw and the filter it needs), the cells (a dashboard voice), and
    SWAPS of a source for another kind of oscillator -- interleaved, two singles a round, so the
    first candidates of a small budget hold some of each"""
    if dash:
        from . import dash as DS
        view = DS.view(mods)[0]
    else:
        view = mods
    singles = AN.moves(TA, R, view, rng=rng)
    # A ROOM gets its own place (2026-10-04): ranked by missing energy it sat behind every partial and
    # noise band and was never tried (Wave Pad, Organ, Air Sweep: their presets' reverb moves the
    # fitness 9.5..19.5) -- one a step while the voice has none
    space = [c for c in singles if not isinstance(c, AN.Replace)
             and any(q.kind in ("room", "fx:fx.hall", "fx:fx.reverb") for q in c)][:1] if SPACE_SLOT else []
    singles = [c for c in singles if not any(c is q for q in space)]
    lists = [c for c in singles if not isinstance(c, AN.Replace)][:PAIR_TOP]
    pairs = []
    for a in range(len(lists)):
        for b in range(a + 1, len(lists)):
            if len(pairs) < PAIRS and _pairable(lists[a], lists[b]):
                pairs.append([q.copy() for q in lists[a]] + [q.copy() for q in lists[b]])
    cells = DS.cell_moves(TA, R, mods, rng=rng)[:3] if dash else []
    swaps = AN.source_swaps(view, rng)[:SWAPS]
    upgrades = AN.fm4_upgrades(TA, R, view)[:1]          # an FM pair -> four operators
    out, streams = [], [list(singles), space, pairs, cells, swaps, upgrades]
    while len(out) < MAX_CANDS and any(streams):
        for j, st_ in enumerate(streams):
            for _ in range(2 if j == 0 else 1):
                if st_ and len(out) < MAX_CANDS:
                    out.append(st_.pop(0))
    return out


def _children(ev, TA, st, f0, gate_s, rng, limit, log, name, dash=False):
    """one growth step of a build in the BEAM: its candidates (candidates()) by successive halving
    (the first MAX_CANDS each tuned HALVE_N1 renders, the best HALVE_KEEP HALVE_N2 more) -> up to
    KIDS children, the best PAYING moves (fitness gain over COST_ABS a piece + COST_REL of the
    score), each a new build; none: the build is finished"""
    R = AN.Sound(ev.heard(st["mods"]), f0, gate_s)
    cands = candidates(TA, R, st["mods"], rng, dash)
    if not cands:
        log("%s step %d: nothing missing that a piece could add" % (name, len(st["steps"])))
        return []
    first = []
    for c in cands:
        if ev.n + HALVE_N1 > limit:
            break
        m2, idx = (_apply_dash if dash else _apply)(st["mods"], c)
        m2, s = tune(ev, m2, idx, HALVE_N1, rng, pop=8)
        first.append((s, m2, idx, c))
    trials = []
    for s, m2, idx, c in sorted(first, key=lambda q: q[0])[:HALVE_KEEP]:
        if ev.n + HALVE_N2 <= limit:
            m3, s3 = tune(ev, m2, idx, HALVE_N2, rng)
            if s3 < s:
                m2, s = m3, s3
        trials.append((s, m2, c))
        log("   %s try %-28s fitness %.3f  (%s)" % (name, _label(c), s,
                                                     c.why if isinstance(c, AN.Replace) else c[0].why))
    kids, seen = [], set()
    for s, m2, c in sorted(trials, key=lambda q: q[0]):
        n_new = 1 if isinstance(c, AN.Replace) else len(c)
        if st["score"] - s <= COST_ABS * n_new + COST_REL * st["score"]:
            break
        if _label(c) in seen:
            continue
        seen.add(_label(c))
        log("%s step %d: + %s  fitness %.3f -> %.3f" % (name, len(st["steps"]), _label(c), st["score"], s))
        kids.append(dict(mods=m2, score=s, done=False, name=name,
                         steps=st["steps"] + [dict(step=len(st["steps"]), kind=_label(c), score=s,
                                                   why=c.why if isinstance(c, AN.Replace) else c[0].why,
                                                   renders=ev.n)]))
        if len(kids) == KIDS:
            break
    if not kids:
        log("%s step %d: no move pays: finished at %.3f" % (name, len(st["steps"]), st["score"]))
    return kids


def net_starts(model, xt, midi, gate_s, k, rng):
    """the network's proposals as first voices: model.propose -> k voices, each piece marked as the
    network's. A growx network (slots_full's genome): sources first; the DASHBOARD network (dashx,
    slots_dash's genome): dashboard voices as they are, the dash piece last"""
    dashx = getattr(model, "cfg", {}).get("engine") == "dashx"
    if dashx:
        from . import slots_dash as GF
    else:
        from . import slots_full as GF
    G = model.propose(xt, SR, midi, k, gate_s=gate_s, seed=int(rng.integers(2 ** 31)))
    out = []
    for j, g in enumerate(G):
        mods = GF.to_mods(g)
        if dashx:
            for m in mods:
                m.why = "network proposal %d%s" % (j, " (greedy)" if j == 0 else "")
            out.append(mods)
            continue
        if not any(BL.is_source(m.kind) for m in mods):
            continue
        mods = [m for m in mods if BL.is_source(m.kind)] + [m for m in mods if not BL.is_source(m.kind)]
        for m in mods:
            m.why = "network proposal %d%s" % (j, " (greedy)" if j == 0 else "")
        out.append(mods)
    return out


def _family(v):
    """a first voice's family for the start's refine: a dashboard template's (bass, lead, pad, ...),
    'net', or its first piece's kind"""
    d = [m for m in v if m.kind == "dash"]
    if d and d[0].extra.get("family"):
        return "fam:" + d[0].extra["family"]
    return "net" if v[0].why.startswith("network") else v[0].kind


def grow(audio, sr, midi, gate_s, budget=5000, rng=None, threads=4, trim=True, verbose=False,
         name="grown", progress=None, alts=4, model=None, model_k=8, dashboard=False, polish_k=K_POLISH,
         beam=None, templates=True, library=False, exclude_doc=None, chord=None):
    """progress: called with (log line, fraction of the budget spent) as the build goes (the lab).
    dashboard: DASHBOARD GROW (dash.py) -- every voice holds the dashboard's skeleton (ENV 1, the
    filter, ENV 2, one LFO, the FX slot), the analysis's filter / LFO / effect moves fold into it,
    and the document is a dashboard instrument. polish_k: how many of the most sensitive genes the
    final polish searches at once (K_POLISH; each of its two stages picks them afresh). beam: builds
    grown side by side (None: BEAM, one). templates: the hand-written
    family templates among the starts (False: GROW builds from single sources by itself). library:
    the recipes of the sound's nearest pchkraft-synth presets among them too (grow/library.py;
    exclude_doc: a document left out -- a bench target made by it) -- OFF by default (2026-10-04:
    on, a preset's plain tone out-screened the analysis's starts and tests/test_grow.py's
    self-recovery ended at tone + noise, tf 12.9; off it finds the x2.76 partial, tf 1.21).
    chord: the notes the recording plays together (fractional MIDI, notes.estimate_notes; `midi`
    one of them) -- every candidate is rendered and scored as that chord, and the analysis (the
    starts, the moves, the networks) reads `midi`'s note alone, isolated from the chord
    (notes.isolate), since every note of it is the same patch (2026-10-06). None, or one note: as
    before, bit for bit."""
    if sr != SR:
        raise ValueError("44.1 kHz audio expected (match.to_mono_44k)")
    rng = rng if rng is not None else np.random.default_rng(0)
    t_begin = time.perf_counter()
    from . import kit as KT
    KT.install()                                     # the full kit's kinds
    log_lines = []

    def log(s):
        log_lines.append(s)
        if verbose:
            print("   " + s, flush=True)
        if progress is not None:
            progress(s, min(1.0, ev.n / budget) if "ev" in scope else 0.0)

    scope = {}

    x = np.asarray(audio, np.float32)
    onset = MA.estimate_onset(x) if trim else 0
    x = x[onset:]
    xt = FT.normalize(x)
    T = FT.Target(xt, SR, free_gain=True, gain_cost=MA.GAIN_COST, mod=MA.MOD)
    f0 = 440.0 * 2.0 ** ((float(midi) - 69.0) / 12.0)
    chord = [float(m) for m in chord] if chord is not None and len(chord) > 1 else None
    xa = xt                                          # what the analysis and the networks read
    if chord is not None:
        from .. import notes as NO
        xa = FT.normalize(NO.isolate(x, chord, float(midi)))
        log("chord: %d notes (%s) -- every voice plays all of them; the analysis reads MIDI %.2f alone" % (
            len(chord), " ".join("%.2f" % m for m in chord), float(midi)))
    TA = AN.Sound(xa, f0, gate_s)
    log("target: attack %.3f s decay %.2f s sustain %.2f release %.2f s; drop %.1f st in %.0f ms; vibrato "
        "%.0f ct at %.1f Hz; wobble %.1f dB at %.1f Hz; darkening %.2f oct; click %+.0f dB; %d/%d peaks" % (
            TA.attack, TA.decay, TA.sustain, TA.release, TA.drop, 1000 * TA.drop_t, TA.vib, TA.vib_rate,
            TA.wob, TA.wob_rate, TA.darkening, TA.click, len(TA.pk["early"][0]),
            len(TA.pk["held"][0]) if "held" in TA.pk else 0))
    ev = Evaluator(T, midi, gate_s, len(xt), threads, chord=chord)
    scope["ev"] = ev
    marks = [("begin", t_begin, 0), ("analyse", time.perf_counter(), 0)]   # (phase, when it ended, renders by then)

    def mark(phase):
        marks.append((phase, time.perf_counter(), ev.n))
    # START: screen every first voice briefly, tune the best three properly
    screened = []
    # one network or several (a list: each one's proposals join the starts -- growx's breadth beside the
    # dashboard network's template voices, 2026-10-05); the dashboard network's family head picks templates
    models = [] if model is None else (list(model) if isinstance(model, (list, tuple)) else [model])
    dmodel = next((q for q in models if getattr(q, "cfg", {}).get("engine") == "dashx"), None)
    dashx = dmodel is not None
    if dashboard and templates and (DASH_TEMPLATES or (dashx and DASH_NET_TEMPLATES)):
        # DASHBOARD TEMPLATES (dash_templates.py): whole dashboard instruments for the sound's kind,
        # beside the single sources and the GROW templates no dashboard template covers
        from . import dash_templates as DT
        first = AN.starts(TA, templates_on=False) + [m for n, m in AN.templates(TA) if n in DASH_KEEP_TEMPLATES]
        dt = DT.starts(TA)
        if dashx:
            # THE DASHBOARD NETWORK chooses: its family head is over the templates themselves
            from . import slots_dash as SD
            _, pf = dmodel.structure(xa, SR, midi, gate_s)
            fams = SD._families()
            top = {fams[i] for i in np.argsort(-pf)[:DASH_NET_TOP] if i < len(fams)}
            dt = [v for v in dt if v[-1].extra.get("builder") in top] or dt
        log("dashboard templates: %d (%s)" % (len(dt), ", ".join(v[-1].extra.get("template", "?") for v in dt)))
    else:
        first = AN.starts(TA, templates_on=templates)
        dt = []
    if templates and library:
        from . import library as LB
        lib = LB.templates(TA, LB.LIB_K, exclude_doc)
        if lib:
            log("library: %d starts from the nearest presets (%s)" % (len(lib), "; ".join(
                v[0].why.split(" (")[0][9:] for v in lib)))
        first = first + lib
    for mdl in models:                               # the networks' whole voices beside the templates
        props = net_starts(mdl, xa, midi, gate_s, model_k, rng)
        log("network %s: %d proposals (%s)" % (getattr(mdl, "cfg", {}).get("engine", "?"), len(props),
                                              "; ".join("+".join(m.kind for m in v) for v in props[:3])))
        first = props + first
    if dashboard:
        from . import dash as DS
        first = [DS.dashify(v, TA) for v in first] + dt
        log("dashboard: every voice holds ENV 1, ENV 2, the filter, one LFO and the FX slot")
    mark("starts")
    # SCREEN: every start briefly -- in two stages when SCREEN_KEEP is set and there are more starts
    # (the dashboard templates: ~30 starts at 40 renders each are 1 200 renders before anything grows)
    two = dashboard and 0 < SCREEN_KEEP < len(first)
    for v in first:
        mods, s = tune(ev, v, _tune_idx(v, dashboard), SCREEN_N1 if two else SCREEN_N, rng, pop=8 if two else 12)
        screened.append((s, mods))
        name = v[-1].extra.get("template") if v and v[-1].kind == "dash" and v[-1].extra.get("template") else "+".join(m.kind for m in v)
        log("screen %-17s fitness %.3f  (%s)" % (name, s, v[0].why))
    screened.sort(key=lambda q: q[0])
    if two:
        for j in range(min(SCREEN_KEEP, len(screened))):
            s0, v = screened[j]
            mods, s = tune(ev, v, _tune_idx(v, dashboard), SCREEN_N - SCREEN_N1, rng, pop=8)
            screened[j] = (s, mods) if s < s0 else (s0, v)
        screened.sort(key=lambda q: q[0])
    if dashboard and ROOM_STARTS and TA.tail >= AN.REVERB_TAIL:
        for s0, v in list(screened[:ROOM_STARTS]):
            if _reverb(v):
                continue
            rv = _room_start(ev, v, TA)
            mods, s = tune(ev, rv, _tune_idx(rv, dashboard), SCREEN_N, rng)
            screened.append((s, mods))
            log("screen %-17s fitness %.3f  (a room for the release: the start at %.3f with a %.1f s reverb)" % (
                "+".join(m.kind for m in rv), s, s0, min(8.0, 2.0 * TA.tail)))
        screened.sort(key=lambda q: q[0])
    mark("screen")
    # the best of each FAMILY (the first piece's kind) goes on, not the best three overall: 60
    # renders under-rate a voice with more to tune (DX7 GUITAR 1: FM screened 4th behind three
    # templates and was dropped; grown, it had reached fit 2.90 -- without it 6.72, 2026-10-03)
    fam = {}
    for s0, v in screened:
        fam.setdefault(_family(v), (s0, v))
    refined = []
    for s0, v in sorted(fam.values(), key=lambda q: q[0])[:REFINE]:
        mods, s = tune(ev, v, _tune_idx(v, dashboard), START_N, rng)
        refined.append((min(s, s0), mods if s <= s0 else v))
        log("start  %-17s fitness %.3f" % ("+".join(m.kind for m in v), min(s, s0)))
    refined.sort(key=lambda q: q[0])
    mark("refine")
    # THE BEAM (2026-10-04, was two greedy stalks): the best `width` starts of distinct first kinds
    # within FOCUS_BEAM of the best grow side by side; each step every live build is pruned (a piece a
    # later one made redundant goes now, not only at the end), tries its candidates and offers its
    # KIDS best paying moves as children; children and finished builds compete for the places, one
    # build per structure -- a move second-best now can lead somewhere better later
    width = int(beam) if beam else BEAM
    stalks = []
    for s0, v in refined:
        if len(stalks) >= width:
            break
        if all(v[0].kind != b["mods"][0].kind for b in stalks) and (not stalks or s0 <= FOCUS_BEAM * stalks[0]["score"]):
            stalks.append(dict(mods=v, score=s0, steps=[dict(step=0, kind="+".join(m.kind for m in v), score=s0,
                                                              why=v[0].why, renders=ev.n)],
                               done=False, name="ABCDE"[len(stalks)]))
    limit = budget - POLISH_MIN
    for _ in range(MAX_STEPS):
        live = [b for b in stalks if not b["done"]]
        if not live or ev.n >= limit:
            break
        pool = [b for b in stalks if b["done"]]
        for b in live:
            if ev.n >= limit:
                pool.append(b)
                continue
            if len(b["mods"]) >= 3:
                b["mods"], b["score"] = prune(ev, b["mods"], b["score"], log)
            kids = _children(ev, TA, b, f0, gate_s, rng, limit, log, b["name"], dash=dashboard)
            if kids:
                pool += kids
            else:
                b["done"] = True
                pool.append(b)
        pool.sort(key=lambda q: q["score"])
        nxt, seen = [], set()
        for q in pool:
            key = tuple(sorted(m.kind for m in q["mods"]))
            if key in seen or (nxt and q["score"] > FOCUS_BEAM * nxt[0]["score"]):
                continue
            seen.add(key)
            nxt.append(q)
            if len(nxt) == width:
                break
        for j, q in enumerate(nxt):
            q["name"] = "ABCDE"[j]
        stalks = nxt
    mark("beam")
    win = min(stalks, key=lambda st: st["score"])
    mods, score = win["mods"], win["score"]
    log("stalk %s kept (%s)" % (win["name"], " / ".join("%s %.3f" % (st["name"], st["score"]) for st in stalks)))
    # the ALTERNATIVES (A B C D): the best voice of up to ALTS - 1 OTHER families -- a grown stalk
    # first, else a family's refined start -- each tuned ALT_N renders and pruned after the winner's
    # polish (Synplant shows four buds: one note cannot tell which voice the player wants)
    others, seen = [], {mods[0].kind}
    for cand_mods, cand_s in [(st["mods"], st["score"]) for st in stalks if st is not win] + \
            [(v, s0) for s0, v in refined]:
        if cand_mods[0].kind not in seen and len(others) < alts - 1:
            seen.add(cand_mods[0].kind)
            others.append((cand_mods, cand_s))
    reserve = ALT_N * len(others)
    mods, score = polish(ev, mods, score, budget - reserve, rng, log, k=polish_k)
    mark("polish")
    mods, score = merge_envelopes(ev, mods, score, MERGE_TOL, log, dash=dashboard)
    mods, score = prune(ev, mods, score, log)
    if dashboard:
        mods, score = DS.prune(ev, mods, score, PRUNE_TOL, log)
    mark("merge+prune")
    if dashboard:
        knobs = DS.choose_synth(ev, mods)
        log("dashboard: SYNTH %s" % ", ".join(k[2] for k in knobs))
        mark("synth knobs")
    k, c = BL.key_cents(midi)

    def pack(ms, s, family):
        doc = BL.document(ms, cents=c, name=name)
        return dict(mods=ms, doc=doc, play_doc=BL.playable(doc, midi, gate_s), score=float(s), family=family,
                    describe=BL.describe(ms))
    alternatives = [pack(mods, score, mods[0].kind)]
    for cand_mods, cand_s in others:
        m2, s2 = tune(ev, cand_mods, _tune_idx(cand_mods, dashboard), ALT_N, rng)
        if s2 > cand_s:
            m2, s2 = cand_mods, cand_s
        m2, s2 = merge_envelopes(ev, m2, s2, MERGE_TOL, lambda _: None, dash=dashboard)
        m2, s2 = prune(ev, m2, s2, lambda _: None)
        if dashboard:
            m2, s2 = DS.prune(ev, m2, s2, PRUNE_TOL, lambda _: None)
            DS.choose_synth(ev, m2)
        log("alternative %-14s fitness %.3f" % (m2[0].kind, s2))
        alternatives.append(pack(m2, s2, m2[0].kind))
    alternatives.sort(key=lambda a: a["score"])
    mark("alternatives")
    best = alternatives[0]
    timing = dict(phases=[(ph, round(t - marks[i][1], 3), n - marks[i][2]) for i, (ph, t, n) in enumerate(marks[1:])],
                  render_s=round(ev.t_render, 2), score_s=round(ev.t_score, 2), total_s=round(marks[-1][1] - marks[0][1], 2))
    return dict(mods=best["mods"], doc=best["doc"], play_doc=best["play_doc"], score=best["score"],
                renders=ev.n, steps=win["steps"], log=log_lines, onset=int(onset), describe=best["describe"], chord=chord,
                stalks=[(st["name"], st["score"]) for st in stalks], alternatives=alternatives, timing=timing)


def render(mods, midi, gate_s, secs, seed=1):
    """one note of a grown voice (not normalised)"""
    return BL.render_batch([mods], midi, gate_s, secs, threads=1, seed=seed)[0]


def save(result, path):
    with open(path, "w") as f:
        json.dump(result["doc"], f, indent=1)
