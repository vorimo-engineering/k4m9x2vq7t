"""DASHBOARD TEMPLATES: whole dashboard instruments as Dashboard GROW's starts, one per kind of sound.

Volo (2026-10-04): "we have to focus on dashboard, do we have network for it, do we have wide range of
templates?" -- GROW's thirteen family templates (analyse.templates) are a few pieces each, folded into
a dashboard afterwards with its screens at rest. These are instruments as a player sets one up on the
dashboard: the sources seeded from the analysis (the note's own envelope, peaks, FM pairs, drop,
noise), and the skeleton set the way that kind is played -- a bass's filter envelope, a pad's slow
attack and its chorus or room, an organ's rotary LFO, a lead's vibrato, a brass swell, a pluck's
snapping filter. Each declares WHEN it applies (held or struck, register, harmonic, inharmonic or
noisy), so a sound screens the plausible dozen, not all; its FAMILY (bass, lead, pad, brass, keys,
bell, pluck, drum, noise) is what the start's refine keeps the best of.

    from dnasynth.grow import dash_templates as DT
    voices = DT.starts(TA)            # [voice], each ending with its `dash` piece (extra["family"])
"""
from __future__ import annotations

import numpy as np

from . import analyse as AN
from . import blocks as BL
from . import dash as DS

SAW, PULSE, TRI, SINE = 2 / 3, 1.0, 1 / 3, 0.0
FAMILIES = ("bass", "lead", "pad", "brass", "keys", "bell", "pluck", "drum", "noise")


def _m(kind, ratio=1.0, why="", **p):
    from . import kit as KT
    KT.install()
    return BL.Module.new(kind, ratio, why=why, **p)


# ------------------------------------------------------------------------------- the reading

def features(T):
    """what the conditions read: held / struck, register, harmonic / inharmonic peaks, noise"""
    w = "held" if "held" in T.pk else "early"
    fq, lv = T.pk[w]
    r = fq / T.f0 if fq.size else np.zeros(0)
    k = np.maximum(1, np.round(r))
    harm = int(np.sum(np.abs(r / k - 1) < 0.012)) if r.size else 0
    fe, le = T.pk["early"]
    re_ = fe / T.f0 if fe.size else np.zeros(0)
    ke = np.maximum(1, np.round(re_))
    inharm = int(np.sum(np.abs(re_ / ke - 1) >= 0.012)) if re_.size else 0
    nz = float(np.max(T.noise["early"])) if np.size(T.noise["early"]) else -200.0
    return dict(held=T.sustain >= 0.3, struck=T.sustain < 0.3, f0=float(T.f0), harm=harm, inharm=inharm,
                noisy=nz > T.top - 22.0, slow=T.attack >= 0.08 or T.tail >= 0.6, long_tail=T.tail >= 0.6,
                vib=T.vib >= 6.0, drop=T.drop >= 2.0, bright=T.centroid >= 2500.0)


def _env(T, **over):
    e = dict(att=float(np.clip(T.attack, 0.001, 8.0)), dec=float(np.clip(T.decay, 0.002, 12.0)),
             sus=float(np.clip(T.sustain, 0.0, 1.0)), rel=float(np.clip(T.release, 0.002, 12.0)))
    e.update(over)
    return e


def _voice(T, name, family, pieces, **sk):
    """the template's pieces folded into a dashboard voice (dash.dashify: a single source's envelope
    becomes ENV 1), then its skeleton settings -> [pieces..., dash]"""
    why = "dashboard template: %s" % name
    for p in pieces:
        p.why = why
    v = DS.dashify(pieces, T)
    d = v[-1]
    for key, val in sk.items():
        lo_hi = {"cut": (20.0, 18000.0), "res": (0.0, 0.95), "lfo_rate": (0.05, 20.0)}.get(key)
        DS._set(d, key, float(np.clip(val, *lo_hi)) if lo_hi else val)
    d.why = why
    d.extra["family"] = family
    d.extra["template"] = name
    return v


def _cut(T, mult, lo=60.0):
    return float(np.clip(mult * T.f0, lo, 16000.0))


def _vib(F):
    """a lead's vibrato on the LFO when the note has one: (pitch depth, rate)"""
    return (0.12, 5.5) if F["vib"] else (0.0, 5.5)


# ------------------------------------------------------------------------------- the catalogue

def bass_sub(T, F):
    return _voice(T, "sub bass", "bass", [_m("tone", shape=TRI, **_env(T)), _m("tone", shape=SINE, oct=-1, level=0.6,
                                                                              **_env(T))],
                  model="filter.svf", mode="low pass", cut=_cut(T, 5), res=0.1)


def bass_saw(T, F):
    return _voice(T, "saw bass", "bass", [_m("tone", shape=SAW, **_env(T))], model="filter.ladder", mode="low pass",
                  cut=_cut(T, 4), res=0.3, fenv=2.5, f_att=0.002, f_dec=float(np.clip(T.decay, 0.15, 2.0)), f_sus=0.2)


def bass_fm(T, F):
    return _voice(T, "FM bass", "bass", [_m("fm", 1.0, mratio=1.0, mfb=0.4, index=0.8, idec=0.3, isus=0.2, **_env(T))])


def bass_reese(T, F):
    return _voice(T, "Reese bass", "bass", [_m("tone", shape=SAW, detune=-12.0, level=0.8, **_env(T)),
                                            _m("tone", shape=SAW, detune=12.0, level=0.8, **_env(T))],
                  model="filter.ladder", mode="low pass", cut=_cut(T, 8), res=0.2, lfo_shape="triangle", lfo_rate=0.3,
                  lfo_cut=0.3)


def acid(T, F):
    return _voice(T, "acid", "bass", [_m("tone", shape=SAW, **_env(T))], model="filter.acid", cut=_cut(T, 3), res=0.7,
                  fenv=3.0, f_att=0.002, f_dec=0.2, f_sus=0.0)


def lead_saw(T, F):
    d, r = _vib(F)
    return _voice(T, "saw lead", "lead", [_m("tone", shape=SAW, **_env(T))], model="filter.sk", mode="low pass",
                  cut=_cut(T, 10, 400.0), res=0.2, lfo_shape="sine", lfo_rate=r, lfo_pitch=d, fx_type="delay",
                  fx_depth=0.2)


def lead_square(T, F):
    d, r = _vib(F)
    return _voice(T, "square lead", "lead", [_m("tone", shape=PULSE, pw=0.5, **_env(T))], model="filter.svf",
                  mode="low pass", cut=_cut(T, 10, 400.0), res=0.1, lfo_shape="sine", lfo_rate=r, lfo_pitch=d)


def lead_whistle(T, F):
    d, r = _vib(F)
    return _voice(T, "whistle", "lead", [_m("partial", 1.0, level=0.9, **_env(T)),
                                         _m("noise", freq=float(np.clip(2 * T.f0, 200.0, 12000.0)), res=0.6, morph=0.5,
                                            level=0.15, **_env(T))], lfo_shape="sine", lfo_rate=r, lfo_pitch=d)


def pad_ensemble(T, F):
    return _voice(T, "ensemble pad", "pad", [_m("tone", shape=SAW, detune=-9.0, level=0.6, **_env(T)),
                                             _m("tone", shape=SAW, detune=9.0, level=0.6, **_env(T))],
                  model="filter.svf", mode="low pass", cut=_cut(T, 6, 300.0), res=0.1,
                  fx_type="reverb" if F["long_tail"] else "chorus", fx_depth=0.5)


def pad_pwm(T, F):
    return _voice(T, "PWM strings", "pad", [_m("tone", shape=PULSE, pw=0.35, **_env(T))], model="filter.svf",
                  mode="low pass", cut=_cut(T, 8, 400.0), res=0.1, lfo_shape="triangle", lfo_rate=0.5, lfo_pw=0.25,
                  fx_type="chorus", fx_depth=0.4)


def pad_wavetable(T, F):
    return _voice(T, "wavetable pad", "pad", [_m("src:osc.table", pos=0.5, **_env(T)), _m("cell:lfo>pos", amount=0.2)],
                  model="filter.svf", mode="low pass", cut=_cut(T, 8, 400.0), res=0.1, lfo_shape="sine", lfo_rate=0.2,
                  fx_type="reverb", fx_depth=0.4)


def choir(T, F):
    d, r = _vib(F)
    return _voice(T, "choir", "pad", [_m("tone", shape=SAW, **_env(T)),
                                      _m("eq", freq=700.0, gain=9.0, q=3.0), _m("eq", freq=1200.0, gain=6.0, q=3.0),
                                      _m("eq", freq=2600.0, gain=4.0, q=3.0)],
                  model="filter.svf", mode="low pass", cut=4000.0, res=0.1, lfo_shape="sine", lfo_rate=r,
                  lfo_pitch=max(d, 0.06), fx_type="chorus", fx_depth=0.5)


def brass(T, F):
    return _voice(T, "brass", "brass", [_m("tone", shape=SAW, **_env(T))], model="filter.ladder", mode="low pass",
                  cut=_cut(T, 3, 200.0), res=0.15, fenv=2.0, f_att=float(np.clip(T.attack, 0.03, 0.3)), f_dec=0.4,
                  f_sus=0.6, lfo_shape="sine", lfo_rate=5.0, lfo_pitch=0.05 if F["vib"] else 0.0)


def epiano(T, F):
    tine = dict(rat4=14.0, lev4=0.35, att4=0.001, dec4=0.12, sus4=0.0, rel4=0.1)
    body = dict(rat1=1.0, lev1=0.8, att1=0.001, dec1=float(np.clip(T.decay, 0.3, 6.0)), sus1=float(T.sustain),
                rel1=float(np.clip(T.release, 0.05, 6.0)), rat2=1.0, lev2=0.45, att2=0.001, dec2=1.0, sus2=0.2,
                rel2=0.3, rat3=1.0, lev3=0.5, att3=0.001, dec3=float(np.clip(T.decay * 0.6, 0.2, 4.0)), sus3=0.0,
                rel3=0.2)
    return _voice(T, "FM e-piano", "keys", [_m("fm4", algo=BL.FM4_TWO_STACKS, level=0.8, **body, **tine)],
                  fx_type="chorus", fx_depth=0.3)


def fm_bell(T, F):
    f4 = AN.fm4_start(T, fallback=True)
    pieces = f4 if f4 else [_m("fm", 1.0, mratio=3.5, index=0.7, idec=float(np.clip(T.decay, 0.2, 6.0)), isus=0.0,
                               **_env(T))]
    return _voice(T, "FM bell", "bell", pieces, fx_type="reverb" if F["long_tail"] else "off", fx_depth=0.3)


def organ(T, F):
    w = "held" if "held" in T.pk else "early"
    fq, lv = T.pk[w]
    lvl = {}
    for f, l in zip(fq, lv):
        k = int(round(f / T.f0))
        if k in (1, 2, 3, 4, 6, 8) and abs(f / (k * T.f0) - 1) < 0.012:
            lvl[k] = max(lvl.get(k, -300.0), l)
    flat = dict(att=0.005, dec=12.0, sus=1.0, rel=float(np.clip(T.release, 0.03, 1.0)))
    parts = [_m("partial", float(k), level=float(np.clip(10 ** ((lvl.get(k, T.top - 18.0) - T.top + 6) / 20), 0.05, 1.0)),
                **flat) for k in (1, 2, 3, 4, 6, 8)]
    return _voice(T, "drawbar organ", "keys", parts, lfo_shape="sine", lfo_rate=6.5, lfo_amp=0.08, fx_type="chorus",
                  fx_depth=0.4)


def mallet(T, F):
    return _voice(T, "mallet", "bell", [_m("partial", 1.0, level=0.9, att=0.001, dec=float(np.clip(T.decay, 0.1, 3.0)),
                                           sus=0.0, rel=0.2),
                                        _m("partial", 4.0, level=0.3, att=0.001, dec=float(np.clip(T.decay / 4, 0.03, 1.0)),
                                           sus=0.0, rel=0.1)])


def synth_pluck(T, F):
    return _voice(T, "synth pluck", "pluck", [_m("tone", shape=SAW, **_env(T))], model="filter.ladder", mode="low pass",
                  cut=_cut(T, 3, 150.0), res=0.25, fenv=3.0, f_att=0.001, f_dec=0.15, f_sus=0.0,
                  fx_type="delay" if F["long_tail"] else "off", fx_depth=0.2)


def string_pluck(T, F):
    return _voice(T, "plucked string", "pluck", [_m("pluck", decay=float(np.clip(T.decay * 2, 0.05, 20.0)),
                                                    rel=float(np.clip(T.release, 0.01, 6.0)))])


def kick(T, F):
    body = AN.swept_body(T, "kick body")
    return _voice(T, "kick", "drum", body + [_m("noise", freq=4000.0, res=0.1, morph=1.0, level=0.3, att=0.001, dec=0.02,
                                                 sus=0.0, rel=0.02)])


def snare(T, F):
    return _voice(T, "snare", "drum", [_m("partial", 1.0, level=0.7, att=0.001, dec=0.12, sus=0.0, rel=0.05),
                                       _m("noise", freq=float(np.clip(T.centroid, 1500.0, 8000.0)), res=0.2, morph=0.5,
                                          level=0.7, att=0.001, dec=float(np.clip(T.decay, 0.05, 0.5)), sus=0.0, rel=0.05)])


def hat(T, F):
    return _voice(T, "metal hat", "drum", [_m("fm", 3.3, mratio=7.0, mfine=1.5, index=1.2, idec=0.05, isus=0.0, level=0.5,
                                              att=0.001, dec=float(np.clip(T.decay, 0.03, 0.8)), sus=0.0, rel=0.05),
                                           _m("noise", freq=8000.0, res=0.1, morph=1.0, level=0.7, att=0.001,
                                              dec=float(np.clip(T.decay, 0.03, 0.8)), sus=0.0, rel=0.05)])


def wind(T, F):
    return _voice(T, "wind", "noise", [_m("noise", freq=float(np.clip(T.centroid, 100.0, 12000.0)), res=0.5, morph=0.5,
                                          **_env(T))], lfo_shape="sine", lfo_rate=0.3, lfo_cut=0.5,
                  fx_type="reverb" if F["long_tail"] else "off", fx_depth=0.4)


# (build, applies when) -- the conditions are inclusive on purpose: the screen decides
CATALOGUE = (
    (bass_sub, lambda F: F["f0"] < 160 and F["harm"] >= 1),
    (bass_saw, lambda F: F["f0"] < 220 and F["harm"] >= 2),
    (bass_fm, lambda F: F["f0"] < 220),
    (bass_reese, lambda F: F["f0"] < 220 and F["held"]),
    (acid, lambda F: F["f0"] < 260 and F["harm"] >= 2),
    (lead_saw, lambda F: F["held"] and F["f0"] >= 150 and F["harm"] >= 3),
    (lead_square, lambda F: F["held"] and F["f0"] >= 150 and F["harm"] >= 2),
    (lead_whistle, lambda F: F["held"] and F["f0"] >= 300 and F["harm"] <= 3),
    (pad_ensemble, lambda F: F["held"] and F["slow"]),
    (pad_pwm, lambda F: F["held"] and F["harm"] >= 3),
    (pad_wavetable, lambda F: F["held"] and F["slow"]),
    (choir, lambda F: F["held"] and 100 <= F["f0"] <= 700 and F["harm"] >= 3),
    (brass, lambda F: F["held"] and F["harm"] >= 3),
    (epiano, lambda F: F["harm"] >= 2),
    (fm_bell, lambda F: F["inharm"] >= 2),
    (organ, lambda F: F["held"] and F["harm"] >= 3),
    (mallet, lambda F: (F["struck"] or F["inharm"] >= 2) and F["harm"] + F["inharm"] >= 2),
    (synth_pluck, lambda F: F["struck"] and F["harm"] >= 2),
    (string_pluck, lambda F: F["struck"] and F["harm"] >= 2),
    (kick, lambda F: F["struck"] and F["drop"] and F["f0"] < 200),
    (snare, lambda F: F["struck"] and F["noisy"]),
    (hat, lambda F: F["struck"] and F["noisy"] and F["bright"]),
    (wind, lambda F: F["noisy"] and F["held"]),
)


def starts(T):
    """every template whose condition the sound meets, built from its analysis -> [voice]"""
    F = features(T)
    out = []
    for build, applies in CATALOGUE:
        if applies(F):
            v = build(T, F)
            v[-1].extra["builder"] = build.__name__      # the dashboard network's family name
            out.append(v)
    return out


def family(voice):
    """a template voice's family (its dash piece's extra), or None"""
    d = [m for m in voice if m.kind == "dash"]
    return d[0].extra.get("family") if d else None
