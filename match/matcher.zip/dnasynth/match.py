"""Sound -> dnasynth patch: one recorded note in, a genome (and three alternatives) out.

    import numpy as np, soundfile as sf
    from dnasynth import match
    y, sr = sf.read("note.wav")
    r = match.match(y, sr)                       # midi and gate estimated, seeds from the prior
    r["best"], r["alternatives"], r["score"], r["midi"], r["gate_s"], r["gain_db"]

THE PIPELINE (docs/matcher/search.md):
  1. the note is brought to 44.1 kHz mono and trimmed to its onset (the engine starts a note at
     sample 0); its pitch (midi=None) is a YIN estimate over the sustained frames refined to a
     fraction of a cent by a harmonic fit on a long window (after an odd-partial check: a sub or
     osc B at 3/2 makes the waveform repeat an octave under osc A's note); its note-off
     (gate_s=None) is the sharpest KNEE of its envelope, where the level starts to fall faster
     (none: the note ended by itself, and the gate is where it fell silent);
  2. LEVEL: dnasynth has no output-gain gene, so the note is normalised to the engine's typical
     level (fitness.normalize) and, by default (level="free"), every candidate is scored at its
     best gain with a small cost per dB (fitness.Target(free_gain=True, gain_cost=GAIN_COST): a
     patch's volume is the player's, so a candidate whose natural level differs from the
     normalised note must not lose to a louder wrong one); the gain the best needs to sit at the
     recording's own level is returned as gain_db. level="fixed" scores as rendered (a dnasynth
     render as the target: the truth then scores exactly 0);
  3. SEEDS: the model's proposals when a model is given (model.propose(audio, sr, midi, k)), and a
     pool of prior draws rendered at the note's key / gate / length and scored; with an estimated
     pitch, small pools an octave down and up check the octave (a tracker's octave is never
     trusted: graft); with an estimated gate, the best seeds score the envelope's other knees;
  4. REFINE: ga.refine on the best distinct seeds -> the best genome and four alternatives
     (method "auto": the GA below AUTO_HYBRID_FROM renders, the hybrid -- GA, then CMA-ES polish --
     from it; measured on 16 held-out prior genomes, docs/matcher/search.md);
  5. THE FINE NOTE (pitch or gate estimated): the four alternatives a few cents and 10-20 ms either
     side; a better note is taken and NOTE_FRAC of the budget refines on from the alternatives.
Every render counts against `budget`.
"""
from __future__ import annotations

import time

import numpy as np

from .core import N_GENES, widen
from . import fitness as FT
from . import ga as GA
from . import prior as PR

SR = 44100.0
ONSET_DB = 50.0             # the onset: the first 128-sample frame within this of the loudest
POOL_FRAC = 0.15            # prior seeds: this share of the budget ...
POOL_MIN, POOL_MAX = 200, 3000
POOL_FRAC_MODEL = 0.05      # ... and this share when a model proposes seeds too
MODEL_K = 32                # proposals asked of a model
# the parts of the voice the search holds off (results.md section 26): the sub, the envelope key
# scaling and operator D -- held off for the whole search on 69 real sounds they cost nothing
# measurable; operator D's other genes follow its amount. Version 5's formant and chorus stay in
# the search: on three seeds they cleared the section study's bar twice (rsynth's ruler +21 / +9 /
# +20 sounds net, PANNs no worse). 50 free genes of 57 (version 4: 51)
FROZEN = ("sub_lvl", "env_key", "d_amt")
MOD = True                  # the fitness is modulation-aware (fitness.Target(mod=True): the wobble
#                             term where the note holds -- a vibrato at another phase no longer
#                             loses to none; adopted 2026-09-30, results.md section 25)
OCTAVE_FRAC = 0.25          # each octave probe's pool, as a share of the main pool
OCTAVE_MARGIN = 0.85        # another octave wins if its top-5 median is below this x ours
N_GATE_SEEDS = 8            # the knee probe: the other knees scored with this many best seeds
KNEE_MARGIN = 0.9           # ... another knee wins only below this x the first knee's score
NOTE_FRAC = 0.10            # an estimated pitch or gate: this share of the budget refines after
PITCH_CENTS = (-20, -10, -5, 5, 10, 20)     # the fine note probe, at these pitch offsets ...
GATE_FINE = (-0.02, -0.01, 0.01, 0.02)      # ... and these gate offsets (s)
NOTE_GAIN = 0.02            # an offset wins when it scores at least 2 % under the best
AUTO_HYBRID_FROM = 3500     # method "auto": the GA below this budget, the hybrid from it
GAIN_COST = 0.05            # level "free": fitness per dB of gain a candidate needs (the engine has
                            # no output gain; the player sets the volume, so level is nearly free)


# ============================================================================= note analysis

DC_SHARE = 0.10             # a recording with more than this share of its energy under 20 Hz ...
DC_HP_HZ = 10.0             # ... is high-passed here first (2nd order, zero-phase)


def to_mono_44k(audio, sr):
    """float32 mono at 44.1 kHz (a polyphase resample from any other rate). A recording with a DC
    offset (more than DC_SHARE of its energy under 20 Hz) is high-passed at DC_HP_HZ first: no
    engine makes DC, and the offset reads as the note to the onset, the level and the envelope
    (measured: a hi-hat recorded at +0.019 offset, 99 % of its energy, matched at 17-20 dB on the
    ruler by every arm)"""
    x = np.asarray(audio, np.float64)
    if x.ndim == 2:
        x = x.mean(axis=1) if x.shape[1] <= 8 else x.mean(axis=0)
    if abs(float(sr) - SR) > 1e-6:
        from fractions import Fraction
        from scipy.signal import resample_poly
        fr = Fraction(SR / float(sr)).limit_denominator(1000)
        x = resample_poly(x, fr.numerator, fr.denominator)
    if x.size >= 64:
        P = np.abs(np.fft.rfft(x * np.hanning(x.size))) ** 2
        if P[np.fft.rfftfreq(x.size, 1.0 / SR) < 20.0].sum() > DC_SHARE * max(P.sum(), 1e-30):
            from scipy.signal import butter, sosfiltfilt
            x = sosfiltfilt(butter(2, DC_HP_HZ / (SR / 2), "high", output="sos"), x)
    return x.astype(np.float32)


def to_stereo_44k(audio, sr):
    """float32 [n, 2] at 44.1 kHz when the recording has two channels (each resampled and, when it
    carries a DC offset, high-passed as to_mono_44k does), else None"""
    x = np.asarray(audio, np.float64)
    if x.ndim != 2 or 2 not in x.shape or min(x.shape) != 2:
        return None
    if x.shape[0] == 2 and x.shape[1] != 2:
        x = x.T
    return np.stack([to_mono_44k(x[:, c], sr) for c in range(2)], axis=1)


def _frames_db(x, n, hop):
    """frame RMS in dB (frames of n, hop, starting at 0) and the frame start times (samples)"""
    x = np.asarray(x, np.float64)
    if x.size < n:
        x = np.pad(x, (0, n - x.size))
    c = np.concatenate([[0.0], np.cumsum(x * x)])
    starts = np.arange(0, x.size - n + 1, hop)
    e = (c[starts + n] - c[starts]) / n
    return 10 * np.log10(np.maximum(e, 1e-20)), starts


def estimate_onset(x, sr=SR):
    """the sample where the note starts: the first 128-sample frame within ONSET_DB of the loudest"""
    L, st = _frames_db(x, 128, 32)
    k = int(np.argmax(L >= L.max() - ONSET_DB))
    return int(st[k])


def gate_candidates(x, sr=SR, k=3):
    """candidate note-offs, seconds from the start of x, best first -> (list, found). A release is
    a KNEE of the envelope (512-sample frames, dB): the level falls faster after it (20 ms) than
    before it (80 ms). Knees are taken where the note is still within 45 dB of its peak and the
    frame 20 ms later is not yet at the engine's -80 dB voice end (clamped at 75 dB under the
    peak), at least 60 dB/s sharper, 50 ms apart. None: the note ended by itself (a pluck, a hit)
    and the gate is where it fell 60 dB under its peak."""
    hop = 64
    L, st = _frames_db(x, 512, hop)
    t = (st + 256) / sr
    top = L.max()
    L = np.maximum(L, top - 75.0)
    ipk = int(np.argmax(L))
    fa = max(1, int(round(0.02 * sr / hop)))
    fb = max(1, int(round(0.08 * sr / hop)))
    dt = hop / sr
    i = np.arange(L.size)
    ok = (i >= ipk + int(0.02 * sr / hop)) & (i + fa < L.size) & (i - fb >= 0)
    ok &= L > top - 45.0
    ok[ok] &= L[i[ok] + fa] > top - 74.0
    end = np.flatnonzero(L > top - 60.0)
    t_end = float(min(t[end[-1]] if end.size else x.size / sr, x.size / sr))
    if not ok.any():
        return [t_end], False
    j = i[ok]
    s_after = (L[j + fa] - L[j]) / (fa * dt)
    s_before = (L[j] - L[j - fb]) / (fb * dt)
    knee = s_before - s_after
    cands = []
    for q in np.argsort(-knee):
        if knee[q] < 60.0 or len(cands) >= k:
            break
        tq = float(t[j[q]] - 256 / sr)          # a frame sees the drop half a frame early
        if all(abs(tq - c) > 0.05 for c in cands):
            cands.append(max(tq, 0.0))
    if not cands:
        return [t_end], False
    return cands, True


def estimate_gate(x, sr=SR):
    """the note-off, seconds from the start of x -> (gate_s, found): the sharpest knee
    (gate_candidates), or where the note fell silent when it has none"""
    c, found = gate_candidates(x, sr)
    return c[0], found


def _yin_f0(seg, sr, fmin=25.0, fmax=2000.0, thr=0.25):
    tmax = int(sr / fmin)
    tmin = max(2, int(sr / fmax))
    W = 2048
    if seg.size < W + tmax + 2:
        tmax = max(tmin + 2, seg.size - W - 2)
        if tmax <= tmin + 2:
            return np.nan, 1.0
    x = seg[:W + tmax + 1].astype(np.float64)
    nfft = 1 << int(np.ceil(np.log2(2 * x.size)))
    X = np.fft.rfft(x, nfft)
    Wn = np.fft.rfft(np.r_[np.ones(W), np.zeros(nfft - W)])
    r = np.fft.irfft(np.conj(np.fft.rfft(x[:W], nfft)) * X, nfft)[:tmax + 1]     # cross-corr
    e = np.concatenate([[0.0], np.cumsum(x * x)])
    e0 = e[W]
    et = e[np.arange(tmax + 1) + W] - e[np.arange(tmax + 1)]
    d = e0 + et - 2 * r
    del Wn
    d[0] = 0
    cm = np.cumsum(d[1:])
    dp = np.ones_like(d)
    dp[1:] = d[1:] * np.arange(1, tmax + 1) / np.maximum(cm, 1e-20)
    below = np.flatnonzero(dp[tmin:tmax] < thr)
    if below.size:
        tau = tmin + int(below[0])
        while tau + 1 < tmax and dp[tau + 1] < dp[tau]:
            tau += 1
    else:
        tau = tmin + int(np.argmin(dp[tmin:tmax]))
    if 1 <= tau < tmax:
        a, b, c = dp[tau - 1], dp[tau], dp[tau + 1]
        den = a - 2 * b + c
        off = 0.5 * (a - c) / den if abs(den) > 1e-12 else 0.0
    else:
        off = 0.0
    return sr / (tau + off), float(dp[tau])


def _harmonic_fit(seg, sr, f0, span_c=40.0):
    """f0 refined to a fraction of a cent: the frequency whose harmonics (up to 20, under 16 kHz)
    carry the most log-magnitude on a long zero-padded Hann spectrum"""
    x = seg.astype(np.float64) * np.hanning(seg.size)
    nfft = 1 << int(np.ceil(np.log2(max(seg.size * 4, 1 << 16))))
    A = np.abs(np.fft.rfft(x, nfft))
    df = sr / nfft
    H = max(1, min(20, int(16000.0 / f0)))
    h = np.arange(1, H + 1)
    wts = 1.0 / np.sqrt(h)

    def fit(cents):
        f = f0 * 2.0 ** (cents[:, None] / 1200.0) * h[None]
        k = f / df
        k0 = np.floor(k).astype(int)
        fr = k - k0
        k0 = np.clip(k0, 0, A.size - 2)
        a = A[k0] * (1 - fr) + A[k0 + 1] * fr
        return (np.log(a + 1e-9) * wts[None]).sum(axis=1)
    c = np.arange(-span_c, span_c + 0.5, 1.0)
    c0 = c[int(np.argmax(fit(c)))]
    c = np.arange(c0 - 1.5, c0 + 1.5001, 0.05)
    return f0 * 2.0 ** (c[int(np.argmax(fit(c)))] / 1200.0)


def estimate_pitch(x, sr=SR, gate_s=None):
    """the note's pitch as a fractional MIDI number -> (midi, confidence 0..1). YIN over 2048-sample
    frames of the sustained part (after 60 ms, within 25 dB of the loudest frame, before the gate),
    the median of the periodic frames, then a harmonic fit on up to 1 s of it."""
    x = np.asarray(x, np.float64)
    L, st = _frames_db(x, 2048, 1024)
    stop = x.size if gate_s is None else int(gate_s * sr)
    ok = (L > L.max() - 25.0) & (st >= int(0.06 * sr)) & (st + 2048 <= max(stop, 4096))
    if not ok.any():
        ok = L > L.max() - 25.0
    f0s, ap = [], []
    for s in st[ok][:40]:
        f, a = _yin_f0(x[s:s + 2048 + int(sr / 25.0) + 2], sr)
        if np.isfinite(f):
            f0s.append(f)
            ap.append(a)
    if not f0s:
        return 60.0, 0.0
    f0s, ap = np.asarray(f0s), np.asarray(ap)
    good = ap < 0.3
    f0 = float(np.median(f0s[good] if good.any() else f0s))
    conf = float(good.mean())
    s0 = int(st[ok][0])
    seg = x[s0:min(s0 + int(sr), stop if stop > s0 + 4096 else x.size)]
    if seg.size >= 4096:
        for _ in range(3):                       # a sub-octave the waveform repeats at is not
            if _odd_weak(seg, sr, f0):           # the note: go up while its odd partials are
                f0 *= 2.0                        # missing (a sub, osc B at 1/2, 3/2 ...)
            else:
                break
        f0 = float(_harmonic_fit(seg, sr, f0))
    return 69.0 + 12.0 * np.log2(f0 / 440.0), conf


def _odd_weak(seg, sr, f0, fmax=5000.0, margin_db=12.0):
    """True when the odd multiples of f0 (f0, 3 f0, ...) carry far less than its even ones
    (2 f0, 4 f0, ...): then 2 f0 is the note. Peak magnitudes within +-1.5 % of each multiple on
    a long Hann spectrum, compared as mean dB over the partials below fmax."""
    x = seg.astype(np.float64) * np.hanning(seg.size)
    nfft = 1 << int(np.ceil(np.log2(max(seg.size * 2, 1 << 15))))
    A = np.abs(np.fft.rfft(x, nfft))
    df = sr / nfft
    H = int(fmax / f0)
    if H < 4:
        return False
    def lev(h):
        lo = int(h * f0 * 0.985 / df)
        hi = int(np.ceil(h * f0 * 1.015 / df)) + 1
        return 20 * np.log10(A[lo:hi].max() + 1e-12)
    odd = np.array([lev(h) for h in range(1, H + 1, 2)])
    even = np.array([lev(h) for h in range(2, H + 1, 2)])
    return bool(np.mean(odd) < np.mean(even) - margin_db)


# ============================================================================= match

def _pool_scores(T, midi, gate_s, n, G, threads, budget_left):
    """score genomes at another key / gate (a throwaway Evaluator; renders returned to count)"""
    ev = GA.Evaluator(T, midi, gate_s, n, SR, threads=threads, budget=budget_left)
    s = ev(G)
    ev.close()
    return s, ev.renders


def match(audio, sr=44100.0, midi=None, gate_s=None, model=None, budget=5000, rng=None,
          level="free", method="auto", threads=4, device=None, trim=True, octave_probe=True,
          gate_probe=True, pitch_probe=True, n_pool=None, verbose=False, max_seconds=None,
          gain_cost=GAIN_COST, progress=None, texture=None, sweeps=True, infill=True, frozen=None):
    """One recorded note -> dict(best float32[46], alternatives float32[4, 46], score, scores,
    midi, gate_s, gain_db, onset_s, level, timings, renders, history, stats, target (the audio
    the genomes were fitted to: trimmed, 44.1 kHz, normalised unless level="fixed"), n).

    midi None: estimated (estimate_pitch), octave-probed with prior pools before the search and
    fine-probed (PITCH_CENTS) with the four alternatives after it; gate_s None: estimated
    (gate_candidates), the knees probed with the best seeds before the search and the gate
    fine-probed (GATE_FINE) with the alternatives after it; a probe that wins moves the note and
    NOTE_FRAC of the budget refines on from the alternatives. model None: seeds from the prior
    only, else model.propose(audio, sr, midi, k, gate_s=...) seeds too. budget: renders in all
    (pool, probes, refine). progress: optional callable(stage, fraction) for a UI, called at each
    stage and after every scored batch; it may raise to cancel (the exception propagates).
    texture: None (the plain fitness), or the weights of dnasynth/texture.py's terms added to it
    (motion, noise, low pitch; e.g. v3voice.TEXTURE: half weights). sweeps: the search's
    structural sweeps (ga.SWEEP_AT); infill: with a model, its conditional proposals inside the
    search (the parts a sweep switches on, the neural restarts: model.infill, given the target at
    the note the probes chose).
    frozen: genes the search holds at neutral (prior.frozen); None: FROZEN, the parts the section
    study found idle (results.md section 26); () none."""
    with PR.frozen(FROZEN if frozen is None else frozen):
        return _match(audio, sr, midi, gate_s, model, budget, rng, level, method, threads, device,
                      trim, octave_probe, gate_probe, pitch_probe, n_pool, verbose, max_seconds,
                      gain_cost, progress, texture, sweeps, infill)


def _match(audio, sr, midi, gate_s, model, budget, rng, level, method, threads, device, trim,
           octave_probe, gate_probe, pitch_probe, n_pool, verbose, max_seconds, gain_cost,
           progress, texture, sweeps, infill):
    """match()'s search, under its frozen genes"""
    t0 = time.perf_counter()
    tm = {}
    rng = rng if rng is not None else np.random.default_rng()

    def say(stage, done):
        if progress is not None:
            progress(stage, min(1.0, float(done) / max(1.0, float(budget))))
    say("listening to the note", 0)
    if method == "auto":                       # measured: the GA wins at 2k renders, the hybrid
        method = "ga" if int(budget) < AUTO_HYBRID_FROM else "hybrid"      # at 5k (search.md)
    x = to_mono_44k(audio, sr)
    onset = estimate_onset(x) if trim else 0
    x = x[onset:]
    if x.size < 4096:
        raise ValueError("the note is too short (%d samples after the onset)" % x.size)
    n = x.size
    gate_found, gate_cands = None, []
    if gate_s is None:
        gate_cands, gate_found = gate_candidates(x)
        gate_s = gate_cands[0]
    gate_s = float(gate_s)
    midi_est = None
    if midi is None:
        midi_est, _ = estimate_pitch(x, gate_s=gate_s)
        midi = midi_est
    midi = float(midi)
    tm["analysis"] = time.perf_counter() - t0
    raw_loud = FT.loudness(x)
    xt = x.astype(np.float32) if level == "fixed" else FT.normalize(x)
    if texture:          # the texture terms (dnasynth/texture.py: motion, noise, low pitch) on top
        from . import texture as TX
        T = TX.Target(xt, SR, free_gain=(level == "free"), gain_cost=gain_cost, weights=texture)
    else:
        T = FT.Target(xt, SR, device=device, free_gain=(level == "free"), gain_cost=gain_cost,
                      mod=MOD)
    budget = int(budget)
    spent = 0
    fine_pitch = pitch_probe and midi_est is not None
    fine_gate = gate_probe and bool(gate_found)
    note_reserve = int(NOTE_FRAC * budget) if (fine_pitch or fine_gate) else 0
    # ---- seeds: the model's proposals and a prior pool
    t1 = time.perf_counter()
    props = np.zeros((0, N_GENES), np.float32)
    say("the network proposes" if model is not None else "planting seeds", 0)
    if model is not None:          # a version-2 network proposes 40 genes: operator C and B's
        # feedback off (core.widen). Seeded from rng: unseeded, the network drew from torch's
        # global generator, which every infill re-seeds -- a match depended on the matches before
        # it, and the same note three times scored 6.00 / 6.72 / 7.67 (results.md section 25)
        props = PR.canonical(widen(np.atleast_2d(np.asarray(
            model.propose(xt, SR, midi, MODEL_K, gate_s=gate_s, seed=int(rng.integers(2 ** 31))),
            np.float32))))
    frac = POOL_FRAC_MODEL if model is not None else POOL_FRAC
    npool = int(n_pool) if n_pool is not None else int(np.clip(frac * budget, POOL_MIN, POOL_MAX))
    npool = min(npool, max(budget // 3, 16))
    pool = PR.sample(npool, rng)
    G0 = np.vstack([props, pool]) if len(props) else pool
    octave = {}
    if octave_probe and midi_est is not None:
        # an octave's evidence: the median of the 5 best of k prior draws rendered there
        k = max(32, int(OCTAVE_FRAC * npool))
        s_here, r = _pool_scores(T, midi, gate_s, n, pool[:k], threads, None)
        spent += r
        best_o, best_v = 0, float(np.median(np.sort(s_here)[:5]))
        octave[0] = best_v
        for o in (-12, 12):
            if not 12 <= midi + o <= 120:
                continue
            s_o, r = _pool_scores(T, midi + o, gate_s, n, PR.sample(k, rng), threads, None)
            spent += r
            octave[o] = float(np.median(np.sort(s_o)[:5]))
            if octave[o] < OCTAVE_MARGIN * best_v:
                best_o, best_v = o, octave[o]
        midi += best_o
    tm["octave_probe"] = time.perf_counter() - t1
    ev = GA.Evaluator(T, midi, gate_s, n, SR, threads=threads, budget=None)
    base = spent
    ev.on_eval = lambda r, b: say("growing", base + r)
    s0 = ev(G0)
    spent += ev.renders
    gate_scores = {}
    if gate_probe and gate_found and len(gate_cands) > 1:
        # the other knees (a pluck's early fall can out-knee a slow release): the best seeds
        # decide, and another knee must win by KNEE_MARGIN -- the sharpest knee is the estimate
        t2 = time.perf_counter()
        top = G0[np.argsort(s0)[:N_GATE_SEEDS]]
        best_g, best_v = gate_s, float(np.sort(s0)[0])
        gate_scores[round(gate_s, 4)] = best_v
        for g2 in gate_cands[1:]:
            if not 0.01 < g2 < n / SR:
                continue
            s_g, r = _pool_scores(T, midi, g2, n, top, threads, None)
            spent += r
            gate_scores[round(g2, 4)] = float(s_g.min())
            if s_g.min() < KNEE_MARGIN * best_v:
                best_g, best_v = g2, float(s_g.min())
        if best_g != gate_s:                 # the pool is re-scored at the chosen gate
            ev.close()
            gate_s = float(best_g)
            ev = GA.Evaluator(T, midi, gate_s, n, SR, threads=threads, budget=None)
            base = spent
            ev.on_eval = lambda r, b: say("growing", base + r)
            s0 = ev(G0)
            spent += ev.renders
        tm["gate_probe"] = time.perf_counter() - t2
    tm["seeds"] = time.perf_counter() - t1
    # ---- refine: the best distinct seeds (the model's proposals always among them)
    t3 = time.perf_counter()
    order = np.argsort(s0, kind="stable")
    keep = list(order[:GA.HALVING_SEEDS * 2])
    keep += [i for i in range(len(props)) if i not in keep]
    left = max(budget - spent - note_reserve, 8 * GA.N_ISLANDS)
    fill = None
    if model is not None and infill and hasattr(model, "infill"):
        state = model.target_state(xt, SR, midi, gate_s)          # the note the probes chose

        def fill(G, M, k, force_on):
            return model.infill(state, G, M, k=k, force_on=force_on,
                                seed=int(rng.integers(2 ** 31)))
        fill.n_genes = int(model.tok.n)            # the genes it can draw (a 46-gene network keeps D)
    out = GA.refine(xt, midi, G0[keep], budget=left, sr=SR, gate_s=gate_s, rng=rng, fitness=T,
                    method=method, evaluator=ev, seed_scores=s0[keep], verbose=verbose,
                    max_seconds=max_seconds, infill=fill, sweeps=sweeps)
    spent += out["renders"]
    ev.close()
    tm["refine"] = time.perf_counter() - t3
    # ---- the fine note: the four alternatives -- fitted genomes, whose release and pitch are now
    # near the note's -- a few cents and ms either side; an offset that wins by NOTE_GAIN moves the
    # note, and the reserve refines on from the alternatives (at the old note if none did)
    pitch_scores, fine_gate_scores = {}, {}
    if note_reserve:
        t4 = time.perf_counter()
        best_v = float(out["scores"][0])
        best_c, best_dg = 0.0, 0.0
        if fine_pitch:
            pitch_scores[0.0] = best_v
            for c in PITCH_CENTS:
                s_c, r = _pool_scores(T, midi + c / 100.0, gate_s, n, out["alternatives"], threads,
                                      None)
                spent += r
                pitch_scores[c] = float(s_c.min())
                if s_c.min() < best_v * (1 - NOTE_GAIN):
                    best_c, best_v = c, float(s_c.min())
        if fine_gate:
            fine_gate_scores[0.0] = best_v
            for dg in GATE_FINE:
                if not 0.01 < gate_s + dg < n / SR:
                    continue
                s_g, r = _pool_scores(T, midi + best_c / 100.0, gate_s + dg, n,
                                      out["alternatives"], threads, None)
                spent += r
                fine_gate_scores[dg] = float(s_g.min())
                if s_g.min() < best_v * (1 - NOTE_GAIN):
                    best_dg, best_v = dg, float(s_g.min())
        midi += best_c / 100.0
        gate_s += best_dg
        ev2 = GA.Evaluator(T, midi, gate_s, n, SR, threads=threads, budget=None)
        base2 = spent
        ev2.on_eval = lambda r, b: say("fine-tuning the note", base2 + r)
        room = max(budget - spent, 8 * GA.N_ISLANDS)
        out2 = GA.refine(xt, midi, out["alternatives"], budget=room, sr=SR, gate_s=gate_s,
                         rng=rng, fitness=T, method=method, evaluator=ev2, halving=False,
                         max_seconds=max_seconds, sweeps=False)
        spent += out2["renders"]
        ev2.close()
        base = out["history"][-1][0] if out["history"] else 0
        out2["history"] = out["history"] + [(base + r, v) for r, v in out2["history"]]
        out2["stats"] = dict(out["stats"], note_stage=out2["stats"])
        out = out2
        tm["note_probe"] = time.perf_counter() - t4
    # ---- the level the best needs at the RECORDING's own level
    y_best = render_genome(out["best"], midi, gate_s, n / SR)
    _, terms = T.score(y_best[None], terms=True)
    gain_db = float(terms["gain_db"][0]) + (raw_loud - FT.loudness(xt))
    tm["total"] = time.perf_counter() - t0
    say("done", budget)
    return dict(best=out["best"], alternatives=out["alternatives"], score=float(out["scores"][0]),
                scores=out["scores"], midi=midi, midi_estimated=midi_est, gate_s=gate_s,
                gate_found=gate_found, gate_probe=gate_scores, octave_probe=octave,
                pitch_probe=pitch_scores, gate_fine=fine_gate_scores, gain_db=gain_db, onset_s=onset / SR, level=level,
                method=method,
                timings=tm, renders=spent, history=out["history"], stats=out["stats"],
                target=xt, n=n)


# ============================================================================= key laws
# One note cannot tell a filter at fixed Hz from a key-tracked one, nor fixed envelope times from
# key-scaled ones (research note 07 section 3.5): at the recorded key flt_key trades exactly with
# flt_cut, env_key with the six envelope times (dnasynth.c: cut0 = 20 * 1000^flt_cut *
# (f / C4)^flt_key, times * (f / C4)^-bip(env_key)). rekey() re-expresses a genome with another
# key law so that it plays the SAME note at `midi` -- the choice a second note, a family default
# or the player makes.

C4_MIDI = 60.0
TIME_GENES = ("amp_att", "amp_dec", "amp_rel", "mod_att", "mod_dec", "mod_rel")


def _bip1(g):
    """dnasynth.c bip(g, 1): the dead-zoned bipolar law, linear"""
    x = 2.0 * float(g) - 1.0
    a = abs(x) - 0.04
    return 0.0 if a <= 0 else (a / 0.96) * (1 if x > 0 else -1)


def _bip1_inv(k):
    if abs(k) < 1e-9:
        return 0.5
    return 0.5 + 0.5 * np.sign(k) * (0.04 + 0.96 * min(abs(k), 1.0))


def rekey(genome, midi, flt_key=None, env_key=None):
    """the genome with filter key-track flt_key (0 fixed Hz .. 1 follows the note) and/or envelope
    key-scaling env_key (k in -1..1, 0 = times in seconds at every key), its cutoff and times
    moved so that the note at `midi` is unchanged -> (genome, exact). exact is False when a moved
    gene would leave [0, 1] (it is clipped) or the filter is an open bypass (flt_key untouched)."""
    from .core import GENE_INDEX as I
    g = np.asarray(genome, np.float32).copy()
    oct_c4 = (float(midi) - C4_MIDI) / 12.0                  # log2(f / C4)
    exact = True
    if flt_key is not None:
        if not PR.active_mask(g[None])[0][I["flt_cut"]] and float(g[I["flt_mode"]]) <= 1 / 3 + 1e-6 \
                and float(g[I["flt_key"]]) == 0.0:
            exact = exact and float(flt_key) == 0.0            # an open filter stays open
        else:
            cut = float(g[I["flt_cut"]]) + (float(g[I["flt_key"]]) - float(flt_key)) * oct_c4 / np.log2(1000.0)
            exact = exact and 0.0 <= cut <= 1.0
            g[I["flt_cut"]] = np.clip(cut, 0.0, 1.0)
            g[I["flt_key"]] = float(flt_key)
    if env_key is not None:
        k_old, k_new = _bip1(g[I["env_key"]]), float(env_key)
        d = (k_new - k_old) * oct_c4 * np.log10(2.0) / 4.0     # log10000 of (f/C4)^(k_new - k_old)
        for name in TIME_GENES:
            t = float(g[I[name]]) + d
            exact = exact and 0.0 <= t <= 1.0
            g[I[name]] = np.clip(t, 0.0, 1.0)
        g[I["env_key"]] = _bip1_inv(k_new)
    return PR.canonical(g), bool(exact)


KEY_LAWS = (("fixed filter", 0.0), ("half-tracked filter", 0.5), ("tracked filter", 1.0))


def key_laws(genome, midi):
    """the genome under the three filter laws, times in seconds at every key (env_key 0), each
    identical to it at `midi` -> [(name, genome, exact)]"""
    out = []
    for name, kt in KEY_LAWS:
        g, ex = rekey(genome, midi, flt_key=kt, env_key=0.0)
        out.append((name, g, ex))
    return out


def render_genome(genome, midi, gate_s, secs, vel=1.0):
    """one genome's note the way the matcher rendered its candidates (44.1 kHz, seed 1)"""
    from .core import render
    return render(np.asarray(genome, np.float32), midi=float(midi), vel=vel, gate_s=float(gate_s),
                  secs=float(secs), sr=SR)
