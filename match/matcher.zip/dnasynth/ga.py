"""The matcher's SEARCH: a structure-aware refiner over dnasynth genomes.

    import numpy as np
    from dnasynth import ga, prior
    rng = np.random.default_rng(0)
    out = ga.refine(target_audio, midi=48.0, seeds=prior.sample(64, rng), budget=5000,
                    gate_s=1.2, rng=rng)
    out["best"], out["alternatives"], out["scores"], out["history"]

Every candidate is rendered at the TARGET's own key, gate and length through the batch renderer
(render_batch, chunked over a few threads: ctypes releases the GIL) and scored with
fitness.Target (numpy path, also chunked over threads; the torch path is used unthreaded when the
caller passes a device Target). The budget is counted in RENDERS; a canonical genome is rendered
once (a cache keyed on its bytes), so duplicates cost nothing and never reach the budget.

WHY THIS SHAPE (lessons paid for, docs/matcher/search.md):
  * a GA recovers a synth exactly at <= 20 free genes and fails at 115 (pchsynth): the search runs
    on the ACTIVE genes of each candidate (prior.active_mask), ~10 of the 40, and changes the
    ACTIVE SET only by explicit structure moves (switch a gene on / off, a b_ratio plateau step, a
    pure-leg jump of a shape, a filter-mode jump, a module transplant from another island);
  * the landscape is multimodal (graft): several ISLANDS search in parallel from different seeds,
    near-duplicate islands are restarted from the seed queue, and the result is the best of each
    island -- FOUR DIVERSE ALTERNATIVES (Synplant's four trees: the ear picks, graft);
  * seeds are ranked by SUCCESSIVE HALVING before islands start: a raw prior draw with the right
    structure but wrong values scores worse than a wrong structure that happens to be close, so
    each surviving seed is locally improved before it is judged;
  * a noisy patch's score carries its own noise realisation (render_batch seeds noise per batch
    index): an island's new best with noise on is re-rendered with other seeds and the mean kept,
    and the finalists are re-scored the same way before the alternatives are chosen.

METHODS (refine(method=...)), measured against each other on held-out prior genomes
(tests/test_ga.py --curve, docs/matcher/search.md):
  "ga"      per island, a (mu + lambda) GA: local mutants (breed.mutate, structure=False, a step
            size adapted by its success rate), STRUCTURE children of the island best and module
            crossover of elites;
  "hybrid"  the GA for HYBRID_POLISH of the islands' budget, then every island polishes its best
            with CMA-ES on its active continuous genes (b_ratio held on its plateau, pulse widths
            on [0, 0.5]), each gene's first step scaled by a +-PROBE_DELTA sensitivity probe
            (isotropic CMA, full or separable, found nothing a sparse GA step did not: search.md),
            still with structure children every generation -- one that wins restarts the CMA on
            its active set. The GA phase is the "ga" run itself (same rng), so the two differ
            only in the last share of the budget;
  "cma"     the per-gene-scaled CMA-ES from the start, no structure moves (an ablation).
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .core import GENES, GENE_INDEX, N_GENES, render_batch
from . import breed as BR
from . import fitness as FT
from . import prior as PR

_I = GENE_INDEX
NEUTRAL = PR.NEUTRAL
RATIO = _I["b_ratio"]
C_RATIO = _I["c_ratio"]
C_TGT = _I["c_tgt"]
C_AMT = _I["c_amt"]
D_RATIO = _I["d_ratio"]
D_TGT = _I["d_tgt"]
D_AMT = _I["d_amt"]
WAVES = (_I["a_wave"], _I["b_wave"])
PWS = (_I["a_pw"], _I["b_pw"])
MODE = _I["flt_mode"]
NOISE = _I["noise_lvl"]
NEVER = tuple(_I[n] for n in PR.NEVER_DRAWN)
MODES_PURE = (0.0, 1.0 / 3.0, 2.0 / 3.0, 1.0)            # LP24, LP12, BP, HP

# ---- the refiner's constants (the values the measurements in docs/matcher/search.md used)
N_ISLANDS = 4
HALVING_SEEDS = 32          # the best seeds that enter successive halving
HALVING_FRAC = 0.25         # of the budget left after the seeds
FINAL_FRAC = 0.05           # reserved for the finalists' re-scoring and the alternatives
ROUND_MAX = 64              # an island round renders at most about this many (4 islands x 16)
ARCHIVE_TOP = 512           # the alternatives come from the best this many genomes rendered ...
SHORTLIST = 16              # ... thinned to this many, no two in one basin, then rendered
PROBE_DELTA = 0.01          # CMA's per-gene sensitivity probe: +- this, gene units
PROBE_TARGET = 0.1          # ... a gene's first step moves the fitness by this share of the score
HYBRID_POLISH = 0.6         # hybrid: GA for this share of the islands' budget, then CMA polish
N_STRUCT = 4                # structure children per island generation (hybrid, ga)
CMA_STALL = 12              # generations without improvement before a CMA restart
ISLAND_STALL = 3            # CMA restarts without improvement before the island is replaced
NOISE_SEEDS = 2             # extra noise realisations for a noisy island best / finalist
MIN_AUDIBLE = BR.MIN_AUDIBLE    # alternatives must be at least this far apart (fitness units)
NEAR_ACTIVE = 0.08          # two genomes with the same active set within this (max |d|) = one basin
# the STRUCTURAL SWEEP (docs/matcher/literature.md, search section 1-2): at these shares of the
# islands' budget the best island's genome gets every single structural edit -- each part of the
# voice on or off, every plateau of every ratio in use, operator C's route, every pure shape leg,
# every filter mode -- and the most promising edits a short re-fit of the genes each unlocked
# before they are judged, so a right structure is not rejected for its untuned values
SWEEP_AT = (0.35, 0.7)
SWEEP_MIN = 1500            # islands' budget under which no sweep runs (a sweep costs ~250 renders);
                            # under twice this, one sweep at half-way
SWEEP_ON_K = 2              # fills per part switched on (the network's infill, else prior donors)
SWEEP_RACE = ((12, 8), (4, 10), (2, 16))   # the re-fit's halving: (edits kept, children each)
SWEEP_AMOUNT = 0.08         # the re-fit's step (gene units); a third of its children move all genes
SWEEP_ADMIT = 1.25          # a swept structure within this factor of the worst island replaces it
NEURAL_MASK = 0.4           # a neural jump redraws this share of the genes (given the rest)
# the sweep's LADDER (docs/matcher/results.md section 22): a part that helps only SUBTLY (the
# Marimba's 6 % reverb) or only at the right depth (the GM kick's sub, -2.7 dB on the ruler) was
# lost to the sweep's random fills -- they switch it on too strong, it scores badly at its first
# render and is cut before its re-fit. These parts also come on at these starting settings (over
# the part's first fill). Forced on from such a grid and searched, 7 of 101 section tests on the
# bench's 21 real sounds beat their control: reverb on 4, the kicks' sub, amplitude LFO and noise
LADDER = {
    "rvb_mix": (dict(rvb_mix=0.06, rvb_size=0.4, rvb_decay=0.4),
                dict(rvb_mix=0.15, rvb_size=0.3, rvb_decay=0.3),
                dict(rvb_mix=0.15, rvb_size=0.6, rvb_decay=0.6),
                dict(rvb_mix=0.35, rvb_size=0.6, rvb_decay=0.6)),
    "sub_lvl": (dict(sub_lvl=0.15), dict(sub_lvl=0.35), dict(sub_lvl=0.6)),       # -33 / -18 / -9 dB
    "lfo_amp": tuple(dict(lfo_amp=a, lfo_rate=r, lfo_delay=0.0)                    # 10 / 30 %, 3 / 6 Hz
                     for a in (0.308, 0.543) for r in (0.64, 0.749)),
    "noise_lvl": tuple(dict(noise_lvl=a, noise_col=c)                             # -40 / -24 dB
                       for a in (0.1, 0.25) for c in (0.3, 0.7)),
    # version 5 (results.md sections 25-26: the settings the oracle probes found): the chorus at
    # mix 0.3 / 0.6, 0.4 Hz x 2 ms or 1 Hz x 5 ms; the formant at 600 Hz / 1.2 kHz / 2.5 kHz,
    # +-9 dB, Q 2
    "cho_mix": tuple(dict(cho_mix=m, cho_rate=r, cho_depth=d) for m in (0.3, 0.6)
                     for r, d in ((0.354, 0.5), (0.589, 0.830))),
    "fmt_gain": tuple(dict(fmt_gain=gg, fmt_freq=f, fmt_q=0.5) for f in (0.340, 0.509, 0.688)
                      for gg in (0.814, 0.186)),
}
HEADS = tuple(_I[n] for n in ("osc_mix", "fm_amt", "b_fb", "c_amt", "d_amt", "sub_lvl", "noise_lvl",
                              "menv_fm", "menv_pitch", "menv_bpitch", "flt_env", "flt_lfo",
                              "flt_key", "flt_res", "lfo_pitch", "lfo_amp", "drive", "rvb_mix",
                              "env_key", "b_detune", "fmt_gain", "cho_mix"))
LADDER_IDX = {_I[h]: tuple({_I[k]: float(v) for k, v in d.items()} for d in L)
              for h, L in LADDER.items()}


# ============================================================================= evaluation

class Evaluator:
    """Renders and scores genomes against one target at its key / gate / length, counting renders.

    ev = Evaluator(target, midi, gate_s, n, sr)      target: a fitness.Target (or anything with
    s = ev(G)                                        .score(audio[K, n]) -> float[K])
    ev.renders, ev.best, ev.best_score, ev.history

    A genome is canonicalised first and looked up in a cache (its float32 bytes): an identical
    canonical genome renders the same sound, so it is never rendered twice. Past the budget, the
    remaining candidates of a call score +inf and are not rendered. Renders are chunked
    (`chunk` patches per render_batch call) over `threads` threads; the noise seed of a chunk is
    derived from (seed, call number, chunk index), so the result does not depend on the thread
    count."""

    def __init__(self, target, midi, gate_s, n, sr=44100.0, seed=1, threads=4, chunk=8,
                 budget=None, vel=1.0):
        self.T = target
        self.midi = float(midi)
        self.gate_s = float(gate_s)
        self.n = int(n)
        self.sr = float(sr)
        self.vel = float(vel)
        self.seed = int(seed)
        self.threads = max(1, int(threads))
        self.chunk = int(chunk)
        self.budget = budget
        self.cache = {}
        self.renders = 0
        self.calls = 0
        self.best, self.best_score = None, np.inf
        self.history = []
        self.t_render = 0.0
        self.t_score = 0.0
        self.on_eval = None                 # optional callable(renders, best_score) after each call
        feat = getattr(target, "feat", None)
        self._thread_score = not isinstance(feat, FT._TorchFeatures)
        self._pool = ThreadPoolExecutor(self.threads) if self.threads > 1 else None

    # --------------------------------------------------------------- raw render + score
    def _render_chunk(self, G, seed):
        return render_batch(G, midi=self.midi, vel=self.vel, gate_s=self.gate_s,
                            secs=self.n / self.sr, sr=self.sr, seed=seed)

    def render(self, G, seed=None):
        """audio [K, n] of genomes G at the target's key / gate / length (not cached, not counted)"""
        G = np.atleast_2d(np.asarray(G, np.float32))
        call = self.calls if seed is None else int(seed)
        self.calls += 1
        parts = [np.arange(a, min(a + self.chunk, len(G))) for a in range(0, len(G), self.chunk)]
        seeds = [(self.seed * 1000003 + call * 7919 + j * 104729) & 0x7FFFFFFF
                 for j in range(len(parts))]
        t0 = time.perf_counter()
        if self._pool is not None and len(parts) > 1:
            Y = list(self._pool.map(lambda a: self._render_chunk(G[a[0]], a[1]), zip(parts, seeds)))
        else:
            Y = [self._render_chunk(G[p], s) for p, s in zip(parts, seeds)]
        self.t_render += time.perf_counter() - t0
        return np.vstack(Y) if Y else np.zeros((0, self.n), np.float32)

    def score_audio(self, Y):
        t0 = time.perf_counter()
        if self._pool is not None and self._thread_score and len(Y) > self.chunk:
            parts = [Y[a:a + self.chunk] for a in range(0, len(Y), self.chunk)]
            s = np.concatenate(list(self._pool.map(self.T.score, parts)))
        else:
            s = self.T.score(Y) if len(Y) else np.zeros(0, np.float32)
        self.t_score += time.perf_counter() - t0
        return np.asarray(s, np.float64)

    # --------------------------------------------------------------- the counted, cached call
    def remaining(self):
        return np.inf if self.budget is None else max(0, self.budget - self.renders)

    def __call__(self, G):
        G = PR.canonical(np.atleast_2d(np.asarray(G, np.float32)))
        keys = [g.tobytes() for g in G]
        out = np.full(len(G), np.inf)
        todo, seen = [], {}
        for i, k in enumerate(keys):
            if k in self.cache:
                out[i] = self.cache[k]
            elif k in seen:
                continue
            else:
                seen[k] = i
                todo.append(i)
        room = self.remaining()
        if room < len(todo):
            todo = todo[:int(room)]
        if todo:
            Y = self.render(G[todo])
            s = self.score_audio(Y)
            self.renders += len(todo)
            for i, v in zip(todo, s):
                self.cache[keys[i]] = float(v)
                if v < self.best_score:
                    self.best_score, self.best = float(v), G[i].copy()
        for i, k in enumerate(keys):              # duplicates inside this call
            if not np.isfinite(out[i]) and k in self.cache:
                out[i] = self.cache[k]
        self.history.append((self.renders, self.best_score))
        if self.on_eval is not None:         # progress for a UI; it may raise to cancel the search
            self.on_eval(self.renders, self.best_score)
        return out

    def prime(self, G, scores):
        """record already-known scores (e.g. a seed pool scored by the caller): not rendered again"""
        G = PR.canonical(np.atleast_2d(np.asarray(G, np.float32)))
        for g, v in zip(G, np.asarray(scores, np.float64)):
            self.cache[g.tobytes()] = float(v)
            if v < self.best_score:
                self.best_score, self.best = float(v), g.copy()

    def rescore(self, G, n_seeds=NOISE_SEEDS):
        """the mean score over the cached realisation and n_seeds fresh ones (renders counted;
        the cache is updated to the mean). Genomes without noise are returned as cached."""
        G = PR.canonical(np.atleast_2d(np.asarray(G, np.float32)))
        base = self(G)
        noisy = np.flatnonzero(PR.active_mask(G)[:, NOISE] & np.isfinite(base))
        if not noisy.size or n_seeds <= 0:
            return base
        n_seeds = int(min(n_seeds, self.remaining() // max(noisy.size, 1)))
        if n_seeds <= 0:
            return base
        acc = base[noisy].copy()
        for r in range(n_seeds):
            Y = self.render(G[noisy])
            acc += self.score_audio(Y)
            self.renders += noisy.size
        acc /= (n_seeds + 1)
        out = base.copy()
        out[noisy] = acc
        for i in noisy:
            self.cache[G[i].tobytes()] = float(out[i])
        # the best may have been a lucky draw: recompute it from the cache
        ks = list(self.cache)
        vs = np.array([self.cache[k] for k in ks])
        j = int(np.argmin(vs))
        self.best_score = float(vs[j])
        self.best = np.frombuffer(ks[j], np.float32).copy()
        return out

    def close(self):
        if self._pool is not None:
            self._pool.shutdown(wait=True)
            self._pool = None


# ============================================================================= CMA-ES

def _mirror(x, lo, hi):
    """reflect into [lo, hi] (per coordinate), then clip"""
    w = hi - lo
    y = np.mod(x - lo, 2 * w)
    y = np.where(y > w, 2 * w - y, y) + lo
    return np.clip(y, lo, hi)


class CMA:
    """(mu/mu_w, lambda)-CMA-ES with rank-one and rank-mu updates and cumulative step-size
    adaptation (Hansen's tutorial, arXiv 1604.00772), box-bounded by mirroring: the repaired
    points are what is evaluated and what the update uses. diag=True is the separable variant
    (sep-CMA-ES, Ros & Hansen 2008): a diagonal covariance learned (n + 2) / 3 times faster, which
    is what a short budget can afford."""

    def __init__(self, x0, sigma0, lo, hi, rng, lam=None, diag=False):
        n = self.n = len(x0)
        self.diag = bool(diag)
        self.lo, self.hi = np.asarray(lo, float), np.asarray(hi, float)
        self.rng = rng
        self.lam = int(lam or max(10, 4 + int(3 * np.log(max(n, 1)))))
        self.mu = self.lam // 2
        w = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.w = w / w.sum()
        self.mueff = 1.0 / float((self.w ** 2).sum())
        self.cc = (4 + self.mueff / n) / (n + 4 + 2 * self.mueff / n)
        self.cs = (self.mueff + 2) / (n + self.mueff + 5)
        self.c1 = 2 / ((n + 1.3) ** 2 + self.mueff)
        self.cmu = min(1 - self.c1, 2 * (self.mueff - 2 + 1 / self.mueff) / ((n + 2) ** 2 + self.mueff))
        if self.diag:
            self.c1 = min(1.0, self.c1 * (n + 2) / 3.0)
            self.cmu = min(1 - self.c1, self.cmu * (n + 2) / 3.0)
        self.damps = 1 + 2 * max(0.0, np.sqrt((self.mueff - 1) / (n + 1)) - 1) + self.cs
        self.chiN = np.sqrt(n) * (1 - 1 / (4 * n) + 1 / (21 * n * n))
        self.m = _mirror(np.asarray(x0, float), self.lo, self.hi)
        self.sigma = float(sigma0)
        self.pc, self.ps = np.zeros(n), np.zeros(n)
        self.B, self.D = np.eye(n), np.ones(n)
        self.C, self.invsqrtC = np.eye(n), np.eye(n)
        self.gen = 0
        self.best_f, self.best_x, self.stall = np.inf, self.m.copy(), 0

    def ask(self):
        z = self.rng.standard_normal((self.lam, self.n))
        x = self.m + self.sigma * (z * self.D[None]) @ self.B.T
        return _mirror(x, self.lo, self.hi)

    def tell(self, X, f):
        f = np.asarray(f, float)
        order = np.argsort(np.where(np.isfinite(f), f, np.inf), kind="stable")
        n = self.n
        xold = self.m
        Xs = X[order[:self.mu]]
        self.m = self.w @ Xs
        y_w = (self.m - xold) / self.sigma
        self.ps = (1 - self.cs) * self.ps + np.sqrt(self.cs * (2 - self.cs) * self.mueff) \
            * (self.invsqrtC @ y_w)
        self.gen += 1
        hsig = (np.linalg.norm(self.ps) / np.sqrt(1 - (1 - self.cs) ** (2 * self.gen)) / self.chiN
                < 1.4 + 2 / (n + 1))
        self.pc = (1 - self.cc) * self.pc + hsig * np.sqrt(self.cc * (2 - self.cc) * self.mueff) * y_w
        art = (Xs - xold) / self.sigma
        self.sigma *= np.exp((self.cs / self.damps) * (np.linalg.norm(self.ps) / self.chiN - 1))
        self.sigma = float(min(self.sigma, 0.5))
        if self.diag:
            c = np.diag(self.C)
            c = (1 - self.c1 - self.cmu) * c \
                + self.c1 * (self.pc ** 2 + (1 - hsig) * self.cc * (2 - self.cc) * c) \
                + self.cmu * (self.w @ (art ** 2))
            c = np.maximum(c, 1e-20)
            self.C = np.diag(c)
            self.D = np.sqrt(c)
            self.invsqrtC = np.diag(1.0 / self.D)
        else:
            self.C = (1 - self.c1 - self.cmu) * self.C \
                + self.c1 * (np.outer(self.pc, self.pc) + (1 - hsig) * self.cc * (2 - self.cc) * self.C) \
                + self.cmu * (art.T * self.w) @ art
            C = (self.C + self.C.T) / 2
            d2, B = np.linalg.eigh(C)
            d2 = np.maximum(d2, 1e-20)
            self.B, self.D = B, np.sqrt(d2)
            self.invsqrtC = (B / self.D[None]) @ B.T
        if f[order[0]] < self.best_f - 1e-9:
            self.best_f, self.best_x, self.stall = float(f[order[0]]), X[order[0]].copy(), 0
        else:
            self.stall += 1

    def converged(self, tol=2e-3, stall=CMA_STALL):
        return self.sigma * float(self.D.max()) < tol or self.stall >= stall


# ============================================================================= moves

class _Marginals:
    """a fixed bank of prior genomes: a gene switched ON takes a value from here (the prior's own
    marginal for that gene, so what appears is musical, not uniform)"""
    _bank = {}

    @classmethod
    def get(cls):
        if "G" not in cls._bank:
            with PR.unfrozen():                  # the prior's bank, whatever a search holds off
                G = PR.sample(4096, np.random.default_rng(20260924))
            cls._bank["G"], cls._bank["A"] = G, PR.active_mask(G)
        return cls._bank["G"], cls._bank["A"]


def active_continuous(g):
    """indices of the active genes CMA moves: b_ratio is a plateau choice and c_tgt / d_tgt
    routings, never continuous. c_ratio and d_ratio stay: on a plateau the probe reads no slope, so
    the first step is the largest (PROBE clip), which is what leaves a plateau for a ratio just
    off it"""
    g = np.asarray(g, np.float32)
    a = PR.active_mask(g[None])[0].copy()
    a[RATIO] = False
    a[C_TGT] = False
    a[D_TGT] = False
    a[list(NEVER)] = False
    return np.flatnonzero(a)


def _bounds(idx):
    hi = np.ones(len(idx))
    for k, j in enumerate(idx):
        if j in PWS:
            hi[k] = 0.5
    return np.zeros(len(idx)), hi


def switch_off(g, rng):
    """one active gene back to its neutral value (Occam: is it needed?)"""
    g = g.copy()
    act = np.flatnonzero(PR.active_mask(g[None])[0])
    if act.size <= 1:
        return g
    k = int(rng.choice(act))
    g[k] = NEUTRAL[k]
    return g


def switch_on(g, rng, tries=8):
    """one inactive gene switched on, its value and its companions' (breed.COMPANIONS) from one
    prior genome in which it is active; only a gene whose section then sounds counts (else the
    genome is returned unchanged)"""
    G, A = _Marginals.get()
    act = PR.active_mask(g[None])[0]
    cand = [k for k in range(N_GENES) if not act[k] and k not in NEVER and A[:, k].any()]
    rng.shuffle(cand)
    for k in cand[:tries]:
        t = BR.coherent_on(g, k, G[rng.choice(np.flatnonzero(A[:, k]))])
        if PR.active_mask(t[None])[0][k]:
            return t
    return g.copy()


def discrete_move(g, rng):
    """a plateau / pure-leg choice: b_ratio one or two plateaus over (osc B in use), operator C's
    ratio to another plateau or its route to the other oscillator (operator C heard), a shape to
    a neighbouring pure leg, the filter mode to a pure mode"""
    g = g.copy()
    act = PR.active_mask(g[None])[0]
    opts = []
    if act[RATIO] or act[_I["b_wave"]]:
        opts.append("ratio")
    if act[C_AMT]:
        opts += ["c_ratio", "c_tgt"]
    if act[D_AMT]:
        opts += ["d_ratio", "d_tgt"]
    opts += ["a_wave"] + (["b_wave"] if act[_I["b_wave"]] or act[RATIO] else [])
    if act[MODE] or act[_I["flt_cut"]]:
        opts.append("mode")
    what = opts[int(rng.integers(len(opts)))]
    if what == "c_ratio":
        p = int(PR.c_plateau(g[C_RATIO]))
        if p < 0:
            p = int(np.argmin(np.abs(PR.C_CENTRES - g[C_RATIO])))
        g[C_RATIO] = PR.C_CENTRES[BR._step_plateau(p, rng, len(PR.C_RATIOS))]
    elif what == "c_tgt":
        g[C_TGT] = 0.75 if g[C_TGT] < 0.5 else 0.25
    elif what == "d_ratio":
        p = int(PR.c_plateau(g[D_RATIO]))
        if p < 0:
            p = int(np.argmin(np.abs(PR.C_CENTRES - g[D_RATIO])))
        g[D_RATIO] = PR.C_CENTRES[BR._step_plateau(p, rng, len(PR.C_RATIOS))]
    elif what == "d_tgt":
        r = int(PR.d_route(g[D_TGT]))
        g[D_TGT] = PR.D_ROUTES[int(rng.choice([q for q in range(3) if q != r]))]
    elif what == "ratio":
        p = int(PR.plateau(g[RATIO]))
        q = int(np.clip(p + int(rng.choice([-2, -1, -1, 1, 1, 2])), 0, 15))
        if q == int(PR.plateau(NEUTRAL[RATIO])):
            q = int(np.clip(q + (1 if q > p else -1), 0, 15))
        g[RATIO] = (q + 0.5) / 16.0
    elif what in ("a_wave", "b_wave"):
        j = _I[what]
        legs = np.asarray(PR.LEGS)
        k0 = int(np.argmin(np.abs(legs - g[j])))
        near = [k for k in (k0 - 1, k0 + 1) if 0 <= k < 4]
        if abs(legs[k0] - g[j]) > 1e-6:
            near.append(k0)
        g[j] = legs[near[int(rng.integers(len(near)))]]
    else:
        cur = int(np.argmin(np.abs(np.asarray(MODES_PURE) - g[MODE])))
        g[MODE] = MODES_PURE[int(rng.choice([k for k in range(4) if k != cur]))]
    return g


def structure_children(g, rng, n, others=()):
    """n children of g that may change its ACTIVE SET or its discrete choices: a breed mutation
    with structure moves, a switch-off, a switch-on, a discrete move, or a module transplant from
    another island's best (crossover)"""
    out = []
    kinds = ["mutate", "off", "on", "discrete"] + (["cross"] if len(others) else [])
    p = np.array([0.25, 0.2, 0.25, 0.2, 0.1][:len(kinds)])
    for _ in range(n):
        k = kinds[int(rng.choice(len(kinds), p=p / p.sum()))]
        if k == "mutate":
            c = BR.mutate(g, rng, 1, amount=0.12, structure=True)[0]
        elif k == "off":
            c = switch_off(g, rng)
        elif k == "on":
            c = switch_on(g, rng)
        elif k == "discrete":
            c = discrete_move(g, rng)
        else:
            c = BR.crossover(g, others[int(rng.integers(len(others)))], rng, 1)[0]
        out.append(c)
    return PR.canonical(np.asarray(out, np.float32))


def same_basin(a, b, tol=NEAR_ACTIVE):
    """two canonical genomes in one basin: the same active set, the same b_ratio plateau, the same
    c_ratio plateau (or both between plateaus) and every active gene within tol"""
    A = PR.active_mask(np.vstack([a, b]))
    if not np.array_equal(A[0], A[1]):
        return False
    if PR.plateau(a[RATIO]) != PR.plateau(b[RATIO]):
        return False
    if PR.c_plateau(a[C_RATIO]) != PR.c_plateau(b[C_RATIO]):
        return False
    if PR.c_plateau(a[D_RATIO]) != PR.c_plateau(b[D_RATIO]):
        return False
    d = np.abs(a - b)[A[0]]
    return bool(d.size == 0 or d.max() < tol)


# ============================================================================= structural sweep

def _module_of(j):
    """the gene indices of the breed module holding gene j"""
    for ix in BR.MODULE_IDX:
        if j in ix:
            return ix
    return np.array([j], np.int64)


def sweep_edits(g, rng, infill=None):
    """every single structural edit of g -> (E float32[m, N] canonical, focus: per edit the gene
    indices it unlocked or re-voiced, which its re-fit moves). The edits: each HEADS part off; each
    part on (its value and its companions from the network's infill given the target and every
    other gene -- SWEEP_ON_K draws with the part forced on -- or, without a network, from prior
    donors) -- operator C switched on also at every plateau into each oscillator, operator D at every
    plateau into each of its three routes, and osc B at every
    plateau (the first fill's values): a part that comes on at the wrong ratio is the wrong
    structure; a LADDER part also at each of its starting settings (over the first fill); every
    other plateau of b_ratio (osc B in use) and of c_ratio (operator C heard) and operator C's other
    route; every other pure leg of the shapes in use; every other filter mode."""
    g = PR.canonical(np.asarray(g, np.float32))
    act = PR.active_mask(g[None])[0]
    E, F = [], []

    def add(e, focus):
        E.append(np.asarray(e, np.float32))
        F.append(np.asarray(sorted(set(int(j) for j in focus)), np.int64))

    b_used = bool(act[_I["osc_mix"]] or act[_I["fm_amt"]] or act[RATIO])
    for h in HEADS:                                                   # parts off
        if act[h]:
            e = g.copy()
            e[h] = NEUTRAL[h]
            add(e, _module_of(h))
    off = [h for h in HEADS if not act[h] and h not in NEVER]         # parts on
    if off:
        comps = [np.concatenate([[h], BR.COMPANION_IDX.get(h, np.zeros(0, np.int64))]).astype(
            np.int64) for h in off]
        fills = [None] * len(off)
        # the network fills the parts in its own layout (a 46-gene network in the 51-gene search
        # keeps operator D as it is: infill's n_genes); the rest come from prior donors
        n_net = int(getattr(infill, "n_genes", N_GENES)) if infill is not None else 0
        net = [i for i, (h, c) in enumerate(zip(off, comps)) if int(c.max()) < n_net]
        if net:
            M = np.zeros((len(net), N_GENES), bool)
            FO = np.zeros_like(M)
            for r, i in enumerate(net):
                h, c = off[i], comps[i]
                M[r, [j for j in c if j == h or not act[j]]] = True    # companions in use stay
                FO[r, h] = True
            P = infill(np.repeat(g[None], len(net), 0), M, SWEEP_ON_K, FO)
            for r, i in enumerate(net):
                fills[i] = (off[i], comps[i], P[r])
        G, A = _Marginals.get()
        for i, (h, c) in enumerate(zip(off, comps)):
            if fills[i] is None:
                rows = np.flatnonzero(A[:, h])
                fills[i] = (h, c, np.asarray([BR.coherent_on(g, h, G[d]) for d in rng.choice(
                    rows, min(SWEEP_ON_K, rows.size), replace=False)], np.float32))
        for h, c, fl in fills:
            if not len(fl):                  # no donor in which the part sounds: nothing to try
                continue
            for e in fl:
                add(e, c)
            for st in LADDER_IDX.get(h, ()):                 # the part at its ladder's settings
                e = fl[0].copy()
                for j, v in st.items():
                    e[j] = v
                add(e, c)
            # a part with a discrete choice comes on at EVERY choice (the first fill's values):
            # operator C at each plateau into each oscillator, osc B at each plateau
            if h == C_AMT:
                for q in range(len(PR.C_RATIOS)):
                    for tg in (0.25, 0.75):
                        e = fl[0].copy()
                        e[C_RATIO], e[C_TGT] = PR.C_CENTRES[q], tg
                        add(e, c)
            elif h == D_AMT:                                 # operator D at every plateau, each route
                for q in range(len(PR.C_RATIOS)):
                    for tg in PR.D_ROUTES:
                        e = fl[0].copy()
                        e[D_RATIO], e[D_TGT] = PR.C_CENTRES[q], tg
                        add(e, c)
            elif h in (_I["fm_amt"], _I["osc_mix"]) and not act[RATIO]:
                for q in range(16):
                    e = fl[0].copy()
                    e[RATIO] = (q + 0.5) / 16.0
                    add(e, c)
    if b_used:                                                        # every plateau in use
        p = int(PR.plateau(g[RATIO]))
        for q in range(16):
            if q != p:
                e = g.copy()
                e[RATIO] = (q + 0.5) / 16.0
                add(e, _module_of(RATIO))
    if act[C_AMT]:
        p = int(PR.c_plateau(g[C_RATIO]))
        for q in range(len(PR.C_RATIOS)):
            if q != p:
                e = g.copy()
                e[C_RATIO] = PR.C_CENTRES[q]
                add(e, _module_of(C_RATIO))
        e = g.copy()
        e[C_TGT] = 0.75 if g[C_TGT] < 0.5 else 0.25
        add(e, _module_of(C_RATIO))
    if act[D_AMT]:                                                    # operator D likewise
        p = int(PR.c_plateau(g[D_RATIO]))
        for q in range(len(PR.C_RATIOS)):
            if q != p:
                e = g.copy()
                e[D_RATIO] = PR.C_CENTRES[q]
                add(e, _module_of(D_RATIO))
        for tg in PR.D_ROUTES:
            if int(PR.d_route(tg)) != int(PR.d_route(g[D_TGT])):
                e = g.copy()
                e[D_TGT] = tg
                add(e, _module_of(D_RATIO))
    for j, used in ((WAVES[0], True), (WAVES[1], b_used)):           # every pure leg, every mode
        if used:
            for leg in PR.LEGS:
                if abs(float(g[j]) - leg) > 1e-6:
                    e = g.copy()
                    e[j] = leg
                    add(e, _module_of(j))
    if act[MODE] or act[_I["flt_cut"]]:
        for mode in MODES_PURE:
            if abs(float(g[MODE]) - mode) > 1e-6:
                e = g.copy()
                e[MODE] = mode
                add(e, _module_of(MODE))
    if not E:
        return np.zeros((0, N_GENES), np.float32), []
    E = PR.canonical(np.asarray(E, np.float32))
    keep, seen = [], {g.tobytes()}
    for i, e in enumerate(E):                                         # no-ops and duplicates out
        if e.tobytes() not in seen:
            seen.add(e.tobytes())
            keep.append(i)
    return E[keep], [F[i] for i in keep]


def _refit_children(g, focus, n, rng, amount=SWEEP_AMOUNT):
    """n children of g for a re-fit: two thirds move only the genes `focus` (the breed laws), a
    third every active gene at half the step; the active set is kept"""
    g = PR.canonical(np.asarray(g, np.float32))
    act = PR.active_mask(g[None])[0]
    idx = np.asarray([j for j in focus if act[j] and j not in NEVER and j not in (C_TGT, D_TGT)],
                     np.int64)
    n_f = int(np.ceil(2 * n / 3)) if idx.size else 0
    parts = []
    if n_f:
        K = PR.canonical(BR._moves(g.astype(np.float64), idx, n_f, amount, rng).astype(np.float32))
        K[(PR.active_mask(K) != act[None]).any(axis=1)] = g
        parts.append(K)
    if n - n_f > 0:
        parts.append(BR.mutate(g, rng, n - n_f, amount=amount / 2, structure=False))
    return np.vstack(parts)


def sweep(ev, g, rng, infill=None, race=SWEEP_RACE):
    """the structural sweep of genome g -> [(score, genome)] of its re-fitted edits, best first
    (not compared with g yet). Every edit renders once; then successive halving over the edits
    (race: (edits kept, children each) per round), each edit keeping its best child."""
    E, F = sweep_edits(g, rng, infill)
    if not len(E):
        return []
    s = ev(E)
    cand = sorted(([float(v), e.copy(), f] for v, e, f in zip(s, E, F) if np.isfinite(v)),
                  key=lambda c: c[0])
    for n_keep, n_kids in race:
        cand = cand[:n_keep]
        if not cand or ev.remaining() < n_kids * len(cand):
            break
        kids = [_refit_children(c[1], c[2], n_kids, rng) for c in cand]
        sk = ev(np.vstack(kids))
        a = 0
        for c, K in zip(cand, kids):
            part = sk[a:a + len(K)]
            a += len(K)
            j = int(np.argmin(part))
            if part[j] < c[0]:
                c[0], c[1] = float(part[j]), PR.canonical(K[j])
        cand.sort(key=lambda c: c[0])
    return [(c[0], c[1]) for c in cand]


def neural_jump(ev, g, rng, infill, k=4):
    """a restart point near g: NEURAL_MASK of its genes redrawn by the network given the target and
    the rest (the structure may change where the audio says so) -> (score, genome)"""
    m = rng.random(N_GENES) < NEURAL_MASK
    m[list(NEVER)] = False
    if not m.any():
        m[int(rng.integers(N_GENES))] = True
    P = infill(np.asarray(g, np.float32)[None], m[None], k, None)[0]
    s = ev(P)
    j = int(np.argmin(s))
    return float(s[j]), P[j].copy()


# ============================================================================= islands

class _Island:
    """one island: a GA ("ga", and "hybrid" until polish()), or CMA-ES scaled per gene by a
    sensitivity probe ("cma", and "hybrid" after polish()); structure children every generation
    except for "cma"."""

    def __init__(self, ev, g, s, rng, method):
        self.ev, self.rng, self.method = ev, rng, method
        self.best, self.best_s = PR.canonical(np.asarray(g, np.float32)), float(s)
        self.restarts_without_gain = 0
        self.stall = 0                     # generations since the island's best last improved
        self.steps = 0
        self.struct_wins = 0
        self.elites = [(self.best_s, self.best.copy())]
        self.sigma = 0.1                   # the GA's step size (gene units), adapted
        self.cma = None
        self.mode = "cma" if method == "cma" else "ga"
        self._probe = None
        if self.mode == "cma":
            self._start_probe()

    def polish(self):
        """hybrid: switch from the GA to per-gene-scaled CMA-ES on the island's best"""
        if self.mode != "cma":
            self.mode = "cma"
            self._start_probe()

    def adopt(self, g, s):
        """take over a better genome (a swept structure): the GA's elites restart from it, a
        polishing island probes it afresh"""
        self.best, self.best_s = PR.canonical(np.asarray(g, np.float32)), float(s)
        self.elites = [(self.best_s, self.best.copy())]
        self.stall = 0
        self.restarts_without_gain = 0
        self.struct_wins += 1
        if self.mode == "cma":
            self._start_probe()

    # ---- CMA, scaled per gene: a probe of +-PROBE_DELTA on every active continuous gene
    def _start_probe(self):
        self.base = self.best.copy()
        self.idx = active_continuous(self.base)
        self.cma_start = self.best_s
        self.cma = None
        if self.idx.size == 0:
            self._probe = None
            return
        lo, hi = _bounds(self.idx)
        P = np.tile(self.base, (2 * len(self.idx), 1))
        for k, j in enumerate(self.idx):
            P[2 * k, j] = min(hi[k], self.base[j] + PROBE_DELTA)
            P[2 * k + 1, j] = max(lo[k], self.base[j] - PROBE_DELTA)
        self._probe = P

    def _cma_from_probe(self, sp):
        """per-gene steps from the probe: a step that moves the fitness by PROBE_TARGET of the
        island's score, clipped to [0.002, 0.08] gene units"""
        lo, hi = _bounds(self.idx)
        sp = np.where(np.isfinite(sp), sp, self.best_s + 10.0)
        sens = np.maximum(np.abs(sp[0::2] - self.best_s), np.abs(sp[1::2] - self.best_s)) / PROBE_DELTA
        sig = np.clip(PROBE_TARGET * max(self.best_s, 0.05) / np.maximum(sens, 1e-6), 0.002, 0.08)
        s0 = float(np.exp(np.mean(np.log(sig))))
        self.cma = CMA(self.base[self.idx], s0, lo, hi, self.rng, diag=False)
        self.cma.D = sig / s0
        self.cma.C = np.diag(self.cma.D ** 2)
        self.cma.invsqrtC = np.diag(1.0 / self.cma.D)
        self._probe = None

    def _embed(self, X):
        G = np.tile(self.base, (len(X), 1))
        G[:, self.idx] = X
        return G

    # ---- one generation: ask / tell
    def ask(self, others):
        self.steps += 1
        parts = []
        self._X = None
        self._probing = False
        if self.mode == "ga":
            parts.append(self._ga_children(others))
        elif self._probe is not None:
            parts.append(self._probe)
            self._probing = True
        elif self.cma is not None:
            self._X = self.cma.ask()
            parts.append(self._embed(self._X))
        n_struct = 0 if self.method == "cma" else N_STRUCT
        if self.mode == "cma" and self.cma is None and self._probe is None:
            n_struct = max(n_struct, 8)          # nothing continuous to move: only structure moves
        self._n_struct = n_struct
        if n_struct:
            parts.append(structure_children(self.best, self.rng, n_struct, others))
        self._G = np.vstack(parts).astype(np.float32)
        return self._G

    def tell(self, s):
        s = np.asarray(s, float)
        G = self._G
        if self._probing:
            self._cma_from_probe(s[:len(G) - self._n_struct])
        elif self._X is not None:
            self.cma.tell(self._X, s[:len(self._X)])
        improved = False
        j = int(np.argmin(s))
        if s[j] < self.best_s - 1e-9:
            cand = PR.canonical(G[j])
            s_conf = float(s[j])
            if PR.active_mask(cand[None])[0][NOISE]:          # a lucky noise draw?
                s_conf = float(self.ev.rescore(cand[None])[0])
            if s_conf < self.best_s - 1e-9:
                is_struct = j >= len(G) - self._n_struct
                self.best, self.best_s = cand.copy(), s_conf
                improved = True
                if is_struct:
                    self.struct_wins += 1
                    if self.mode == "cma":             # CMA restarts on the new active set
                        self._start_probe()
        self.stall = 0 if improved else self.stall + 1
        if self.mode == "ga":
            self._ga_tell(G, s)
        elif self._probe is None and (self.cma is None or self.cma.converged()):
            if self.best_s < self.cma_start - 1e-6:
                self.restarts_without_gain = 0
            else:
                self.restarts_without_gain += 1
            self._start_probe()
        return improved

    def stuck(self):
        if self.mode == "ga":
            return self.stall >= ISLAND_STALL * CMA_STALL
        return self.restarts_without_gain >= ISLAND_STALL

    # ---- the GA's own children and selection
    def _ga_children(self, others, lam=12):
        out = []
        el = self.elites
        n_local = lam * 2 // 3
        for _ in range(n_local):
            a, b = self.rng.integers(len(el), size=2)
            parent = el[min(a, b)][1]                          # a tournament of two
            out.append(BR.mutate(parent, self.rng, 1, amount=self.sigma, structure=False)[0])
        self._n_local = n_local
        for _ in range(lam - n_local):
            if len(el) > 1 and self.rng.random() < 0.7:
                a, b = self.rng.choice(len(el), 2, replace=False)
                pa, pb = el[a][1], el[b][1]
            elif len(others):
                pa, pb = self.best, others[int(self.rng.integers(len(others)))]
            else:
                pa, pb = self.best, self.best
            c = BR.crossover(pa, pb, self.rng, 1)[0]
            if self.rng.random() < 0.5:
                c = BR.mutate(c, self.rng, 1, amount=0.5 * self.sigma, structure=False)[0]
            out.append(c)
        self._parent_best = el[0][0]
        return np.asarray(out, np.float32)

    def _ga_tell(self, G, s, mu=6):
        """(mu + lambda) selection over unique genomes; the step size follows the local children's
        success rate (a 1/5th rule)"""
        rate = float((s[:self._n_local] < self._parent_best).mean())
        self.sigma = float(np.clip(self.sigma * (1.25 if rate > 0.2 else 0.85), 0.005, 0.25))
        pool = {e[1].tobytes(): e for e in self.elites}
        for g, v in zip(G, s):
            if np.isfinite(v):
                pool.setdefault(g.tobytes(), (float(v), g.copy()))
        self.elites = sorted(pool.values(), key=lambda e: e[0])[:mu]


# ============================================================================= refine

def _halving(ev, pool, rng, budget_h, n_keep):
    """successive halving over the seed pool: each survivor gets a few local mutants per round
    (its best kept), the worse half is dropped; returns the survivors [(s, g)] best first and the
    dropped ones (the restart queue)"""
    S = [list(x) for x in pool]
    dropped = []
    if len(S) <= n_keep or budget_h < len(S):
        return S, dropped
    rounds = max(1, int(np.ceil(np.log2(len(S) / n_keep))))
    per_round = budget_h / rounds
    for r in range(rounds):
        m = int(per_round // max(len(S), 1))
        if m < 1 or ev.remaining() < len(S):
            break
        kids, owner = [], []
        for i, (s, g) in enumerate(S):
            n_struct = m // 4
            K = BR.mutate(g, rng, m - n_struct, amount=0.06, structure=False)
            if n_struct:
                K = np.vstack([K, BR.mutate(g, rng, n_struct, amount=0.1, structure=True)])
            kids.append(K)
            owner += [i] * len(K)
        K = np.vstack(kids)
        sk = ev(K)
        owner = np.asarray(owner)
        for i in range(len(S)):
            mine = np.flatnonzero(owner == i)
            j = mine[int(np.argmin(sk[mine]))]
            if sk[j] < S[i][0]:
                S[i] = [float(sk[j]), K[j].copy()]
        S.sort(key=lambda x: x[0])
        keep = max(n_keep, len(S) // 2)
        dropped = S[keep:] + dropped
        S = S[:keep]
        if len(S) <= n_keep:
            break
    return S, dropped


def _distinct(cands, n):
    """up to n candidates [(s, g)] best first, no two in one basin"""
    out = []
    for s, g in cands:
        if all(not same_basin(g, h) for _, h in out):
            out.append((s, g))
        if len(out) == n:
            break
    return out


def refine(target_audio, midi, seeds, budget=5000, sr=44100.0, gate_s=1.0, secs=None, rng=None,
           fitness=None, method="hybrid", n_islands=N_ISLANDS, seed_scores=None, threads=4,
           level="fixed", device=None, evaluator=None, halving=True, verbose=False,
           max_seconds=None, noise_seeds=NOISE_SEEDS, infill=None, sweeps=True):
    """Refine seed genomes against one target note -> dict(best, alternatives, scores, history, ...).

    target_audio  the target (float, mono, sr); candidates render at its length unless secs is set
    midi, gate_s  the note the candidates play (the target's own; fractional midi allowed)
    seeds         float32[K, 40] starting genomes (the model's proposals or the best prior draws)
    budget        renders this call may spend (seeds without seed_scores are rendered from it)
    fitness       a fitness.Target (or anything with .score(audio[K, n])); None builds one from
                  target_audio: level "fixed" = fitness.Target(audio), "free" = free_gain=True
    method        "hybrid" (default), "ga" or "cma" (see the module docstring)
    evaluator     an Evaluator to share (its cache and render count; match() passes its own)
    infill        None, or the network's conditional proposal: infill(G [R, N], masks bool [R, N],
                  k, force_on bool [R, N] or None) -> float32 [R, k, N] canonical (the masked genes
                  drawn given the target and the rest; match() builds it from model.infill). It
                  fills the parts the structural sweep switches on and makes the neural restarts
    sweeps        the structural sweeps at SWEEP_AT (method "ga" / "hybrid"; none when the islands'
                  budget is under SWEEP_MIN, one at half-way under twice it)
    Returns best float32[40], alternatives float32[4, 40] (best first, distinct, each at least
    MIN_AUDIBLE from the others when the archive allows), scores float32[4] (noise-averaged where
    noise is on), history [(renders, best score)] from this call's start, renders, seconds, stats."""
    t_start = time.perf_counter()
    rng = rng if rng is not None else np.random.default_rng()
    x = np.asarray(target_audio, np.float32).ravel()
    n = int(round(secs * sr)) if secs is not None else x.size
    own_ev = evaluator is None
    if own_ev:
        T = fitness if fitness is not None else FT.Target(x, sr, device=device,
                                                         free_gain=(level == "free"))
        ev = Evaluator(T, midi, gate_s, n, sr, threads=threads)
    else:
        ev = evaluator
    r0 = ev.renders
    ev.budget = r0 + int(budget)
    final_reserve = int(max(8 * n_islands, FINAL_FRAC * budget))
    seeds = PR.canonical(np.atleast_2d(np.asarray(seeds, np.float32)))
    if seed_scores is not None:
        ev.prime(seeds, seed_scores)
    s_seed = ev(seeds)
    order = np.argsort(s_seed, kind="stable")
    pool = [(float(s_seed[i]), seeds[i].copy()) for i in order if np.isfinite(s_seed[i])]
    pool = _distinct(pool, max(HALVING_SEEDS, n_islands))
    stats = dict(method=method, n_seeds=len(seeds), seed_best=pool[0][0] if pool else np.inf,
                 seed_best_genome=pool[0][1].copy() if pool else None)
    queue = []
    if halving and len(pool) > n_islands:
        room = max(0, ev.remaining() - final_reserve)
        S, dropped = _halving(ev, pool, rng, HALVING_FRAC * room, n_islands)
        pool, queue = S, dropped
    stats["after_halving"] = ev.best_score
    stats["renders_seeding"] = ev.renders - r0
    starts = _distinct(pool, n_islands)
    used = {g.tobytes() for _, g in starts}
    queue = sorted([q for q in pool + queue if q[1].tobytes() not in used], key=lambda q: q[0])
    while len(starts) < n_islands:                    # too few distinct seeds: mutants of the best
        base = starts[0][1] if starts else NEUTRAL
        g = BR.mutate(base, rng, 1, amount=0.3, structure=True)[0]
        starts.append((float(ev(g[None])[0]), g))
    islands = [_Island(ev, g, s, rng, method) for s, g in starts]
    rnd, restarts = 0, 0
    r_isl = ev.renders
    polish_at = r_isl + HYBRID_POLISH * max(ev.remaining() - final_reserve, 0)
    isl_budget = max(ev.remaining() - final_reserve, 0)
    shares = () if not sweeps or method == "cma" or isl_budget < SWEEP_MIN else \
        (0.5,) if isl_budget < 2 * SWEEP_MIN else SWEEP_AT
    sweep_at = [r_isl + f * isl_budget for f in shares]
    n_sweeps = sweep_wins = sweep_admits = 0
    polishing = False
    while ev.remaining() > final_reserve + ROUND_MAX:
        if max_seconds is not None and time.perf_counter() - t_start > max_seconds:
            break
        if method == "hybrid" and not polishing and ev.renders >= polish_at:
            polishing = True
            for isl in islands:
                isl.polish()
        if sweep_at and ev.renders >= sweep_at[0]:
            # the structural sweep of the best island's genome: a better edit is adopted; a new
            # structure within SWEEP_ADMIT of the worst island replaces it (protected, it already
            # had its re-fit), the next ones go to the front of the restart queue
            sweep_at.pop(0)
            b = int(np.argmin([isl.best_s for isl in islands]))
            res = sweep(ev, islands[b].best, rng, infill)
            n_sweeps += 1
            # a noisy winner may be a lucky noise draw (every edit rendered once): the first
            # few are re-scored over more noise seeds, as an island's own best is, before use
            if res:
                top = [g_ for _, g_ in res[:3]]
                s_top = ev.rescore(np.asarray(top, np.float32), noise_seeds)
                res = sorted([(float(s_), g_) for s_, g_ in zip(s_top, top)] + res[3:],
                             key=lambda r_: r_[0])
            if res and res[0][0] < islands[b].best_s - 1e-9:
                islands[b].adopt(res[0][1], res[0][0])
                sweep_wins += 1
                res = res[1:]
            fresh = [r_ for r_ in res if not any(same_basin(r_[1], isl.best) for isl in islands)]
            if fresh:
                w = int(np.argmax([isl.best_s for isl in islands]))
                if w != b and fresh[0][0] < SWEEP_ADMIT * islands[w].best_s:
                    islands[w] = _Island(ev, fresh[0][1], fresh[0][0], rng, method)
                    if polishing:
                        islands[w].polish()
                    sweep_admits += 1
                    fresh = fresh[1:]
                queue = sorted([list(q) for q in fresh[:3]] + queue, key=lambda q: q[0])
            if ev.remaining() <= final_reserve + ROUND_MAX:
                break
        rnd += 1
        # the better an island, the more often it steps: rank r steps every (r + 1)-th round
        ranks = np.argsort([isl.best_s for isl in islands], kind="stable")
        stepping = [int(i) for r, i in enumerate(ranks) if rnd % (r + 1) == 0]
        bests = [isl.best for isl in islands]
        asks = [islands[i].ask([b for k, b in enumerate(bests) if k != i]) for i in stepping]
        s_all = ev(np.vstack(asks))
        a = 0
        for i, G in zip(stepping, asks):
            islands[i].tell(s_all[a:a + len(G)])
            a += len(G)
        # niching: an island inside a better island's basin, or stuck far behind, is replaced by
        # the next seed of the queue (or, when it is empty, by a structure jump from its best)
        top = min(j.best_s for j in islands)
        for i, isl in enumerate(islands):
            dup = any(k != i and islands[k].best_s <= isl.best_s
                      and same_basin(isl.best, islands[k].best) for k in range(len(islands)))
            far = isl.stuck() and isl.best_s > 1.2 * top + 0.3
            if not (dup or far):
                continue
            if queue:
                s0, g0 = queue.pop(0)
            elif dup and infill is not None:        # the network redraws part of the best
                s0, g0 = neural_jump(ev, islands[int(np.argmin([j.best_s for j in islands]))].best,
                                     rng, infill)
            elif dup:
                g0 = switch_on(BR.mutate(isl.best, rng, 1, amount=0.3, structure=True)[0], rng)
                s0 = float(ev(g0[None])[0])
            else:
                continue
            islands[i] = _Island(ev, g0, s0, rng, method)
            if polishing:
                islands[i].polish()
            restarts += 1
        if verbose and rnd % 25 == 0:
            print("    round %4d renders %6d best %.4f islands %s" % (
                rnd, ev.renders - r0, ev.best_score,
                " ".join("%.3f" % isl.best_s for isl in islands)), flush=True)
    stats.update(rounds=rnd, island_restarts=restarts,
                 struct_wins=int(sum(isl.struct_wins for isl in islands)),
                 island_scores=[float(isl.best_s) for isl in islands],
                 sweeps=n_sweeps, sweep_wins=sweep_wins, sweep_admits=sweep_admits)
    # ---- the alternatives: the archive (every genome rendered, the island bests among them) by
    # score, thinned to a shortlist no two of which share a basin, noise re-scored, then chosen
    # apart in SOUND
    arch = sorted(ev.cache.items(), key=lambda kv: kv[1])[:ARCHIVE_TOP]
    cands = [np.frombuffer(k, np.float32).copy() for k, _ in arch]
    F = _shortlist(np.asarray(cands, np.float32), SHORTLIST)
    sF = ev.rescore(F, noise_seeds) if noise_seeds else ev(F)
    alts, alt_s = _choose_alternatives(ev, F, sF, n_islands)
    ev.history.append((ev.renders, float(alt_s[0])))
    out = dict(best=alts[0].copy(), alternatives=alts, scores=alt_s,
               history=[(r - r0, s) for r, s in ev.history if r >= r0],
               renders=ev.renders - r0, seconds=time.perf_counter() - t_start,
               render_seconds=ev.t_render, score_seconds=ev.t_score, stats=stats)
    if own_ev:
        ev.close()
    return out


def _shortlist(C, k, tol=NEAR_ACTIVE):
    """up to k of the candidates C (in their order), no two in one basin (same_basin, vectorised)"""
    A = PR.active_mask(C)
    P = PR.plateau(C[:, RATIO])
    Q = PR.c_plateau(C[:, C_RATIO])
    R = PR.c_plateau(C[:, D_RATIO])
    keep = []
    for i in range(len(C)):
        dup = False
        for j in keep:
            if P[i] == P[j] and Q[i] == Q[j] and R[i] == R[j] and np.array_equal(A[i], A[j]):
                d = np.abs(C[i] - C[j])[A[i]]
                if d.size == 0 or d.max() < tol:
                    dup = True
                    break
        if not dup:
            keep.append(i)
            if len(keep) == k:
                break
    return C[keep]


def _choose_alternatives(ev, F, sF, n):
    """the best first; then, by score, the next candidate at least MIN_AUDIBLE (fitness units,
    each chosen one's render as the reference) from every one chosen; the threshold halves when
    the candidates run out. Renders the candidates once (counted)."""
    order = [int(i) for i in np.argsort(sF, kind="stable") if np.isfinite(sF[i])] or [0]
    order = order[:int(max(n, min(len(order), ev.remaining())))]
    Y = ev.render(F[order])
    ev.renders += len(order)
    pos = {i: p for p, i in enumerate(order)}
    chosen = [order[0]]
    Ts = [FT.Target(Y[0], ev.sr)]
    cand = list(order[1:])
    thr = MIN_AUDIBLE
    while len(chosen) < n and cand and thr > 1e-3:
        for i in cand:
            if min(float(T.score(Y[pos[i]][None])[0]) for T in Ts) >= thr:
                chosen.append(i)
                cand.remove(i)
                Ts.append(FT.Target(Y[pos[i]], ev.sr))
                break
        else:
            thr /= 2
    while len(chosen) < n:                          # nothing left: repeat the last one
        chosen.append(chosen[-1])
    return (np.asarray([F[i] for i in chosen], np.float32),
            np.asarray([sF[i] for i in chosen], np.float32))


def gene_error(a, b):
    """mean |a - b| over the 40 genes of two canonical genomes (b_ratio compared by plateau:
    0 on the same plateau, else the plateau distance / 16)"""
    a = PR.canonical(np.asarray(a, np.float32))
    b = PR.canonical(np.asarray(b, np.float32))
    d = np.abs(a - b).astype(np.float64)
    d[..., RATIO] = np.abs(PR.plateau(a[..., RATIO]) - PR.plateau(b[..., RATIO])) / 16.0
    return d.mean(axis=-1)


def structure_jaccard(a, b):
    """|A & B| / |A | B| of two genomes' active sets (1 = the same structure)"""
    A = PR.active_mask(np.atleast_2d(a))
    B = PR.active_mask(np.atleast_2d(b))
    inter = (A & B).sum(axis=1)
    union = np.maximum((A | B).sum(axis=1), 1)
    return inter / union


GENE_NAMES = tuple(g.name for g in GENES)
