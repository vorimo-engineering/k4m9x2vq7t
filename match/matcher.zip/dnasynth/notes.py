"""WHICH NOTES SOUND: a recording may be one key or several held together -- a chord (a sample
pack's chord stabs, an organ, a pad played as a triad). GROW plays its patch on the keys that were
played, so it must know them (2026-10-06: a DX7 pack's synth-organ3c is C3 E-flat3 G3 B-flat3;
read as one note it is G#1 at 35 % confidence, and nothing grown on one key comes near it).

    from dnasynth import notes as NO
    ns = NO.estimate_notes(x)                 # [{"midi": 48.10, "salience": 1.0, "harmonics": 8}, ...]
    y = NO.isolate(x, [n["midi"] for n in ns], ns[0]["midi"])     # one of them alone (an STFT mask)

ESTIMATE_NOTES. The held part's spectrum -- from the onset + HOLD_T0, a Hann window of up to HOLD_S,
zero-padded to 2^16 -- gives its peaks (local maxima within PEAK_DB of the top, 30 Hz .. 5 kHz,
parabolic in dB). A harmonic SIEVE then takes one note at a time: every peak over k = 1..4 is a
candidate f0; its salience is the summed level over the floor (PEAK_DB under the top) of the peaks
at its harmonics h = 1..MAX_H within TOL_CENTS, weighted 1/sqrt(h). The best candidate is a note when
it holds its fundamental or three of its first four harmonics, and MIN_HARM harmonics in all; its
partials then leave the list and the sieve runs again, until the best is under REL_STOP of the first
note's salience. A candidate an octave (or two) under a note already found, explaining only that
note's partials, is not a note (the sieve's classic error). So one note reads as ONE note: a second
note must be a harmonic series of its own, which a saw's harmonics (taken with their fundamental) or
a bell's inharmonic partials (no series) are not.

ISOLATE. One note of a chord alone, for GROW's ANALYSIS (every note of a chord played on one patch
is that patch; the fitness still hears the whole chord): an STFT mask that keeps the bins around the
note's harmonics (a raised cosine, WIDTH_CENTS wide or two and a half bins, whichever is wider),
shares a bin another note's harmonic also covers by the notes there, drops the rest, and adds the
frames back (Hann, hop n/8).

numpy only (it runs in the browser too: pchkraft-synth web/match/pack.py packs it)."""
from __future__ import annotations

import numpy as np

SR = 44100.0
HOLD_T0 = 0.06          # the held part starts this long after the onset ...
HOLD_S = 0.75           # ... and is read over at most this long
N_FFT = 1 << 16
PEAK_DB = 45.0          # peaks within this of the loudest; the floor of the salience
F_LO, F_HI = 30.0, 5000.0
TOL_CENTS = 25.0
MAX_H = 16
MIN_HARM = 4            # a note has at least this many of its harmonics among the peaks ...
REL_STOP = 0.3          # ... and a salience at least this share of the first note's
MAX_NOTES = 6
MIN_SEP_CENTS = 90.0    # two notes closer than this are one (a detuned unison is one note)
PROM_DB = 10.0          # a peak stands this far over the median level of its sixth-octave
OWN_CENTS = 50.0        # a later note's harmonic is its OWN when no found note's harmonic is this near ...
MIN_OWN = 2             # ... and it needs its fundamental and this many own harmonics in its first 8 (a fifth above a
                        # found note owns only its 1st, 3rd and 7th; the 7th is often too weak to count)
EXPLAIN = 0.75          # a chord's notes explain at least this share of the peaks' power ...
HARM_SHARE = 0.5        # ... and this share of ALL the held part's power (30 Hz .. 5 kHz): a cymbal's
                        # prominent peaks line up by chance, its power is the noise between them
MIN_HARM_MORE = 5       # a further note needs this many harmonics
NO_FUND = 0.5           # a candidate WITHOUT its fundamental counts this share of its salience: a virtual
                        # bass under a chord gathers several notes' partials at once (E-flat2 for E-flat3 +
                        # B-flat3, its 2nd and 3rd harmonics) -- it wins only when nothing real explains as much
STACK_CENTS = (500.0, 700.0, 1200.0, 1900.0, 2400.0)   # two notes this far apart (+-30) read as one note
                        # with a stacked oscillator: a power chord and a fifth oscillator sound the same,
                        # and one key keeps the patch playable


def _onset(x, sr):
    n = 128
    k = len(x) // n
    if k < 2:
        return 0
    e = 10 * np.log10(np.mean(x[:k * n].reshape(k, n).astype(np.float64) ** 2, axis=1) + 1e-20)
    return int(np.argmax(e >= e.max() - 50.0)) * n


def peaks(x, sr=SR, gate_s=None):
    """the held part's spectral peaks -> (freqs Hz, levels dB re the loudest), loudest first"""
    x = np.asarray(x, np.float64).ravel()
    a = _onset(x, sr) + int(HOLD_T0 * sr)
    stop = len(x) if gate_s is None else max(a + 2048, int(float(gate_s) * sr))
    seg = x[a:min(stop, a + int(HOLD_S * sr))]
    if seg.size < 2048:
        seg = x[:min(len(x), int(HOLD_S * sr))]
    N = max(N_FFT, 1 << int(np.ceil(np.log2(max(seg.size, 2)))))
    S = np.abs(np.fft.rfft(seg * np.hanning(seg.size), N))
    L = 20 * np.log10(S / (S.max() + 1e-30) + 1e-12)
    df = sr / N
    i = np.flatnonzero((L[1:-1] > L[:-2]) & (L[1:-1] >= L[2:]) & (L[1:-1] > -PEAK_DB)) + 1
    i = i[(i * df >= F_LO) & (i * df <= F_HI)]
    # PROMINENCE: a peak of noise is a local maximum too; a partial stands over its neighbourhood
    fb = i * df
    lo = np.searchsorted(np.arange(L.size) * df, fb * 2 ** (-1 / 6))
    hi = np.searchsorted(np.arange(L.size) * df, fb * 2 ** (1 / 6))
    floor = np.array([np.median(L[a:b]) if b > a else -200.0 for a, b in zip(lo, hi)])
    i = i[L[i] - floor >= PROM_DB]
    y0, y1, y2 = L[i - 1], L[i], L[i + 1]
    den = y0 - 2 * y1 + y2
    d = np.where(np.abs(den) > 1e-12, 0.5 * (y0 - y2) / np.where(np.abs(den) > 1e-12, den, 1.0), 0.0)
    f = (i + d) * df
    lv = y1 - 0.25 * (y0 - y2) * d
    o = np.argsort(-lv)
    band = (np.arange(S.size) * df >= F_LO) & (np.arange(S.size) * df <= F_HI)
    peaks.last = dict(power=10 ** (L[band] / 10), freqs=np.arange(S.size)[band] * df)
    return f[o], lv[o]


def _salience(f0, pf, pl):
    """(salience, harmonics found, has the fundamental, matched peak indices) of f0 in the peak list.
    EVERY peak near a harmonic is its (a chorus or a detuned stack makes a cluster of them, and the
    rest of a cluster read as another note), the loudest counts"""
    s, hs, used, pairs = 0.0, [], [], []
    for h in range(1, MAX_H + 1):
        fh = h * f0
        if fh > F_HI:
            break
        c = np.abs(1200 * np.log2(pf / fh))
        near = np.flatnonzero(c <= TOL_CENTS)
        if near.size:
            top = int(near[np.argmax(pl[near])])
            s += (pl[top] + PEAK_DB) / np.sqrt(h)
            hs.append(h)
            used += [int(j) for j in near]
            pairs.append((top, h))
    return s, hs, (1 in hs), used, pairs


def _own(f0, found):
    """the harmonics 1..8 of f0 that no found note's harmonic (up to 32) sits near"""
    out = []
    for h in range(1, 9):
        fh = h * f0
        if not any(abs(1200 * np.log2(fh / (k * n["f0"]))) <= OWN_CENTS for n in found for k in range(1, 33)):
            out.append(h)
    return out


def estimate_notes(x, sr=SR, gate_s=None):
    """the notes sounding together in the held part -> [{"midi", "salience", "harmonics"}], low to
    high (salience: a share of the strongest note's). One note when the sound is one note."""
    pf, pl = peaks(x, sr, gate_s)
    if pf.size == 0:
        return []
    found, first = [], None
    total = float(np.sum(10 ** (pl / 10)))
    PF, PL = pf.copy(), pl.copy()          # every peak: what a candidate's harmonics are counted in
    pf, pl = pf.copy(), pl.copy()          # the peaks no note has taken yet: where candidates come from
    for _ in range(MAX_NOTES):
        if pf.size == 0:
            break
        best = None
        for j in range(min(len(pf), 40)):
            for k in (1, 2, 3, 4):
                f0 = pf[j] / k
                if f0 < F_LO:
                    break
                # counted in EVERY peak: a chord's notes share partials (a fifth above a note owns
                # only a few of its own), and the ones an earlier note took are still this one's
                s, hs, h1, _, pairs = _salience(f0, PF, PL)
                if not (h1 or len([h for h in hs if h <= 4]) >= 3) or len(hs) < (MIN_HARM_MORE if found else MIN_HARM):
                    continue
                used = _salience(f0, pf, pl)[3]
                if found:                    # a further note: a series of its own, fundamental first
                    own = _own(f0, found)
                    if 1 not in own or len([h for h in own if h in hs]) < MIN_OWN:
                        continue
                if not h1:
                    s *= NO_FUND
                if best is None or s > best[0]:
                    best = (s, f0, hs, used, pairs)
        if best is None:
            break
        s, f0, hs, used, pairs = best
        if first is not None and s < REL_STOP * first:
            break
        if not found:
            # THE OCTAVE UNDER: a stack whose fundamental is weak (a sub an octave down) reads as its
            # octave, and the odd harmonics then look like other notes; the octave under wins when it
            # holds its own fundamental and nearly the salience
            for k in (2, 3):
                s2, hs2, h12, used2, pairs2 = _salience(f0 / k, PF, PL)
                if h12 and s2 >= 0.8 * (s if 1 in hs else s / NO_FUND) and len(hs2) >= len(hs):
                    s, f0, hs, used, pairs = s2, f0 / k, hs2, used2, pairs2
                    break
        # refine f0 on the matched harmonics (a weighted mean of f / h, the loudest peak of each)
        w = np.array([PL[j] + PEAK_DB for j, _ in pairs])
        f0 = float(np.sum(w * np.array([PF[j] / h for j, h in pairs])) / max(np.sum(w), 1e-9))
        m = 69.0 + 12.0 * np.log2(f0 / 440.0)
        sub = any(abs((m + 12.0 * o) - n["midi"]) * 100 < MIN_SEP_CENTS for n in found for o in (1, 2))
        near = any(abs(m - n["midi"]) * 100 < MIN_SEP_CENTS for n in found)
        if not sub and not near:
            found.append(dict(midi=m, salience=float(s), harmonics=len(hs), f0=f0,
                              power=float(np.sum(10 ** (pl[used] / 10))) if used else 0.0))
            if first is None:
                first = s
        keep = np.ones(len(pf), bool)
        keep[used] = False
        pf, pl = pf[keep], pl[keep]
    # a CHORD only when its notes explain the sound: noise's chance series, a bell's partials do not
    if len(found) > 1 and sum(n["power"] for n in found) < EXPLAIN * total:
        found = found[:1]
    if len(found) > 1:
        sp = peaks.last
        inside = np.zeros(sp["freqs"].size, bool)
        for n in found:
            for h in range(1, MAX_H * 2 + 1):
                fh = h * n["f0"]
                if fh > F_HI:
                    break
                inside |= np.abs(sp["freqs"] - fh) <= max(fh * (2 ** (TOL_CENTS / 1200) - 1), 3.0)
        if float(sp["power"][inside].sum()) < HARM_SHARE * float(sp["power"].sum()):
            found = found[:1]
    if len(found) == 2:
        gap = abs(found[1]["midi"] - found[0]["midi"]) * 100
        if any(abs(gap - c) <= 30 for c in STACK_CENTS):
            found = found[:1]
    for n in found:
        n["salience"] = n["salience"] / first
        del n["f0"], n["power"]
    return sorted(found, key=lambda n: n["midi"])


def isolate(x, notes, which, sr=SR, n_fft=4096, width_cents=40.0):
    """note `which` (fractional MIDI, one of `notes`) of the chord in x alone -> float32 like x"""
    x = np.asarray(x, np.float64).ravel()
    hop = n_fft // 8
    f = np.fft.rfftfreq(n_fft, 1.0 / sr)
    df = sr / n_fft

    def cover(m):
        """[bins]: how much of each bin note m's harmonics cover (0..1, a raised cosine each)"""
        f0 = 440.0 * 2.0 ** ((m - 69.0) / 12.0)
        c = np.zeros(f.size)
        for h in range(1, int((0.48 * sr) // f0) + 1):
            fh = h * f0
            wid = max(fh * (2.0 ** (width_cents / 1200.0) - 1.0), 2.5 * df)
            d = np.abs(f - fh) / wid
            c = np.maximum(c, np.where(d < 1.0, 0.5 * (1.0 + np.cos(np.pi * d)), 0.0))
        return c
    mine = cover(which)
    others = sum((cover(m) for m in notes if abs(m - which) * 100 >= MIN_SEP_CENTS), np.zeros(f.size))
    mask = mine / (1.0 + others)
    w = np.hanning(n_fft + 1)[:n_fft]
    pad = n_fft // 2
    xp = np.pad(x, (pad, pad + n_fft))
    nfr = 1 + (len(xp) - n_fft) // hop
    y = np.zeros(len(xp))
    norm = np.zeros(len(xp))
    for i in range(nfr):
        a = i * hop
        Y = np.fft.irfft(np.fft.rfft(xp[a:a + n_fft] * w) * mask, n_fft)
        y[a:a + n_fft] += Y * w
        norm[a:a + n_fft] += w * w
    y = y / np.maximum(norm, 1e-9)
    return y[pad:pad + len(x)].astype(np.float32)
