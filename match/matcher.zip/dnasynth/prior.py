"""The matcher's PRIOR: a sampler of musical dnasynth genomes, sparse like real presets.

    import numpy as np
    from dnasynth import prior
    rng = np.random.default_rng(0)
    G = prior.sample(1000, rng)                   # float32[1000, 51], the family mixture
    G = prior.sample(10, rng, family="pluck")     # one family
    A = prior.active_mask(G)                      # bool[n, 51]: where a gene's effect is ON
    C = prior.canonical(G)                        # inactive genes snapped to their exact neutral

WHY SPARSE (docs/matcher/foundation.md): inversion is measured to work at <= ~20 free genes and to
fail at 84-115 (graft, pchsynth). A preset leaves most controls at their defaults, so a draw starts
from the NEUTRAL genome (a plain saw through an open filter, every other section off) and a FAMILY
TEMPLATE decides which genes to switch on and how they are distributed. Plus, with probability
P_EXTRA, one to three genes switched on at random from their whole range, so the support covers
every genome the engine can play.

ACTIVITY is decided per gene law (dnasynth.h / docs/TECHNICAL.md section 3):
  * a bipolar gene is off inside its dead zone, |g - 0.5| <= 0.02 (the engine is bit-exact there);
  * b_ratio is one of 16 plateaus; it is off on the neutral plateau (1:1);
  * a squared-law level or depth is off below 0.005 (0.005^2 = -92 dB);
  * the genes whose first steps are steep have their own, smaller bands (EPS_SPECIAL: 0.002 of
    drive was a -42 dB clipped copy, of rvb_size an 8 dB jump of a tone's reverb, of a_pw even
    harmonics at -50 dB); any other gene is off within 0.002 of its neutral value
    (tests/test_prior.py: snapping a gene inside its band moves the fitness by < 0.3);
and, with `structural=True` (the default), by the patch's structure -- a gene whose section is
silent has no effect, so it is not active either:
  * osc B (b_wave, b_ratio, b_detune, menv_bpitch) acts only when osc_mix or fm_amt is on or
    menv_fm pushes the FM index up; b_pw / a_pw only when that oscillator's shape has a pulse leg;
  * a negative menv_fm acts only against a static fm_amt (the index is floored at 0);
  * noise_col only with noise; the reverb's size/decay/damp only with rvb_mix;
  * the filter is an EXACT BYPASS when flt_cut is at 1, its mode a low-pass (<= 1/3), no key-track,
    no LFO and no negative envelope; then flt_res, flt_vel, a positive flt_env and the LP24/LP12
    choice do nothing;
  * the mod envelope's times act only if a route uses it (flt_env, menv_pitch, menv_bpitch,
    menv_fm); the LFO's rate/delay only if flt_lfo, lfo_pitch or lfo_amp is on;
  * a decay acts only if its sustain is below 1;
  * operator C (version 3: c_ratio, c_dec, c_sus, c_tgt) acts only once c_amt is on, and when routed
    to osc B only while B is heard; osc B's feedback (b_fb) only while B is heard;
  * operator D (version 4: d_ratio, d_dec, d_sus, d_tgt) acts only once d_amt is on, and when routed
    to osc B only while B is heard, to operator C only while C is heard.
`canonical` also removes two EXACT symmetries of the engine: the pulse widths (g and 1-g play the
same width, dnasynth.c pw_of) fold onto [0, 0.5], and b_ratio lands on its plateau's centre (c_tgt,
d_ratio and d_tgt on their own).
Every rule is checked by rendering in tests/test_prior.py (a canonical genome sounds the same).

VELOCITY: amp_vel and flt_vel are never drawn. One note at one velocity cannot observe them
(flt_vel trades exactly with flt_cut; amp_vel is inaudible at velocity 1), and a sound-to-patch
matcher sees one note. `canonical(..., vel=1.0)` also snaps amp_vel when the velocity is known.

KEY-TRACK: flt_key and env_key ARE drawn (per family, from how presets use them). One note cannot
tell them from flt_cut and the envelope times (at one key they only rescale those), but they are
what carries a patch to other keys, so the prior's distribution is the matcher's best guess.
"""
from __future__ import annotations

import os
from contextlib import contextmanager

import numpy as np

from .core import GENES, GENE_INDEX, N_GENES, neutral

# experiment switch: DN_NO_OPD=1 keeps operator D off everywhere (canonical zeroes its amount, and
# every genome the search renders is canonical first) -- the version-4 code with version 3's reach,
# the control of results.md section 23
NO_OPD = os.environ.get("DN_NO_OPD") == "1"
# experiment switch: DN_FREEZE="sub_lvl,env_key" keeps those genes at their neutral values everywhere
# (canonical snaps them, as DN_NO_OPD does d_amt): the section study's leave-one-out -- a section
# held off while the search is free to make up for it (results.md section 26)
FREEZE = tuple(g for g in os.environ.get("DN_FREEZE", "").split(",") if g)


@contextmanager
def frozen(genes):
    """hold `genes` at their neutral values in canonical -- and so in everything a search renders --
    for the block, then restore FREEZE (the matcher's lean search: match.FROZEN)"""
    global FREEZE
    saved = FREEZE
    FREEZE = tuple(dict.fromkeys(tuple(FREEZE) + tuple(genes)))
    try:
        yield
    finally:
        FREEZE = saved


@contextmanager
def unfrozen():
    """FREEZE cleared for the block: a bank of prior genomes a search draws donors from is the
    PRIOR's, whatever that search holds off -- built inside a frozen match and cached, it had kept
    the frozen parts off for every later search in the process (ga._Marginals, breed._POOL)"""
    global FREEZE
    saved = FREEZE
    FREEZE = ()
    try:
        yield
    finally:
        FREEZE = saved

NEUTRAL = neutral()
IDX = GENE_INDEX
LEGS = (0.0, 1.0 / 3.0, 2.0 / 3.0, 1.0)            # sine, triangle, saw, pulse
DZ = 0.02                                           # a bipolar gene's dead zone, gene units
SQUARED = ("osc_mix", "fm_amt", "sub_lvl", "noise_lvl", "flt_lfo", "lfo_delay", "lfo_pitch",
           "lfo_amp", "c_amt", "b_fb", "d_amt")
EPS_SQUARED = 0.005                                 # a squared level 0.005^2: -92 dB, under the floor
EPS_LINEAR = 0.002
# genes whose first steps are steep (measured: snapping 0.95 eps moved the fitness by 0.1-3.9)
EPS_SPECIAL = {"drive": 1e-4,                       # the drive mix is 4 g: 0.002 was a -42 dB clip
               "rvb_mix": 1e-5,                     # wet ~1.6 g, normalised to the dry (+12 dB tones)
               "rvb_size": 1e-5,                    # a tone's reverb level jumps 8 dB per 0.002 (§10)
               "rvb_decay": 5e-4,
               "flt_mode": 2e-4,                    # a trace of LP12 under LP24 lifts the stop band
               "flt_cut": 5e-4,                     # with key-track or BP / HP the top is not open
               "a_pw": 2e-5, "b_pw": 2e-5,          # 0.2 % off square: even harmonics at -50 dB
               "mod_sus": 1e-4,                     # held mod env x 24 st of pitch: 0.002 = 4.5 c
               "mod_att": 5e-4,
               "fm_amt": 0.002}
B_RATIOS = (0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 11.0)
# operator C's ratio law (dnasynth.c c_ratio_of): log2(ratio) = -1 + 5 g, plateaus on these
C_RATIOS = (0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0,
            15.0, 16.0)
NEVER_DRAWN = ("amp_vel", "flt_vel")                # unobservable from one note at one velocity
P_EXTRA = 0.15                                      # a draw also gets 1..3 random extra genes


def _eps():
    e = np.full(N_GENES, EPS_LINEAR, np.float32)
    for g in GENES:
        if g.bipolar:
            e[g.index] = DZ
        elif g.name in SQUARED:
            e[g.index] = EPS_SQUARED
        if g.name in EPS_SPECIAL:
            e[g.index] = EPS_SPECIAL[g.name]
    return e


EPS = _eps()
BIPOLAR = np.array([g.bipolar for g in GENES])
_I = IDX


def ratio_value(r):
    """the gene value at the centre of the plateau playing ratio r (one of B_RATIOS)"""
    return (B_RATIOS.index(r) + 0.5) / 16.0


def plateau(g):
    """b_ratio gene -> plateau index 0..15 (the engine's (int)(g * 16), clamped)"""
    return np.minimum((np.clip(np.asarray(g, np.float64), 0, 1) * 16.0).astype(np.int64), 15)


def c_ratio_value(r):
    """the c_ratio gene value that plays ratio r exactly (the middle of its plateau, for a listed r)"""
    return (np.log2(float(r)) + 1.0) / 5.0


# operator C's plateaus in log2(ratio) (dnasynth.c c_ratio_of: 30 % of the gap to each neighbour;
# the ratio is continuous across a plateau's edge, so an edge case read either way plays the same)
_CL = np.log2(np.asarray(C_RATIOS, np.float64))
_C_LO = np.concatenate([[-np.inf], _CL[1:] - 0.3 * np.diff(_CL)])
_C_HI = np.concatenate([_CL[:-1] + 0.3 * np.diff(_CL), [np.inf]])
C_CENTRES = (_CL + 1.0) / 5.0                       # the gene value at each plateau's ratio
C_ONE = C_RATIOS.index(1.0)                         # the neutral plateau (ratio 1:1, gene 0.2)


D_ROUTES = (1.0 / 6.0, 0.5, 5.0 / 6.0)              # d_tgt's three routes' centres: osc A, B, op C


def d_route(g):
    """d_tgt gene -> its route: 0 osc A, 1 osc B, 2 operator C (dnasynth.c: thirds)"""
    return np.minimum((np.clip(np.asarray(g, np.float64), 0, 1) * 3.0).astype(np.int64), 2)


def c_plateau(g):
    """c_ratio gene -> the index into C_RATIOS of the plateau it plays, or -1 between plateaus
    (an inharmonic ratio on the smooth slope)"""
    x = -1.0 + 5.0 * np.clip(np.asarray(g, np.float64), 0.0, 1.0)
    i = np.clip(np.searchsorted(_CL, x), 0, len(_CL) - 1)          # the listed ratio at / above x
    out = np.full(np.shape(x), -1, np.int64)
    for k in (i - 1, i):                                            # x is on one of these or none
        k = np.clip(k, 0, len(_CL) - 1)
        on = (x >= _C_LO[k] - 1e-9) & (x <= _C_HI[k] + 1e-9)
        out = np.where((out < 0) & on, k, out)
    return out


# ============================================================================= activity

def law_active(genes):
    """bool[n, N_GENES]: a gene differs from its neutral value beyond its dead zone / plateau / eps."""
    G = np.atleast_2d(np.asarray(genes, np.float32))
    A = np.abs(G - NEUTRAL[None]) > EPS[None]
    j = _I["b_ratio"]
    A[:, j] = plateau(G[:, j]) != plateau(NEUTRAL[j])
    j = _I["c_tgt"]                                   # two plateaus: osc A (neutral) or osc B
    A[:, j] = (G[:, j] >= 0.5) != (NEUTRAL[j] >= 0.5)
    j = _I["d_tgt"]                                   # three: osc A (neutral), osc B, operator C
    A[:, j] = d_route(G[:, j]) != d_route(NEUTRAL[j])
    return A


def active_mask(genes, structural=True, vel=None):
    """bool[n, N_GENES]: True where a gene's effect is ON. Per gene law (law_active) and, with
    structural=True, only where its section sounds (see the module docstring). `vel`: the render
    velocity if known (at vel 1, amp_vel does nothing)."""
    G = np.atleast_2d(np.asarray(genes, np.float32))
    A = law_active(G)
    if not structural:
        return A
    c = lambda name: G[:, _I[name]]                                        # noqa: E731
    a = lambda name: A[:, _I[name]]                                        # noqa: E731
    fm_on = a("fm_amt")
    menv_fm_pos = a("menv_fm") & (c("menv_fm") > 0.5)
    menv_fm_eff = a("menv_fm") & (menv_fm_pos | fm_on)
    b_used = a("osc_mix") | fm_on | menv_fm_pos
    A[:, _I["menv_fm"]] = menv_fm_eff
    for name in ("b_wave", "b_ratio", "b_detune", "menv_bpitch"):
        A[:, _I[name]] &= b_used
    A[:, _I["b_pw"]] &= b_used & (c("b_wave") > 2.0 / 3.0 + EPS_LINEAR)
    A[:, _I["a_pw"]] &= c("a_wave") > 2.0 / 3.0 + EPS_LINEAR
    A[:, _I["noise_col"]] &= a("noise_lvl")
    # the filter's exact bypass: flt_cut 1, a low-pass mode, nothing that can pull the cutoff down
    open_ = (~a("flt_cut")) & (c("flt_mode") <= 1.0 / 3.0 + 1e-6) & (~a("flt_key")) \
        & (~a("flt_lfo")) & ~(a("flt_env") & (c("flt_env") < 0.5))
    for name in ("flt_res", "flt_vel", "flt_env", "flt_mode"):
        A[:, _I[name]] &= ~open_
    # the mod envelope: its times matter only through a route
    routes = a("flt_env") | a("menv_pitch") | a("menv_bpitch") | a("menv_fm")
    for name in ("mod_att", "mod_dec", "mod_sus", "mod_rel"):
        A[:, _I[name]] &= routes
    A[:, _I["mod_dec"]] &= c("mod_sus") < 1.0 - 1e-6          # a decay to full sustain is none
    A[:, _I["amp_dec"]] &= a("amp_sus")                         # (amp_sus is neutral AT 1)
    lfo = a("flt_lfo") | a("lfo_pitch") | a("lfo_amp")
    for name in ("lfo_rate", "lfo_delay"):
        A[:, _I[name]] &= lfo
    for name in ("rvb_size", "rvb_decay", "rvb_damp"):
        A[:, _I[name]] &= a("rvb_mix")
    # version 3: operator C sounds once it has an index -- into osc A always, into osc B only when B
    # is heard; its ratio, envelope and route only then. osc B's feedback only when B is heard.
    c_heard = a("c_amt") & ((c("c_tgt") < 0.5) | b_used)
    A[:, _I["c_amt"]] = c_heard
    for name in ("c_ratio", "c_dec", "c_sus", "c_tgt"):
        A[:, _I[name]] &= c_heard
    A[:, _I["b_fb"]] &= b_used
    # version 4: operator D likewise -- into osc A always, into osc B while B is heard, into
    # operator C while C is heard
    route = d_route(c("d_tgt"))
    d_heard = a("d_amt") & ((route == 0) | ((route == 1) & b_used) | ((route == 2) & c_heard))
    A[:, _I["d_amt"]] = d_heard
    for name in ("d_ratio", "d_dec", "d_sus", "d_tgt"):
        A[:, _I[name]] &= d_heard
    # version 5: the formant's centre and Q only while it has a gain; the chorus's rate and depth
    # only while it is mixed in
    for name in ("fmt_freq", "fmt_q"):
        A[:, _I[name]] &= a("fmt_gain")
    for name in ("cho_rate", "cho_depth"):
        A[:, _I[name]] &= a("cho_mix")
    if vel is not None and float(vel) == 1.0:
        A[:, _I["amp_vel"]] = False
    return A


def canonical(genes, structural=True, vel=None):
    """genes with every inactive gene snapped to its exact neutral value, the pulse widths folded
    onto [0, 0.5] (g and 1 - g play the same width), b_ratio on its plateau's centre, c_ratio and
    d_ratio on their plateau's centre when they sit on one (between plateaus they are left: an
    inharmonic ratio), c_tgt on 0.25 / 0.75 and d_tgt on its route's centre (1/6, 1/2, 5/6). Same
    shape and dtype family as the input (float32). The sound does not change (tests/test_prior)."""
    G0 = np.asarray(genes, np.float32)
    G = np.atleast_2d(np.clip(G0, 0.0, 1.0)).copy()
    G[~np.isfinite(G)] = np.broadcast_to(NEUTRAL, G.shape)[~np.isfinite(G)]
    for name in ("a_pw", "b_pw"):
        j = _I[name]
        G[:, j] = np.minimum(G[:, j], 1.0 - G[:, j])
    j = _I["b_ratio"]
    G[:, j] = (plateau(G[:, j]) + 0.5) / 16.0
    j = _I["c_ratio"]
    p = c_plateau(G[:, j])
    G[:, j] = np.where(p >= 0, C_CENTRES[np.maximum(p, 0)], G[:, j])
    j = _I["c_tgt"]
    G[:, j] = np.where(G[:, j] < 0.5, 0.25, 0.75)
    if NO_OPD:
        G[:, _I["d_amt"]] = 0.0
    for name in FREEZE:
        G[:, _I[name]] = NEUTRAL[_I[name]]
    j = _I["d_ratio"]
    p = c_plateau(G[:, j])
    G[:, j] = np.where(p >= 0, C_CENTRES[np.maximum(p, 0)], G[:, j])
    j = _I["d_tgt"]
    G[:, j] = np.asarray(D_ROUTES, np.float32)[d_route(G[:, j])]
    A = active_mask(G, structural=structural, vel=vel)
    G = np.where(A, G, NEUTRAL[None]).astype(np.float32)
    return G[0] if G0.ndim == 1 else G


def n_active(genes, **kw):
    return active_mask(genes, **kw).sum(axis=1)


# ============================================================================= the families
# A template maps a gene to (probability it is switched on, how its value is drawn). Genes a
# template does not name stay at their neutral value. Values are in gene units; the laws are in
# docs/TECHNICAL.md section 3 (cutoff 20 Hz * 1000^g, times 1 ms * 10000^g, ...). The four Odin2
# patches of rsynth/eval/synthoct.py sit INSIDE these ranges but are not templates of their own:
# tests/test_prior.py checks the coverage by rendering, not by copying.

def U(lo, hi):
    return ("u", lo, hi)


def C(values, probs=None):
    return ("c", tuple(values), probs)


def LEG(p_sine, p_tri, p_saw, p_pulse, p_cont=0.15):
    """an oscillator shape: one of the pure legs (worth landing on), or anywhere with p_cont"""
    return ("leg", (p_sine, p_tri, p_saw, p_pulse), p_cont)


def BIP(lo, hi, p_pos=0.5):
    """a bipolar gene: |g - 0.5| uniform in [lo, hi] (outside the dead zone), positive w.p. p_pos"""
    return ("bip", lo, hi, p_pos)


def RATIO(weights):
    """b_ratio: a plateau, by ratio -> weight"""
    return ("ratio", tuple(weights.items()))


def CRATIO(weights, p_cont=0.0):
    """c_ratio: one of C_RATIOS exactly (by ratio -> weight), or with p_cont anywhere in the law
    (the inharmonic ratios between its plateaus: bells, metal)"""
    return ("cratio", tuple(weights.items()), p_cont)


# useful anchors (gene units): cutoff 100 Hz .233, 400 .434, 1 k .566, 3 k .725, 8 k .867;
# times 5 ms .175, 50 ms .425, 300 ms .619, 1 s .75, 3 s .869; flt_env +1 oct .716, +3 oct .859

FAMILY_SPECS = {
    # subtractive bass: saw/pulse, optional sub and a second osc an octave around, a low LP with
    # its envelope, a short-to-medium amp shape
    "bass": {
        "a_wave": (1.0, LEG(0.05, 0.1, 0.6, 0.25, 0.1)), "a_pw": (0.6, U(0.05, 0.45)),
        "osc_mix": (0.35, U(0.35, 1.0)),
        "b_ratio": (1.0, RATIO({0.5: 0.35, 1.0: 0.35, 2.0: 0.2, 1.5: 0.05, 3.0: 0.05})),
        "b_wave": (0.6, LEG(0.1, 0.1, 0.5, 0.3)), "b_pw": (0.5, U(0.05, 0.45)),
        "b_detune": (0.5, BIP(0.05, 0.2)),
        "sub_lvl": (0.35, U(0.25, 0.6)),
        "noise_lvl": (0.06, U(0.1, 0.35)), "noise_col": (0.5, U(0.0, 1.0)),
        "flt_cut": (1.0, U(0.28, 0.6)), "flt_res": (0.55, U(0.1, 0.65)),
        "flt_mode": (0.3, C((1.0 / 3.0, 0.15, 0.25))), "flt_key": (0.3, U(0.2, 1.0)),
        "flt_env": (0.75, BIP(0.12, 0.42, 0.95)),
        "mod_att": (0.15, U(0.05, 0.4)), "mod_dec": (1.0, U(0.35, 0.7)),
        "mod_sus": (0.4, U(0.05, 0.5)), "mod_rel": (0.3, U(0.2, 0.6)),
        "menv_pitch": (0.05, BIP(0.1, 0.3, 0.8)),
        "drive": (0.25, U(0.1, 0.6)),
        "amp_att": (0.4, U(0.05, 0.3)), "amp_dec": (1.0, U(0.45, 0.8)),
        "amp_sus": (0.75, U(0.3, 0.95)), "amp_rel": (0.7, U(0.15, 0.55)),
        "env_key": (0.1, BIP(0.05, 0.3, 0.8)),
        "rvb_mix": (0.08, U(0.05, 0.25)),
        # version 3: osc B's feedback (a DX bass's bite), sometimes a third operator
        "b_fb": (0.2, U(0.3, 1.0)), "c_amt": (0.12, U(0.2, 0.6)),
        "c_ratio": (1.0, CRATIO({1.0: 0.4, 2.0: 0.3, 0.5: 0.2, 3.0: 0.1})),
        "c_dec": (1.0, U(0.2, 0.6)), "c_sus": (0.3, U(0.1, 0.6)), "c_tgt": (0.3, C((0.75,))),
        # version 4: now and then a second operator (a DX bass's click beside its body)
        "d_amt": (0.06, U(0.15, 0.6)),
        "d_ratio": (1.0, CRATIO({1.0: 0.25, 2.0: 0.2, 3.0: 0.15, 5.0: 0.1, 9.0: 0.1, 14.0: 0.1,
                                 0.5: 0.1})),
        "d_dec": (1.0, U(0.05, 0.5)), "d_sus": (0.2, U(0.05, 0.4)),
        "d_tgt": (0.4, C((0.5, 5.0 / 6.0))),
        # version 5: now and then a body resonance, rarely an ensemble
        "fmt_gain": (0.05, BIP(0.1, 0.35, 0.6)), "fmt_freq": (1.0, U(0.2, 0.6)),
        "fmt_q": (0.5, U(0.3, 0.8)),
        "cho_mix": (0.05, U(0.15, 0.5)), "cho_rate": (1.0, U(0.2, 0.7)),
        "cho_depth": (1.0, U(0.3, 0.9)),
    },
    # subtractive lead: brighter, key-tracked more often, vibrato, some glide-free detune
    "lead": {
        "a_wave": (1.0, LEG(0.08, 0.1, 0.55, 0.27)), "a_pw": (0.6, U(0.05, 0.45)),
        "osc_mix": (0.5, U(0.4, 1.0)),
        "b_ratio": (1.0, RATIO({1.0: 0.5, 2.0: 0.25, 0.5: 0.15, 1.5: 0.05, 3.0: 0.05})),
        "b_wave": (0.5, LEG(0.1, 0.15, 0.45, 0.3)), "b_pw": (0.5, U(0.05, 0.45)),
        "b_detune": (0.7, BIP(0.05, 0.22)),
        "fm_amt": (0.08, U(0.2, 0.6)),
        "sub_lvl": (0.15, U(0.2, 0.5)),
        "noise_lvl": (0.05, U(0.1, 0.3)), "noise_col": (0.5, U(0.0, 1.0)),
        "flt_cut": (0.9, U(0.45, 0.85)), "flt_res": (0.45, U(0.05, 0.5)),
        "flt_mode": (0.3, C((1.0 / 3.0, 0.15, 0.25))), "flt_key": (0.6, U(0.3, 1.0)),
        "flt_env": (0.45, BIP(0.08, 0.35, 0.9)), "flt_lfo": (0.1, U(0.2, 0.5)),
        "mod_att": (0.2, U(0.05, 0.5)), "mod_dec": (1.0, U(0.35, 0.75)),
        "mod_sus": (0.4, U(0.1, 0.6)), "mod_rel": (0.3, U(0.2, 0.6)),
        "menv_pitch": (0.05, BIP(0.05, 0.2, 0.3)),
        "lfo_pitch": (0.3, U(0.15, 0.45)), "lfo_rate": (1.0, U(0.55, 0.8)),
        "lfo_delay": (0.5, U(0.2, 0.6)), "lfo_amp": (0.05, U(0.2, 0.5)),
        "drive": (0.3, U(0.1, 0.7)),
        "amp_att": (0.5, U(0.05, 0.45)), "amp_dec": (1.0, U(0.5, 0.85)),
        "amp_sus": (0.6, U(0.5, 0.95)), "amp_rel": (0.7, U(0.15, 0.65)),
        "rvb_mix": (0.25, U(0.1, 0.35)), "rvb_size": (0.5, U(0.2, 0.8)),
        "rvb_decay": (0.5, U(0.2, 0.7)), "rvb_damp": (0.4, U(0.2, 0.8)),
        "b_fb": (0.15, U(0.2, 0.9)), "c_amt": (0.08, U(0.15, 0.5)),
        "c_ratio": (1.0, CRATIO({1.0: 0.3, 2.0: 0.3, 3.0: 0.2, 4.0: 0.2})),
        "c_dec": (1.0, U(0.3, 0.7)), "c_sus": (0.4, U(0.2, 0.8)), "c_tgt": (0.3, C((0.75,))),
        # version 5: a horn's or a voice's formant, a chorused lead
        "fmt_gain": (0.15, BIP(0.12, 0.42, 0.7)), "fmt_freq": (1.0, U(0.3, 0.8)),
        "fmt_q": (0.6, U(0.3, 0.8)),
        "cho_mix": (0.15, U(0.2, 0.7)), "cho_rate": (1.0, U(0.2, 0.75)),
        "cho_depth": (1.0, U(0.3, 0.9)),
    },
    # pluck: a filter envelope that falls fast, no sustain to speak of
    "pluck": {
        "a_wave": (1.0, LEG(0.05, 0.15, 0.55, 0.25)), "a_pw": (0.6, U(0.05, 0.45)),
        "osc_mix": (0.3, U(0.3, 0.9)),
        "b_ratio": (1.0, RATIO({1.0: 0.35, 2.0: 0.35, 0.5: 0.1, 3.0: 0.1, 4.0: 0.05, 1.5: 0.05})),
        "b_wave": (0.5, LEG(0.15, 0.15, 0.4, 0.3)), "b_pw": (0.5, U(0.05, 0.45)),
        "b_detune": (0.4, BIP(0.05, 0.18)),
        "sub_lvl": (0.1, U(0.2, 0.5)),
        "noise_lvl": (0.1, U(0.15, 0.45)), "noise_col": (0.6, U(0.3, 1.0)),
        "flt_cut": (1.0, U(0.28, 0.65)), "flt_res": (0.45, U(0.05, 0.55)),
        "flt_mode": (0.2, C((1.0 / 3.0, 0.15))), "flt_key": (0.35, U(0.2, 1.0)),
        "flt_env": (1.0, BIP(0.2, 0.46, 1.0)),
        "mod_att": (0.1, U(0.02, 0.2)), "mod_dec": (1.0, U(0.4, 0.72)),
        "mod_sus": (0.2, U(0.02, 0.25)), "mod_rel": (0.4, U(0.3, 0.7)),
        "amp_att": (0.4, U(0.02, 0.25)), "amp_dec": (1.0, U(0.55, 0.85)),
        "amp_sus": (1.0, U(0.0, 0.45)), "amp_rel": (0.8, U(0.15, 0.7)),
        "env_key": (0.25, BIP(0.05, 0.35, 0.9)),
        "drive": (0.1, U(0.1, 0.5)),
        "rvb_mix": (0.3, U(0.1, 0.4)), "rvb_size": (0.5, U(0.2, 0.8)),
        "rvb_decay": (0.5, U(0.2, 0.7)), "rvb_damp": (0.4, U(0.2, 0.8)),
        # a harpsichord's or a koto's bright edge: a third operator that dies fast
        "c_amt": (0.2, U(0.2, 0.65)),
        "c_ratio": (1.0, CRATIO({2.0: 0.15, 3.0: 0.2, 4.0: 0.15, 5.0: 0.15, 6.0: 0.1, 7.0: 0.1,
                                 8.0: 0.1, 1.0: 0.05}, 0.15)),
        "c_dec": (1.0, U(0.1, 0.45)), "c_sus": (0.1, U(0.05, 0.3)), "c_tgt": (0.2, C((0.75,))),
        "b_fb": (0.1, U(0.2, 0.8)),
        "d_amt": (0.08, U(0.15, 0.6)),
        "d_ratio": (1.0, CRATIO({3.0: 0.2, 4.0: 0.15, 5.0: 0.15, 6.0: 0.15, 7.0: 0.15, 8.0: 0.1,
                                 2.0: 0.1}, 0.15)),
        "d_dec": (1.0, U(0.05, 0.4)), "d_sus": (0.1, U(0.05, 0.3)),
        "d_tgt": (0.3, C((0.5, 5.0 / 6.0))),
    },
    # pad: slow attack and release, a detuned second oscillator, slow modulation, often a room
    "pad": {
        "a_wave": (1.0, LEG(0.1, 0.15, 0.5, 0.25, 0.2)), "a_pw": (0.6, U(0.1, 0.45)),
        "osc_mix": (0.75, U(0.5, 1.0)),
        "b_ratio": (1.0, RATIO({1.0: 0.55, 2.0: 0.2, 0.5: 0.15, 1.5: 0.05, 3.0: 0.05})),
        "b_wave": (0.5, LEG(0.1, 0.2, 0.4, 0.3)), "b_pw": (0.5, U(0.1, 0.45)),
        "b_detune": (0.85, BIP(0.08, 0.26)),
        "fm_amt": (0.05, U(0.1, 0.4)),
        "sub_lvl": (0.15, U(0.2, 0.5)),
        "noise_lvl": (0.2, U(0.1, 0.35)), "noise_col": (0.6, U(0.0, 1.0)),
        "flt_cut": (0.85, U(0.42, 0.85)), "flt_res": (0.3, U(0.05, 0.4)),
        "flt_mode": (0.2, C((1.0 / 3.0, 0.15, 0.5))), "flt_key": (0.45, U(0.2, 1.0)),
        "flt_env": (0.4, BIP(0.05, 0.3, 0.8)), "flt_lfo": (0.3, U(0.2, 0.55)),
        "mod_att": (0.6, U(0.4, 0.85)), "mod_dec": (1.0, U(0.5, 0.9)),
        "mod_sus": (0.5, U(0.2, 0.8)), "mod_rel": (0.5, U(0.5, 0.85)),
        "amp_att": (1.0, U(0.45, 0.85)), "amp_dec": (1.0, U(0.55, 0.9)),
        "amp_sus": (0.5, U(0.5, 0.95)), "amp_rel": (0.85, U(0.2, 0.88)),
        "lfo_rate": (1.0, U(0.25, 0.65)), "lfo_delay": (0.3, U(0.2, 0.7)),
        "lfo_pitch": (0.15, U(0.1, 0.35)), "lfo_amp": (0.15, U(0.2, 0.55)),
        "rvb_mix": (0.6, U(0.15, 0.5)), "rvb_size": (0.6, U(0.4, 1.0)),
        "rvb_decay": (0.7, U(0.4, 0.9)), "rvb_damp": (0.5, U(0.2, 0.8)),
        "c_amt": (0.05, U(0.1, 0.4)),
        "c_ratio": (1.0, CRATIO({1.0: 0.4, 2.0: 0.3, 3.0: 0.3})),
        "c_dec": (1.0, U(0.5, 0.9)), "c_sus": (0.5, U(0.3, 0.9)), "b_fb": (0.05, U(0.1, 0.5)),
        # version 5: the ensemble a string machine or a choir pad carries; a vowel-like formant
        "cho_mix": (0.35, U(0.2, 0.8)), "cho_rate": (1.0, U(0.15, 0.7)),
        "cho_depth": (1.0, U(0.3, 0.9)),
        "fmt_gain": (0.1, BIP(0.12, 0.4, 0.6)), "fmt_freq": (1.0, U(0.25, 0.75)),
        "fmt_q": (0.5, U(0.3, 0.8)),
    },
    # FM: sine-ish carrier and modulator at a musical ratio, an index that decays (bells, keys,
    # FM basses); a hook below makes sure some FM is on
    "fm": {
        "a_wave": (1.0, LEG(0.75, 0.1, 0.1, 0.05, 0.1)),
        "b_wave": (1.0, LEG(0.8, 0.1, 0.1, 0.0, 0.05)),
        "b_ratio": (1.0, RATIO({1.0: 0.22, 2.0: 0.15, 3.0: 0.1, 4.0: 0.07, 5.0: 0.05, 7.0: 0.05,
                                0.5: 0.05, 1.5: 0.05, 3.5: 0.07, 2.5: 0.04, 6.0: 0.03, 8.0: 0.03,
                                9.0: 0.02, 11.0: 0.04, 0.75: 0.03})),
        "fm_amt": (0.75, U(0.2, 0.8)), "menv_fm": (0.75, BIP(0.12, 0.45, 0.95)),
        "menv_bpitch": (0.05, BIP(0.1, 0.3)), "b_detune": (0.25, BIP(0.04, 0.15)),
        "osc_mix": (0.2, U(0.3, 0.8)),
        "mod_att": (0.1, U(0.02, 0.3)), "mod_dec": (1.0, U(0.35, 0.8)),
        "mod_sus": (0.35, U(0.05, 0.5)), "mod_rel": (0.4, U(0.3, 0.7)),
        "amp_att": (0.3, U(0.02, 0.3)), "amp_dec": (1.0, U(0.55, 0.9)),
        "amp_sus": (0.8, U(0.0, 0.7)), "amp_rel": (0.8, U(0.3, 0.8)),
        "env_key": (0.3, BIP(0.05, 0.35, 0.9)),
        "flt_cut": (0.25, U(0.55, 0.9)), "flt_res": (0.2, U(0.05, 0.35)),
        "flt_key": (0.3, U(0.3, 1.0)),
        "lfo_pitch": (0.1, U(0.1, 0.3)), "lfo_amp": (0.1, U(0.2, 0.45)),
        "lfo_rate": (1.0, U(0.5, 0.8)),
        "rvb_mix": (0.35, U(0.1, 0.45)), "rvb_size": (0.5, U(0.2, 0.9)),
        "rvb_decay": (0.5, U(0.3, 0.8)), "rvb_damp": (0.4, U(0.2, 0.8)),
        # the DX7's third operator (a tine at 14, a bell's inharmonic partner) and feedback
        "c_amt": (0.45, U(0.2, 0.8)),
        "c_ratio": (1.0, CRATIO({1.0: 0.15, 2.0: 0.1, 3.0: 0.1, 4.0: 0.08, 5.0: 0.07, 7.0: 0.07,
                                 14.0: 0.12, 0.5: 0.04, 1.5: 0.04, 6.0: 0.05, 8.0: 0.05,
                                 11.0: 0.04, 16.0: 0.04}, 0.2)),
        "c_dec": (1.0, U(0.15, 0.7)), "c_sus": (0.35, U(0.05, 0.6)), "c_tgt": (0.35, C((0.75,))),
        "b_fb": (0.25, U(0.2, 1.0)),
        # version 4: a fourth operator -- a second modulator beside C (two pairs, a tine over a
        # body) or on C (a three-operator stack)
        "d_amt": (0.25, U(0.15, 0.7)),
        "d_ratio": (1.0, CRATIO({14.0: 0.15, 1.0: 0.12, 2.0: 0.1, 3.0: 0.1, 4.0: 0.08, 5.0: 0.07,
                                 7.0: 0.07, 0.5: 0.05, 9.0: 0.05, 11.0: 0.04, 13.0: 0.04,
                                 15.0: 0.04, 16.0: 0.04, 6.0: 0.05}, 0.2)),
        "d_dec": (1.0, U(0.1, 0.65)), "d_sus": (0.3, U(0.05, 0.6)),
        "d_tgt": (0.35, C((0.5, 5.0 / 6.0))),
    },
    # noise / percussion: noise and short envelopes, a pitch drop, band- or high-pass filters,
    # sometimes a metallic FM pair
    "perc": {
        "noise_lvl": (0.9, U(0.45, 1.0)), "noise_col": (0.8, U(0.0, 1.0)),
        "a_wave": (1.0, LEG(0.6, 0.2, 0.15, 0.05, 0.1)),
        "menv_pitch": (0.5, BIP(0.25, 0.48, 0.95)),
        "fm_amt": (0.15, U(0.3, 0.9)),
        "b_ratio": (1.0, RATIO({1.5: 0.1, 2.5: 0.1, 3.5: 0.15, 5.0: 0.15, 7.0: 0.15, 9.0: 0.1,
                                11.0: 0.15, 3.0: 0.1})),
        "b_wave": (0.5, LEG(0.7, 0.1, 0.1, 0.1)), "menv_fm": (0.15, BIP(0.1, 0.4, 0.9)),
        "osc_mix": (0.1, U(0.3, 0.8)),
        "sub_lvl": (0.15, U(0.2, 0.55)),
        "flt_cut": (0.6, U(0.4, 0.9)), "flt_res": (0.35, U(0.1, 0.55)),
        "flt_mode": (0.5, C((2.0 / 3.0, 1.0, 1.0 / 3.0), (0.45, 0.45, 0.1))),
        "flt_env": (0.4, BIP(0.1, 0.4, 0.7)),
        "mod_att": (0.05, U(0.02, 0.2)), "mod_dec": (1.0, U(0.15, 0.55)),
        "mod_sus": (0.05, U(0.05, 0.3)), "mod_rel": (0.3, U(0.1, 0.5)),
        "amp_att": (0.3, U(0.0, 0.2)), "amp_dec": (1.0, U(0.3, 0.72)),
        "amp_sus": (1.0, C((0.0, 0.05, 0.1, 0.15), (0.6, 0.15, 0.15, 0.1))),
        "amp_rel": (0.8, U(0.15, 0.65)),
        "drive": (0.25, U(0.1, 0.7)),
        "env_key": (0.15, BIP(0.05, 0.35, 0.8)),
        "rvb_mix": (0.25, U(0.1, 0.4)), "rvb_size": (0.5, U(0.1, 0.7)),
        "rvb_decay": (0.5, U(0.1, 0.6)), "rvb_damp": (0.4, U(0.2, 0.8)),
        # metal: a third operator at an inharmonic ratio (cymbals, cowbells, rims)
        "c_amt": (0.3, U(0.3, 1.0)),
        "c_ratio": (1.0, CRATIO({1.5: 0.2, 3.0: 0.2, 5.0: 0.2, 7.0: 0.2, 11.0: 0.2}, 0.7)),
        "c_dec": (1.0, U(0.05, 0.55)), "c_sus": (0.05, U(0.05, 0.3)), "c_tgt": (0.4, C((0.75,))),
        "b_fb": (0.15, U(0.3, 1.0)),
        "d_amt": (0.15, U(0.3, 1.0)),
        "d_ratio": (1.0, CRATIO({1.5: 0.2, 3.0: 0.2, 5.0: 0.2, 7.0: 0.2, 11.0: 0.2}, 0.7)),
        "d_dec": (1.0, U(0.05, 0.5)), "d_sus": (0.05, U(0.05, 0.3)),
        "d_tgt": (0.4, C((0.5, 5.0 / 6.0))),
    },
    # organ-ish / keys: sine-to-triangle drawbars (osc B at an octave or a twelfth, the sub),
    # little filtering, a steady or gently decaying level, a touch of tremolo or FM
    "keys": {
        "a_wave": (1.0, LEG(0.45, 0.25, 0.2, 0.1, 0.15)), "a_pw": (0.5, U(0.1, 0.45)),
        "osc_mix": (0.6, U(0.35, 0.9)),
        "b_ratio": (1.0, RATIO({2.0: 0.4, 3.0: 0.2, 0.5: 0.15, 4.0: 0.1, 1.0: 0.1, 1.5: 0.05})),
        "b_wave": (0.8, LEG(0.7, 0.2, 0.1, 0.0)), "b_detune": (0.2, BIP(0.04, 0.12)),
        "sub_lvl": (0.4, U(0.2, 0.55)),
        "fm_amt": (0.2, U(0.15, 0.5)), "menv_fm": (0.25, BIP(0.1, 0.35, 1.0)),
        "flt_cut": (0.4, U(0.5, 0.9)), "flt_res": (0.15, U(0.05, 0.35)),
        "flt_key": (0.3, U(0.3, 1.0)),
        "mod_dec": (1.0, U(0.4, 0.75)), "mod_sus": (0.3, U(0.1, 0.5)),
        "amp_att": (0.4, U(0.02, 0.25)), "amp_dec": (1.0, U(0.55, 0.85)),
        "amp_sus": (0.4, U(0.4, 0.95)), "amp_rel": (0.7, U(0.2, 0.55)),
        "lfo_amp": (0.15, U(0.2, 0.45)), "lfo_pitch": (0.1, U(0.1, 0.3)),
        "lfo_rate": (1.0, U(0.55, 0.8)),
        "drive": (0.2, U(0.1, 0.5)),
        "rvb_mix": (0.3, U(0.1, 0.35)), "rvb_size": (0.5, U(0.2, 0.8)),
        "rvb_decay": (0.5, U(0.2, 0.7)), "rvb_damp": (0.4, U(0.2, 0.8)),
        # an electric piano's tine: a third operator at 14 (or 5 .. 16) that dies in tens of ms
        "c_amt": (0.35, U(0.2, 0.6)),
        "c_ratio": (1.0, CRATIO({14.0: 0.35, 7.0: 0.1, 5.0: 0.1, 3.0: 0.1, 1.0: 0.1, 2.0: 0.1,
                                 16.0: 0.05}, 0.1)),
        "c_dec": (1.0, U(0.1, 0.5)), "c_sus": (0.1, U(0.05, 0.3)), "c_tgt": (0.15, C((0.75,))),
        "b_fb": (0.1, U(0.1, 0.6)),
        # version 4: the tine on operator D, over a body operator C brightens (the DX7 E.Piano:
        # 1:1 pairs and a 14:1 tine)
        "d_amt": (0.2, U(0.15, 0.55)),
        "d_ratio": (1.0, CRATIO({14.0: 0.4, 13.0: 0.1, 15.0: 0.1, 16.0: 0.1, 7.0: 0.1, 5.0: 0.1,
                                 3.0: 0.1}, 0.05)),
        "d_dec": (1.0, U(0.05, 0.45)), "d_sus": (0.1, U(0.05, 0.3)),
        "d_tgt": (0.15, C((0.5, 5.0 / 6.0))),
        # version 5: an organ's rotary-ish chorus, a body resonance
        "cho_mix": (0.1, U(0.15, 0.6)), "cho_rate": (1.0, U(0.3, 0.8)),
        "cho_depth": (1.0, U(0.3, 0.8)),
        "fmt_gain": (0.1, BIP(0.1, 0.35, 0.5)), "fmt_freq": (1.0, U(0.3, 0.75)),
        "fmt_q": (0.5, U(0.3, 0.8)),
    },
}

FAMILIES = tuple(FAMILY_SPECS)
WEIGHTS = np.array([dict(bass=0.17, lead=0.17, pluck=0.17, pad=0.14, fm=0.13, perc=0.10,
                         keys=0.12)[f] for f in FAMILIES])
WEIGHTS = WEIGHTS / WEIGHTS.sum()

# extras: a random gene anywhere in its range, a few ranges kept away from the extremes that only
# make silence or feedback-like howls (they stay reachable by breeding)
EXTRA_GENES = tuple(g.name for g in GENES if g.name not in NEVER_DRAWN)
EXTRA_RANGE = {"flt_res": (0.0, 0.7), "drive": (0.0, 0.8), "flt_cut": (0.25, 1.0),
               "noise_lvl": (0.0, 0.8), "sub_lvl": (0.0, 0.7), "amp_att": (0.0, 0.9),
               "c_amt": (0.1, 0.9), "d_amt": (0.1, 0.9)}


def _draw(dist, k, rng):
    kind = dist[0]
    if kind == "u":
        return rng.uniform(dist[1], dist[2], k)
    if kind == "c":
        vals = np.asarray(dist[1], np.float64)
        p = None if dist[2] is None else np.asarray(dist[2], np.float64) / np.sum(dist[2])
        return vals[rng.choice(len(vals), k, p=p)]
    if kind == "leg":
        p = np.asarray(dist[1], np.float64)
        v = np.asarray(LEGS)[rng.choice(4, k, p=p / p.sum())]
        cont = rng.random(k) < dist[2]
        v[cont] = rng.uniform(0.0, 1.0, int(cont.sum()))
        return v
    if kind == "bip":
        lo, hi, p_pos = dist[1], dist[2], dist[3]
        mag = rng.uniform(max(lo, DZ + 0.01), hi, k)
        sgn = np.where(rng.random(k) < p_pos, 1.0, -1.0)
        return 0.5 + sgn * mag
    if kind == "ratio":
        rs = [r for r, _ in dist[1]]
        w = np.array([w for _, w in dist[1]], np.float64)
        pick = rng.choice(len(rs), k, p=w / w.sum())
        return np.array([ratio_value(rs[i]) for i in pick])
    if kind == "cratio":
        rs = [r for r, _ in dist[1]]
        w = np.array([w for _, w in dist[1]], np.float64)
        pick = rng.choice(len(rs), k, p=w / w.sum())
        v = np.array([c_ratio_value(rs[i]) for i in pick])
        cont = rng.random(k) < dist[2]
        v[cont] = rng.uniform(0.0, 1.0, int(cont.sum()))
        return v
    raise ValueError(kind)


def _extra_value(name, k, rng):
    g = GENES[_I[name]]
    if name == "b_ratio":
        return (rng.integers(0, 16, k) + 0.5) / 16.0
    if g.bipolar:
        return _draw(BIP(DZ + 0.01, 0.5, 0.5), k, rng)
    lo, hi = EXTRA_RANGE.get(name, (0.0, 1.0))
    return rng.uniform(lo, hi, k)


def _sample_family(fam, n, rng):
    G = np.tile(NEUTRAL, (n, 1)).astype(np.float64)
    for name, (p, dist) in FAMILY_SPECS[fam].items():
        on = rng.random(n) < p
        k = int(on.sum())
        if k:
            G[on, _I[name]] = _draw(dist, k, rng)
    if fam == "fm":                                   # FM must be on: a static or enveloped index
        none = (G[:, _I["fm_amt"]] < EPS_SQUARED) & (np.abs(G[:, _I["menv_fm"]] - 0.5) <= DZ)
        k = int(none.sum())
        if k:
            G[none, _I["fm_amt"]] = rng.uniform(0.2, 0.8, k)
    return G


def _sample_spec(spec, n, rng):
    G = np.tile(NEUTRAL, (n, 1)).astype(np.float64)
    for name, (p, dist) in spec.items():
        on = rng.random(n) < p
        k = int(on.sum())
        if k:
            G[on, _I[name]] = _draw(dist, k, rng)
    return G


# ============================================================================= archetypes
# CORRELATED sub-priors for the regions the base families barely reach (docs/matcher/results.md
# section 17: operator C heard in 18 % of base draws, the pitch envelope in 6 %, both together
# ~0 %, while the DX7 voices and drums need them together; literature.md network section 1: a
# network trained on independent random settings fails on hand-programmed ones). Each template
# couples what a preset couples: an FM tine with its fast decay, a drum's pitch drop with its
# short envelopes, a cymbal's inharmonic ratios with its high-pass noise. Drawn by sample_mix
# (engine "v1y"), never by sample(): the base mixture and its tests stay as they were.
ARCHETYPE_SPECS = {
    # DX-style keys and mallets: E.Piano, Clav, Harpsichord, Marimba, Vibe, Koto -- sine
    # operators, an FM index that decays with the mod envelope, a third operator with its own
    # fast decay (the tine), key-scaled decays, a percussive amp shape
    "dx_keys": {
        "a_wave": (1.0, LEG(0.8, 0.1, 0.05, 0.05, 0.05)),
        "b_wave": (1.0, LEG(0.85, 0.1, 0.05, 0.0, 0.05)),
        "b_ratio": (1.0, RATIO({1.0: 0.25, 2.0: 0.15, 3.0: 0.12, 4.0: 0.1, 5.0: 0.06, 7.0: 0.08,
                                0.5: 0.06, 1.5: 0.05, 3.5: 0.04, 6.0: 0.04, 8.0: 0.03, 11.0: 0.02})),
        "fm_amt": (0.6, U(0.15, 0.7)), "menv_fm": (0.85, BIP(0.12, 0.48, 0.97)),
        "b_detune": (0.2, BIP(0.03, 0.12)), "osc_mix": (0.15, U(0.2, 0.7)),
        "b_fb": (0.3, U(0.15, 0.8)),
        "mod_att": (0.1, U(0.01, 0.15)), "mod_dec": (1.0, U(0.25, 0.7)),
        "mod_sus": (0.4, U(0.02, 0.4)), "mod_rel": (0.4, U(0.2, 0.6)),
        "c_amt": (0.75, U(0.15, 0.85)),
        "c_ratio": (1.0, CRATIO({14.0: 0.2, 1.0: 0.12, 2.0: 0.1, 3.0: 0.1, 4.0: 0.08, 5.0: 0.08,
                                 7.0: 0.08, 11.0: 0.05, 16.0: 0.05, 0.5: 0.04, 1.5: 0.05,
                                 8.0: 0.05}, 0.12)),
        "c_dec": (1.0, U(0.05, 0.55)), "c_sus": (0.3, U(0.03, 0.4)), "c_tgt": (0.4, C((0.75,))),
        "d_amt": (0.45, U(0.15, 0.7)),
        "d_ratio": (1.0, CRATIO({14.0: 0.35, 1.0: 0.1, 2.0: 0.1, 3.0: 0.1, 5.0: 0.08, 7.0: 0.08,
                                 13.0: 0.05, 15.0: 0.05, 16.0: 0.05, 4.0: 0.04}, 0.05)),
        "d_dec": (1.0, U(0.03, 0.45)), "d_sus": (0.2, U(0.03, 0.4)),
        "d_tgt": (0.35, C((0.5, 5.0 / 6.0))),
        "amp_att": (0.3, U(0.0, 0.12)), "amp_dec": (1.0, U(0.45, 0.85)),
        "amp_sus": (0.6, U(0.0, 0.5)), "amp_rel": (0.9, U(0.25, 0.7)),
        "env_key": (0.45, BIP(0.05, 0.35, 0.9)),
        "menv_pitch": (0.12, BIP(0.03, 0.2, 0.7)),
        "lfo_amp": (0.12, U(0.15, 0.45)), "lfo_pitch": (0.08, U(0.05, 0.25)),
        "lfo_rate": (1.0, U(0.5, 0.8)),
        "flt_cut": (0.2, U(0.55, 0.9)), "flt_key": (0.2, U(0.3, 1.0)),
        "drive": (0.1, U(0.05, 0.4)),
        "rvb_mix": (0.3, U(0.05, 0.35)), "rvb_size": (0.5, U(0.2, 0.8)),
        "rvb_decay": (0.5, U(0.2, 0.7)),
    },
    # FM bass: a low carrier, a bright decaying index, feedback, a click from a high operator,
    # sometimes a pitch drop at the attack
    "dx_bass": {
        "a_wave": (1.0, LEG(0.6, 0.25, 0.1, 0.05, 0.05)),
        "b_wave": (1.0, LEG(0.8, 0.1, 0.1, 0.0, 0.05)),
        "b_ratio": (1.0, RATIO({0.5: 0.25, 1.0: 0.35, 2.0: 0.2, 3.0: 0.1, 1.5: 0.05, 4.0: 0.05})),
        "fm_amt": (0.8, U(0.3, 0.9)), "menv_fm": (0.8, BIP(0.15, 0.48, 0.97)),
        "b_fb": (0.45, U(0.2, 1.0)), "osc_mix": (0.25, U(0.2, 0.6)),
        "mod_att": (0.05, U(0.01, 0.1)), "mod_dec": (1.0, U(0.2, 0.6)),
        "mod_sus": (0.4, U(0.02, 0.4)), "mod_rel": (0.3, U(0.1, 0.5)),
        "c_amt": (0.5, U(0.15, 0.8)),
        "c_ratio": (1.0, CRATIO({1.0: 0.2, 2.0: 0.15, 3.0: 0.1, 0.5: 0.1, 5.0: 0.08, 7.0: 0.08,
                                 11.0: 0.1, 14.0: 0.1, 16.0: 0.09}, 0.1)),
        "c_dec": (1.0, U(0.03, 0.45)), "c_sus": (0.25, U(0.03, 0.4)), "c_tgt": (0.4, C((0.75,))),
        "d_amt": (0.35, U(0.15, 0.7)),
        "d_ratio": (1.0, CRATIO({1.0: 0.2, 0.5: 0.15, 2.0: 0.15, 3.0: 0.1, 5.0: 0.1, 9.0: 0.1,
                                 14.0: 0.1, 11.0: 0.1}, 0.05)),
        "d_dec": (1.0, U(0.03, 0.45)), "d_sus": (0.25, U(0.03, 0.4)),
        "d_tgt": (0.45, C((0.5, 5.0 / 6.0))),
        "menv_pitch": (0.35, BIP(0.05, 0.3, 0.9)),
        "sub_lvl": (0.2, U(0.2, 0.5)),
        "amp_att": (0.15, U(0.0, 0.08)), "amp_dec": (1.0, U(0.45, 0.95)),
        "amp_sus": (0.7, U(0.0, 0.6)), "amp_rel": (0.8, U(0.15, 0.55)),
        "env_key": (0.2, BIP(0.05, 0.3, 0.8)),
        "lfo_pitch": (0.15, U(0.05, 0.3)), "lfo_rate": (1.0, U(0.5, 0.8)),
        "flt_cut": (0.3, U(0.4, 0.85)), "flt_env": (0.2, BIP(0.1, 0.4, 0.9)),
        "drive": (0.3, U(0.05, 0.6)),
    },
    # bells and struck metal: tubular bells, steel drum, timpani's partials -- inharmonic
    # operator ratios, long decays, some pitch movement
    "dx_bell": {
        "a_wave": (1.0, LEG(0.85, 0.1, 0.05, 0.0, 0.05)),
        "b_wave": (1.0, LEG(0.85, 0.1, 0.05, 0.0, 0.05)),
        "b_ratio": (1.0, RATIO({1.5: 0.1, 2.5: 0.1, 3.5: 0.15, 5.0: 0.1, 7.0: 0.12, 9.0: 0.1,
                                11.0: 0.1, 0.75: 0.08, 3.0: 0.08, 4.0: 0.07})),
        "fm_amt": (0.75, U(0.15, 0.8)), "menv_fm": (0.6, BIP(0.1, 0.45, 0.9)),
        "b_fb": (0.25, U(0.1, 0.7)), "osc_mix": (0.25, U(0.2, 0.7)),
        "b_detune": (0.3, BIP(0.03, 0.2)),
        "mod_att": (0.1, U(0.01, 0.2)), "mod_dec": (1.0, U(0.35, 0.85)),
        "mod_sus": (0.3, U(0.05, 0.5)), "mod_rel": (0.5, U(0.3, 0.8)),
        "c_amt": (0.85, U(0.15, 0.9)),
        "c_ratio": (1.0, CRATIO({1.5: 0.1, 3.0: 0.1, 5.0: 0.1, 7.0: 0.1, 9.0: 0.1, 11.0: 0.1,
                                 13.0: 0.1, 0.5: 0.1, 2.0: 0.1, 4.0: 0.1}, 0.55)),
        "c_dec": (1.0, U(0.25, 0.85)), "c_sus": (0.35, U(0.05, 0.6)), "c_tgt": (0.5, C((0.75,))),
        "d_amt": (0.5, U(0.15, 0.8)),
        "d_ratio": (1.0, CRATIO({1.5: 0.1, 3.0: 0.1, 5.0: 0.1, 7.0: 0.1,
                                 9.0: 0.1, 11.0: 0.1, 13.0: 0.1, 0.5: 0.1, 2.0: 0.1, 4.0: 0.1}, 0.6)),
        "d_dec": (1.0, U(0.2, 0.85)), "d_sus": (0.3, U(0.05, 0.6)),
        "d_tgt": (0.5, C((0.5, 5.0 / 6.0))),
        "amp_att": (0.2, U(0.0, 0.1)), "amp_dec": (1.0, U(0.6, 0.95)),
        "amp_sus": (0.6, U(0.0, 0.4)), "amp_rel": (0.9, U(0.4, 0.85)),
        "env_key": (0.4, BIP(0.05, 0.35, 0.9)),
        "menv_pitch": (0.2, BIP(0.03, 0.25, 0.3)),
        "lfo_amp": (0.1, U(0.1, 0.35)), "lfo_pitch": (0.1, U(0.05, 0.2)),
        "lfo_rate": (1.0, U(0.45, 0.8)),
        "rvb_mix": (0.45, U(0.1, 0.45)), "rvb_size": (0.6, U(0.3, 0.9)),
        "rvb_decay": (0.6, U(0.3, 0.85)), "rvb_damp": (0.4, U(0.2, 0.8)),
    },
    # pitched drums: kick, toms, timpani -- a sine / triangle body falling in pitch fast, short
    # envelopes, a click or skin noise, sometimes a membrane's inharmonic partner
    "drum_tone": {
        "a_wave": (1.0, LEG(0.7, 0.2, 0.05, 0.05, 0.05)),
        "menv_pitch": (0.92, BIP(0.12, 0.48, 0.97)),
        "mod_att": (0.05, U(0.0, 0.1)), "mod_dec": (1.0, U(0.1, 0.5)),
        "mod_sus": (0.1, U(0.0, 0.2)), "mod_rel": (0.3, U(0.05, 0.4)),
        "amp_att": (0.2, U(0.0, 0.06)), "amp_dec": (1.0, U(0.2, 0.7)),
        "amp_sus": (1.0, C((0.0, 0.02, 0.05), (0.8, 0.1, 0.1))), "amp_rel": (0.9, U(0.1, 0.55)),
        "noise_lvl": (0.45, U(0.1, 0.6)), "noise_col": (0.8, U(0.0, 1.0)),
        "c_amt": (0.3, U(0.1, 0.6)),
        "c_ratio": (1.0, CRATIO({1.5: 0.2, 2.0: 0.1, 3.0: 0.15, 5.0: 0.1, 0.5: 0.1, 1.0: 0.15,
                                 7.0: 0.1, 11.0: 0.1}, 0.5)),
        "c_dec": (1.0, U(0.02, 0.45)), "c_sus": (0.05, U(0.02, 0.2)), "c_tgt": (0.2, C((0.75,))),
        "d_amt": (0.15, U(0.1, 0.6)),
        "d_ratio": (1.0, CRATIO({1.5: 0.2, 2.0: 0.1, 3.0: 0.15, 5.0: 0.15, 0.5: 0.1, 7.0: 0.15,
                                 11.0: 0.15}, 0.5)),
        "d_dec": (1.0, U(0.02, 0.4)), "d_sus": (0.05, U(0.02, 0.2)),
        "d_tgt": (0.3, C((0.5, 5.0 / 6.0))),
        "fm_amt": (0.2, U(0.1, 0.6)), "menv_fm": (0.25, BIP(0.1, 0.45, 0.9)),
        "b_ratio": (1.0, RATIO({1.5: 0.25, 2.5: 0.2, 3.5: 0.2, 0.5: 0.1, 2.0: 0.1, 5.0: 0.15})),
        "b_wave": (0.3, LEG(0.9, 0.1, 0.0, 0.0)),
        "sub_lvl": (0.2, U(0.2, 0.6)),
        "flt_cut": (0.35, U(0.3, 0.8)), "flt_res": (0.25, U(0.05, 0.5)),
        "flt_env": (0.3, BIP(0.1, 0.45, 0.9)),
        "drive": (0.35, U(0.05, 0.7)),
        "env_key": (0.15, BIP(0.05, 0.3, 0.8)),
        "rvb_mix": (0.2, U(0.05, 0.3)), "rvb_size": (0.5, U(0.1, 0.6)),
    },
    # noise drums and metal: snares, claps, hats, cymbals -- noise through a band- or high-pass,
    # a tone body with a pitch drop (snare), metallic FM at inharmonic ratios (hats, cymbals)
    "drum_noise": {
        "noise_lvl": (1.0, U(0.45, 1.0)), "noise_col": (0.9, U(0.0, 1.0)),
        "a_wave": (1.0, LEG(0.5, 0.2, 0.1, 0.2, 0.1)),
        "menv_pitch": (0.4, BIP(0.1, 0.45, 0.95)),
        "fm_amt": (0.45, U(0.3, 0.95)), "menv_fm": (0.2, BIP(0.1, 0.4, 0.9)),
        "b_ratio": (1.0, RATIO({1.5: 0.1, 2.5: 0.1, 3.5: 0.15, 5.0: 0.15, 7.0: 0.15, 9.0: 0.15,
                                11.0: 0.2})),
        "b_wave": (0.6, LEG(0.4, 0.1, 0.2, 0.3)), "b_fb": (0.3, U(0.3, 1.0)),
        "osc_mix": (0.3, U(0.2, 0.8)),
        "c_amt": (0.45, U(0.2, 1.0)),
        "c_ratio": (1.0, CRATIO({1.5: 0.2, 3.0: 0.2, 5.0: 0.2, 7.0: 0.2, 11.0: 0.2}, 0.7)),
        "c_dec": (1.0, U(0.03, 0.6)), "c_sus": (0.1, U(0.02, 0.3)), "c_tgt": (0.5, C((0.75,))),
        "d_amt": (0.3, U(0.2, 1.0)),
        "d_ratio": (1.0, CRATIO({1.5: 0.2, 3.0: 0.2, 5.0: 0.2, 7.0: 0.2, 11.0: 0.2}, 0.7)),
        "d_dec": (1.0, U(0.03, 0.6)), "d_sus": (0.1, U(0.02, 0.3)),
        "d_tgt": (0.5, C((0.5, 5.0 / 6.0))),
        "flt_cut": (0.85, U(0.45, 0.95)), "flt_res": (0.4, U(0.05, 0.6)),
        "flt_mode": (0.75, C((2.0 / 3.0, 1.0, 1.0 / 3.0), (0.4, 0.5, 0.1))),
        "flt_env": (0.35, BIP(0.1, 0.45, 0.8)),
        "mod_att": (0.05, U(0.0, 0.1)), "mod_dec": (1.0, U(0.1, 0.55)),
        "mod_sus": (0.05, U(0.0, 0.2)), "mod_rel": (0.3, U(0.05, 0.5)),
        "amp_att": (0.25, U(0.0, 0.1)), "amp_dec": (1.0, U(0.15, 0.85)),
        "amp_sus": (1.0, C((0.0, 0.03, 0.08), (0.75, 0.15, 0.1))), "amp_rel": (0.9, U(0.1, 0.8)),
        "lfo_amp": (0.1, U(0.2, 0.5)), "lfo_rate": (1.0, U(0.6, 0.9)),
        "drive": (0.25, U(0.05, 0.6)),
        "rvb_mix": (0.3, U(0.05, 0.4)), "rvb_size": (0.5, U(0.1, 0.8)),
        "rvb_decay": (0.5, U(0.1, 0.7)),
    },
}
ARCHETYPES = tuple(ARCHETYPE_SPECS)
P_ARCHETYPE = 0.35              # sample_mix: this share of the draws from ARCHETYPES (equal weights)
P_EXTRA_ARCH = 0.45             # ... which get 1..3 extra random genes this often (denser patches)


def sample_mix(n, rng, p_arch=P_ARCHETYPE, return_family=False):
    """the v1y training prior: the base mixture (sample) for 1 - p_arch of the draws, ARCHETYPES
    for p_arch (equal weights, P_EXTRA_ARCH extra genes) -> float32[n, 51] canonical; with
    return_family=True also each row's index into FAMILIES + ARCHETYPES"""
    rng = rng if rng is not None else np.random.default_rng()
    arch = rng.random(n) < p_arch
    G = np.zeros((n, N_GENES), np.float32)
    fam = np.zeros(n, np.int64)
    nb = int((~arch).sum())
    if nb:
        G[~arch], fam[~arch] = sample(nb, rng, return_family=True)
    rows = np.flatnonzero(arch)
    if rows.size:
        which = rng.integers(0, len(ARCHETYPES), rows.size)
        A = np.tile(NEUTRAL, (rows.size, 1)).astype(np.float64)
        for a in np.unique(which):
            sel = np.flatnonzero(which == a)
            A[sel] = _sample_spec(ARCHETYPE_SPECS[ARCHETYPES[a]], sel.size, rng)
        for r in np.flatnonzero(rng.random(rows.size) < P_EXTRA_ARCH):
            k = rng.choice([1, 2, 3], p=[0.5, 0.35, 0.15])
            for name in rng.choice(EXTRA_GENES, k, replace=False):
                A[r, _I[name]] = _extra_value(name, 1, rng)[0]
        G[rows] = canonical(A.astype(np.float32))
        fam[rows] = len(FAMILIES) + which
    return (G, fam) if return_family else G


def sample(n, rng, family=None, return_family=False):
    """n musical genomes, canonical, float32[n, 51]. family: one of FAMILIES, or None for the
    mixture (WEIGHTS). With return_family=True also the family index of every row."""
    rng = rng if rng is not None else np.random.default_rng()
    if family is None:
        fam = rng.choice(len(FAMILIES), n, p=WEIGHTS)
    else:
        if family not in FAMILY_SPECS:
            raise ValueError("unknown family %r (have %s)" % (family, ", ".join(FAMILIES)))
        fam = np.full(n, FAMILIES.index(family))
    G = np.tile(NEUTRAL, (n, 1)).astype(np.float64)
    for f in np.unique(fam):
        rows = np.flatnonzero(fam == f)
        G[rows] = _sample_family(FAMILIES[f], len(rows), rng)
    extra = np.flatnonzero(rng.random(n) < P_EXTRA)
    for r in extra:
        k = rng.choice([1, 2, 3], p=[0.6, 0.3, 0.1])
        for name in rng.choice(EXTRA_GENES, k, replace=False):
            G[r, _I[name]] = _extra_value(name, 1, rng)[0]
    G = canonical(G.astype(np.float32))
    return (G, fam) if return_family else G


# ============================================================================= support

def _in_dist(v, dist):
    kind = dist[0]
    if kind == "u":
        return dist[1] - 1e-6 <= v <= dist[2] + 1e-6
    if kind == "c":
        return any(abs(v - x) < 1e-6 for x in dist[1])
    if kind == "leg":
        p = dist[1]
        return dist[2] > 0 or any(abs(v - LEGS[i]) < 1e-6 and p[i] > 0 for i in range(4))
    if kind == "bip":
        m, pos = abs(v - 0.5), v > 0.5
        ok_sign = (dist[3] > 0) if pos else (dist[3] < 1)
        return ok_sign and max(dist[1], DZ + 0.01) - 1e-6 <= m <= dist[2] + 1e-6
    if kind == "ratio":
        return any(plateau(v) == plateau(ratio_value(r)) for r, _ in dist[1])
    if kind == "cratio":
        return dist[2] > 0 or any(abs(v - c_ratio_value(r)) < 0.02 for r, _ in dist[1])
    raise ValueError(kind)


def outside_family(genome, family):
    """the ACTIVE genes of `genome` that the family's template cannot draw (a gene it never switches
    on, or a value outside its range). Empty = the template alone can produce this genome's active
    set; the mixture also reaches any genome up to 3 genes outside a template (P_EXTRA)."""
    g = canonical(np.asarray(genome, np.float32))
    A = active_mask(g[None])[0]
    spec = FAMILY_SPECS[family]
    out = []
    for gi in GENES:
        if not A[gi.index]:
            continue
        if gi.name not in spec or spec[gi.name][0] <= 0 or not _in_dist(float(g[gi.index]),
                                                                       spec[gi.name][1]):
            out.append(gi.name)
    return out


def support(genome):
    """{family: genes outside its template} for one genome (see outside_family)"""
    return {f: outside_family(genome, f) for f in FAMILIES}


# ============================================================================= report
# `python3 -m dnasynth.prior` -- per family: active genes, near-silent and hot fractions.

SILENT_DB = -40.0       # a render whose loudest 23 ms frame is below this (dBFS rms) is near-silent
HOT_PEAK = 2.0          # a render peaking above this is hot (the neutral saw peaks at 1.39)
CLIP_PEAK = 4.0         # ... and above this CLIPPING: +9 dB over a plain full-scale saw


def level_stats(Y):
    """per render: loudest 1024-sample frame rms in dBFS, and the peak"""
    n = Y.shape[1] // 1024
    fr = Y[:, :n * 1024].reshape(Y.shape[0], n, 1024).astype(np.float64)
    loud = 10 * np.log10(np.maximum((fr ** 2).mean(axis=2).max(axis=1), 1e-20))
    return loud, np.abs(Y).max(axis=1)


def report(n=256, seed=0, gate_s=1.2, secs=2.5, verbose=True):
    from .core import render_batch
    rng = np.random.default_rng(seed)
    out = {}
    for fam in FAMILIES + (None,):
        G = sample(n, rng, family=fam)
        midi = rng.integers(36, 73, n).astype(np.float32)
        Y = render_batch(G, midi=midi, gate_s=gate_s, secs=secs, seed=seed + 1)
        loud, peak = level_stats(Y)
        na = n_active(G)
        row = dict(active_mean=float(na.mean()), active_max=int(na.max()),
                   silent=float((loud < SILENT_DB).mean()), hot=float((peak > HOT_PEAK).mean()),
                   clip=float((peak > CLIP_PEAK).mean()), loud_median=float(np.median(loud)),
                   finite=bool(np.isfinite(Y).all()))
        out[fam or "mixture"] = row
        if verbose:
            print("  %-8s active %5.2f (max %2d)  near-silent %5.1f%%  hot (peak>%.1f) %5.1f%%  "
                  "clipping (peak>%.0f) %4.1f%%  loudest-frame median %6.1f dBFS"
                  % (fam or "mixture", row["active_mean"], row["active_max"], 100 * row["silent"],
                     HOT_PEAK, 100 * row["hot"], CLIP_PEAK, 100 * row["clip"],
                     row["loud_median"]))
    return out


# ============================================================================= Odin2 coverage
# `python3 -m dnasynth.prior --coverage` -- is the bench's synth inside the prior's reach? The four
# Odin2 patches of rsynth/eval/synthoct.py are read from that file (never copied into a template),
# rendered at C3 the way the bench does (HOLD_S then TAIL_S, velocity 100, a fresh instance each),
# and the nearest of n prior draws is compared with the nearest of n uniform-random genomes.

SYNTHOCT = "/Users/sansel/Projects/rsynth/eval/synthoct.py"


def synthoct_constants(path=SYNTHOCT):
    """PATCHES, HOLD_S, TAIL_S, ROOT, KEYS, ODIN from the bench's source (parsed, not imported:
    importing it would load rsynth)"""
    import ast
    tree = ast.parse(open(path).read())
    env = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        t = node.targets[0]
        names = [t.id] if isinstance(t, ast.Name) else \
            [e.id for e in t.elts] if isinstance(t, ast.Tuple) else []
        if not set(names) & {"PATCHES", "HOLD_S", "TAIL_S", "ROOT", "KEYS", "ODIN", "SR"}:
            continue
        val = eval(compile(ast.Expression(node.value), path, "eval"),       # noqa: S307
                   {"dict": dict, "__builtins__": {}})
        env.update(zip(names, val) if len(names) > 1 else [(names[0], val)])
    return env


def odin_note(patch, midi, cache_dir=None, velocity=100, overrides=None):
    """one Odin2 note of a synthoct patch, mono float32, as the bench renders it (a FRESH instance:
    the plugin leaks state between renders). overrides: Odin2 parameters set on top of the patch
    (the fitness validation sweeps them)."""
    import os
    c = synthoct_constants()
    fn = None
    if cache_dir:
        tag = "".join("_%s%g" % (k, v) for k, v in sorted((overrides or {}).items()))
        fn = os.path.join(cache_dir, "odin_%s_%d%s.npy" % (patch, int(midi), tag))
        if os.path.exists(fn):
            return np.load(fn)
    import mido
    import pedalboard
    p = pedalboard.load_plugin(c["ODIN"])
    for k, v in dict(c["PATCHES"][patch], **(overrides or {})).items():
        setattr(p, k, v)
    msgs = [mido.Message("note_on", note=int(midi), velocity=velocity, time=0.0),
            mido.Message("note_off", note=int(midi), velocity=0, time=c["HOLD_S"])]
    y = np.asarray(p(msgs, duration=c["HOLD_S"] + c["TAIL_S"], sample_rate=44100.0, reset=True),
                   np.float64)
    y = (y.mean(axis=0) if y.ndim == 2 else y).astype(np.float32)
    if fn:
        os.makedirs(cache_dir, exist_ok=True)
        np.save(fn, y)
    return y


def coverage(n=2000, seed=0, cache_dir=None, verbose=True):
    """per Odin2 patch at C3: the fitness of the nearest prior draw vs the nearest uniform genome
    (the target level-matched to the prior's median loudness), and rsynth's ruler (gain-free) on
    the nearest few"""
    import sys
    from .core import render_batch
    from . import fitness as FT
    c = synthoct_constants()
    rng = np.random.default_rng(seed)
    root, secs, gate = c["ROOT"], c["HOLD_S"] + c["TAIL_S"], c["HOLD_S"]
    Gp, fam = sample(n, rng, return_family=True)
    Gu = rng.random((n, N_GENES)).astype(np.float32)
    Yp = render_batch(Gp, midi=root, gate_s=gate, secs=secs, seed=seed + 1)
    Yu = render_batch(Gu, midi=root, gate_s=gate, secs=secs, seed=seed + 1)
    ref_db = float(np.median(level_stats(Yp)[0]))
    if FT.RULER_DIR not in sys.path:
        sys.path.insert(0, FT.RULER_DIR)
    import ruler
    out = {}
    for patch in c["PATCHES"]:
        y = odin_note(patch, root, cache_dir)
        y = y[:Yp.shape[1]] if y.size >= Yp.shape[1] else np.pad(y, (0, Yp.shape[1] - y.size))
        y = y * 10 ** ((ref_db - level_stats(y[None])[0][0]) / 20)
        T = FT.Target(y)
        sp, su = T.score(Yp), T.score(Yu)
        top = np.argsort(sp)[:5]
        tf_top = [ruler.score(y, Yp[i], 44100.0, align=False)["tf"] for i in top]
        topu = np.argsort(su)[:5]
        tf_topu = [ruler.score(y, Yu[i], 44100.0, align=False)["tf"] for i in topu]
        row = dict(prior_best=float(sp.min()), prior_p1=float(np.percentile(sp, 1)),
                   prior_median=float(np.median(sp)), uniform_best=float(su.min()),
                   uniform_p1=float(np.percentile(su, 1)), uniform_median=float(np.median(su)),
                   prior_best5_tf=float(np.min(tf_top)), uniform_best5_tf=float(np.min(tf_topu)),
                   best_families=[FAMILIES[fam[i]] for i in top])
        out[patch] = row
        if verbose:
            print("  %-6s fitness nearest/1%%/median: prior %6.2f %6.2f %6.2f | uniform %6.2f %6.2f "
                  "%6.2f ; ruler tf of the 5 nearest: prior %5.2f, uniform %5.2f ; families %s"
                  % (patch, row["prior_best"], row["prior_p1"], row["prior_median"],
                     row["uniform_best"], row["uniform_p1"], row["uniform_median"],
                     row["prior_best5_tf"], row["uniform_best5_tf"], ",".join(row["best_families"])))
    return out


if __name__ == "__main__":
    import sys
    if "--coverage" in sys.argv:
        coverage(cache_dir=sys.argv[sys.argv.index("--cache") + 1] if "--cache" in sys.argv
                 else None)
    else:
        report()
