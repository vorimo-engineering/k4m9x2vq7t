"""The engines the matcher's network can learn: one interface over dnasynth v1 (the C voice),
DNA v2 (the graph voice) and DNA v3 (the dense C voice), so model.py, nnfeat.py and
scripts/train.py are written once.

    from dnasynth import engines
    E = engines.get("v2")
    G = E.sample(64, rng)                      # training genomes, canonical
    Y = E.render_batch(G, midi=48, gate_s=0.8, secs=2.5, seed=7)

An engine gives: its genes (each with .name, .index, .neutral, .bipolar), their neutral values,
the dead zone of a bipolar gene in GENE units, its prior families (v2 has none), the SELECTOR genes
(a plateau count per gene), the genes whose value g and 1 - g sound the same (FOLD) and the
continuous morphs whose four pure legs are grid points (LEGS); and the functions sample, canonical,
active_mask, render and render_batch. v1's are exactly the modules it always used (prior, core),
so a v1 network is unchanged by this layer.
"""
from __future__ import annotations

import os

import numpy as np

NAMES = ("v1", "v1x", "v1xm", "v1y", "v1d", "v1e", "v2", "v3", "v3m", "v3m2", "v3m3", "grow", "growx", "va", "dashx")
_CACHE = {}


class Engine:
    def __init__(self, name, genes, neutral, dz, families, selectors, fold, legs, sample,
                 canonical, active_mask, render, render_batch, fine=None):
        self.name = name
        self.genes = list(genes)
        self.n = len(self.genes)
        self.neutral = np.asarray(neutral, np.float32)
        self.dz = float(dz)
        self.families = tuple(families)
        self.selectors = dict(selectors)
        self.fold = tuple(fold)
        self.legs = tuple(legs)
        self.fine = dict(fine or {})         # gene -> grid factor (the network's resolution)
        self.index = {g.name: g.index for g in self.genes}
        self._sample, self.canonical, self.active_mask = sample, canonical, active_mask
        self.render, self.render_batch = render, render_batch

    def sample(self, n, rng, return_family=False):
        """n training genomes (canonical); with return_family also int64[n] family indices (all 0
        for an engine without families)"""
        return self._sample(n, rng, return_family)

    def plateau(self, name, g):
        """a selector gene's value -> its plateau index (the engine's floor(g * k), clamped)"""
        k = self.selectors[name]
        return np.minimum((np.clip(np.asarray(g, np.float64), 0, 1) * k).astype(np.int64), k - 1)


def _v1():
    """v1 as its VERSION-2 networks know it: the first 40 genes (operator C and osc B's feedback held
    at neutral, so a 40-gene genome plays as it always did); the checkpoints trained on it keep their
    40-gene tokenizer"""
    from . import core, prior as PR
    k = core.N_GENES_V2

    def sample(n, rng, return_family):
        G, fam = PR.sample(n, rng, return_family=True)
        G[:, k:] = PR.NEUTRAL[k:]
        G = PR.canonical(G)[:, :k]
        return (G, fam) if return_family else G

    def canonical(G, **kw):
        return PR.canonical(core.widen(G), **kw)[:, :k]

    def active_mask(G, **kw):
        return PR.active_mask(core.widen(G), **kw)[:, :k]
    return Engine("v1", core.GENES[:k], PR.NEUTRAL[:k], PR.DZ, PR.FAMILIES, {"b_ratio": 16},
                  ("a_pw", "b_pw"), ("a_wave", "b_wave", "flt_mode"), sample, canonical,
                  active_mask, core.render, core.render_batch)


def _first(name, k, base_sample, families, selectors):
    """v1 as a network trained on its first k genes knows it: the genes past k held at neutral (so a
    k-gene genome plays as it always did) and cut off; its checkpoints keep their k-gene tokenizer"""
    from . import core, prior as PR

    def sample(n, rng, return_family):
        G, fam = base_sample(n, rng)
        G[:, k:] = PR.NEUTRAL[k:]
        G = PR.canonical(G)[:, :k]
        return (G, fam) if return_family else G

    def canonical(G, **kw):
        return PR.canonical(core.widen(G), **kw)[:, :k]

    def active_mask(G, **kw):
        return PR.active_mask(core.widen(G), **kw)[:, :k]
    return Engine(name, core.GENES[:k], PR.NEUTRAL[:k], PR.DZ, families, selectors,
                  ("a_pw", "b_pw"), ("a_wave", "b_wave", "flt_mode"), sample, canonical,
                  active_mask, core.render, core.render_batch)


def _v1x():
    """v1 at version 3: 46 genes -- operator C (a third FM operator with its own envelope) and osc
    B's feedback, drawn by the prior's families (the keys' tine, FM's third operator, metal). The
    version-4 genes (operator D) are held at neutral: checkpoints/v1x knows 46"""
    from . import core, prior as PR
    return _first("v1x", core.N_GENES_V3,
                  lambda n, rng: PR.sample(n, rng, return_family=True), PR.FAMILIES,
                  {"b_ratio": 16, "c_tgt": 2})


def _v1d():
    """v1 at version 4: 51 genes -- operator D, a fourth operator (a second modulator beside C, or
    on C: a tine over a body, a DX7's parallel pairs and three-operator stacks). Since version 5 its
    first 51 genes (the formant and the chorus held at neutral), as _first pins v1x to 46"""
    from . import core, prior as PR
    return _first("v1d", core.N_GENES_V4,
                  lambda n, rng: PR.sample(n, rng, return_family=True), PR.FAMILIES,
                  {"b_ratio": 16, "c_tgt": 2, "d_tgt": 3})


def _v1e():
    """v1 at version 5: all 57 genes -- the FORMANT (one peaking band fixed in Hz: a body's, a bell's,
    a mouth's resonance) and the CHORUS (two copies swept in opposite phase: an ensemble), drawn by
    the prior's families (results.md section 26). The app and the matcher play this layout; a
    46-gene network's proposals are widened into it and the search switches the new parts on
    (ga.sweep_edits)"""
    from . import core, prior as PR

    def sample(n, rng, return_family):
        return PR.sample(n, rng, return_family=return_family)
    return Engine("v1e", core.GENES, PR.NEUTRAL, PR.DZ, PR.FAMILIES,
                  {"b_ratio": 16, "c_tgt": 2, "d_tgt": 3}, ("a_pw", "b_pw"),
                  ("a_wave", "b_wave", "flt_mode"), sample, PR.canonical, PR.active_mask,
                  core.render, core.render_batch)


def _v1xm():
    """v1x exactly (its genes, tokens and 7 families) learning from the archetype mix
    (prior.sample_mix), each archetype labelled with its nearest base family: a v1x checkpoint
    continues on it with every weight in place (the fine-tune experiments, results.md section 19)"""
    from . import core, prior as PR
    fmap = np.array(list(range(len(PR.FAMILIES))) + [PR.FAMILIES.index(f) for f in (
        "keys", "bass", "fm", "perc", "perc")], np.int64)
    assert len(fmap) == len(PR.FAMILIES) + len(PR.ARCHETYPES)

    def base(n, rng):
        G, fam = PR.sample_mix(n, rng, return_family=True)
        return G, fmap[fam]
    return _first("v1xm", core.N_GENES_V3, base, PR.FAMILIES, {"b_ratio": 16, "c_tgt": 2})


def _v1y():
    """v1 at version 3 (46 genes) learned from the ARCHETYPE prior (prior.sample_mix: 35 % of the
    draws from correlated templates -- DX keys and mallets, FM bass, bells, pitched drums, noise
    drums -- where the base families barely reach: results.md section 17) and with operator C's
    ratio tokenised by its plateaus (model.Tokenizer kind "cratio"). The genes, laws and renders
    are v1x's: only the network's data and tokens differ, so its proposals play in the same
    search."""
    from . import core, prior as PR

    return _first("v1y", core.N_GENES_V3, lambda n, rng: PR.sample_mix(n, rng, return_family=True),
                  PR.FAMILIES + PR.ARCHETYPES, {"b_ratio": 16, "c_tgt": 2})


# DNA v2's training prior: random genomes of the voice at a spread of sparsity (the probability
# that each amount / modulation is on), so simple sounds and busy ones are both seen
V2_P_ON = (0.08, 0.15, 0.25, 0.35)


def _v2():
    from .graph import voice as V

    def sample(n, rng, return_family):
        p = rng.choice(V2_P_ON, n)
        G = np.concatenate([V.random_genomes(int((p == q).sum()), rng, p_on=q) for q in V2_P_ON])
        G = G[np.argsort(np.concatenate([np.flatnonzero(p == q) for q in V2_P_ON]))]
        return (G, np.zeros(n, np.int64)) if return_family else G

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return V.render(g, midi, vel, gate_s, secs, sr, seed)

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1,
                     threads=4):
        G = np.atleast_2d(np.asarray(G, np.float32))
        seeds = (int(seed) + np.arange(len(G))) & 0x7FFFFFFF    # one noise draw per patch
        return V.render_batch(G, midi, vel, gate_s, secs, sr, seed=seeds, threads=threads)
    return Engine("v2", V.GENES, V.NEUTRAL, V.DZ / 2.0, (),
                  {n: V.GENES[V.GENE_INDEX[n]].steps for n in V.SELECTORS}, ("b_pw",),
                  ("b_shape",), sample, V.canonical, V.active_mask, render, render_batch)


# DNA v3's training prior: its own random genomes at a spread of density (the probability that
# each amount / modulation is on). Synplant's sounds are dense (DNA_V3_ANALYSIS.md: three or more
# modulation depths on in 78 %), so the spread sits higher than v2's.
# DNA v3's NETWORK learns a LEAN layout of the voice (measured 2026-09-24, docs/matcher/results.md
# section 10): the first network, on all 57 genes and a dense prior (p_on 0.15 .. 0.6), closed
# about half the gap between the prior and the tokenised floor and did not help a match. Two
# causes, each measured: (1) genes the network cannot identify -- key laws (at one recorded note
# they are the cutoff's and the envelope's own job), stereo width (the network hears mono),
# curvatures and details a whole-range move barely changes (eval/synplant_study/ambiguity.py) --
# and one symmetry: osc A alone and osc B alone are the same sound (81 %); (2) a dense prior.
# The training prior holds V3_NET_FREEZE at neutral, keeps osc B at most as loud as osc A, and
# spreads density like DNA v2's; the SEARCH a proposal seeds still moves all 57 genes.
V3_P_ON = (0.08, 0.15, 0.25, 0.35)
V3_NET_FREEZE = ("flt_key", "env_key", "ens_width", "vol_atk", "vol_dcy", "mod_atk", "mod_dcy",
                 "lfo_shape", "clip")
V3_NET_MIX_MAX = 0.5
# experiment knob: DN_V3_P_ON="0.15,0.3,0.45,0.6" trains on another spread (the first run's)
if os.environ.get("DN_V3_P_ON"):
    V3_P_ON = tuple(float(x) for x in os.environ["DN_V3_P_ON"].split(","))


# the genes whose one-token step is loudest on v3's own sounds (the tokenised-truth floor's
# makers: eval/synplant_study/ambiguity.py and the per-gene floor): a grid 4x finer.
# DN_V3_FINE=0 turns it off (the first v3 network used 64 steps everywhere)
V3_FINE = {} if os.environ.get("DN_V3_FINE") == "0" else {
    n: 4 for n in ("env_loop", "env_len", "env_tilt", "b_ratio", "a_tune", "pitch_mod",
                   "rvb_size")}


def _v3():
    from . import v3voice as V

    def sample(n, rng, return_family):
        p = rng.choice(V3_P_ON, n)
        G = np.zeros((n, V.N_GENES), np.float32)
        for q in V3_P_ON:
            k = np.flatnonzero(p == q)
            if k.size:
                G[k] = V.random_genomes(k.size, rng, p_on=q)
        # the network's lean layout (above): frozen genes at neutral, osc B never over osc A
        fz = [V.GENE_INDEX[x] for x in V3_NET_FREEZE]
        G[:, fz] = V.NEUTRAL[fz]
        G[:, V.GENE_INDEX["osc_mix"]] = np.minimum(G[:, V.GENE_INDEX["osc_mix"]], V3_NET_MIX_MAX)
        G = V.canonical(G)
        return (G, np.zeros(n, np.int64)) if return_family else G

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return V.render(g, midi, vel, gate_s, secs, sr, seed)

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1,
                     threads=4):
        G = np.atleast_2d(np.asarray(G, np.float32))
        seeds = (int(seed) + np.arange(len(G))) & 0x7FFFFFFF    # one noise draw per patch
        return V.render_batch(G, midi, vel, gate_s, secs, sr, seed=seeds, threads=threads)
    return Engine("v3", V.GENES, V.NEUTRAL, V.DZ / 2.0, (),
                  {n: V.GENES[V.GENE_INDEX[n]].steps for n in V.SELECTORS}, (), ("flt_type",),
                  sample, V.canonical, V.active_mask, render, render_batch, fine=V3_FINE)


# DNA v3 through its 20 MACROS (dnasynth/v3macro.py): the matchable control space. Its training
# prior spreads density like v2's (every macro is a strong, distinct control, so sparse sounds teach
# each one on its own).
V3M_P_ON = (0.15, 0.3, 0.45, 0.6)
V3M_FINE = {n: 4 for n in ("ratio", "length", "attack", "loop")}


def _v3m():
    from . import v3macro as V

    def sample(n, rng, return_family):
        p = rng.choice(V3M_P_ON, n)
        G = np.zeros((n, V.N_GENES), np.float32)
        for q in V3M_P_ON:
            k = np.flatnonzero(p == q)
            if k.size:
                G[k] = V.random_genomes(k.size, rng, p_on=q)
        return (G, np.zeros(n, np.int64)) if return_family else G

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return V.render(g, midi, vel, gate_s, secs, sr, seed)

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1,
                     threads=4):
        G = np.atleast_2d(np.asarray(G, np.float32))
        seeds = (int(seed) + np.arange(len(G))) & 0x7FFFFFFF
        return V.render_batch(G, midi, vel, gate_s, secs, sr, seed=seeds, threads=threads)
    return Engine("v3m", V.GENES, V.NEUTRAL, V.DZ / 2.0, (),
                  {n: V.GENES[V.GENE_INDEX[n]].steps for n in V.SELECTORS}, (), (),
                  sample, V.canonical, V.active_mask, render, render_batch, fine=V3M_FINE)


# DNA v3 through its 20 IDENTIFIABLE macros (dnasynth/v3macro2.py): the same density spread; the
# grid 2x finer on the macros that are times or rates, 4x on the detented ratio
V3M2_P_ON = V3M_P_ON
V3M2_FINE = {"ratio": 4, "attack": 2, "decay": 2, "loop": 2, "lfo_rate": 2}


def _layer(name, V, p_on, fine):
    """a macro layer over DNA v3 (a module with the search-voice interface) as an engine: its
    training prior spreads density over p_on"""
    def sample(n, rng, return_family):
        p = rng.choice(p_on, n)
        G = np.zeros((n, V.N_GENES), np.float32)
        for q in p_on:
            k = np.flatnonzero(p == q)
            if k.size:
                G[k] = V.random_genomes(k.size, rng, p_on=q)
        return (G, np.zeros(n, np.int64)) if return_family else G

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return V.render(g, midi, vel, gate_s, secs, sr, seed)

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1,
                     threads=4):
        G = np.atleast_2d(np.asarray(G, np.float32))
        seeds = (int(seed) + np.arange(len(G))) & 0x7FFFFFFF
        return V.render_batch(G, midi, vel, gate_s, secs, sr, seed=seeds, threads=threads)
    return Engine(name, V.GENES, V.NEUTRAL, V.DZ / 2.0, (),
                  {n: V.GENES[V.GENE_INDEX[n]].steps for n in V.SELECTORS}, (), (),
                  sample, V.canonical, V.active_mask, render, render_batch, fine=fine)


def _v3m2():
    from . import v3macro2 as V
    return _layer("v3m2", V, V3M2_P_ON, V3M2_FINE)


# DNA v3 through 27 identifiable macros (dnasynth/v3macro3.py: v3macro2's and the seven Synplant's
# sounds lean on); the tune's grid 4x finer (5 cents a step)
V3M3_P_ON = V3M_P_ON
V3M3_FINE = dict(V3M2_FINE, tune=4)


def _v3m3():
    from . import v3macro3 as V
    return _layer("v3m3", V, V3M3_P_ON, V3M3_FINE)


# GROW (dnasynth/grow): the voice the matcher BUILDS, as the fixed-slot genome of grow/slots.py (a
# sine slot per harmonic number, sorted slots for the pieces that can swap places, an on gene per
# slot) and its prior over the start families. No finer grids: a ratio gene (six octaves) at 64
# steps is a semitone apart, which GROW's own tuning (+-60 cents) refines; a 4x grid on the ratio
# genes stretched every gene's vocabulary to 257 tokens (32 M parameters, 108 samples/s against
# DNA v2's 280; 2026-10-03)
def _grow():
    from .grow import blocks as BL
    from .grow import slots as GS

    def sample(n, rng, return_family):
        return GS.sample(n, rng, return_family)

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return GS.render_batch(np.asarray(g)[None], midi, vel, gate_s, secs, sr, seed, threads=1)[0]

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1, threads=4):
        return GS.render_batch(G, midi, vel, gate_s, secs, sr, seed, threads)
    return Engine("grow", GS.GENES, GS.NEUTRAL, BL.DZ / 2.0, GS.FAMILIES, GS.SELECTORS, (), GS.LEGS,
                  sample, GS.canonical, GS.active_mask, render, render_batch)


# GROW's FULL KIT (grow/slots_full.py): the small layout and a slot for every kit kind (331 genes)
def _growx():
    from .grow import blocks as BL
    from .grow import slots_full as GF

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return GF.render_batch(np.asarray(g)[None], midi, vel, gate_s, secs, sr, seed, threads=1)[0]

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1, threads=4):
        return GF.render_batch(G, midi, vel, gate_s, secs, sr, seed, threads)
    return Engine("growx", GF.GENES, GF.NEUTRAL, BL.DZ / 2.0, GF.FAMILIES, GF.SELECTORS, (), GF.LEGS,
                  lambda n, rng, rf: GF.sample(n, rng, rf), GF.canonical, GF.active_mask, render, render_batch)


# THE ANALOG TEMPLATE (graph/analog.py): the architect's first graph. Its network is the template's
# TUNER -- which parts of the graph a sound needs (every optional part is an amount with an exact off
# token, decoded structure first) and their knobs. The training prior: the template's own random
# genomes at DNA v2's spread of density (2026-10-04)
def _va():
    from .graph import analog as V

    def sample(n, rng, return_family):
        p = rng.choice(V2_P_ON, n)
        G = np.concatenate([V.random_genomes(int((p == q).sum()), rng, p_on=q) for q in V2_P_ON])
        G = G[np.argsort(np.concatenate([np.flatnonzero(p == q) for q in V2_P_ON]))]
        return (G, np.zeros(n, np.int64)) if return_family else G

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return V.render(g, midi, vel, gate_s, secs, sr, seed)

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1,
                     threads=4):
        G = np.atleast_2d(np.asarray(G, np.float32))
        seeds = (int(seed) + np.arange(len(G))) & 0x7FFFFFFF    # one noise draw per patch
        return V.render_batch(G, midi, vel, gate_s, secs, sr, seed=seeds, threads=threads)
    return Engine("va", V.GENES, V.NEUTRAL, V.DZ / 2.0, (),
                  {n: V.GENES[V.GENE_INDEX[n]].steps for n in V.SELECTORS}, (),
                  ("o1_shape", "o2_shape", "sub_shape"), sample, V.canonical, V.active_mask, render,
                  render_batch)


# DASHBOARD GROW's voice (grow/slots_dash.py): every piece a dashboard voice keeps underneath and the
# 24 skeleton genes; the prior is the dashboard template catalogue, a family per template (2026-10-04)
def _dashx():
    from .grow import blocks as BL
    from .grow import slots_dash as SD

    def render(g, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1):
        return SD.render_batch(np.asarray(g)[None], midi, vel, gate_s, secs, sr, seed, threads=1)[0]

    def render_batch(G, midi=48.0, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, seed=1, threads=4):
        return SD.render_batch(G, midi, vel, gate_s, secs, sr, seed, threads)
    return Engine("dashx", SD.GENES, SD.NEUTRAL, BL.DZ / 2.0, SD._families(), SD.SELECTORS, (), SD.LEGS,
                  lambda n, rng, rf: SD.sample(n, rng, rf), SD.canonical, SD.active_mask, render, render_batch)


def get(name="v1"):
    if name not in NAMES:
        raise ValueError("unknown engine %r (have %s)" % (name, ", ".join(NAMES)))
    if name not in _CACHE:
        _CACHE[name] = {"v1": _v1, "v1x": _v1x, "v1xm": _v1xm, "v1y": _v1y, "v1d": _v1d, "v1e": _v1e, "v2": _v2,
                        "v3": _v3, "v3m": _v3m, "v3m2": _v3m2, "v3m3": _v3m3, "grow": _grow, "growx": _growx,
                        "va": _va, "dashx": _dashx}[name]()
    return _CACHE[name]
