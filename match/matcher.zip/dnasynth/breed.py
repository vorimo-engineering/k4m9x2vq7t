"""Breeding dnasynth genomes: mutation, crossover and Synplant-style "variations".

    import numpy as np
    from dnasynth import breed
    rng = np.random.default_rng(0)
    kids = breed.mutate(g, rng, n=32, amount=0.1)          # float32[32, 40], near g
    kids = breed.crossover(a, b, rng, n=16)                # module-wise mixes of a and b
    four = breed.variations(g, rng, n=4, amount=0.15)      # four musically related variants

Every output is CANONICAL (dnasynth.prior.canonical): inactive genes at their exact neutral value,
b_ratio on a plateau centre, pulse widths on [0, 0.5].

THE LAWS a move respects (the gene laws are docs/TECHNICAL.md section 3):
  * a gene moves in gene units: an active continuous gene is displaced by N(0, amount), reflected
    at 0 and 1. A move that would land it inside its dead zone / eps band around neutral (i.e.
    switch it off) is pushed back out to the side it came from -- switching off is a STRUCTURE
    move, taken only on purpose (below);
  * the oscillator shapes (a_wave, b_wave) land on a pure leg (sine 0, triangle 1/3, saw 2/3,
    pulse 1) with probability P_SNAP when one is within SNAP_RADIUS, and JUMP to a neighbouring
    pure leg with probability 2.5 x amount (0.25 at amount 0.1): the legs are worth landing on (a
    preset's shape is almost always one), and a sine -> triangle step is one move, not a random
    walk across the crossfade. Landing on the neutral saw switches the shape off, so only
    structure=True may do it;
  * b_ratio is a plateau gene: it steps to a neighbouring plateau (one step 70 %, two 20 %, any
    10 %), never to "somewhere between", and skips the 1:1 plateau (its neutral) unless switching;
  * c_ratio (operator C) is 60 % plateaus and 40 % inharmonic slopes: on a plateau it steps to
    another plateau (P_C_STEP; the same one / two / any law, the 1:1 neutral skipped), else it
    slides N(0, amount / 2) -- off the plateau onto a slope or the next plateau; on a slope it
    slides, or snaps to the nearest plateau (P_C_SNAP). A nudge inside a plateau would change
    nothing (the engine plays the listed ratio there), so it is never spent;
  * c_tgt (operator C into osc A or B) is a routing choice: never nudged, only switched by the
    search's discrete moves (ga.discrete_move);
  * operator D (version 4) follows operator C's laws: d_ratio as c_ratio, d_tgt (into osc A, osc B
    or operator C) a routing choice;
  * amp_vel / flt_vel are never switched on (one note at one velocity cannot observe them).
STRUCTURE (structure=True): each child also switches one gene OFF with probability P_OFF and one
gene ON with probability P_ON (both scaled by amount / 0.1, capped at 0.3). A gene switched on
takes a value drawn from the prior's own marginal for it (a random prior genome in which it is
active), so what appears is musical, not uniform -- and its COMPANIONS come from the same prior
genome (operator C's amount brings that genome's ratio, decay, sustain and target; a mod-envelope
route its times, when no other route already set them): a module never switches on at its
defaults, where it usually sounds worse and is rejected before it is tuned (docs/matcher/
literature.md, search §2). structure=False keeps the active set exactly.
"""
from __future__ import annotations

import numpy as np

from .core import GENE_INDEX, N_GENES
from . import prior as PR

_I = GENE_INDEX
P_SNAP = 0.35
SNAP_RADIUS = 0.12
P_LEG_JUMP_PER_AMOUNT = 2.5         # a shape jumps to a neighbouring pure leg w.p. 2.5 x amount
P_ON = 0.12
P_OFF = 0.12
MIN_AUDIBLE = 0.5       # a variant closer than this (fitness units) to its parent is not a variant
NEAR_QUANTILE = 0.6     # ... and one in the far 40 % of its pool is no longer related to it
WAVE = (_I["a_wave"], _I["b_wave"])
RATIO = _I["b_ratio"]
C_RATIO = _I["c_ratio"]
C_TGT = _I["c_tgt"]
D_RATIO = _I["d_ratio"]
D_TGT = _I["d_tgt"]
P_C_STEP = 0.5          # c_ratio on a plateau: a plateau step (else a slide at the full step: a
                        # ratio just off a plateau -- a DX7's 2.98 -- must stay reachable; 0.8
                        # lost E.Piano's copy, results.md section 18)
P_C_SNAP = 0.3          # c_ratio on a slope: a snap to the nearest plateau (else a slide)
NEUTRAL = PR.NEUTRAL
EPS = PR.EPS
NEVER = tuple(_I[n] for n in PR.NEVER_DRAWN)
MODULES = (
    ("osc_a", ("a_wave", "a_pw")),
    ("osc_b", ("b_wave", "b_pw", "b_ratio", "b_detune", "osc_mix", "fm_amt", "menv_fm",
               "menv_bpitch", "b_fb")),
    ("op_c", ("c_ratio", "c_amt", "c_dec", "c_sus", "c_tgt")),
    ("op_d", ("d_ratio", "d_amt", "d_dec", "d_sus", "d_tgt")),
    ("sub", ("sub_lvl",)),
    ("noise", ("noise_lvl", "noise_col")),
    ("filter", ("flt_cut", "flt_res", "flt_mode", "flt_key", "flt_env", "flt_lfo", "flt_vel")),
    ("drive", ("drive",)),
    ("amp", ("amp_att", "amp_dec", "amp_sus", "amp_rel", "amp_vel")),
    ("mod", ("mod_att", "mod_dec", "mod_sus", "mod_rel", "menv_pitch")),
    ("lfo", ("lfo_rate", "lfo_delay", "lfo_pitch", "lfo_amp")),
    ("key", ("env_key",)),
    ("space", ("rvb_mix", "rvb_size", "rvb_decay", "rvb_damp")),
    ("formant", ("fmt_freq", "fmt_gain", "fmt_q")),                     # version 5
    ("chorus", ("cho_mix", "cho_rate", "cho_depth")),
)
MODULE_IDX = tuple(np.array([_I[g] for g in genes]) for _, genes in MODULES)
assert sorted(np.concatenate(MODULE_IDX).tolist()) == list(range(N_GENES))

# a gene that switches a part of the voice on, and the genes that shape that part: switched on,
# the head brings its companions from the same prior genome (those still off in the child)
_MOD_TIMES = ("mod_att", "mod_dec", "mod_sus", "mod_rel")
_OSC_B = ("b_wave", "b_pw", "b_ratio", "b_detune")
_LFO = ("lfo_rate", "lfo_delay")
COMPANIONS = {
    "c_amt": ("c_ratio", "c_dec", "c_sus", "c_tgt"),
    "d_amt": ("d_ratio", "d_dec", "d_sus", "d_tgt"),
    "fm_amt": _OSC_B, "osc_mix": _OSC_B,
    "menv_fm": _MOD_TIMES, "menv_pitch": _MOD_TIMES, "menv_bpitch": _MOD_TIMES,
    "flt_env": _MOD_TIMES,
    "lfo_pitch": _LFO, "lfo_amp": _LFO, "flt_lfo": _LFO,
    "noise_lvl": ("noise_col",),
    "rvb_mix": ("rvb_size", "rvb_decay", "rvb_damp"),
    "fmt_gain": ("fmt_freq", "fmt_q"), "cho_mix": ("cho_rate", "cho_depth"),
}
COMPANION_IDX = {_I[h]: np.array([_I[c] for c in cs], np.int64) for h, cs in COMPANIONS.items()}


def coherent_on(g, k, donor):
    """g with gene k set from the prior genome `donor` (in which k is active), and k's companions
    that are off in g taken from the donor too -> the child (canonical not applied)"""
    t = g.copy()
    t[k] = donor[k]
    comp = COMPANION_IDX.get(int(k))
    if comp is not None and comp.size:
        off = ~PR.active_mask(g[None])[0][comp]
        t[comp[off]] = donor[comp[off]]
    return t

_POOL = {}


def _marginal_pool():
    """a fixed bank of prior genomes: where a gene is switched on, its value comes from here"""
    if "G" not in _POOL:
        with PR.unfrozen():                      # the prior's bank, whatever a search holds off
            G = PR.sample(4096, np.random.default_rng(12345))
        _POOL["G"], _POOL["A"] = G, PR.active_mask(G)
    return _POOL["G"], _POOL["A"]


def _reflect01(x):
    x = np.abs(x)
    x = np.where(x > 1.0, 2.0 - x, x)
    return np.clip(x, 0.0, 1.0)


def _keep_on(new, old, j):
    """a move that would land an active gene inside its off-band is pushed back out, to the side of
    neutral the gene came from"""
    neu, eps = float(NEUTRAL[j]), float(EPS[j])
    off = np.abs(new - neu) <= eps
    if not off.any():
        return new
    side = np.sign(old - neu)
    side = np.where(side == 0, 1.0, side)
    pushed = neu + side * eps * 1.5
    if neu <= eps or neu >= 1.0 - eps:              # neutral on an edge: the gene has one side
        pushed = neu + (eps * 1.5 if neu <= eps else -eps * 1.5)
    return np.where(off, pushed, new)


def _step_plateau(p, rng, n, one=None):
    """one plateau move from plateau p (0..n-1): a neighbour (70 %), two over (20 %) or any
    (10 %); `one` (the neutral plateau) is stepped over"""
    u = rng.random()
    if u < 0.1:
        q = int(rng.integers(0, n))
    else:
        q = p + int(rng.choice([-1, 1])) * (1 if u < 0.8 else 2)
    q = int(np.clip(q, 0, n - 1))
    if one is not None and q == one:
        q = q + (1 if q >= p else -1)
        q = int(np.clip(q, 0, n - 1))
        if q == one:
            q = p
    return q


def _step_ratio(p, rng, allow_one):
    """one b_ratio plateau move from plateau p (0..15)"""
    return _step_plateau(p, rng, 16, None if allow_one else int(PR.plateau(NEUTRAL[RATIO])))


def _move_c_ratio(v, amount, rng):
    """operator C's ratio, one move (the module docstring's law) -> the new gene value"""
    p = int(PR.c_plateau(v))
    if p >= 0 and rng.random() < P_C_STEP:
        return float(PR.C_CENTRES[_step_plateau(p, rng, len(PR.C_RATIOS), PR.C_ONE)])
    if p < 0 and rng.random() < P_C_SNAP:
        return float(PR.C_CENTRES[int(np.argmin(np.abs(PR.C_CENTRES - v)))])
    return float(_reflect01(np.asarray(v + rng.normal(0.0, amount))))


def _switch_on(g, rng, j=None):
    """switch one inactive gene on (its value and its companions' from one prior genome in which
    it is active); returns the gene or None"""
    G, A = _marginal_pool()
    act = PR.active_mask(g[None])[0]
    cand = [k for k in range(N_GENES) if not act[k] and k not in NEVER and A[:, k].any()]
    rng.shuffle(cand)
    for k in ([j] if j is not None else cand[:8]):
        rows = np.flatnonzero(A[:, k])
        trial = coherent_on(g, k, G[rng.choice(rows)])
        if PR.active_mask(trial[None])[0][k]:          # its section sounds: it really is on
            g[:] = trial
            return k
    return None


def _moves(g0, idx, n, amount, rng, allow_off=False):
    """n children of g0 with the active genes idx displaced by the gene laws (no structure moves;
    allow_off lets a shape land on its neutral leg, which switches it off)"""
    out = np.tile(g0, (n, 1))
    if not idx.size:
        return out
    p_move = max(0.35, 1.0 / idx.size)
    M = rng.random((n, idx.size)) < p_move
    none = ~M.any(axis=1)
    M[none, rng.integers(0, idx.size, int(none.sum()))] = True
    for c, j in enumerate(idx):
        rows = np.flatnonzero(M[:, c])
        if not rows.size:
            continue
        if j == RATIO:
            for r in rows:
                q = _step_ratio(int(PR.plateau(out[r, j])), rng, allow_one=False)
                out[r, j] = (q + 0.5) / 16.0
            continue
        if j in (C_TGT, D_TGT):         # a routing choice: switched by ga.discrete_move, not nudged
            continue
        if j in (C_RATIO, D_RATIO):
            for r in rows:
                out[r, j] = _move_c_ratio(float(out[r, j]), amount, rng)
            out[rows, j] = _keep_on(out[rows, j], g0[j], j)
            continue
        old = out[rows, j]
        new = _reflect01(old + rng.normal(0.0, amount, rows.size))
        new = _keep_on(new, old, j)
        if j in WAVE:
            legs = np.asarray(PR.LEGS)
            ok_leg = allow_off | (np.abs(legs - NEUTRAL[j]) > EPS[j])
            near = legs[np.argmin(np.abs(new[:, None] - legs[None]), axis=1)]
            snap = (rng.random(rows.size) < P_SNAP) & (np.abs(new - near) < SNAP_RADIUS) \
                & (allow_off | (np.abs(near - NEUTRAL[j]) > EPS[j]))
            new = np.where(snap, near, new)
            # a LEG JUMP: to a pure leg next to where the shape was (sine-tri-saw-pulse order)
            jump = rng.random(rows.size) < min(P_LEG_JUMP_PER_AMOUNT * amount, 0.5)
            for r_, (o, jmp) in enumerate(zip(old, jump)):
                if not jmp:
                    continue
                k0 = int(np.argmin(np.abs(legs - o)))
                cand = {k0 - 1, k0 + 1} | ({k0} if abs(legs[k0] - o) > 1e-6 else set())
                cand = [k for k in cand if 0 <= k < 4 and ok_leg[k]]
                if cand:
                    new[r_] = legs[cand[int(rng.integers(len(cand)))]]
        out[rows, j] = new
    return out


def mutate(genes, rng, n, amount=0.1, structure=True):
    """n mutants of one genome -> float32[n, 40] (canonical). See the module docstring.
    structure=False keeps the active set EXACTLY: a child whose moves change it anyway (a shape
    leaving the pulse leg silences its width; menv_fm changing sign without fm_amt silences osc B)
    is drawn again (8 rounds), and after that left equal to the parent."""
    rng = rng if rng is not None else np.random.default_rng()
    g0 = PR.canonical(np.asarray(genes, np.float32).reshape(N_GENES)).astype(np.float64)
    act = PR.active_mask(g0[None])[0]
    idx = np.flatnonzero(act)
    out = _moves(g0, idx, n, amount, rng, allow_off=structure)
    if not structure:
        out = PR.canonical(out.astype(np.float32)).astype(np.float64)
        for _ in range(8):
            bad = np.flatnonzero((PR.active_mask(out) != act[None]).any(axis=1))
            if not bad.size:
                break
            out[bad] = PR.canonical(_moves(g0, idx, bad.size, amount, rng).astype(np.float32))
        bad = (PR.active_mask(out) != act[None]).any(axis=1)
        out[bad] = g0
        return PR.canonical(out.astype(np.float32))
    scale = min(max(amount / 0.1, 0.0), 2.5)
    p_on, p_off = min(P_ON * scale, 0.3), min(P_OFF * scale, 0.3)
    for r in range(n):
        if rng.random() < p_off:
            a_now = np.flatnonzero(PR.active_mask(out[r][None])[0])
            if a_now.size > 1:
                k = rng.choice(a_now)
                out[r, k] = NEUTRAL[k]
        if rng.random() < p_on:
            _switch_on(out[r], rng)
    return PR.canonical(out.astype(np.float32))


def crossover(a, b, rng, n):
    """n children of two genomes -> float32[n, 40] (canonical). 70 %: module-wise uniform crossover
    (each module -- osc A, osc B + FM, sub, noise, filter, drive, amp env, mod env, LFO, key, space --
    taken whole from one parent, so a filter keeps its own envelope depth and an osc B its ratio);
    30 %: a blend a + t (b - a), t ~ U(0.2, 0.8), b_ratio and operator C's and D's ratios and
    routes from the nearer parent (a ratio half-way between two plateaus is a third, unrelated
    sound)."""
    rng = rng if rng is not None else np.random.default_rng()
    A = PR.canonical(np.asarray(a, np.float32).reshape(N_GENES)).astype(np.float64)
    B = PR.canonical(np.asarray(b, np.float32).reshape(N_GENES)).astype(np.float64)
    differ = [m for m, ix in enumerate(MODULE_IDX) if not np.array_equal(A[ix], B[ix])]
    out = np.empty((n, N_GENES))
    for r in range(n):
        if rng.random() < 0.3:
            t = rng.uniform(0.2, 0.8)
            c = A + t * (B - A)
            for j in (RATIO, C_RATIO, C_TGT, D_RATIO, D_TGT):
                c[j] = A[j] if t < 0.5 else B[j]
        else:
            pick = rng.random(len(MODULE_IDX)) < 0.5
            if len(differ) >= 2:                     # a child is neither parent
                if all(pick[m] for m in differ):
                    pick[rng.choice(differ)] = False
                if not any(pick[m] for m in differ):
                    pick[rng.choice(differ)] = True
            c = A.copy()
            for m, ix in enumerate(MODULE_IDX):
                if pick[m]:
                    c[ix] = B[ix]
        out[r] = c
    return PR.canonical(out.astype(np.float32))


def variations(genes, rng, n=4, amount=0.15, midi=60.0, gate_s=0.6, secs=1.0, check=True,
               pool=None):
    """Synplant-style BREED: n musically related variants of one genome -> float32[n, 40].

    A pool of mutants (pool, default 12 n: most at `amount`, a third at twice it) is rendered once
    (midi, gate_s, secs) when check=True; near-silent or clipping ones are dropped (prior.SILENT_DB,
    prior.CLIP_PEAK), so are ones the fitness cannot tell from the parent (< MIN_AUDIBLE) and the
    far tail of the pool (beyond its NEAR_QUANTILE of distance to the parent: a structure switch
    can land farther than a random prior genome). Of the rest, the n are chosen far apart from
    EACH OTHER in gene space (greedy farthest point,
    starting from the one at the median audible distance from the parent), so the choice offers
    different directions rather than four copies of the easiest one."""
    from .core import render_batch
    rng = rng if rng is not None else np.random.default_rng()
    g = PR.canonical(np.asarray(genes, np.float32).reshape(N_GENES))
    m = pool or 12 * n
    P = np.vstack([mutate(g, rng, m - m // 3, amount=amount, structure=True),
                   mutate(g, rng, m // 3, amount=2 * amount, structure=True)])
    P = np.unique(P, axis=0)
    P = P[~np.all(P == g[None], axis=1)]
    d_par = np.full(len(P), np.nan)
    if check and len(P):
        from . import fitness as FT
        Y = render_batch(np.vstack([g[None], P]), midi=midi, gate_s=gate_s, secs=secs)
        loud, peak = PR.level_stats(Y[1:])
        d_par = FT.Target(Y[0]).score(Y[1:]) if np.any(Y[0]) else np.full(len(P), 1.0)
        ok = (loud > PR.SILENT_DB) & (peak < PR.CLIP_PEAK) & (d_par >= MIN_AUDIBLE)
        if ok.sum() >= n:
            P, d_par = P[ok], d_par[ok]
            near = d_par <= np.quantile(d_par, NEAR_QUANTILE)     # related: not the far tail
            if near.sum() >= n:
                P, d_par = P[near], d_par[near]
    if len(P) <= n:
        extra = mutate(g, rng, n - len(P) + 1, amount=2 * amount) if len(P) < n else P[:0]
        return np.vstack([P, extra])[:n].astype(np.float32)
    first = int(np.nanargmin(np.abs(d_par - np.nanmedian(d_par)))) if check else int(rng.integers(len(P)))
    chosen = [first]
    dmin = np.linalg.norm(P - P[first][None], axis=1)
    while len(chosen) < n:
        k = int(np.argmax(dmin))
        chosen.append(k)
        dmin = np.minimum(dmin, np.linalg.norm(P - P[k][None], axis=1))
    return P[chosen].astype(np.float32)

