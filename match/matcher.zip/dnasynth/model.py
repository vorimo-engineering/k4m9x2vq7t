"""The INVERSE MODEL: one note's audio (+ its midi note and gate) -> a DISTRIBUTION over genomes.

    from dnasynth import model as M
    net = M.load("checkpoints/model.pt", device="mps")
    G = net.propose(audio, 44100, midi=48, k=8, gate_s=1.2)    # float32[8, 40], canonical
    # row 0 is the greedy decode (the model's mode); rows 1.. are samples, all distinct

WHY A DISTRIBUTION (docs/matcher/model.md; memory: synth-inversion-permutation-symmetry): patches
that sound alike are modes of a posterior, and one note cannot tell a key-tracked filter from a
fixed one. A point regression averages the modes into a genome that belongs to none of them. So
every gene is a TOKEN and the network is a masked discrete diffusion (MaskGIT-style) transformer
over the 40 gene tokens, cross-attending to an audio encoder: it learns p(gene tokens | audio,
midi, gate) jointly, and k candidates are k samples of it.

TOKENS (Tokenizer(bins=64); every grid holds the gene's EXACT neutral value, so "off" is a token.
64 bins, not 32: the tokenised truth's sound floor was measured at median 0.98 fitness units with
32 bins and 0.47 with 64, rvb_size / menv_pitch / b_detune / flt_cut carrying most of it):
  * b_ratio: its 16 plateaus (the centre of each);
  * a bipolar gene: an exact centre token (0.5, off: the whole dead zone +-0.02 maps to it) and
    bins//2 magnitudes per side, linear from 0.03 (just outside the dead zone) to 0.5;
  * a_pw, b_pw: bins+1 points on [0, 0.5] (canonical folds g and 1 - g onto one width);
  * a_wave, b_wave, flt_mode: 3*ceil(bins/3)+1 points on [0, 1], so the pure legs 0, 1/3, 2/3, 1
    (and the neutral saw) are grid points;
  * any other gene: bins+1 points on [0, 1]; a neutral that is not on that grid (amp_rel,
    mod_rel: 0.4) is inserted and the grid point next to it dropped.
  encode() maps a genome to the nearest grid value (in gene units; a bipolar gene inside its dead
  zone to the centre); decode() is exact. Grid values and neutral values round-trip exactly.

THE NETWORK (Net; 8.0 M parameters at the defaults d=256, 2 encoder + 4 decoder layers, 64 bins):
  audio   nnfeat.features [B, 198, 216] -> Conv1d stem (stride 4 in time) -> 54 tokens, + a learned
          position and the CONDITION (midi as Fourier features, the gate and whether it is known)
          -> a pre-LN transformer encoder;
  genes   40 tokens: a per-gene token embedding (a MASK token per gene), + a projection of the
          token's value (Fourier features; zero when masked), + the gene's position, + the
          condition -> pre-LN transformer decoder (self-attention over genes, cross-attention to
          the audio) -> per-gene logits over that gene's own grid (other tokens at -1e4);
  aux     from the mean audio token: the STRUCTURE head (40 logits: which genes are active,
          prior.active_mask) and the FAMILY head (7 prior families). Auxiliary losses; the
          structure head is a direct read-out of "which sources make this sound".
TRAINING (loss): a mask ratio r = cos(pi/2 u), u ~ U(0,1), ceil(40 r) random genes masked; CE on
the masked genes against the true tokens, label-smoothed by `smooth` onto the ordinal neighbours
(never onto or off the neutral token, never for b_ratio), + aux_w * (structure BCE + family CE).
SAMPLING (sample_tokens): MaskGIT -- start all-masked; each of `steps` steps predicts every masked
gene, draws a token (temperature), keeps the most confident draws (confidence = log p, plus Gumbel
noise that fades over the steps) and re-masks the rest on a cosine schedule. Greedy rows take the
argmax with no noise -- STRUCTURE FIRST (greedy_choice): off when P(off) >= 0.5, else the best
value token; a plain argmax would call a gene off whenever its "on" mass is spread over bins.
"""
from __future__ import annotations

import math
import os

import numpy as np

from .core import GENES, GENE_INDEX                   # v1's; every function takes the engine's
from .core import N_GENES_V2 as N_GENES               # the default engine v1 is its 40 genes
from . import engines as EN
from . import nnfeat as NF

_I = GENE_INDEX
MODEL_VERSION = 1
# v1's sets, kept as module names for the code and tests that read them (the grids use the engine's)
FOLD = ("a_pw", "b_pw")
LEG_GENES = ("a_wave", "b_wave", "flt_mode")
N_FAM = 7


# ============================================================================= tokens

C_SLOPE_POINTS = (0.42, 0.58)       # "cratio": the slope points, as fractions of a log2 gap


def _grid(gene, bins, E):
    name, i = gene.name, gene.index
    neu = E.neutral[i]
    if name in E.selectors:
        k = E.selectors[name]
        return ((np.arange(k) + 0.5) / k).astype(np.float32), "ratio"
    if name == "c_ratio" and E.name == "v1y":
        # operator C's ratio by its plateaus (one token each, the engine plays exactly that ratio
        # anywhere on one) and two inharmonic points on every slope between them (literature.md,
        # network section 7: categorical tokens for detented controls)
        from . import prior as PR
        L = np.log2(np.asarray(PR.C_RATIOS, np.float64))
        pts = list(PR.C_CENTRES) + [(a + f * (b - a) + 1.0) / 5.0 for a, b in zip(L[:-1], L[1:])
                                    for f in C_SLOPE_POINTS]
        gr = np.sort(np.asarray(pts)).astype(np.float32)
        gr[int(np.argmin(np.abs(gr - neu)))] = neu
        return gr, "cratio"
    if gene.bipolar:
        half = bins // 2
        mags = np.linspace(E.dz + 0.01, 0.5, half)
        gr = np.concatenate([0.5 - mags[::-1], [0.5], 0.5 + mags]).astype(np.float32)
        return gr, "bip"
    if name in E.fold:
        gr = np.linspace(0.0, 0.5, bins + 1).astype(np.float32)
        return gr, "fold"
    nb = 3 * int(math.ceil(bins / 3.0)) if name in E.legs else bins
    nb *= int(getattr(E, "fine", {}).get(name, 1))    # a gene the grid must resolve finer
    gr = np.linspace(0.0, 1.0, nb + 1)
    if np.min(np.abs(gr - float(neu))) > 1e-7:
        gr = np.sort(np.append(gr[np.abs(gr - float(neu)) > 0.4 / nb], float(neu)))
    gr = gr.astype(np.float32)
    gr[int(np.argmin(np.abs(gr - neu)))] = neu            # the engine's exact float32 neutral
    return gr, "lin"


class Tokenizer:
    """Per-gene grids of one engine (engines.get(engine)). encode(genes[n, N]) -> int64[n, N];
    decode(tokens) -> float32[n, N]."""

    def __init__(self, bins=64, engine="v1"):
        self.bins = int(bins)
        self.E = EN.get(engine)
        self.n = self.E.n
        self.grids, self.kinds = [], []
        for g in self.E.genes:
            gr, kind = _grid(g, self.bins, self.E)
            self.grids.append(gr)
            self.kinds.append(kind)
        self.sizes = np.array([len(x) for x in self.grids], np.int64)
        self.V = int(self.sizes.max())
        self.MASK = self.V
        self.values = np.tile(self.E.neutral[:, None], (1, self.V)).astype(np.float32)
        self.valid = np.zeros((self.n, self.V), bool)
        for i, gr in enumerate(self.grids):
            self.values[i, :len(gr)] = gr
            self.valid[i, :len(gr)] = True
        self.neutral_tok = np.array([int(np.flatnonzero(gr == self.E.neutral[i])[0])
                                     for i, gr in enumerate(self.grids)], np.int64)
        # nearest-grid search: midpoints in float64 (a grid value maps to itself exactly)
        self._mids = []
        for i, gr in enumerate(self.grids):
            g64 = gr.astype(np.float64)
            if self.kinds[i] == "bip":
                c = int(self.neutral_tok[i])
                side = np.delete(g64, c)                   # nearest among the side tokens only
                self._mids.append((side[1:] + side[:-1]) / 2.0)
            else:
                self._mids.append((g64[1:] + g64[:-1]) / 2.0)
        self.step = np.array([float(np.median(np.diff(gr))) for gr in self.grids])
        self._cratio = {}                      # "cratio" gene -> (plateau -> token, slope tokens)
        for i, kind in enumerate(self.kinds):
            if kind == "cratio":
                from . import prior as PR
                gr = self.grids[i]
                pl = np.array([int(np.argmin(np.abs(gr - c))) for c in PR.C_CENTRES])
                sl = np.setdiff1d(np.arange(len(gr)), pl)
                self._cratio[i] = (pl, sl)

    def encode(self, genes):
        G = np.atleast_2d(np.array(genes, np.float32, copy=True))
        bad = ~np.isfinite(G)
        G[bad] = np.broadcast_to(self.E.neutral, G.shape)[bad]
        G = np.clip(G, 0.0, 1.0)
        T = np.empty(G.shape, np.int64)
        for i in range(self.n):
            v = G[:, i].astype(np.float64)
            kind = self.kinds[i]
            if kind == "ratio":
                T[:, i] = self.E.plateau(self.E.genes[i].name, v)
            elif kind == "cratio":                          # its plateau, else the nearest slope point
                from . import prior as PR
                pl, sl = self._cratio[i]
                p = PR.c_plateau(v)
                gs = self.grids[i][sl].astype(np.float64)
                near = sl[np.argmin(np.abs(v[:, None] - gs[None]), axis=1)]
                T[:, i] = np.where(p >= 0, pl[np.maximum(p, 0)], near)
            elif kind == "fold":
                T[:, i] = np.searchsorted(self._mids[i], np.minimum(v, 1.0 - v))
            elif kind == "bip":
                c = int(self.neutral_tok[i])
                j = np.searchsorted(self._mids[i], v)       # index among the side tokens
                j = np.where(j >= c, j + 1, j)
                T[:, i] = np.where(np.abs(v - 0.5) <= self.E.dz, c, j)
            else:
                T[:, i] = np.searchsorted(self._mids[i], v)
        return T

    def decode(self, tokens):
        t = np.atleast_2d(np.asarray(tokens, np.int64))
        t = np.clip(t, 0, self.sizes[None] - 1)
        return self.values[np.arange(self.n)[None], t].astype(np.float32)

    def is_neutral(self, tokens):
        return np.asarray(tokens) == self.neutral_tok[None]

    def smoothing(self, smooth):
        """[N, V, V]: row t of gene g is the training target for true token t (label smoothing
        `smooth` spread over the ordinal neighbours t-1, t+1, never across the neutral token)"""
        S = np.zeros((self.n, self.V, self.V), np.float32)
        for i in range(self.n):
            n, c = int(self.sizes[i]), int(self.neutral_tok[i])
            for t in range(self.V):
                S[i, t, min(t, n - 1)] = 1.0
                if smooth <= 0 or t >= n or t == c or self.kinds[i] in ("ratio", "cratio"):
                    continue
                nb = [u for u in (t - 1, t + 1) if 0 <= u < n and u != c]
                if nb:
                    S[i, t, t] = 1.0 - smooth
                    for u in nb:
                        S[i, t, u] = smooth / len(nb)
        return S


# ============================================================================= the network

N_COND = 12


def cond_features(midi, gate_s, secs=NF.SECS):
    """[B, N_COND] float32: midi as Fourier features, the gate (in windows) and a known flag"""
    B = max(len(np.atleast_1d(midi)), len(np.atleast_1d(gate_s)) if gate_s is not None else 1)
    m = (np.broadcast_to(np.asarray(midi, np.float64), (B,)) - 60.0) / 24.0
    ga = NF._gate_array(gate_s, B)
    known = np.isfinite(ga)
    gw = np.where(known, np.minimum(ga, secs + 0.5) / secs, 0.0)
    cols = [m]
    for j in (1, 2, 4, 8):
        cols += [np.sin(np.pi * m * j / 2), np.cos(np.pi * m * j / 2)]
    cols += [gw, known.astype(np.float64), 1.0 - known.astype(np.float64)]
    return np.stack(cols, 1).astype(np.float32)


def _torch():
    import torch
    return torch


def build_net(cfg, tok):
    torch = _torch()
    nn = torch.nn

    class Net(nn.Module):
        def __init__(self):
            super().__init__()
            d, h, V = cfg["d"], cfg["heads"], tok.V
            self.V = V
            self.n_genes, self.n_fam = tok.n, len(tok.E.families)
            NG = tok.n
            gn = lambda: nn.GroupNorm(8, d)                                    # noqa: E731
            s2 = 1 if int(cfg.get("stem_stride", 4)) == 2 else 2     # 4: 46 ms tokens, 2: 23 ms
            self.stem = nn.Sequential(
                nn.Conv1d(cfg["n_ch"], d, 5, padding=2), gn(), nn.GELU(),
                nn.Conv1d(d, d, 3, stride=2, padding=1), gn(), nn.GELU(),
                nn.Conv1d(d, d, 3, stride=s2, padding=1), gn(), nn.GELU())
            self.pos_a = nn.Parameter(torch.randn(1, cfg["max_t"], d) * 0.02)
            self.cond = nn.Sequential(nn.Linear(N_COND, d), nn.GELU(), nn.Linear(d, d))
            el = nn.TransformerEncoderLayer(d, h, cfg["ff"] * d, cfg["dropout"], activation="gelu",
                                            batch_first=True, norm_first=True)
            self.enc = nn.TransformerEncoder(el, cfg["enc_layers"], enable_nested_tensor=False)
            self.enc_norm = nn.LayerNorm(d)
            self.tok_emb = nn.Embedding(NG * (V + 1), d)
            self.val_proj = nn.Linear(9, d)
            self.gene_pos = nn.Parameter(torch.randn(1, NG, d) * 0.02)
            dl = nn.TransformerDecoderLayer(d, h, cfg["ff"] * d, cfg["dropout"], activation="gelu",
                                            batch_first=True, norm_first=True)
            self.dec = nn.TransformerDecoder(dl, cfg["dec_layers"])
            self.dec_norm = nn.LayerNorm(d)
            self.head_w = nn.Parameter(torch.randn(NG, d, V) * d ** -0.5)
            self.head_b = nn.Parameter(torch.zeros(NG, V))
            self.aux = nn.Sequential(nn.LayerNorm(d), nn.Linear(d, d), nn.GELU(),
                                     nn.Linear(d, NG + self.n_fam))
            self.register_buffer("valid", torch.as_tensor(tok.valid))
            self.register_buffer("values", torch.as_tensor(tok.values))
            self.register_buffer("offs", torch.arange(NG) * (V + 1))

        def encode(self, feats, cond):
            c = self.cond(cond)                                                 # [B, d]
            x = self.stem(feats).transpose(1, 2)                                # [B, T', d]
            x = x + self.pos_a[:, :x.shape[1]] + c[:, None]
            mem = self.enc_norm(self.enc(x))
            aux = self.aux(mem.mean(dim=1))
            return mem, aux, c

        def decode(self, tokens, mem, c):
            V = self.V
            masked = tokens >= V
            tk = torch.where(masked, torch.full_like(tokens, V), tokens)
            h = self.tok_emb(self.offs[None] + tk)
            gi = torch.arange(self.n_genes, device=tokens.device)[None].expand_as(tokens)
            val = self.values[gi, torch.clamp(tk, max=V - 1)]                  # [B, N]
            ph = val[..., None] * torch.tensor([1.0, 2.0, 4.0, 8.0], device=val.device) * math.pi
            vf = torch.cat([val[..., None], torch.sin(ph), torch.cos(ph)], -1)
            vf = vf * (~masked)[..., None].float()
            h = h + self.val_proj(vf) + self.gene_pos + c[:, None]
            h = self.dec_norm(self.dec(h, mem))
            logits = torch.einsum("bgd,gdv->bgv", h, self.head_w) + self.head_b[None]
            return logits.masked_fill(~self.valid[None], -1e4)

    return Net()


DEFAULT_CFG = dict(d=256, heads=4, ff=4, enc_layers=2, dec_layers=4, dropout=0.1, bins=64,
                   n_ch=NF.N_CH, max_t=64, secs=NF.SECS, feat_version=NF.VERSION,
                   model_version=MODEL_VERSION, engine="v1", norm=None)


def make_cfg(**kw):
    cfg = dict(DEFAULT_CFG)
    cfg.update({k: v for k, v in kw.items() if v is not None})
    return cfg


def n_params(net):
    return int(sum(p.numel() for p in net.parameters()))


# ============================================================================= loss

def mask_batch(B, gen, device, n_genes=N_GENES):
    """the MaskGIT training mask: r = cos(pi/2 u), ceil(N r) random genes (>= 1) per example"""
    torch = _torch()
    u = torch.rand(B, generator=gen)
    n = torch.clamp(torch.ceil(torch.cos(u * math.pi / 2) * n_genes), 1, n_genes).long()
    ranks = torch.rand(B, n_genes, generator=gen).argsort(1).argsort(1)
    return (ranks < n[:, None]).to(device)


def loss_fn(net, feats, cond, tokens, active, fam, smooth_mat, mask, aux_w=0.2):
    """-> (loss, stats dict of floats-as-tensors). tokens/active/fam on the device (fam unused
    for an engine without families); smooth_mat [N, V, V] on the device; mask bool [B, N]"""
    torch = _torch()
    F = torch.nn.functional
    V = net.V
    inp = tokens.masked_fill(mask, V)
    mem, aux, c = net.encode(feats, cond)
    logits = net.decode(inp, mem, c)
    logp = F.log_softmax(logits, -1)
    NG = tokens.shape[1]
    gi = torch.arange(NG, device=tokens.device)[None].expand_as(tokens)
    target = smooth_mat[gi, tokens]                                            # [B, N, V]
    ce = -(target * logp).sum(-1)
    mf = mask.float()
    nm = mf.sum().clamp(min=1.0)
    l_tok = (ce * mf).sum() / nm
    l_str = F.binary_cross_entropy_with_logits(aux[:, :NG], active.float())
    l_fam = F.cross_entropy(aux[:, NG:], fam) if net.n_fam else torch.zeros_like(l_str)
    loss = l_tok + aux_w * (l_str + l_fam)
    with torch.no_grad():
        acc = ((logits.argmax(-1) == tokens).float() * mf).sum() / nm
    return loss, dict(loss=loss.detach(), tok=l_tok.detach(), str=l_str.detach(),
                      fam=l_fam.detach(), acc=acc)


# ============================================================================= sampling

def greedy_choice(logits, neutral=None, on_threshold=0.5):
    """the greedy token per gene. neutral None: the plain argmax. With the per-gene neutral token
    indices ([40] long tensor): STRUCTURE FIRST -- the gene is off (its neutral token) when
    P(neutral) >= on_threshold, else the argmax among its value tokens. The plain argmax is biased
    to "off": an active gene's mass is spread over up to 66 value tokens, so the single neutral
    token wins the argmax even at P(on) > 0.5 (measured on the 16-minute smoke model: 90.8 % of
    greedy tokens decoded off where the prior has ~74 % off)."""
    torch = _torch()
    if neutral is None:
        return logits.argmax(-1)
    n, NG = logits.shape[0], logits.shape[1]
    idx = neutral[None, :, None].expand(n, NG, 1)
    p_off = torch.softmax(logits, -1).gather(2, idx)[..., 0]
    arg_on = logits.scatter(2, idx, -1e9).argmax(-1)
    return torch.where(p_off >= on_threshold, neutral[None].expand(n, NG), arg_on)


def sample_tokens(net, mem, c, k, steps=12, temperature=1.0, greedy_rows=1, choice_noise=1.0,
                  neutral=None, on_threshold=0.5):
    """MaskGIT decode. mem [B, T, d], c [B, d] -> int64 [B, k, 40] on the device. The first
    `greedy_rows` of each target's k are greedy (greedy_choice: structure first when `neutral`,
    the per-gene neutral token indices, is given; no noise), the rest sampled (torch's global
    RNG: seed it with torch.manual_seed for a repeatable draw)."""
    torch = _torch()
    F = torch.nn.functional
    dev = mem.device
    B = mem.shape[0]
    V = net.V
    mem_k = mem.repeat_interleave(k, 0)
    c_k = c.repeat_interleave(k, 0)
    n = B * k
    NG = net.n_genes
    tokens = torch.full((n, NG), V, dtype=torch.long, device=dev)
    greedy = (torch.arange(n, device=dev) % k) < greedy_rows
    n_masked = NG
    for s in range(steps):
        logits = net.decode(tokens, mem_k, c_k)
        logp = F.log_softmax(logits, -1)
        if temperature > 0:
            probs = F.softmax(logits / temperature, -1)
            draw = torch.multinomial(probs.reshape(-1, V), 1).reshape(n, NG)
        else:
            draw = logits.argmax(-1)
        if greedy_rows > 0:
            draw = torch.where(greedy[:, None], greedy_choice(logits, neutral, on_threshold), draw)
        masked = tokens >= V
        chosen = torch.where(masked, draw, tokens)
        conf = torch.gather(logp, 2, chosen[..., None])[..., 0]
        if s < steps - 1:
            u = torch.rand(n, NG, device=dev)
            gum = -torch.log(-torch.log(u.clamp(1e-9, 1 - 1e-9)))
            noise = choice_noise * (1.0 - (s + 1) / steps)
            conf = conf + noise * gum * (~greedy)[:, None].float()
        conf = torch.where(masked, conf, torch.full_like(conf, float("inf")))
        n_next = int(math.floor(NG * math.cos(math.pi / 2 * (s + 1) / steps)))
        n_next = max(0, min(n_next, n_masked - 1)) if s < steps - 1 else 0
        if n_next > 0:
            order = conf.argsort(1)                                             # lowest first
            remask = torch.zeros_like(masked)
            remask.scatter_(1, order[:, :n_next], True)
        else:
            remask = torch.zeros_like(masked)
        tokens = torch.where(remask, torch.full_like(chosen, V), chosen)
        n_masked = n_next
        if n_masked == 0:
            break
    return tokens.reshape(B, k, NG)


def infill_tokens(net, mem, c, init, steps=8, temperature=1.0, choice_noise=1.0, force_on=None,
                  neutral=None):
    """MaskGIT decode of the MASKED genes only (the search's conditional proposal). mem [n, T, d],
    c [n, d], init int64 [n, NG] (the kept genes' tokens, net.V where the gene is to be drawn) ->
    int64 [n, NG]: kept tokens unchanged, every masked one drawn given the audio AND the kept
    genes. The re-mask schedule is MaskGIT's cosine over each row's own masked count. force_on
    bool [n, NG] (with `neutral`, the per-gene neutral token indices): those genes may not draw
    their neutral token (a module the search is switching on)."""
    torch = _torch()
    F = torch.nn.functional
    dev = mem.device
    V = net.V
    tokens = init.clone()
    n, NG = tokens.shape
    m0 = (tokens >= V).sum(1)                                   # each row's masked count
    ban = None
    if force_on is not None and neutral is not None:
        ban = torch.zeros(n, NG, V, dtype=torch.bool, device=dev)
        ban.scatter_(2, neutral[None, :, None].expand(n, NG, 1), force_on[..., None])
    for s in range(steps):
        masked = tokens >= V
        if not bool(masked.any()):
            break
        logits = net.decode(tokens, mem, c)
        if ban is not None:
            logits = logits.masked_fill(ban, -1e9)
        logp = F.log_softmax(logits, -1)
        if temperature > 0:
            probs = F.softmax(logits / temperature, -1)
            draw = torch.multinomial(probs.reshape(-1, V), 1).reshape(n, NG)
        else:
            draw = logits.argmax(-1)
        chosen = torch.where(masked, draw, tokens)
        conf = torch.gather(logp, 2, chosen[..., None])[..., 0]
        if s < steps - 1:
            u = torch.rand(n, NG, device=dev)
            gum = -torch.log(-torch.log(u.clamp(1e-9, 1 - 1e-9)))
            conf = conf + choice_noise * (1.0 - (s + 1) / steps) * gum
            n_next = torch.floor(m0.float() * math.cos(math.pi / 2 * (s + 1) / steps)).long()
            n_next = torch.minimum(n_next, (masked.sum(1) - 1).clamp(min=0))
        else:
            n_next = torch.zeros_like(m0)
        conf = torch.where(masked, conf, torch.full_like(conf, float("inf")))
        rank = conf.argsort(1).argsort(1)                          # 0 = the least confident
        remask = rank < n_next[:, None]
        tokens = torch.where(remask, torch.full_like(chosen, V), chosen)
    return tokens


# ============================================================================= the model

class Model:
    """A loaded inverse model. propose() is the matcher's entry point."""

    def __init__(self, net, tok, cfg, device, structured_greedy=True):
        torch = _torch()
        self.net, self.tok, self.cfg = net, tok, cfg
        self.device = device
        self.secs = float(cfg.get("secs", NF.SECS))
        self.norm = cfg.get("norm")                      # nnfeat.features' level rule (None: raw)
        self.feat_version = int(cfg.get("feat_version", 1))   # nnfeat.features' channels
        self.neutral = torch.as_tensor(tok.neutral_tok, device=device)
        self.structured_greedy = structured_greedy       # greedy_choice's structure-first rule

    def _prep(self, audios, sr):
        torch = _torch()
        A = [NF.resample(np.asarray(a, np.float32).ravel(), sr) for a in audios]
        n = NF.n_samples(self.secs)
        return torch.as_tensor(np.stack([NF.fit_length(a, n)[0] for a in A]))

    def encode(self, audios, sr, midi, gate_s):
        torch = _torch()
        x = self._prep(audios, sr)
        B = x.shape[0]
        midi = np.broadcast_to(np.asarray(midi, np.float64), (B,))
        gate = NF._gate_array(gate_s, B)
        feats = NF.features(x, midi, gate, device=self.device, secs=self.secs, norm=self.norm,
                            version=self.feat_version)
        cond = torch.as_tensor(cond_features(midi, gate, self.secs), device=self.device)
        return self.net.encode(feats, cond)

    def propose_many(self, audios, sr=44100.0, midi=60.0, k=8, gate_s=None, temperature=1.0,
                     steps=12, seed=None, greedy_first=True, oversample=2, batch=16):
        """B notes -> float32 [B, k, 40] canonical genomes, k distinct per note where the model
        allows (duplicates are replaced from an oversampled pool; row 0 greedy if greedy_first)"""
        torch = _torch()
        self.net.eval()
        audios = [audios] if np.asarray(audios[0]).ndim == 0 else list(audios)
        B = len(audios)
        midi = np.broadcast_to(np.asarray(midi, np.float64), (B,))
        gate = NF._gate_array(gate_s, B)
        if seed is not None:
            torch.manual_seed(int(seed))
        kk = max(k, int(math.ceil(k * max(oversample, 1))))
        out = np.zeros((B, k, self.tok.n), np.float32)
        with torch.no_grad():
            for a in range(0, B, batch):
                sl = slice(a, min(B, a + batch))
                mem, _, c = self.encode(audios[sl], sr, midi[sl], gate[sl])
                toks = sample_tokens(self.net, mem, c, kk, steps=steps, temperature=temperature,
                                     greedy_rows=1 if greedy_first else 0,
                                     neutral=self.neutral if self.structured_greedy else None)
                toks = toks.cpu().numpy()
                for bi in range(toks.shape[0]):
                    G = self.tok.E.canonical(self.tok.decode(toks[bi]))
                    keep, seen = [], set()
                    for r in range(kk):
                        key = G[r].tobytes()
                        if key not in seen:
                            seen.add(key)
                            keep.append(r)
                        if len(keep) == k:
                            break
                    while len(keep) < k:                       # the model is sure: repeat rows
                        keep.append(keep[len(keep) % max(1, len(seen))])
                    out[a + bi] = G[keep]
        return out

    def propose(self, audio, sr=44100.0, midi=60.0, k=8, gate_s=None, **kw):
        """one note -> float32[k, 40]: k diverse canonical candidate genomes (row 0 = greedy)"""
        return self.propose_many([np.asarray(audio, np.float32).ravel()], sr, midi, k, gate_s,
                                 **kw)[0]

    def target_state(self, audio, sr=44100.0, midi=60.0, gate_s=None):
        """one note's encoder output (mem [1, T, d], c [1, d]) for infill(): encode the target
        once per match, then ask for as many conditional proposals as the search wants"""
        torch = _torch()
        self.net.eval()
        with torch.no_grad():
            mem, _, c = self.encode([np.asarray(audio, np.float32).ravel()], sr, [midi],
                                    [np.nan if gate_s is None else gate_s])
        return mem, c

    def infill(self, state, G, masks, k=1, temperature=1.0, steps=8, seed=None, force_on=None):
        """CONDITIONAL proposals: for each genome G[r] (float32 [R, N], the search's gene space),
        draw the genes where masks[r] is True given the target (state = target_state(...)) and
        every other gene of G[r] -> float32 [R, k, N], canonical. The kept genes keep their EXACT
        values (their tokens only condition the draw). force_on bool [R, N]: genes that may not be
        drawn off. A network of fewer genes than N (a 40-gene v1 network in the 46-gene search)
        draws among its own genes and keeps the rest."""
        torch = _torch()
        self.net.eval()
        G = np.atleast_2d(np.asarray(G, np.float32))
        masks = np.atleast_2d(np.asarray(masks, bool))
        R, N = G.shape
        nt = self.tok.n
        if seed is not None:
            torch.manual_seed(int(seed))
        tok = self.tok.encode(G[:, :nt])
        tok = np.where(masks[:, :nt], self.tok.MASK, tok)
        init = torch.as_tensor(np.repeat(tok, k, 0), device=self.device)
        fo = None
        if force_on is not None:
            fo = torch.as_tensor(np.repeat(np.atleast_2d(force_on)[:, :nt], k, 0),
                                 device=self.device)
        mem, c = state
        with torch.no_grad():
            out = infill_tokens(self.net, mem.repeat(R * k, 1, 1), c.repeat(R * k, 1), init,
                                steps=steps, temperature=temperature, force_on=fo,
                                neutral=self.neutral)
        D = self.tok.decode(out.cpu().numpy())                                   # [R k, nt]
        full = np.repeat(G, k, 0)
        keep = np.repeat(masks, k, 0)
        full[:, :nt] = np.where(keep[:, :nt], D, full[:, :nt])
        if nt == N:
            return self.tok.E.canonical(full).reshape(R, k, N)
        from . import prior as PR                         # the 46-gene search space
        return PR.canonical(full).reshape(R, k, N)

    def structure(self, audio, sr=44100.0, midi=60.0, gate_s=None):
        """the aux heads for one note: (P(active) float32[40], P(family) float32[7])"""
        torch = _torch()
        self.net.eval()
        with torch.no_grad():
            _, aux, _ = self.encode([np.asarray(audio, np.float32).ravel()], sr, [midi],
                                    [np.nan if gate_s is None else gate_s])
            NG = self.tok.n
            a = torch.sigmoid(aux[0, :NG]).cpu().numpy()
            f = (torch.softmax(aux[0, NG:], -1).cpu().numpy() if self.net.n_fam
                 else np.zeros(0, np.float32))
        return a.astype(np.float32), f.astype(np.float32)


def default_device():
    torch = _torch()
    return "mps" if torch.backends.mps.is_available() else "cpu"


def save(path, net, cfg, **extra):
    """atomic checkpoint write: cfg + net state + anything in extra (optimizer, step, rng ...)"""
    torch = _torch()
    tmp = path + ".tmp"
    torch.save(dict(cfg=cfg, net=net.state_dict(), **extra), tmp)
    os.replace(tmp, path)


def warm_start(net, tok, path):
    """initialise a NEW network from a trained checkpoint of another gene layout of the same
    architecture (d, heads, layers, bins, vocabulary): every weight whose shape matches is copied,
    and the per-gene weights -- token embeddings, gene positions, output heads, the structure head's
    rows -- gene by gene where the gene's NAME and grid are the same in both layouts (the family rows
    too). The version-3 v1 (engine v1x) starts from the version-2 v1 network so; its six new genes
    start fresh. -> dict(copied=[param names], genes=[gene names carried])"""
    torch = _torch()
    ck = torch.load(path, map_location="cpu", weights_only=False)
    old_cfg, old = ck["cfg"], ck["net"]
    otok = Tokenizer(old_cfg["bins"], old_cfg.get("engine", "v1"))
    if otok.V != tok.V:
        raise ValueError("vocabularies differ (%d vs %d): no warm start" % (otok.V, tok.V))
    oidx = {g.name: g.index for g in otok.E.genes}
    pairs = [(g.index, oidx[g.name]) for g in tok.E.genes
             if g.name in oidx and np.array_equal(tok.grids[g.index], otok.grids[oidx[g.name]])]
    new_i = torch.as_tensor([a for a, _ in pairs], dtype=torch.long)     # long even when empty: a
    old_i = torch.as_tensor([b for _, b in pairs], dtype=torch.long)     # layout sharing no gene
    sd = net.state_dict()
    copied = []
    with torch.no_grad():
        for k, v in old.items():
            if k not in sd or k in ("valid", "values", "offs"):
                continue
            t = sd[k]
            v = v.to(t.device)
            ni, oi = new_i.to(t.device), old_i.to(t.device)
            if t.shape == v.shape:
                t.copy_(v)
                copied.append(k)
            elif k == "stem.0.weight" and t.shape[0] == v.shape[0] and t.shape[2] == v.shape[2] \
                    and t.shape[1] > v.shape[1]:
                # more input channels (feature version 3 = version 1's, then new ones): the old
                # channels keep their weights, the new ones start at zero -- the same function
                t.zero_()
                t[:, :v.shape[1]] = v
                copied.append(k + " (+%d zero channels)" % (t.shape[1] - v.shape[1]))
            elif k == "tok_emb.weight":
                W = tok.V + 1
                for a, b in pairs:
                    t[a * W:(a + 1) * W] = v[b * W:(b + 1) * W]
                copied.append(k + " (per gene)")
            elif k == "gene_pos":
                t[:, ni] = v[:, oi]
                copied.append(k + " (per gene)")
            elif k in ("head_w", "head_b"):
                t[ni] = v[oi]
                copied.append(k + " (per gene)")
            elif k.startswith("aux.") and t.shape[1:] == v.shape[1:]:
                # rows: the genes, then the families -- the same families in both, or (one engine)
                # the checkpoint's, which the engine has since appended to (dashx's "free",
                # 2026-10-05); the appended ones start fresh
                t[ni] = v[oi]
                nf, of = len(tok.E.families), v.shape[0] - otok.n
                if nf and (of == nf or (0 < of < nf and old_cfg.get("engine", "v1") == tok.E.name)):
                    t[tok.n:tok.n + of] = v[otok.n:otok.n + of]
                copied.append(k + " (per gene)")
    net.load_state_dict(sd)
    return dict(copied=copied, genes=[tok.E.genes[a].name for a, _ in pairs])


def load(path, device=None):
    """a checkpoint written by scripts/train.py -> Model (eval mode) on `device` (None: mps if
    available, else cpu)"""
    torch = _torch()
    device = device or default_device()
    ck = torch.load(path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    tok = Tokenizer(cfg["bins"], cfg.get("engine", "v1"))
    net = build_net(cfg, tok)
    sd, nf = ck["net"], len(tok.E.families)
    w = sd.get("aux.3.weight")
    if w is not None and nf and w.shape[0] < tok.n + nf:
        # trained before its engine appended a family (dashx's "free", 2026-10-05): the old
        # families keep their rows, the new ones are never proposed (weight 0, bias -30)
        k = tok.n + nf - w.shape[0]
        sd = dict(sd)
        sd["aux.3.weight"] = torch.cat([w, w.new_zeros(k, w.shape[1])])
        sd["aux.3.bias"] = torch.cat([sd["aux.3.bias"], sd["aux.3.bias"].new_full((k,), -30.0)])
    net.load_state_dict(sd)
    net.to(device).eval()
    m = Model(net, tok, cfg, device)
    m.meta = {k: ck[k] for k in ("step", "samples", "elapsed_s") if k in ck}
    return m
