"""DNA v2: the voice on PchKraft's own graph engine (see voice.py)."""
