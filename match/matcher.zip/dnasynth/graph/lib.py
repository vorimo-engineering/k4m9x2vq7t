"""dnasynth/graph/lib.py IN THE BROWSER (match/pack.py puts this file in matcher.zip in place of the
native ctypes binding): one note of a patch document on the web synth's own wasm engine, through the
worker's JavaScript (match/render.js renderNote) -- the same C patch loader (pcks_patch_load), the
same compile and the same steps as the native render_note: 2048 frames of silence (the smoothers
settle), note on, held gate_s, note off, the rest, mono (L+R)/2.

render_batch is where the browser's parallelism lives: when the worker offers `pcksRenderBatch`
(a pool of engine workers, match/worker.js) a batch goes to it whole; otherwise note by note here."""
from __future__ import annotations

import json

import numpy as np


class PatchError(RuntimeError):
    pass


def _js():
    import js                                        # Pyodide's bridge to the worker's globals
    return js


def _text(doc):
    if isinstance(doc, (bytes, bytearray)):
        return bytes(doc).decode()
    return doc if isinstance(doc, str) else json.dumps(doc)


def _array(r):
    if isinstance(r, str):
        raise PatchError(r)
    return np.array(r.to_py(), dtype=np.float32)


def _midi(midi):
    """a note (a number) or a chord (a JSON list of numbers, as render.js takes it)"""
    m = np.atleast_1d(np.asarray(midi, np.float64))
    return float(m[0]) if m.size == 1 and np.ndim(midi) == 0 else json.dumps([float(v) for v in m])


def render_note(doc_bytes, midi, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, warm=2048):
    """one note, or a chord (midi a sequence: every key at once, as the native render_note)"""
    return _array(_js().pcksRenderNote(_text(doc_bytes), _midi(midi), float(vel), float(gate_s), float(secs),
                                       float(sr), int(warm)))


def render_batch(docs, midi, vel=100 / 127, gate_s=1.2, secs=2.5, sr=44100.0, threads=4, chord=None):
    B = len(docs)
    mm = (np.broadcast_to(np.asarray(midi, np.float64), (B,)).tolist() if chord is None
          else [[float(k) for k in chord]] * B)
    vv = np.broadcast_to(np.asarray(vel, np.float64), (B,))
    js = _js()
    if B > 1 and hasattr(js, "pcksRenderBatch"):
        r = js.pcksRenderBatch(json.dumps([_text(d) for d in docs]), json.dumps(mm),
                               json.dumps(vv.tolist()), float(gate_s), float(secs), float(sr))
        return _array(r).reshape(B, -1)
    return np.stack([render_note(d, m, v, gate_s, secs, sr) for d, m, v in zip(docs, mm, vv)])


def _native_only(*a, **k):
    raise NotImplementedError("the browser's engine binding renders notes only (render_note, render_batch)")


load = destroy = render_frames = retune = check_threads = _native_only
