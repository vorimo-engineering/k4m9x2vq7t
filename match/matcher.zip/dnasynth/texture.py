"""The ruler's TEXTURE terms: what a note does that its spectrum frames do not say -- how each band
MOVES (tremolo, beating, looping envelopes), how NOISY it is, how WIDE (stereo), and how its low
PITCH moves (a kick's drop). Measured blind spots of dnasynth.fitness (docs/DNA_V3_ANALYSIS.md
section 4: a match whose spectrum is 4.5 dB off moved 21 dB off; a kick's 99 -> 39 Hz sweep in
60 ms is invisible at the fitness's FFT sizes).

    from dnasynth import texture as TX
    T = TX.Target(audio, sr, stereo=st)            # st: the target's [n, 2], optional
    s = T.score(cands, cands_stereo=None)          # base fitness + the texture terms, float32[K]

Every term is LEVEL-FREE (dB fluctuations about their own trend, flatness ratios, side/mid
ratios, frequencies), so it composes with fitness.Target's free gain unchanged. Every term is
computed where the TARGET is active (its masks), weighted by how much of the target lives there.

TERMS (each in its natural unit; W_* bring them to the fitness's scale):
  mod     per octave band (62.5 Hz .. 16 kHz), the level envelope (dB, 5.8 ms hop) over the
          target's active span, minus its own quadratic trend (a decay is the fitness's business),
          Hann-windowed, its 1..40 Hz spectrum pooled into 8 log-spaced modulation bands, as dB
          of fluctuation amplitude floored at MOD_FLOOR dB: |candidate - target|, mean over
          modulation bands, weighted by the target's band energy
  flat    per third-octave band (100 Hz .. 16 kHz, 4096-point frames), spectral flatness
          (geometric / arithmetic mean power) in log10, averaged over the target's active frames:
          |candidate - target|, weighted by the target's band energy (square-rooted, so the top
          octaves count)
  stereo  per octave band, side / mid power in dB over the target's active span, floored at
          STEREO_FLOOR dB (a mono render reads the floor): |candidate - target|, weighted
  pitch   over the first PITCH_SPAN seconds, the instantaneous frequency (analytic phase slope,
          smoothed over 5 ms) of the 25..400 Hz band: |log2(candidate / target)| in octaves,
          clamped at 2, over the frames where that band is within 20 dB of its peak -- counted
          only when the band carries at least PITCH_MIN_SHARE of the target's early energy
"""
from __future__ import annotations

import numpy as np

from . import fitness as FT

SR = 44100.0
OCT_EDGES = 62.5 * 2.0 ** np.arange(0, 9)             # 8 octave bands, 62.5 Hz .. 16 kHz
MOD_N, MOD_HOP = 1024, 256
MOD_ACTIVE_DB = 45.0          # a band's active span: within this of its peak ...
MOD_MIN_FRAMES = 48           # ... for at least this many frames (0.28 s), else not scored
MOD_FFT = 1024                # frames the envelope is zero-padded to (0.17 Hz bins at 172 Hz)
MOD_EDGES = np.array([1.0, 1.6, 2.5, 4.0, 6.3, 10.0, 16.0, 25.0, 40.0])
MOD_FLOOR = 0.15              # dB of fluctuation amplitude: steadier than this reads as steady
FLAT_N = 4096
FLAT_ACTIVE_DB = 50.0
STEREO_FLOOR = -30.0          # dB side / mid: a mono render reads this
PITCH_SPAN = 0.6
PITCH_MIN_SHARE = 0.10
W_MOD, W_FLAT, W_STEREO, W_PITCH = 1.0, 4.0, 0.1, 4.0      # calibrated: docs/matcher/texture.md


def _frames(X, n, hop):
    """[K, N] -> [K, T, n] Hann-windowed frames (the last partial frame dropped)"""
    K, N = X.shape
    T = max(1, 1 + (N - n) // hop)
    idx = np.arange(n)[None] + hop * np.arange(T)[:, None]
    idx = np.minimum(idx, N - 1)
    return X[:, idx] * np.hanning(n)


def _band_power(X, sr, n, hop, edges):
    """[K, B, T] band powers of Hann frames"""
    P = np.abs(np.fft.rfft(_frames(X, n, hop), axis=-1)) ** 2
    f = np.fft.rfftfreq(n, 1.0 / sr)
    return np.stack([P[..., (f >= a) & (f < b)].sum(-1) for a, b in zip(edges[:-1], edges[1:])],
                    axis=1)


class _Mod:
    def __init__(self, x, sr):
        self.sr = sr
        B = _band_power(x[None], sr, MOD_N, MOD_HOP, OCT_EDGES)[0]           # [B, T]
        self.T = B.shape[1]
        db = 10 * np.log10(B + 1e-20)
        self.active = db >= db.max(axis=1, keepdims=True) - MOD_ACTIVE_DB
        e = B.sum(axis=1)
        self.w = e / max(e.sum(), 1e-30)
        self.ok = self.active.sum(axis=1) >= MOD_MIN_FRAMES
        self.w = np.where(self.ok, self.w, 0.0)
        s = self.w.sum()
        self.w = self.w / s if s > 0 else self.w
        fs = sr / MOD_HOP
        mf = np.fft.rfftfreq(MOD_FFT, 1.0 / fs)
        self.pool = [np.flatnonzero((mf >= a) & (mf < b)) for a, b in
                     zip(MOD_EDGES[:-1], MOD_EDGES[1:])]
        self.ref = self.features(B[None])[0]

    def features(self, B):
        """[K, B, T] band powers -> [K, B, M] fluctuation dB per modulation band"""
        K, nb, T = B.shape
        T = min(T, self.T)
        db = 10 * np.log10(B[..., :T] + 1e-20)
        out = np.full((K, nb, len(self.pool)), 20 * np.log10(MOD_FLOOR))
        for b in range(nb):
            if not self.ok[b]:
                continue
            m = self.active[b, :T]
            t = np.flatnonzero(m)
            t0, t1 = t[0], t[-1] + 1
            seg = db[:, b, t0:t1]
            L = seg.shape[1]
            u = np.linspace(-1, 1, L)
            V = np.stack([np.ones(L), u, u * u], 1)                       # quadratic trend
            coef, *_ = np.linalg.lstsq(V, seg.T, rcond=None)
            r = seg - (V @ coef).T
            r = r * np.hanning(L)
            R = np.abs(np.fft.rfft(r, n=MOD_FFT, axis=1)) * (2.0 / max(np.hanning(L).sum(), 1.0))
            amp = np.stack([np.sqrt(np.mean(R[:, ix] ** 2, axis=1)) if ix.size else
                            np.zeros(K) for ix in self.pool], 1)
            out[:, b] = 20 * np.log10(np.maximum(amp, MOD_FLOOR))
        return out

    def distance(self, X):
        B = _band_power(X, self.sr, MOD_N, MOD_HOP, OCT_EDGES)
        F = self.features(B)
        d = np.abs(F - self.ref[None]).mean(axis=2)                          # [K, B]
        return d @ self.w


class _Flat:
    def __init__(self, x, sr):
        self.sr = sr
        f = np.fft.rfftfreq(FLAT_N, 1.0 / sr)
        edges = 100.0 * 2.0 ** (np.arange(0, 3 * 7 + 2) / 3.0)               # 100 Hz .. 16 kHz
        edges = edges[edges <= min(16000.0, sr / 2)]
        self.bins = [np.flatnonzero((f >= a) & (f < b)) for a, b in zip(edges[:-1], edges[1:])]
        self.bins = [ix for ix in self.bins if ix.size >= 2]
        P = self._power(x[None])[0]                                          # [T, F]
        bp = np.stack([P[:, ix].mean(axis=1) for ix in self.bins], 1)       # [T, B]
        db = 10 * np.log10(bp + 1e-20)
        self.active = db >= db.max() - FLAT_ACTIVE_DB
        e = bp.sum(axis=0)
        w = np.sqrt(e / max(e.sum(), 1e-30))
        w = np.where(self.active.sum(axis=0) > 0, w, 0.0)
        self.w = w / max(w.sum(), 1e-30)
        self.ref = self.features(P[None])[0]

    def _power(self, X):
        return np.abs(np.fft.rfft(_frames(X, FLAT_N, FLAT_N // 2), axis=-1)) ** 2 + 1e-20

    def features(self, P):
        K, T = P.shape[0], min(P.shape[1], self.active.shape[0])
        out = np.zeros((K, len(self.bins)))
        for j, ix in enumerate(self.bins):
            Q = P[:, :T, ix]
            fl = np.log10(np.exp(np.mean(np.log(Q), axis=2)) / np.mean(Q, axis=2))   # [K, T]
            m = self.active[:T, j]
            out[:, j] = (fl * m).sum(axis=1) / max(m.sum(), 1)
        return out

    def distance(self, X):
        return np.abs(self.features(self._power(X)) - self.ref[None]) @ self.w


class _Stereo:
    def __init__(self, st, sr):
        self.sr = sr
        M, S = self._ms(st[None])
        dbm = 10 * np.log10(M[0] + 1e-20)
        self.active = dbm >= dbm.max(axis=1, keepdims=True) - 40.0
        e = (M[0] * self.active).sum(axis=1)
        self.w = e / max(e.sum(), 1e-30)
        self.ref = self.features(M, S)[0]

    def _ms(self, ST):
        m = 0.5 * (ST[..., 0] + ST[..., 1])
        s = 0.5 * (ST[..., 0] - ST[..., 1])
        return (_band_power(m, self.sr, 2048, 1024, OCT_EDGES),
                _band_power(s, self.sr, 2048, 1024, OCT_EDGES))

    def features(self, M, S):
        T = min(M.shape[2], self.active.shape[1])
        a = self.active[None, :, :T]
        r = (S[..., :T] * a).sum(-1) / np.maximum((M[..., :T] * a).sum(-1), 1e-30)
        return np.maximum(10 * np.log10(r + 1e-20), STEREO_FLOOR)

    def distance(self, ST):
        M, S = self._ms(ST)
        return np.abs(self.features(M, S) - self.ref[None]) @ self.w


class _Pitch:
    def __init__(self, x, sr):
        from scipy.signal import butter
        self.sr = sr
        self.sos = butter(4, [25.0 / (sr / 2), 400.0 / (sr / 2)], "band", output="sos")
        self.n = int(PITCH_SPAN * sr)
        xs = np.asarray(x[:self.n], np.float64)
        lo = self._band(xs[None])[0]
        share = float((lo ** 2).sum() / max((xs ** 2).sum(), 1e-30))
        self.on = share >= PITCH_MIN_SHARE
        f, e = self._track(lo[None])
        self.ref = f[0]
        edb = 20 * np.log10(e[0] + 1e-12)
        self.mask = edb >= edb.max() - 20.0

    def _band(self, X):
        from scipy.signal import sosfiltfilt
        X = X[:, :self.n]
        if X.shape[1] < self.n:
            X = np.pad(X, ((0, 0), (0, self.n - X.shape[1])))
        return sosfiltfilt(self.sos, X, axis=1)

    def _track(self, lo):
        from scipy.signal import hilbert
        z = hilbert(lo, axis=1)
        ph = np.unwrap(np.angle(z), axis=1)
        k = int(0.005 * self.sr)
        c = np.cumsum(np.diff(ph, axis=1), axis=1)
        inst = (c[:, k:] - c[:, :-k]) / k * self.sr / (2 * np.pi)            # 5 ms mean slope
        step = int(0.0025 * self.sr)
        f = np.abs(inst[:, ::step])
        env = np.abs(z)[:, k:][:, ::step][:, :f.shape[1]]
        return np.maximum(f, 1.0), env

    def distance(self, X):
        if not self.on:
            return np.zeros(len(X))
        f, _ = self._track(self._band(X))
        T = min(f.shape[1], self.ref.size)
        d = np.minimum(np.abs(np.log2(f[:, :T] / self.ref[None, :T])), 2.0)
        m = self.mask[None, :T]
        return (d * m).sum(axis=1) / max(m.sum(), 1)


class Target:
    """fitness.Target (the frames: spectra and envelope) plus the texture terms. `stereo`: the
    target's [n, 2] (the stereo term is scored only when given); candidates' stereo arrive as
    cands_stereo [K, n, 2] (absent: they are mono, and read as such)."""

    def __init__(self, audio, sr=SR, stereo=None, free_gain=False, gain_cost=FT.GAIN_COST,
                 weights=None):
        x = np.asarray(audio, np.float32).ravel()
        self.base = FT.Target(x, sr, free_gain=free_gain, gain_cost=gain_cost)
        self.n, self.sr = x.size, float(sr)
        self.w = dict(mod=W_MOD, flat=W_FLAT, stereo=W_STEREO, pitch=W_PITCH)
        if weights:
            self.w.update(weights)
        x64 = x.astype(np.float64)
        self.mod = _Mod(x64, self.sr)
        self.flat = _Flat(x64, self.sr)
        self.pitch = _Pitch(x64, self.sr)
        self.stereo = _Stereo(np.asarray(stereo, np.float64)[:self.n], self.sr) \
            if stereo is not None else None

    def terms(self, cands, cands_stereo=None):
        c = self.base._fit_len(cands).astype(np.float64)
        base, bt = self.base.score(c, terms=True)
        out = dict(base=np.asarray(base, np.float64), mod=self.mod.distance(c),
                   flat=self.flat.distance(c), pitch=self.pitch.distance(c))
        if self.stereo is not None:
            if cands_stereo is None:
                cs = np.stack([c, c], axis=-1)
            else:
                cs = np.asarray(cands_stereo, np.float64)[:, :self.n]
                if cs.shape[1] < self.n:
                    cs = np.pad(cs, ((0, 0), (0, self.n - cs.shape[1]), (0, 0)))
            out["stereo"] = self.stereo.distance(cs)
        else:
            out["stereo"] = np.zeros(len(c))
        out["gain_db"] = bt["gain_db"]
        return out

    def score(self, cands, cands_stereo=None, terms=False):
        t = self.terms(cands, cands_stereo)
        s = t["base"] + sum(self.w[k] * t[k] for k in ("mod", "flat", "stereo", "pitch"))
        s = np.where(np.isfinite(t["base"]), s, np.inf).astype(np.float32)
        return (s, t) if terms else s
