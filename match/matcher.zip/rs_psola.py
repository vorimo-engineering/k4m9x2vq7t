"""rs_psola.py — one recorded note into pchkraft-core's `osc.psola`, and the dashboard synth around it
(2026-10-07). numpy only: natively (scripts/make_resynth.py --block psola) and in the browser (the
MATCH view's "Grain sampler" builder).

THE GRAIN SAMPLER, the second of the three recording builders (rs_common.py): the block cuts the
recording into grains of two periods centred on its PITCH MARKS and lays them down one output period
apart (TD-PSOLA), so the pitch moves while each grain's waveform — the resonances, a singer's formants
— stays put, and the recording's time runs at its own speed whatever the key. The `data` layout is
documented at the top of ../pchkraft-core/synth/nodes/n_psola_impl.h.

What is measured here is the marks: one a period wherever the note is VOICED (YIN's aperiodicity under
0.25 and within 40 dB of the note's level), each found as the shift that best repeats the period
before it (normalised cross-correlation over one period, 0.8 to 1.25 periods on, refined by a
parabola), so consecutive grains are cut at the same place of their cycles and overlap in phase;
where it is not voiced, marks one root period apart — there the grains keep the recording's own
spacing. Each mark carries the distances to its two neighbours: the grain's two halves, which between
two marks are complementary, so at the recorded pitch the grains add back to the recording exactly.

Measured on one singer's long tones, moved an octave and a fourth against the singer's own notes
there: 10.6-11.8 against 13.1-19.2 for the sampler and 13.9-19.0 for the light resynthesis
(dnasynth docs/matcher/results.md §36).
"""
import numpy as np

from rs_common import (SR, MAX_FLOATS, trim_onset, estimate_gate, attack_end, yin_track, estimate_root,  # noqa: F401
                       pcm16, fit_length, build_synth, _level_db, fold_octaves, struck, release_for, root_key_hz,
                       key_up_s)

# (macro id, label, icon, default value, the osc.psola parameter, its range, steps)
KNOBS = [
    ("TRACK", "TRACK", "tune", 0.0, "track", [0, 1], None),
    ("FORMANT", "FORMANT", "filter", 0.5, "formant", [-12, 12], None),
    ("MOTION", "MOTION", "lfo", 1.0, "motion", [0, 1], None),
    ("SPEED", "SPEED", "env", 0.5, "speed", [0.25, 4], None),
    ("HOLD", "HOLD", "wave", 0.0, "hold", ["wander", "loop"], "2"),
]

# this block's part of each character
PRESETS = {
    "pad": {"SPEED": 0.25},
    "bass": {"MOTION": 0.0},
}


def _ncc(x, a, b, L):
    if a < 0 or b < 0 or a + L > x.size or b + L > x.size:
        return -1.0
    u = x[a:a + L]
    v = x[b:b + L]
    den = float(np.sqrt(np.dot(u, u) * np.dot(v, v)))
    return float(np.dot(u, v)) / den if den > 1e-12 else -1.0


def pitch_marks(x, f_root, hop=128):
    """-> [M, 4]: position (samples), distance to the previous mark, to the next, voiced (1/0)"""
    x = np.asarray(x, np.float64)
    # THE SEARCH REACHES BELOW THE NOTE: YIN finds no period longer than SR/fmin, nor than half its
    # window — at 50 Hz and 2048 samples a 33 Hz minimoog bass had no period to find, 36 of its 76
    # marks came out unvoiced, and the grains at its own key scored 1.14 from the recording
    fmin = min(50.0, 0.6 * f_root) if f_root > 0 else 50.0
    win = 2048
    while win < 2 * (SR / fmin) + 4:
        win *= 2
    f0, ap, hs = yin_track(x, SR, hop=hop, fmin=fmin, fmax=1000.0, win=win)
    db = _level_db(x)
    loud = float(np.percentile(db, 95))
    lvl = db[np.minimum((np.arange(f0.size) * hop), x.size - 1)]
    voiced = (ap < 0.25) & (f0 > 0) & (lvl > loud - 40.0)
    f0, voiced = fold_octaves(f0, voiced, f_root)      # an octave slip would cut grains a half period wide

    def frame(p):
        return min(max(int(round(p / hop)), 0), f0.size - 1)
    Tu = float(SR / f_root) if f_root > 20.0 else 200.0
    marks = []
    p = 0.0
    last = None                                       # the last voiced mark
    while p < x.size:
        i = frame(p)
        if not voiced[i]:
            marks.append((p, 0))
            p += Tu
            last = None
            continue
        T = SR / f0[i]
        if last is None:                              # into a voiced run: anchor on the period's peak
            seg = x[int(p):int(p + T)]
            if seg.size < 2:
                break
            p = float(int(p) + int(np.argmax(np.abs(seg))))
            marks.append((p, 1))
            last = p
            continue
        L = int(round(T))
        a = int(round(last - T / 2))
        lo, hi = int(0.8 * T), int(1.25 * T) + 1
        cs = [_ncc(x, a, a + d, L) for d in range(lo, hi)]
        j = int(np.argmax(cs))
        if cs[j] < 0.3:                               # nothing repeats: unvoiced from here
            p = last + T
            last = None
            continue
        d = float(lo + j)
        if 0 < j < len(cs) - 1:
            y0, y1, y2 = cs[j - 1], cs[j], cs[j + 1]
            den = y0 - 2 * y1 + y2
            if abs(den) > 1e-12:
                d += 0.5 * (y0 - y2) / den
        p = last + d
        if p >= x.size:
            break
        marks.append((p, 1))
        last = p
    if not marks:
        marks = [(0.0, 0)]
    pos = np.array([m[0] for m in marks], np.float64)
    vc = np.array([m[1] for m in marks], np.float64)
    gap = np.diff(pos) if pos.size > 1 else np.array([Tu])
    tl = np.concatenate([[gap[0]], gap])
    tr = np.concatenate([gap, [gap[-1]]])
    return np.stack([pos, np.clip(tl, 8, 4096), np.clip(tr, 8, 4096), vc], axis=1)


STEADY_NCC = 0.95       # a mark whose period repeats the next one at least this well is a steady one


def steady_region(x, M, ha, hb):
    """the HOLD region pulled in to where the marks are STEADY: three in a row whose period repeats the
    next (normalised correlation >= STEADY_NCC) at each end. A held key drifts through the region in
    any order and repeats its grains, which is exact only where each grain is one clean period: the
    last 50 ms before a singer's key-up had marks half a cycle off (the voice already ending), and the
    drift that reached them thinned the note — its fundamental 8 dB down for a third of a second.
    -> (ha, hb); (hb, hb) when no steady run is left"""
    pos = M[:, 0]
    vc = M[:, 3] > 0
    good = np.zeros(pos.size, bool)
    for i in range(pos.size - 1):
        if vc[i] and vc[i + 1]:
            a0, T = int(pos[i]), int(round(pos[i + 1] - pos[i]))
            b0 = int(pos[i + 1])
            if T > 8 and b0 + T <= x.size:
                u, v = x[a0:a0 + T], x[b0:b0 + T]
                den = float(np.sqrt(np.dot(u, u) * np.dot(v, v)))
                good[i] = den > 1e-12 and float(np.dot(u, v)) / den >= STEADY_NCC
    run = good & np.r_[good[1:], False] & np.r_[good[2:], False, False]   # i, i+1, i+2 all steady
    inside = np.flatnonzero(run & (pos >= ha) & (pos < hb))
    if inside.size == 0:
        return hb, hb
    a = int(pos[inside[0]])
    j = inside[-1] + 2                                # the run's last mark...
    b = int(min(hb, pos[j + 1] if j + 1 < pos.size else hb))   # ...and the end of its period
    return (a, b) if b - a >= int(0.05 * SR) else (hb, hb)


def analyse(x, f0_hint, gate):
    """mono float audio at 44.1 kHz from its onset, the matcher's pitch (Hz, a hint) and key-up (s)
    -> dict(data=[...], n, M, voiced, key_up, hold, f0): the osc.psola array, version 1"""
    x = np.asarray(x, np.float64)
    f_meas = estimate_root(x, f0_hint)
    f_root = root_key_hz(f_meas)
    room = MAX_FLOATS - 16
    x, gate = fit_length(x, gate, int(room / (1.0 + 4.0 * f_root / SR * 1.3)))   # samples and ~marks
    gate = key_up_s(x, gate)
    M = pitch_marks(x, f_meas)
    hit = struck(x)
    key_up = x.size if hit else int(min(x.size, max(1, round(gate * SR))))   # a decay is all held part
    ha = int(min(key_up, round((attack_end(x) + 0.03) * SR)))
    hb = key_up
    if hit or hb - ha < int(0.05 * SR):
        ha = hb = key_up                              # a decay, or too short to drift in: plays through
    else:
        ha, hb = steady_region(x, M, ha, hb)
        if hb <= ha:
            ha = hb = key_up
    q, scale = pcm16(x)
    hdr = [1, SR, round(f_root, 4), x.size, int(M.shape[0]), key_up, ha, hb, float("%.6g" % scale), 0, 0, 0, 0, 0, 0, 0]
    mk = []
    for pos, tl, tr, vc in M:
        mk += [round(float(pos), 2), round(float(tl), 2), round(float(tr), 2), int(vc)]
    data = hdr + mk + q
    if len(data) > MAX_FLOATS:
        raise ValueError("the recording is %d floats, more than a node carries (%d)" % (len(data), MAX_FLOATS))
    return dict(data=data, n=x.size, M=int(M.shape[0]), voiced=int(M[:, 3].sum()), key_up=key_up,
                key_up_s=key_up / SR, hold=(ha, hb), f0=f_root, f_measured=f_meas, struck=hit, release=release_for(hit, key_up < x.size))


def build(x, f0_hint, gate, base_doc, name):
    """the note in osc.psola inside analog 1 (dashboard) -> (document, the measurement)"""
    m = analyse(x, f0_hint, gate)
    return build_synth("osc.psola", m["data"], KNOBS, PRESETS, base_doc, name, m["release"]), m
