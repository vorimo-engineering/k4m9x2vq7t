"""rs_common.py — what the three recording builders share (2026-10-07).

The MATCH page turns one recorded note into an instrument three ways, each a block of pchkraft-core
inside analog 1's dashboard synth (its filters, envelopes, LFO, FX and matrix stay; its oscillators,
noise and mixer go):

  * Sampler           osc.sampler  — rs_sampler.py: the samples, read faster or slower for the key
  * Grain sampler     osc.psola    — rs_psola.py:   the samples re-pitched one period at a time
  * Resynthesize      osc.resynth  — resynth.py:    a light harmonic + noise measurement

Here: reading the note (its onset, pitch, key-up and the steady part a held key sustains on), the
int16 coding the two recording blocks carry their samples in, and the synth around a block — the same
document shape, the same five characters and the same velocity cell for all three, so what differs
between them is the block alone. numpy only: natively (scripts/make_resynth.py) and in the browser.
"""
import copy
import math

import numpy as np

SR = 44100
MAX_FLOATS = 250000      # under pchkraft-core's PCKS_DATA_MAX (262,144): one node's whole array
PCM_FULL = 32767         # the int16 coding's largest value
# THE LEVEL A RECORDING ENTERS analog 1's filters at: its loudest sample at 0.35, not 0.9. The filters
# drive softly by design (the oscillators' character), and a recording peaking at 0.9 came out of them
# coloured: a voice at its own pitch 1.06 from itself through the dashboard against 0.01 alone, and 0.51
# at 0.35 (a brass 1.58 -> 0.67, 2026-10-07). The synth wins it back after the filters: VOL at full
# with its macro gain at 2 and velocity on it (VEL_VOL), level with analog 1's own presets.
RECORD_PEAK = 0.35


# ------------------------------------------------------------------------- reading the note

def trim_onset(x):
    """from the first sample within 40 dB of the peak (a little before it)"""
    pk = np.abs(x).max()
    i = int(np.argmax(np.abs(x) > pk * 0.01))
    return x[max(0, i - 64):]


def _level_db(x):
    k = int(0.01 * SR)
    env = np.sqrt(np.convolve(x * x, np.ones(k) / k, mode="same")) + 1e-12
    return 20 * np.log10(env)


def estimate_gate(x):
    """the key-up: the first moment, past the first 30 ms, where the 10 ms RMS falls 10 dB under the
    note's loud level (its 90th percentile) and STAYS under for 30 ms — then back to where that fall
    BEGAN (2 dB under the loud level); the end when it never falls (no tail recorded). The loud level
    and not "the level after the peak": in a short note the peak sits near the key-up and a window
    after it already holds the fall. The fall is looked for only once the note has REACHED its loud
    level: a voice swelling in sits 10 dB under it for its first ~100 ms, and read as the key-up that
    froze the instrument on the breath before the note (a sung "a": key-up 0.000 s, 2026-10-07)."""
    db = _level_db(x)
    loud = np.percentile(db, 90)
    below = db < loud - 10.0
    w = int(0.03 * SR)
    run = np.convolve(below.astype(np.int32), np.ones(w, np.int32), mode="valid")   # run[i] = below in [i, i+w)
    s0 = max(int(0.03 * SR), int(np.argmax(db >= loud - 2.0)))
    hit = np.nonzero(run[s0:] == w)[0]
    if not hit.size:
        return x.size / SR
    i = s0 + int(hit[0])
    while i > 0 and db[i] < loud - 2.0:              # back to where the fall BEGINS: the knee
        i -= 1
    return i / SR


def key_up_s(x, gate, by_hand=False):
    """the KEY-UP a recording builder plays from, seconds: the matcher's (`gate`), or this module's own
    knee (estimate_gate) when the note's final fall begins before it. The matcher's reading can sit in
    the release: a minimoog bass read as let go at 2.251 s had been falling since 2.03 s, 25 dB down by
    the key-up — the sampler's loop then ended inside the fall and every pass jumped back up 23 dB,
    and the grains and the resynthesis held a fading note. Five other notes read the same to 10 ms.

    The knee counts only when what follows it IS a release: the level 20 dB under the note's loud
    level within 0.3 s, and never back within 12 dB of it after that. A DX7 e-piano's natural dip at
    0.8 s (10 dB down, then back to 7) was taken for the key-up of a note held to 3.5 s, and its loop
    sat in the attack (2026-10-07).

    `by_hand`: the gate was placed by hand on the MATCH page — it is the key-up, where it was put."""
    x = np.asarray(x, np.float64)
    g = float(gate)
    if by_hand:
        return g
    k_s = float(estimate_gate(x))
    if k_s >= g:
        return g
    db = _level_db(x)
    loud = float(np.percentile(db, 90))
    k = int(k_s * SR)
    down = np.flatnonzero(db[k:k + int(0.3 * SR)] <= loud - 20.0)
    if down.size and float(db[k + int(down[0]):].max()) <= loud - 12.0:
        return k_s
    return g


def attack_end(x):
    """seconds to where the note first reaches 3 dB under its loud level: the attack is over"""
    db = _level_db(x)
    loud = np.percentile(db, 90)
    return int(np.argmax(db >= loud - 3.0)) / SR


def yin_track(x, sr=SR, hop=128, fmin=50.0, fmax=1000.0, win=2048, thr=0.15):
    """YIN, frame by frame: -> (f0 Hz [n], aperiodicity [n], seconds per frame). Frame i is centred on
    sample i * hop. Vectorised: one FFT autocorrelation per frame."""
    x = np.asarray(x, np.float64)
    tmax = min(int(sr / fmin) + 2, win // 2)
    tmin = max(2, int(sr / fmax))
    xp = np.pad(x, (win // 2, win))
    n = 1 + x.size // hop
    W = win // 2                                     # the integration length
    nfft = 1 << int(np.ceil(np.log2(2 * win)))
    taus = np.arange(tmax + 1)
    f0 = np.zeros(n)
    ap = np.ones(n)
    for a in range(0, n, 256):                       # in batches: a long note stays small in memory
        b = min(n, a + 256)
        idx = (np.arange(a, b) * hop)[:, None] + np.arange(win)[None, :]
        fr = xp[idx]
        F = np.fft.rfft(fr, nfft)
        head = np.fft.rfft(fr[:, :W], nfft)
        r = np.fft.irfft(np.conj(head) * F, nfft)[:, :tmax + 1]
        cs = np.concatenate([np.zeros((b - a, 1)), np.cumsum(fr ** 2, axis=1)], axis=1)
        d = cs[:, W][:, None] + (cs[:, W + taus] - cs[:, taus]) - 2.0 * r
        d[:, 0] = 0.0
        cm = np.cumsum(d[:, 1:], axis=1)
        dn = np.ones_like(d)
        dn[:, 1:] = d[:, 1:] * taus[1:][None, :] / np.maximum(cm, 1e-12)
        for i in range(b - a):
            row = dn[i]
            below = np.nonzero(row[tmin:tmax] < thr)[0]
            if below.size:
                t = tmin + int(below[0])
                while t + 1 < tmax and row[t + 1] < row[t]:
                    t += 1
            else:
                t = tmin + int(np.argmin(row[tmin:tmax]))
            ap[a + i] = row[t]
            tt = float(t)
            if 1 <= t < tmax:
                y0, y1, y2 = row[t - 1], row[t], row[t + 1]
                den = y0 - 2 * y1 + y2
                if abs(den) > 1e-12:
                    tt = t + 0.5 * (y0 - y2) / den
            f0[a + i] = sr / tt if tt > 0 else 0.0
    return f0, ap, hop / sr


def fold_octaves(f0, ok, ref):
    """a pitch track's octave slips put back: each usable frame (`ok`) more than seven semitones from
    `ref` moved by whole octaves toward it, and unusable if that does not bring it within -> (f0, ok)"""
    f0 = np.asarray(f0, np.float64).copy()
    ok = np.asarray(ok, bool).copy()
    if ref <= 0:
        return f0, ok
    with np.errstate(divide="ignore", invalid="ignore"):
        st = 12.0 * np.log2(np.where(f0 > 0, f0, ref) / ref)
    k = np.round(st / 12.0)
    f0 = np.where(ok, f0 / 2.0 ** k, f0)
    st = st - 12.0 * k
    ok &= np.abs(st) <= 7.0
    return f0, ok


def root_key_hz(f_measured):
    """the ROOT a recording plays from: the equal-tempered key nearest its measured pitch, so that key
    reads it at exactly its own speed — the recording as it was, which is what a sampler is for. The
    measured pitch put the root between keys, and the nearest one then played the note shifted by
    the difference (47 cents on a sung B3: pitch, formants and length all moved). The instrument is
    as in tune as the recording; MOTION 0 (grains, resynthesis) tunes it to the keys."""
    if not f_measured or f_measured <= 0:
        return 220.0
    return 440.0 * 2.0 ** (round(12.0 * math.log2(f_measured / 440.0)) / 12.0)


def estimate_root(x, hint_hz=None):
    """the note's pitch, Hz: rsynth's comb over a long window (rs_capture.f0_from_audio — the lowest
    partial that carries a harmonic series, 99% on a 137-note pack); the hint (the matcher's own
    reading) when that finds nothing, or when the two disagree by more than a fifth — then the
    comb has caught a chord tone or a sideband and the hint is the safer of the two"""
    import rs_capture as RC
    f = float(RC.f0_from_audio(np.asarray(x, np.float64), SR) or 0.0)
    if hint_hz and hint_hz > 0:
        if f <= 0 or abs(12 * math.log2(f / hint_hz)) > 7.0:
            return float(hint_hz)
    return f if f > 0 else 220.0


def pcm16(x):
    """samples -> (whole numbers -32767..32767, the scale back to output units with the loudest at
    RECORD_PEAK) — the coding osc.sampler / osc.psola / osc.resynth's attack read (n_pcm_impl.h)"""
    x = np.asarray(x, np.float64)
    pk = float(np.abs(x).max()) or 1.0
    q = np.round(x / pk * PCM_FULL).astype(np.int64)
    return [int(v) for v in q], RECORD_PEAK / PCM_FULL


def struck(x, upto_s=None):
    """does the note only DECAY — a piano, a pluck, a mallet? Two conditions, both needed: its loudest
    moment in its first quarter (a strike is loudest at the strike), and from there it never
    plateaus — 12 dB down by the last fifth of what follows, falling at least 2.5 dB from the first
    fifth to the middle and again from the middle to the last.

    Such a note has no key-up to find — the matcher's knee-of-the-first-fall reads a piano's C4 as
    released at 0.08 s while the key was down for its whole 1.2 s ring — and the recording blocks
    take the decay as the HELD part: no tail, no loop, a damper's short release. Both conditions
    are measured failures of the other alone: the decay rule without the first called a sung note
    struck (loudest just before its release, so "what follows the peak" WAS the release — it got no
    loop and no hold, and went silent with the key still down), and "the last quarter 12 dB under"
    called a brass with a long recorded release struck.

    `upto_s`: the key-up. When the note was let go well before the recording ends, only the HELD part
    is judged — over the whole of it a bench pad held 1.2 s and released over 3 s was called struck
    (the release outvoted the steady part), got no loop, and went silent with the key still down. A
    held part under 0.3 s says nothing (a piano's key-up read at its first knee): the whole decides."""
    x = np.asarray(x, np.float64)
    if upto_s is not None and 0.3 <= float(upto_s) <= 0.9 * x.size / SR:
        x = x[:int(float(upto_s) * SR)]
    db = _level_db(x)
    loud = float(np.percentile(db, 90))
    live = np.flatnonzero(db > loud - 50.0)
    if live.size < int(0.2 * SR):
        return False
    seg = db[live[0]:live[-1] + 1]
    ipk = int(np.argmax(seg))
    if ipk > 0.25 * seg.size:
        return False
    post = seg[ipk:]
    if post.size < int(0.2 * SR):
        return False
    m = post.size

    def q(a, b):
        return float(np.median(post[int(a * m):max(int(b * m), int(a * m) + 1)]))
    early, mid, late = q(0.1, 0.2), q(0.45, 0.55), q(0.8, 0.9)
    return bool(post[0] - late >= 12.0 and early - mid >= 2.5 and mid - late >= 2.5)


def release_for(is_struck, has_tail):
    """ENV 1's release (R1) for a recording: a damper's 0.24 s for a struck note; the longest, 12 s,
    when the recording has its own tail — the block plays it and ends the note itself, and any shorter
    release dims it (2.1 s cost the HP clip's 0.27 s tail 0.4 against 5 s); 0.57 s when it has none
    (then the envelope IS the release)"""
    return 0.55 if is_struck else (1.0 if has_tail else 0.65)


def gain_of(gain_db):
    """the MATCH page's gain, dB (-40..+24), as a factor on a recording block's output scale"""
    return 10.0 ** (min(max(float(gain_db or 0.0), -40.0), 24.0) / 20.0)


def hand_span(loop, lo, hi):
    """a stretch placed BY HAND on the MATCH page, (start, end) seconds into the note, as samples inside
    [lo, hi] -> (a, b), or None when nothing of it is left there"""
    a = int(min(max(round(float(loop[0]) * SR), lo), hi))
    b = int(min(max(round(float(loop[1]) * SR), lo), hi))
    return (a, b) if b > a else None


def fit_length(x, gate, room):
    """the note cut to fit `room` samples of a node's array: the start kept, the key-up moved in"""
    if x.size <= room:
        return x, gate
    return x[:room], min(gate, room / SR)


# ------------------------------------------------------------------------- the synth around a block

GONE = {"va", "va2", "noise", "mixer", "WAVE1", "WAVE2", "VOL2", "PW", "DETUNE", "TUNE2", "FM", "NOISE"}

# the starting point a measured sound wants: the filter still (and OPEN at any normal velocity — the
# velocity cell below adds the rest), the amp out of the way
OPEN = {"cutoff": 0.7, "resonance": 0.0, "ENV amout": 0.0, "filter drive": 0.0,
        "A1": 0.0, "S1": 1.0, "R1": 0.65, "FLT FM": 0.0, "FX TYPE": 0.0, "FX DEPTH": 0.0, "VOL": 0.35}
VOL_GAIN = 2.0          # the VOL macro's gain: +6 dB over its usual 1 (RECORD_PEAK above)

# five characters, the same for all three blocks: (name, character, the dashboard knobs it changes).
# Each block adds its own knobs per character (its PRESETS); every preset states every face knob and
# every knob the bank touches, so switching between them never leaves one where the last put it
CHARACTERS = [
    ("VOX LEAD", "lead", {}),
    ("VOX PAD", "pad", {"A1": 0.5, "R1": 1.0}),
    ("VOX KEYS", "keys", {"S1": 0.45, "D1": 0.55}),
    ("VOX PLUCK", "pluck", {"S1": 0.0, "D1": 0.6}),    # 0.36 s: at 0.45 (0.1 s) gone before it is heard
    ("VOX BASS", "bass", {"cutoff": 0.45, "ladder/diod": 0.0, "filter drive": 0.15}),   # 0.35 clipped
]

VEL_VOL = 0.65          # the matrix cell velocity -> VOL: 0.35 + 0.65 x vel — full at velocity 1, 3.4 dB down at
                        # 0.5, 9 dB at 0. A recording that did not answer how hard the key went down sounded
                        # "wrong in loudness": nothing in the synth followed velocity but the filter.
VEL_CUTOFF = 0.4        # the matrix cell velocity -> cutoff: 0.7 + 0.4 x vel opens the filter fully from
                        # velocity 0.75 up (the recording as it was), a soft note comes out darker. On TILT
                        # it tilted the recording itself at a normal velocity: 8.08 against 5.57.
# NO SLEW on the two macros the velocity cells land on. A voice's copy of a voiced macro starts where the
# macro RESTS and glides to its own value (pcks_graph voice_free -> mx_voice_freed), so a velocity cell
# through VOL's 4 ms slew faded every note in over 15 ms — a piano's strike, a pluck's edge softened
# (the matcher: brass 0.78 -> 0.59, piano 0.23 -> 0.19 with both at 0). A knob turned or a preset loaded
# still glides: the graph smooths every parameter over 8 ms itself (a jump mid-note measured no rougher).
CELL_SLEW = 0.0


def panel_of(doc):
    """THE SAME RULE as scripts/instrument_kit.py face_doc() with no wheel: every macro, in board
    order (x, then y), its id as the caption. scripts/make_resynth.py asserts the two agree."""
    macros = [n for n in doc.get("nodes", []) if n.get("type") == "mod.macro"]

    def where(n):
        p = n.get("pos") or [0, 0]
        return (float(p[0]), float(p[1])) if isinstance(p, list) else (0.0, 0.0)
    macros.sort(key=where)
    return [{"label": n["id"], "bind": [n["id"], "value"]} for n in macros] or None


def face_knobs(doc):
    """every macro the dashboard names (its tabs' knobs), in tab order"""
    d = doc.get("dashboard") or {}
    ids = [k.get("macro") for k in ((d.get("synth") or {}).get("knobs") or []) if isinstance(k, dict)]
    for sec in ("env1", "env2", "filter", "lfo", "fx"):
        s = d.get(sec) or {}
        ids += [v for k, v in s.items() if isinstance(v, str) and k not in ("view", "graphs")]
    N = {n["id"]: n for n in doc.get("nodes", [])}
    out = []
    for i in ids:
        if i in N and N[i].get("type") == "mod.macro" and i not in out:
            out.append(i)
    return out


def _state_leg_destinations(doc):
    """write the registry default into every node parameter a macro's `amount` leg reaches and the
    document leaves unwritten (the registry: pchsynth.graph natively, the wasm's in the browser)"""
    try:
        from pchsynth.graph import BY_TYPE
    except Exception:                                 # no registry here: leave the file as it was
        return
    N = {n["id"]: n for n in doc["nodes"]}
    macros = {n["id"] for n in doc["nodes"] if n.get("type") == "mod.macro"}
    for m in doc.get("mod") or []:
        if m["from"][0] not in macros or "amount" not in m:
            continue
        n = N.get(m["to"][0])
        t = BY_TYPE.get(n["type"]) if n else None
        p = t.param(m["to"][1]) if t else None
        if p is None or m["to"][1] in (n.get("params") or {}):
            continue
        n.setdefault("params", {})[m["to"][1]] = p.to_file(p.default_norm)


def build_synth(block_type, data, knobs, presets, base_doc, name, release=None):
    """the block (`block_type`, carrying `data`) in analog 1's dashboard synth -> a new document
    (base_doc untouched). `knobs`: (macro id, label, icon, default, the block's parameter, its range,
    steps) — the SYNTH tab; `presets`: {character: {macro: value}} on top of CHARACTERS; `release`:
    R1 for this recording (release_for)."""
    d = base_doc
    doc = copy.deepcopy(d)
    doc["name"] = name
    doc["nodes"] = [n for n in copy.deepcopy(d["nodes"]) if n["id"] not in GONE]
    N = {n["id"]: n for n in doc["nodes"]}
    for nid, v in dict(OPEN, **({"R1": release} if release is not None else {})).items():
        if nid in N:
            N[nid].setdefault("params", {})["value"] = v
    if "VOL" in N:
        N["VOL"].setdefault("params", {})["gain"] = VOL_GAIN
    for mid in ("VOL", "cutoff"):                     # the velocity cells' macros (CELL_SLEW)
        if mid in N:
            N[mid].setdefault("params", {})["slew"] = CELL_SLEW
    pos = next((n.get("pos") for n in d["nodes"] if n["id"] == "va"), [0, 0])
    doc["nodes"].append({"id": "rs", "type": block_type, "pos": pos, "params": {}, "data": data})
    for i, (mid, _lab, _icon, val, _p, _r, steps) in enumerate(knobs):
        prm = {"value": val}
        if steps:
            prm["steps"] = steps
        doc["nodes"].append({"id": mid, "type": "mod.macro", "pos": [pos[0] - 300, pos[1] + 120 * i], "params": prm})
    # wires: the oscillators' place, before both filters
    doc["audio"] = [a for a in d["audio"] if a[0] not in GONE and a[2] not in GONE]
    doc["audio"] += [["keyboard", "pitch", "rs", "pitch"],
                     ["rs", "out", "ladder", "l"], ["rs", "out", "ladder", "r"],
                     ["rs", "out", "sk", "l"], ["rs", "out", "sk", "r"]]
    doc["mod"] = [m for m in d["mod"] if m["from"][0] not in GONE and m["to"][0] not in GONE]
    doc["mod"] += [{"from": [mid, "out"], "to": ["rs", p], "range": r} for mid, _l, _i, _v, p, r, _s in knobs]
    # the matrix: the same sources; two cells — a soft note darker and quieter (a recording otherwise
    # ignores how hard the key went down)
    vel = next((s["from"] for s in d["matrix"]["sources"] if s.get("label") == "VELOCITY"), ["keyboard", "vel"])
    doc["matrix"] = {"sources": d["matrix"]["sources"],
                     "cells": {"cutoff": {"value": [{"from": list(vel), "amount": VEL_CUTOFF}]},
                               "VOL": {"value": [{"from": list(vel), "amount": VEL_VOL}]}}}
    doc["dashboard"]["synth"] = {"layout": "grid8", "picture": None,
                                 "knobs": [{"macro": mid, "icon": icon, "label": lab} for mid, lab, icon, *_ in knobs]}
    doc["panel"] = panel_of(doc)
    for g in doc.get("groups", []):
        if isinstance(g.get("nodes"), list):
            g["nodes"] = [m for m in g["nodes"] if m not in GONE]
    # every macro leg's destination STATED: analog 1 leaves three at their registry defaults (mixer2.a,
    # ladder.drive, sk.drive), where nothing can tell a leg that moves them from one the clamp absorbs
    # (tests/test_the_face_and_the_pins.py). Written as those defaults, so no sample changes.
    _state_leg_destinations(doc)
    # presets: every one states every macro on the face (the panel's and the groups') and every knob
    # the bank touches; the first is the DEFAULT, read off the graph (the format's rule)
    N = {n["id"]: n for n in doc["nodes"]}
    chars = [(nm, ch, dict(over, **presets.get(ch, {}))) for nm, ch, over in CHARACTERS]
    keys = face_knobs(doc)
    for panel in [doc.get("panel") or []] + [(g.get("panel") or []) for g in doc.get("groups") or []]:
        for k in panel:
            b = k.get("bind") or []
            if len(b) >= 2 and b[1] == "value" and b[0] in N and N[b[0]].get("type") == "mod.macro" and b[0] not in keys:
                keys.append(b[0])
    keys += [k for _, _, p in chars for k in p if k not in keys]
    base = {k: float(N[k]["params"].get("value", 0.0)) for k in keys}

    def state(over):
        return {k: {"value": over.get(k, base[k])} for k in keys}
    doc["presets"] = [{"name": "Default", "default": True, "params": state({})}]
    doc["presets"] += [{"name": nm, "character": ch, "params": state(p)} for nm, ch, p in chars]
    return doc
