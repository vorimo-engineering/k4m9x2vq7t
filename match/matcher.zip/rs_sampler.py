"""rs_sampler.py — one recorded note into pchkraft-core's `osc.sampler`, and the dashboard synth
around it (2026-10-07). numpy only: natively (scripts/make_resynth.py --block sampler) and in the
browser (the MATCH view's "Sampler" builder).

THE PLAINEST OF THE THREE recording builders (rs_common.py): the samples themselves, which the block
reads faster or slower for the key. Exact at the recorded pitch and the lightest — and a key away
from it moves the resonances and the length with the pitch (a chipmunk up, a slow giant down). The
`data` layout is documented at the top of ../pchkraft-core/synth/nodes/n_sampler_impl.h.

What is measured here is only where things are: the pitch (the key that plays the note unchanged),
the key-up (where the recorded TAIL begins), and the sustain LOOP a held key cycles — a stretch of
the steady part whose two ends match, so the seam is a crossfade between two near-identical
stretches: its end the recording's own key-up (a key held as long as the recording hears the
recording), its start the place a quarter of the way into the steady part where the waveform best
repeats what follows the end (normalised correlation over 50 ms).
"""
import math

import numpy as np

from rs_common import (SR, MAX_FLOATS, trim_onset, estimate_gate, attack_end, estimate_root, pcm16,  # noqa: F401
                       fit_length, build_synth, struck, release_for, root_key_hz, key_up_s, _level_db, gain_of)

# (macro id, label, icon, default value, the osc.sampler parameter, its range, steps)
KNOBS = [
    ("LOOP", "LOOP", "wave", 1.0, "loop", ["off", "on"], "2"),
    ("XFADE", "XFADE", "space", 0.5624, "xfade", [0.005, 0.3], None),     # 0.05 s on the EXP knob
    ("START", "START", "env", 0.0, "start", [0, 1], None),
    ("MOVE", "MOVE", "detune", 0.5, "move", [-1, 1], None),      # the loop slid, centre = where it was chosen
    ("SIZE", "SIZE", "pw", 0.5, "size", [-1, 1], None),          # its length, 1/4x .. 4x, in whole periods
]

# this block's part of each character
PRESETS = {
    "pluck": {"LOOP": 0.0},
}

SEAM_S = 0.05            # the window the loop's ends are matched over (the waveform: the phase)
CONT_S = 0.1             # ...and the windows either side of the seam whose loudness and brightness must agree
LEVEL_TOL = 2.0          # dB: a loop's start is looked for where it is this close to the loudness its end has
MIN_LOOP_S = 0.12        # the shortest loop a short held part may take...
GOOD_LOOP_S = 0.25       # ...and the shortest an unheard seam is accepted at (shorter repeats as a flutter)
LEN_BANDS = (0.12, 0.25, 0.4, 0.6, 0.9, 1.3, 2.0, 1e9)   # loop lengths, s: the start search's bands
LB_SPAN = 0.6            # loop_b is looked for this far back into the held part (a fading one sustains where it settles)
# AN UNHEARD SEAM, and of those the LONGEST loop: a seam is unheard when the ends' waveforms match (RHO_OK),
# their loudness is within LEV_OK and their brightness (the centroid) moves no more than the sound's own
# over one window, plus BRIGHT_OK octaves. Scored on the seam alone the search took the shortest loops it could (0.12 s
# on 17 of 44 bench notes) — clean seams, and a choir's or a string pad's movement frozen into an 8 Hz flutter
# RHO_OK is low on purpose: ends that barely repeat (a chorus, a detuned pair) take the long crossfade xfade_s
# gives them, which hides what a waveform match cannot.
RHO_OK, LEV_OK, BRIGHT_OK, LONG_S = 0.5, 1.0, 0.1, 2.0
END_W = 3.0              # of two unheard seams, a second of the recording's own end is worth 3 s of loop
# THE SEAM'S CROSSFADE, by how well the two ends match (their correlation, rho): 20 ms where they repeat
# each other (a voice, 0.94), up to 250 ms where they barely do — an analog synth's detuned oscillators
# never repeat (a jx3p brass 0.48, a juno pad 0.67), and 50 ms of two different waveforms is a swoosh at
# every pass (a pitch frame read an octave low mid-seam). The block keeps the blend's power at rho.
XF_MATCHED, XF_LOOSE = 0.02, 0.25
RHO_GOOD = 0.9           # ends this alike may take a crossfade longer than the room past loop_b (it is capped)
XF_RANGE = (0.005, 0.3)  # the xfade knob's ends (EXP)


def _ncc(x, a, b, w):
    u = x[a - w:a]
    v = x[b - w:b]
    if a - w < 0 or b > x.size or u.size < w or v.size < w:
        return -1.0
    den = float(np.sqrt(np.dot(u, u) * np.dot(v, v)))
    return float(np.dot(u, v)) / den if den > 1e-12 else -1.0


def _starts(x, held_a, lb):
    """the places in [held_a, lb) where the waveform best repeats what follows lb — normalised correlation
    over 50 ms, every sample a candidate (one FFT) — two in every band of loop lengths (LEN_BANDS), taken
    among the places whose next CONT_S is as LOUD as the CONT_S before lb (within LEVEL_TOL) when the
    band has any -> [(loop_a, rho)]. A held part that fades (an e-piano, a
    string patch decaying to its sustain, M1 Angels after its tremolo) has no loud start for its quiet
    end: the start comes from where it was already that quiet."""
    w = int(min(SEAM_S * SR, x.size - lb))
    hi = lb - max(2 * w, int(MIN_LOOP_S * SR))
    if w < 64 or hi <= held_a:
        return []
    v = x[lb:lb + w]
    seg = x[held_a:hi + w]                          # the window starting at every candidate held_a..hi
    nfft = 1 << int(np.ceil(np.log2(seg.size + w)))
    corr = np.fft.irfft(np.fft.rfft(seg, nfft) * np.conj(np.fft.rfft(v, nfft)), nfft)[:hi - held_a + 1]
    cs = np.concatenate([[0.0], np.cumsum(seg * seg)])
    e = cs[w:w + corr.size] - cs[:corr.size]
    ncc = corr / np.sqrt(np.maximum(e, 1e-30) * (float(np.dot(v, v)) + 1e-30))
    W = int(CONT_S * SR)
    xa = x[held_a:hi + W]
    ca = np.concatenate([[0.0], np.cumsum(xa * xa)])
    n_ok = min(corr.size, ca.size - W)
    lev = 10.0 * np.log10((ca[W:W + n_ok] - ca[:n_ok]) / W + 1e-20)
    before = x[max(0, lb - W):lb]
    ref = 10.0 * np.log10(float(np.mean(before * before)) + 1e-20)
    near = np.abs(lev - ref) <= LEVEL_TOL
    # THE BEST IN EVERY LENGTH BAND, not the best k overall: on a chorus or an ensemble the best matches all
    # sit a few periods from lb, and no long loop was ever weighed (a choir's loop fell to 0.12 s)
    L = (lb - held_a - np.arange(n_ok)) / SR          # the loop each candidate makes
    out = []
    for lo, hi_s in zip(LEN_BANDS[:-1], LEN_BANDS[1:]):
        band = np.flatnonzero((L >= lo) & (L < hi_s))
        if not band.size:
            continue
        pool = band[near[band]] if near[band].any() else band
        for j in pool[np.argsort(-ncc[pool])][:2]:
            j = int(j)
            if all(abs(j - (a - held_a)) >= 64 for a, _ in out):
                out.append((held_a + j, float(np.clip(ncc[j], 0.0, 1.0))))
    return out


def _centroid(seg):
    """the spectral centroid, Hz: where a window's brightness sits — what a closing filter moves and a
    singer's vibrato does not (band-by-band levels moved with every harmonic crossing a band edge, and
    called a sung note's every seam a 5 dB jump)"""
    X = np.abs(np.fft.rfft(seg * np.hanning(seg.size), 8192)) ** 2
    f = np.fft.rfftfreq(8192, 1.0 / SR)
    sel = (f >= 50.0) & (f <= 16000.0)
    return float(np.sum(f[sel] * X[sel]) / (np.sum(X[sel]) + 1e-20))


def _change(a, b):
    """(loudness change dB, brightness change in octaves of the centroid) from window `a` to window `b`"""
    lev = 10.0 * np.log10((float(np.mean(b * b)) + 1e-20) / (float(np.mean(a * a)) + 1e-20))
    return float(lev), float(abs(np.log2((_centroid(b) + 1e-6) / (_centroid(a) + 1e-6))))


def seam(x, la, lb):
    """what a held key hears change at the seam: (loudness jump dB, brightness jump in octaves) between
    the CONT_S just before loop_b (the recording up to it) and the CONT_S from loop_a on (the loop again)"""
    W = int(CONT_S * SR)
    a, b = x[max(0, lb - W):lb], x[la:la + W]
    if a.size < W // 2 or b.size < W // 2:
        return 0.0, 0.0
    return _change(a, b)


def steady_end(x, key_up):
    """where the HELD SOUND ends, in samples: the key-up when what follows it falls (a release, 3 dB
    under the last 100 ms before it), later when the sound goes on past it — to the recording's end
    for a note cut while it still sounded (a sung "a" clipped 7 ms past its key-up)"""
    if key_up >= x.size:
        return x.size
    db = _level_db(np.asarray(x, np.float64))
    ref = float(np.median(db[max(0, key_up - int(0.1 * SR)):key_up])) if key_up > 0 else float(db.max())
    fall = np.flatnonzero(db[key_up:] < ref - 3.0)
    return int(key_up + fall[0]) if fall.size else int(x.size)


def loop_points(x, held_a, held_b, end):
    """(loop_a, loop_b, rho, room) in samples, or (0, 0, 0, 0) when the steady part [held_a, held_b) is
    too short to hold one.

    The block crossfades AFTER the jump, the outgoing head reading on past loop_b — so what follows
    loop_b must still be the held sound, up to `end` (steady_end), and `room` is how far the seam may
    read past loop_b (the block caps the XFADE knob at it): a seam at the key-up blended the loop's
    start with the release (a brass 30 dB down 50 ms after its key-up dipped 11 dB at every pass).

    WHERE (2026-10-07, measured on the MATCH page's 44 bench notes held three times their length):
    loop_b anywhere from 20 ms before `end` back through LB_SPAN of the held part; for each, loop_a in
    every band of loop lengths where the waveform best repeats what follows loop_b and the loudness
    matches (`_starts`); each pair judged by what a held key HEARS at the seam (`seam`: the loudness
    and brightness — the centroid — of the CONT_S either side). Kept: the LONGEST loop with an unheard
    seam (RHO_OK, LEV_OK, the brightness within the sound's own change plus BRIGHT_OK, at least
    GOOD_LOOP_S), a second of the recording's own end worth END_W of loop; else the cheapest seam of a
    loop at least that long; else the cheapest. Matching the waveform alone left the held part's own
    movement in every seam — a filter still closing, a swell, a tremolo: an SH-2 pluck jumped 2.8 dB
    at every pass, M1 Angels 4.5, a minimoog bass brightened — and only the last 0.4 s held loop_b,
    so a held part that fades (an e-piano, a D-550 string patch) had no quiet start for its quiet end.
    Scoring the seam alone took the shortest loops it could (0.12 s on 17 of 44: a flutter). 11 of 44
    had a seam a key would hear and two pads none at all (struck, plays once); now 6, every one a
    sound that keeps moving while held (an LFO, a filter, an ensemble) — the grain sampler's drift
    suits those. rho also sets the crossfade's length (xfade_s) and the block holds the blend's power
    at it."""
    back = max(0.4, LB_SPAN * (end - held_a) / SR)
    cands = sorted({int(min(held_b, end - round(d * SR))) for d in np.concatenate([np.arange(XF_MATCHED, 0.4001, 0.02),
                                                                                    np.linspace(0.4, back, 12)])}, reverse=True)
    W = int(CONT_S * SR)
    good_len = min(GOOD_LOOP_S, 0.4 * (end - held_a) / SR)
    best, best_cost, longest, longest_score = None, None, None, None
    best_long, best_long_cost = None, None
    for lb in cands:
        if lb - held_a < int(MIN_LOOP_S * SR) or lb - 2 * W < held_a:
            continue
        # how much the sound changes by itself here: the median over the half second before loop_b
        own = float(np.median([_change(x[t - W:t], x[t:t + W])[1]
                               for t in range(max(held_a + W, lb - 5 * W), lb - W + 1, W)] or [0.0]))
        for la, rho in _starts(x, held_a, lb):
            if end - lb < round(xfade_s(rho) * SR) and rho < RHO_GOOD:
                continue                              # its crossfade would read into the release
            lev, bright = seam(x, la, lb)
            L = (lb - la) / SR
            cost = (10.0 * (1.0 - rho) + abs(lev) + 10.0 * bright
                    + 0.3 * (end - lb) / SR            # keep the recording's own end
                    - 0.5 * min(L, 1.0))               # repeat less
            c = (la, lb, rho, int(end - lb))
            if best_cost is None or cost < best_cost:
                best, best_cost = c, cost
            if L >= good_len and (best_long_cost is None or cost < best_long_cost):
                best_long, best_long_cost = c, cost
            if rho >= RHO_OK and abs(lev) <= LEV_OK and bright <= own + BRIGHT_OK and L >= good_len:
                score = min(L, LONG_S) - END_W * (end - lb) / SR
                if longest_score is None or score > longest_score:
                    longest, longest_score = c, score
    # the longest unheard seam; else the best seam of a loop long enough not to flutter; else the best
    return longest or best_long or best or (0, 0, 0.0, 0)


def xfade_s(rho):
    """the seam's crossfade for ends that correlate `rho`, seconds: XF_MATCHED at 0.9 and above,
    XF_LOOSE at 0.5 and below, geometric between"""
    t = float(np.clip((0.9 - rho) / 0.4, 0.0, 1.0))
    return XF_MATCHED * (XF_LOOSE / XF_MATCHED) ** t


def xfade_knob(rho):
    """xfade_s as the XFADE knob's 0..1 value on its EXP range"""
    return round(math.log(xfade_s(rho) / XF_RANGE[0]) / math.log(XF_RANGE[1] / XF_RANGE[0]), 4)


def user_loop(x, f_meas, held_a, key_up, end, la_s, lb_s):
    """a loop placed BY HAND (the MATCH page's loop markers, seconds into the note) -> (loop_a, loop_b,
    rho, room): loop_b where it was put, loop_a moved at most one period of the note to where the
    waveform best repeats what follows loop_b — a hand cannot place a seam in phase, and a seam out of
    phase blends two waveforms half a cycle apart. The room is the held sound past loop_b when there is
    any, else the recording past it (a loop put into the release is the hand's choice)."""
    n = x.size
    lb = int(min(max(round(lb_s * SR), 128), n - 64))
    la = int(min(max(round(la_s * SR), 0), lb - 64))
    P = SR / f_meas if f_meas > 20.0 else 0.005 * SR
    w = int(min(SEAM_S * SR, n - lb))
    best, rho = la, -1.0
    if w >= 64:
        v = x[lb:lb + w]
        for a in range(max(0, int(la - P)), min(lb - 64, int(la + P)) + 1):
            u = x[a:a + w]
            if u.size < w:
                break
            den = float(np.sqrt(np.dot(u, u) * np.dot(v, v)))
            c = float(np.dot(u, v)) / den if den > 1e-12 else -1.0
            if c > rho:
                best, rho = a, c
    room = (end - lb) if end > lb + 64 else (n - lb)
    return int(best), int(lb), float(np.clip(rho, 0.0, 1.0)), int(max(room, 0))


def analyse(x, f0_hint, gate, loop=None, gate_by_hand=False, gain_db=0.0):
    """mono float audio at 44.1 kHz from its onset, the matcher's pitch (Hz, a hint) and key-up (s)
    -> dict(data=[...], n, key_up, loop, f0): the osc.sampler array, version 1.

    THE MATCH PAGE'S EDITS: `loop` — (start, end) seconds into the note, a loop placed by hand; "off",
    none (the LOOP switch off, the analysis's loop left in the data for it); None, the analysis's.
    `gate_by_hand`: the gate is the key-up as it stands (no knee moves it; a decay gets a tail there
    too). `gain_db`: the recording's level in the synth (its scale)."""
    x = np.asarray(x, np.float64)
    x, gate = fit_length(x, gate, MAX_FLOATS - 16)
    gate = key_up_s(x, gate, gate_by_hand)
    f_meas = estimate_root(x, f0_hint)
    f_root = root_key_hz(f_meas)
    hit = struck(x, gate)
    # a decay is all held part — unless a hand put the key-up somewhere
    key_up = x.size if hit and not gate_by_hand else int(min(x.size, max(1, round(gate * SR))))
    held_a = int(min(key_up, round((attack_end(x) + 0.03) * SR)))
    by_hand = loop is not None and loop != "off" and len(loop) == 2 and float(loop[1]) > float(loop[0])
    if by_hand:
        la, lb, rho, room = user_loop(x, f_meas, held_a, key_up, steady_end(x, key_up), float(loop[0]), float(loop[1]))
    else:
        la, lb, rho, room = (0, 0, 0.0, 0) if hit else loop_points(x, held_a, key_up, steady_end(x, key_up))
    q, scale = pcm16(x)
    hdr = [1, SR, round(f_root, 4), x.size, key_up, la, lb, float("%.6g" % (scale * gain_of(gain_db))),
           round(max(rho, 0.01), 4) if lb > la else 0, room if lb > la else 0, 0, 0, 0, 0, 0, 0]
    return dict(data=hdr + q, n=x.size, key_up=key_up, key_up_s=key_up / SR, loop=(la, lb), rho=rho, f0=f_root,
                f_measured=f_meas, struck=hit, release=release_for(hit, key_up < x.size),
                loop_by_hand=by_hand and lb > la, loop_off=loop == "off", gate_by_hand=bool(gate_by_hand))


def build(x, f0_hint, gate, base_doc, name, loop=None, gate_by_hand=False, gain_db=0.0):
    """the note in osc.sampler inside analog 1 (dashboard) -> (document, the measurement); the MATCH
    page's edits as analyse takes them"""
    m = analyse(x, f0_hint, gate, loop, gate_by_hand, gain_db)
    knobs = []
    for k in KNOBS:
        if k[0] == "LOOP" and (m["loop_off"] or (m["struck"] and not m["loop_by_hand"])):
            k = k[:3] + (0.0,) + k[4:]                 # off by hand; a decay plays through once (unless looped by hand)
        elif k[0] == "XFADE" and m["loop"][1] > m["loop"][0]:
            k = k[:3] + (xfade_knob(m["rho"]),) + k[4:]
        knobs.append(k)
    return build_synth("osc.sampler", m["data"], knobs, PRESETS, base_doc, name, m["release"]), m
