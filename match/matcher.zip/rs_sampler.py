"""rs_sampler.py — one recorded note into pchkraft-core's `osc.sampler`, and the dashboard synth
around it (2026-10-07). numpy only: natively (scripts/make_resynth.py --block sampler) and in the
browser (the MATCH view's "Sampler" builder).

THE PLAINEST OF THE THREE recording builders (rs_common.py): the samples themselves, which the block
reads faster or slower for the key. Exact at the recorded pitch and the lightest — and a key away
from it moves the resonances and the length with the pitch (a chipmunk up, a slow giant down). The
`data` layout is documented at the top of ../pchkraft-core/synth/nodes/n_sampler_impl.h.

What is measured here is only where things are: the pitch (the key that plays the note unchanged),
the key-up (where the recorded TAIL begins), and the sustain LOOP a held key cycles — a stretch of
the steady part whose two ends match, so the seam is a crossfade between two near-identical
stretches: its end the recording's own key-up (a key held as long as the recording hears the
recording), its start the place a quarter of the way into the steady part where the waveform best
repeats what follows the end (normalised correlation over 50 ms).
"""
import math

import numpy as np

from rs_common import (SR, MAX_FLOATS, trim_onset, estimate_gate, attack_end, estimate_root, pcm16,  # noqa: F401
                       fit_length, build_synth, struck, release_for, root_key_hz, key_up_s, _level_db)

# (macro id, label, icon, default value, the osc.sampler parameter, its range, steps)
KNOBS = [
    ("LOOP", "LOOP", "wave", 1.0, "loop", ["off", "on"], "2"),
    ("XFADE", "XFADE", "space", 0.5624, "xfade", [0.005, 0.3], None),     # 0.05 s on the EXP knob
    ("START", "START", "env", 0.0, "start", [0, 1], None),
]

# this block's part of each character
PRESETS = {
    "pluck": {"LOOP": 0.0},
}

SEAM_S = 0.05            # the window the loop's ends are matched over
SPAN_A = 0.6             # loop_a is looked for in the first 60% of the steady part: the loop is 40% of it or more
# THE SEAM'S CROSSFADE, by how well the two ends match (their correlation, rho): 20 ms where they repeat
# each other (a voice, 0.94), up to 250 ms where they barely do — an analog synth's detuned oscillators
# never repeat (a jx3p brass 0.48, a juno pad 0.67), and 50 ms of two different waveforms is a swoosh at
# every pass (a pitch frame read an octave low mid-seam). The block keeps the blend's power at rho.
XF_MATCHED, XF_LOOSE = 0.02, 0.25
RHO_GOOD = 0.9           # ends this alike are a seam the ear does not find: the latest such loop_b is kept
XF_RANGE = (0.005, 0.3)  # the xfade knob's ends (EXP)


def _ncc(x, a, b, w):
    u = x[a - w:a]
    v = x[b - w:b]
    if a - w < 0 or b > x.size or u.size < w or v.size < w:
        return -1.0
    den = float(np.sqrt(np.dot(u, u) * np.dot(v, v)))
    return float(np.dot(u, v)) / den if den > 1e-12 else -1.0


def _best_start(x, held_a, lb):
    """(loop_a, rho): the place in the first SPAN_A of [held_a, lb) where the waveform best repeats
    what follows lb — normalised correlation over 50 ms, every sample a candidate (one FFT) — or None"""
    w = int(min(SEAM_S * SR, x.size - lb))
    hi = min(held_a + int(SPAN_A * (lb - held_a)), lb - 2 * w)
    if w < 64 or hi <= held_a:
        return None
    v = x[lb:lb + w]
    seg = x[held_a:hi + w]                          # the window starting at every candidate held_a..hi
    nfft = 1 << int(np.ceil(np.log2(seg.size + w)))
    corr = np.fft.irfft(np.fft.rfft(seg, nfft) * np.conj(np.fft.rfft(v, nfft)), nfft)[:hi - held_a + 1]
    cs = np.concatenate([[0.0], np.cumsum(seg * seg)])
    e = cs[w:w + corr.size] - cs[:corr.size]
    ncc = corr / np.sqrt(np.maximum(e, 1e-30) * (float(np.dot(v, v)) + 1e-30))
    j = int(np.argmax(ncc))
    return held_a + j, float(np.clip(ncc[j], 0.0, 1.0))


def steady_end(x, key_up):
    """where the HELD SOUND ends, in samples: the key-up when what follows it falls (a release, 3 dB
    under the last 100 ms before it), later when the sound goes on past it — to the recording's end
    for a note cut while it still sounded (a sung "a" clipped 7 ms past its key-up)"""
    if key_up >= x.size:
        return x.size
    db = _level_db(np.asarray(x, np.float64))
    ref = float(np.median(db[max(0, key_up - int(0.1 * SR)):key_up])) if key_up > 0 else float(db.max())
    fall = np.flatnonzero(db[key_up:] < ref - 3.0)
    return int(key_up + fall[0]) if fall.size else int(x.size)


def loop_points(x, held_a, held_b, end):
    """(loop_a, loop_b, rho, room) in samples, or (0, 0, 0, 0) when the steady part [held_a, held_b) is
    too short to hold one.

    The block crossfades AFTER the jump, the outgoing head reading on past loop_b — so what follows
    loop_b must still be the held sound, up to `end` (steady_end): loop_b is the held part's end
    (the key-up) where the sound goes on past it, else ONE CROSSFADE BEFORE `end` — a seam at the
    key-up blended the loop's start with the release (a brass 30 dB down 50 ms after its key-up dipped
    11 dB at every pass once its crossfade was 230 ms). `room` is how far the seam may read past
    loop_b; the block caps the XFADE knob at it.

    WHERE: every loop_b from 20 ms to 400 ms before `end`, 20 ms apart (and the key-up itself where the
    sound goes on past it), each with its loop_a — the place in the first SPAN_A of the steady part
    where the waveform best repeats what follows loop_b (_best_start) — and rho, how well. Of those
    whose crossfade (xfade_s(rho)) fits before `end`, the LATEST that matches well (RHO_GOOD) is kept,
    else the best: a single loop_b at the key-up found nothing to match on a sung "a" (rho 0.25: the
    voice was already ending in its last 60 ms) and a search a period and a half around the quarter
    point found 0.48 on a brass where 0.92 was there — but the best anywhere put loop_b 280 ms before
    a key-up that 0.93 was available at, and a key held as long as the recording heard 280 ms of the
    loop where its own ending was. rho also sets the crossfade's length, and the block holds the
    blend's power at it."""
    cands = sorted({int(min(held_b, end - round(d * SR))) for d in np.arange(XF_MATCHED, 0.4001, 0.02)}, reverse=True)
    best, best_any = None, None
    for lb in cands:                                  # the latest first
        if lb - held_a < int(0.12 * SR):
            continue
        r = _best_start(x, held_a, lb)
        if r is None:
            continue
        c = (r[0], lb, r[1], int(end - lb))
        if best_any is None or c[2] > best_any[2] + 1e-3:
            best_any = c
        if end - lb >= round(xfade_s(r[1]) * SR):
            if r[1] >= RHO_GOOD:
                return c                              # the latest that matches well
            if best is None or c[2] > best[2] + 1e-3:
                best = c
    return best or best_any or (0, 0, 0.0, 0)


def xfade_s(rho):
    """the seam's crossfade for ends that correlate `rho`, seconds: XF_MATCHED at 0.9 and above,
    XF_LOOSE at 0.5 and below, geometric between"""
    t = float(np.clip((0.9 - rho) / 0.4, 0.0, 1.0))
    return XF_MATCHED * (XF_LOOSE / XF_MATCHED) ** t


def xfade_knob(rho):
    """xfade_s as the XFADE knob's 0..1 value on its EXP range"""
    return round(math.log(xfade_s(rho) / XF_RANGE[0]) / math.log(XF_RANGE[1] / XF_RANGE[0]), 4)


def analyse(x, f0_hint, gate):
    """mono float audio at 44.1 kHz from its onset, the matcher's pitch (Hz, a hint) and key-up (s)
    -> dict(data=[...], n, key_up, loop, f0): the osc.sampler array, version 1"""
    x = np.asarray(x, np.float64)
    x, gate = fit_length(x, gate, MAX_FLOATS - 16)
    gate = key_up_s(x, gate)
    f_meas = estimate_root(x, f0_hint)
    f_root = root_key_hz(f_meas)
    hit = struck(x)
    key_up = x.size if hit else int(min(x.size, max(1, round(gate * SR))))   # a decay is all held part
    held_a = int(min(key_up, round((attack_end(x) + 0.03) * SR)))
    la, lb, rho, room = (0, 0, 0.0, 0) if hit else loop_points(x, held_a, key_up, steady_end(x, key_up))
    q, scale = pcm16(x)
    hdr = [1, SR, round(f_root, 4), x.size, key_up, la, lb, float("%.6g" % scale),
           round(max(rho, 0.01), 4) if lb > la else 0, room if lb > la else 0, 0, 0, 0, 0, 0, 0]
    return dict(data=hdr + q, n=x.size, key_up=key_up, key_up_s=key_up / SR, loop=(la, lb), rho=rho, f0=f_root,
                f_measured=f_meas, struck=hit, release=release_for(hit, key_up < x.size))


def build(x, f0_hint, gate, base_doc, name):
    """the note in osc.sampler inside analog 1 (dashboard) -> (document, the measurement)"""
    m = analyse(x, f0_hint, gate)
    knobs = []
    for k in KNOBS:
        if k[0] == "LOOP" and m["struck"]:
            k = k[:3] + (0.0,) + k[4:]                 # a decay plays through once
        elif k[0] == "XFADE" and m["loop"][1] > m["loop"][0]:
            k = k[:3] + (xfade_knob(m["rho"]),) + k[4:]
        knobs.append(k)
    return build_synth("osc.sampler", m["data"], knobs, PRESETS, base_doc, name, m["release"]), m
