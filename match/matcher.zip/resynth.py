"""resynth.py — one recorded note measured into pchkraft-core's `osc.resynth` (version 2), and the
dashboard synth around it (2026-10-07). numpy only: the same module runs natively
(scripts/make_resynth.py --block resynth) and in the browser (the MATCH view's "Resynthesize"
builder, packed into matcher.zip by pack.py).

THE LIGHT RESYNTHESIS, the third of the three recording builders (rs_common.py). The `data` layout is
documented at the top of ../pchkraft-core/synth/nodes/n_resynth_impl.h:

  * rsynth's own analysis (rs_capture.capture: free peaks tracked by cents continuity, two windows on
    one grid, frame 0 on the onset) — then every track FOLDED onto the harmonics of one pitch curve
    (YIN, refined frame by frame by the tracks themselves): the block plays them from one table at the
    note's pitch, so a harmonic is all it can say. A track near no harmonic goes to the noise.
  * the NOISE: rsynth's 24-band residual (the partials' mainlobes taken out of each frame) factored
    into COLOURS (non-negative matrix factorisation): C fixed band shapes whose gains move frame by
    frame. Three colours against rsynth's per-voice FFT noise: 0.2-1.0 worse, at a twentieth the cost.
  * the spectral ENVELOPE (rsynth's iterative true envelope, frozen in time) for `track`;
  * the ATTACK: the recording's first 80 ms, played in front of the model.

Measured on nine notes (2026-10-07, dnasynth docs/matcher/results.md §36): within 0.3 of rsynth's free
partials on a voice, a piano, strings; 1.2-1.8 behind on synths of detuned oscillators, whose beating
no per-frame level can hold.

THE SYNTH (`build`): rs_common.build_synth with this block's knobs — TRACK, BREATH, SPEED, HOLD, TILT,
MOTION — on the SYNTH tab.
"""
import math

import numpy as np

import rs_capture as RC
from rs_common import (SR, MAX_FLOATS, trim_onset, estimate_gate, attack_end, yin_track, estimate_root,  # noqa: F401
                       fold_octaves, struck, release_for, RECORD_PEAK, root_key_hz,
                       pcm16, build_synth, panel_of, face_knobs, OPEN, CHARACTERS, VEL_CUTOFF, key_up_s)

H_MAX = 64              # osc.resynth's harmonic cap (RS_HMAX)
COLOURS = 3             # noise colours (RS_CMAX is 4)
FLOOR = 1e-9

# (macro id, label, icon, default value, the osc.resynth parameter, its range, steps)
KNOBS = [
    ("TRACK", "TRACK", "tune", 0.0, "track", [0, 1], None),
    ("BREATH", "BREATH", "noise", 0.5, "breath", [0, 2], None),
    ("SPEED", "SPEED", "env", 0.5, "speed", [0.25, 4], None),
    ("HOLD", "HOLD", "wave", 0.0, "hold", ["wander", "loop"], "2"),
    ("TILT", "TILT", "filter", 0.5, "tilt", [-12, 12], None),
    ("MOTION", "MOTION", "lfo", 1.0, "motion", [0, 1], None),
]

# this block's part of each character (rs_common.CHARACTERS holds the shared envelope and filter part)
PRESETS = {
    "pad": {"BREATH": 0.6, "SPEED": 0.25},
    "bass": {"TRACK": 1.0, "TILT": 0.35, "MOTION": 0.0},
}


def slots(cap, x, h_max=H_MAX):
    """the free tracks folded onto harmonics of one pitch curve -> (f0 [F], amps [F, H], band power
    [F, 24], H). f0 per frame from YIN, refined by the tracks within a quarter harmonic of k * f0; each
    harmonic the power sum of the tracks within half a harmonic of it; a track near no harmonic is
    added to the noise, in its band, as power."""
    F = np.asarray(cap["freq"], np.float64)
    A = np.asarray(cap["amp"], np.float64)
    nf = F.shape[0]
    f0y, ap, hs = yin_track(x, SR, hop=256)
    t = (np.arange(nf) + cap["centre_hops"]) * cap["hop_s"]          # each frame's time in the take
    good = (ap < 0.3) & (f0y > 0)
    f0y, good = fold_octaves(f0y, good, float(cap["f0"]) if cap.get("f0") else float(np.median(f0y[good] if good.any() else f0y)))
    if good.any():
        tt = np.arange(f0y.size) * hs
        f0 = np.interp(t, tt[good], f0y[good])
    else:
        f0 = np.full(nf, float(cap["f0"]))
    for i in range(nf):
        live = A[i] > 0
        if not live.any():
            continue
        k = np.round(F[i, live] / f0[i])
        ok = (k >= 1) & (np.abs(F[i, live] - k * f0[i]) < 0.25 * f0[i])
        if ok.sum() >= 2:
            w = A[i, live][ok] ** 2 / k[ok]
            f0[i] = float(np.sum(w * F[i, live][ok] / k[ok]) / np.sum(w))
    H = int(max(1, min(h_max, math.floor(0.45 * SR / max(float(np.percentile(f0, 95)), 1.0)))))
    As = np.zeros((nf, H))
    noise = cap.get("noise")
    P = np.zeros((nf, RC.NOISE_BANDS)) if noise is None else 0.5 * np.asarray(noise, np.float64) ** 2
    edges = RC.band_edges_hz()
    for i in range(nf):
        live = A[i] > 0
        f, am = F[i, live], A[i, live]
        k = np.round(f / f0[i]).astype(np.int64)
        on = (k >= 1) & (k <= H) & (np.abs(f - k * f0[i]) < 0.5 * f0[i])
        np.add.at(As[i], k[on] - 1, am[on] ** 2)
        b = np.searchsorted(edges, f[~on]) - 1
        okb = (b >= 0) & (b < RC.NOISE_BANDS)
        np.add.at(P[i], b[okb], 0.5 * am[~on][okb] ** 2)
    return f0, np.sqrt(As), P, H


def nmf(P, C, iters=300, seed=0):
    """P [frames, bands] >= 0 ~ G [frames, C] @ W [C, bands] (multiplicative updates, least squares)"""
    rng = np.random.default_rng(seed)
    nf, B = P.shape
    s = float(P.mean()) + 1e-30
    G = (rng.random((nf, C)) + 0.1) * math.sqrt(s)
    W = (rng.random((C, B)) + 0.1) * math.sqrt(s)
    for _ in range(iters):
        W *= (G.T @ P) / (G.T @ G @ W + 1e-30)
        G *= (P @ W.T) / (G @ W @ W.T + 1e-30)
    return G, W


def _sig(v, n=4):
    return [float("%.*g" % (n, float(u))) for u in np.asarray(v).reshape(-1)]


def steady_frames(f0, As, ha, hb):
    """the HOLD region pulled in to STEADY frames: three in a row at each end whose pitch sits within
    50 cents of its neighbours' median and 150 of the region's, and whose harmonics carry within 6 dB
    of the region's median power. A held key drifts through the region and loops it, so a frame that
    is not the note's — the last 60 ms before a singer's key-up read 183 Hz in a 254 Hz note, the voice
    already ending — came back again and again: the fundamental 14 dB down while held.
    -> (ha, hb); (hb, hb) when no steady run is left"""
    f0 = np.asarray(f0, np.float64)
    nf = f0.size
    if hb - ha < 3:
        return hb, hb
    c = 1200.0 * np.log2(np.maximum(f0, 1.0))
    med = float(np.median(c[ha:hb]))
    loc = np.array([np.median(c[max(0, i - 5):min(nf, i + 6)]) for i in range(nf)])
    pw = 10.0 * np.log10(np.sum(np.asarray(As, np.float64) ** 2, axis=1) + 1e-30)
    pmed = float(np.median(pw[ha:hb]))
    ok = (f0 > 0) & (np.abs(c - loc) < 50.0) & (np.abs(c - med) < 150.0) & (np.abs(pw - pmed) < 6.0)
    run = ok & np.r_[ok[1:], False] & np.r_[ok[2:], False, False]
    inside = np.flatnonzero(run[ha:hb]) + ha
    if inside.size == 0:
        return hb, hb
    a, b = int(inside[0]), int(min(hb, inside[-1] + 3))
    return (a, b) if b - a >= 3 else (hb, hb)


def analyse(x, f0_hint, gate):
    """mono float audio at 44.1 kHz from its onset, the matcher's pitch (Hz, a hint) and key-up (s)
    -> dict(data=[...], F, H, C, rate, key_up, hold, f0, breath_db): the osc.resynth array, version 2"""
    x = np.asarray(x, np.float64)
    cap = RC.capture(x, SR, multi=True, align0=True)
    keep = np.asarray(cap["amp"]).max(axis=0) >= float(np.asarray(cap["amp"]).max() or 1.0) * 1e-3   # rsynth's prune(-60)
    cap["freq"] = np.asarray(cap["freq"])[:, keep]
    cap["amp"] = np.asarray(cap["amp"])[:, keep]
    f_meas = estimate_root(x, f0_hint) if not cap.get("f0") else float(cap["f0"])
    if f0_hint and f0_hint > 0 and abs(12 * math.log2(f_meas / f0_hint)) > 7.0:
        f_meas = float(f0_hint)
    f_root = root_key_hz(f_meas)
    f0, As, P, H = slots(cap, x)
    nf = As.shape[0]
    hop = float(cap["hop_s"])
    # the colours
    C = COLOURS if P.sum() > 0 else 0
    if C:
        G, W = nmf(P, C)
    else:
        G, W = np.zeros((nf, 0)), np.zeros((0, RC.NOISE_BANDS))
    env = cap.get("env")
    E = 0 if env is None else int(np.asarray(env).shape[1])
    head = cap.get("attack")
    nh = 0 if head is None else int(np.asarray(head).size)
    # the output scale: the RECORDING's, as the two recording blocks scale it (its loudest sample at
    # RECORD_PEAK) — the measurement is in the recording's own units, so the three play equally loud.
    # The worst case of every harmonic in phase was 3 dB quieter than the sampler on the same note.
    npow = (G @ W).sum(axis=1) if C else np.zeros(nf)
    norm = RECORD_PEAK / (float(np.abs(x).max()) or 1.0)
    hq, hscale = ([], 0.0)
    if nh:
        h = np.asarray(head, np.float64)
        hpk = float(np.abs(h).max()) or 1.0
        hq = [int(v) for v in np.round(h / hpk * 32767)]
        hscale = norm * hpk / 32767.0
    # where the key goes up, and the steady part a held key wanders in (a decay is all held part)
    hit = struck(x)
    gate = key_up_s(x, gate)
    key_up = nf if hit else int(min(nf, max(1, round(gate / hop))))
    ha = int(min(max(0, round(attack_end(x) / hop) + 2), key_up - 1))
    hb = key_up
    if hit or hb - ha < 2:
        ha = hb = key_up              # a decay, or no room: no region — the block plays it out and ends
    else:
        ha, hb = steady_frames(f0, As, ha, hb)
    hdr = [2, round(f_root, 4), round(hop, 7), nf, H, key_up, ha, hb, C, RC.NOISE_BANDS if C else 0, E, nh,
           SR if nh else 0, float("%.6g" % hscale), float("%.6g" % norm), 0]
    data = hdr + [round(float(v), 2) for v in f0] + _sig(As) + _sig(W) + _sig(G)
    if E:
        data += _sig(np.asarray(env)[0])
    data += hq
    if len(data) > MAX_FLOATS:
        raise ValueError("the measurement is %d floats, more than a node carries (%d)" % (len(data), MAX_FLOATS))
    hpow = 0.5 * float(np.mean(np.sum(As ** 2, axis=1))) + 1e-30
    return dict(data=data, F=nf, H=H, C=C, rate=1.0 / hop, key_up=key_up, key_up_s=(nf * hop if hit else gate),
                hold=(ha, hb), f0=f_root, f_measured=f_meas,
                struck=hit, release=release_for(hit, key_up < nf),
                breath_db=10.0 * math.log10(hpow / (float(np.mean(npow)) + 1e-30)) if C else 200.0)


def build(x, f0_hint, gate, base_doc, name):
    """the note measured into osc.resynth inside analog 1 (dashboard) -> (document, the measurement)"""
    m = analyse(x, f0_hint, gate)
    return build_synth("osc.resynth", m["data"], KNOBS, PRESETS, base_doc, name, m["release"]), m
