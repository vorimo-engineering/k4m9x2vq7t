"""scipy.fft.rfft as the matcher calls it. numpy's pocketfft is scipy's, so the values agree; what
differs is the dtype -- scipy keeps a float32 input single precision (complex64), numpy promotes it --
so the result is cast back the way scipy returns it. `workers` is accepted and ignored."""
import numpy as np


def rfft(x, n=None, axis=-1, norm=None, overwrite_x=False, workers=None, **kw):
    x = np.asarray(x)
    r = np.fft.rfft(x, n=n, axis=axis, norm=norm)
    return r.astype(np.complex64) if x.dtype == np.float32 else r


def irfft(x, n=None, axis=-1, norm=None, overwrite_x=False, workers=None, **kw):
    x = np.asarray(x)
    r = np.fft.irfft(x, n=n, axis=axis, norm=norm)
    return r.astype(np.float32) if x.dtype == np.complex64 else r
