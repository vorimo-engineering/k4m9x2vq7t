"""THE BROWSER'S SCIPY (match/py, packed into matcher.zip): the handful of scipy calls the matcher
makes, in numpy, so the page never downloads scipy (~25 MB in Pyodide) for five functions. Each one
reproduces scipy's own conventions (window placement, edge mode, dtype) and is checked against the
real scipy by match/test_shims.py. Anything else from scipy is an ImportError on purpose: a new
dependency should show up as one, not as a silently different number."""
