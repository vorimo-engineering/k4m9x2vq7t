"""scipy.ndimage's uniform_filter1d and median_filter, as the matcher calls them (uniform on any axis,
median on 1-D). scipy places a window of `size` at [i - size//2, i - size//2 + size) and extends the
ends by its `mode` -- reflect (d c b a | a b c d, the default), nearest, mirror (d c b | a b c d),
wrap, constant -- which are numpy's symmetric, edge, reflect, wrap and constant pads; a float32
input stays float32."""
import numpy as np

_PAD = {"reflect": "symmetric", "nearest": "edge", "mirror": "reflect", "wrap": "wrap", "constant": "constant",
        "grid-mirror": "symmetric", "grid-wrap": "wrap", "grid-constant": "constant"}


def _pad(x, size, axis, mode, cval):
    lo, hi = size // 2, size - 1 - size // 2
    pad = [(0, 0)] * x.ndim
    pad[axis] = (lo, hi)
    m = _PAD[mode]
    return np.pad(x, pad, mode=m, constant_values=cval) if m == "constant" else np.pad(x, pad, mode=m)


def uniform_filter1d(input, size, axis=-1, output=None, mode="reflect", cval=0.0, origin=0):
    if origin != 0 or mode not in _PAD:
        raise NotImplementedError("the browser's uniform_filter1d: origin 0, scipy's modes")
    x = np.asarray(input)
    size = int(size)
    if size <= 1:
        return x.copy()
    axis = axis % x.ndim
    p = _pad(x.astype(np.float64), size, axis, mode, cval)
    c = np.cumsum(p, axis=axis)
    c = np.concatenate([np.zeros_like(np.take(c, [0], axis=axis)), c], axis=axis)
    n = x.shape[axis]
    y = (np.take(c, np.arange(size, size + n), axis=axis) - np.take(c, np.arange(0, n), axis=axis)) / size
    return y.astype(x.dtype) if np.issubdtype(x.dtype, np.floating) else y


def median_filter(input, size=None, footprint=None, output=None, mode="reflect", cval=0.0, origin=0, axes=None):
    if origin != 0 or footprint is not None or mode not in _PAD:
        raise NotImplementedError("the browser's median_filter: origin 0, a size, scipy's modes")
    x = np.asarray(input)
    if x.ndim != 1:
        raise NotImplementedError("the browser's median_filter: 1-D only")
    size = int(size)
    if size <= 1:
        return x.copy()
    w = np.lib.stride_tricks.sliding_window_view(_pad(x, size, 0, mode, cval), size)
    return np.median(w, axis=-1).astype(x.dtype)
