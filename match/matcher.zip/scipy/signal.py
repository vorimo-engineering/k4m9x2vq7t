"""scipy.signal's butter (a high or low pass as second-order sections), sosfiltfilt and resample_poly,
for the one place the matcher reaches for them: match.to_mono_44k (a DC offset's high pass at a few
Hz; a take at another rate). The browser decodes every file at 44.1 kHz already, so resample_poly is
a fallback (linear interpolation, not scipy's polyphase filter); butter + sosfiltfilt follow scipy's
design (the bilinear transform of the prewarped Butterworth prototype) and its padding (odd
extension, padlen 3 * (2 * sections + 1), steady-state initial conditions)."""
import numpy as np


def butter(N, Wn, btype="low", analog=False, output="ba", fs=None):
    if analog or output != "sos":
        raise NotImplementedError("the browser's butter: digital, output='sos'")
    wn = float(Wn) / (fs / 2.0) if fs else float(Wn)
    k = np.tan(np.pi * wn / 2.0)                 # the prewarped edge (fs = 2)
    sos = []
    for i in range(int(N) // 2):                 # conjugate pole pairs of the analog prototype
        q = 1.0 / (2.0 * np.sin(np.pi * (2 * i + 1) / (2.0 * N)))
        a0 = 1.0 + k / q + k * k
        if btype in ("high", "highpass"):
            b = [1.0 / a0, -2.0 / a0, 1.0 / a0]
        else:
            b = [k * k / a0, 2 * k * k / a0, k * k / a0]
        sos.append(b + [1.0, 2.0 * (k * k - 1.0) / a0, (1.0 - k / q + k * k) / a0])
    if int(N) % 2:
        a0 = 1.0 + k
        if btype in ("high", "highpass"):
            sos.append([1.0 / a0, -1.0 / a0, 0.0, 1.0, (k - 1.0) / a0, 0.0])
        else:
            sos.append([k / a0, k / a0, 0.0, 1.0, (k - 1.0) / a0, 0.0])
    return np.asarray(sos, np.float64)


def _sosfilt(sos, x, zi):
    y = np.asarray(x, np.float64).copy()
    x0 = y[0]                                    # scipy scales every section's zi by the CASCADE's input
    for s in range(sos.shape[0]):
        b0, b1, b2, _, a1, a2 = sos[s]
        z0, z1 = zi[s] * x0 if zi is not None else (0.0, 0.0)
        out = np.empty_like(y)
        for i in range(y.size):                  # direct form II transposed, as scipy's sosfilt
            xi = y[i]
            yi = b0 * xi + z0
            z0 = b1 * xi - a1 * yi + z1
            z1 = b2 * xi - a2 * yi
            out[i] = yi
        y = out
    return y


def _sosfilt_zi(sos):
    zi = np.zeros((sos.shape[0], 2))
    scale = 1.0
    for s in range(sos.shape[0]):
        b0, b1, b2, _, a1, a2 = sos[s]
        # the steady state of one section for a unit step (scipy.signal.lfilter_zi of the section)
        A = np.array([[1.0 + a1, -1.0], [a2, 1.0]])
        B = np.array([b1 - a1 * b0, b2 - a2 * b0])
        zi[s] = scale * np.linalg.solve(A, B)
        scale *= (b0 + b1 + b2) / (1.0 + a1 + a2)
    return zi


def sosfiltfilt(sos, x, axis=-1, padtype="odd", padlen=None):
    x = np.asarray(x, np.float64)
    if x.ndim != 1:
        raise NotImplementedError("the browser's sosfiltfilt: 1-D only")
    sos = np.asarray(sos, np.float64)
    n = 3 * (2 * sos.shape[0] + 1 - min(int((sos[:, 2] == 0).sum()), int((sos[:, 5] == 0).sum())))
    n = min(n if padlen is None else int(padlen), x.size - 1)
    ext = np.concatenate([2 * x[0] - x[n:0:-1], x, 2 * x[-1] - x[-2:-n - 2:-1]]) if n > 0 else x
    zi = _sosfilt_zi(sos)
    y = _sosfilt(sos, ext, zi)
    y = _sosfilt(sos, y[::-1], zi)[::-1]
    return y[n:y.size - n] if n > 0 else y


def resample_poly(x, up, down, axis=0, window=("kaiser", 5.0), padtype="constant", cval=None):
    x = np.asarray(x, np.float64)
    if x.ndim != 1:
        raise NotImplementedError("the browser's resample_poly: 1-D only")
    m = int(np.ceil(x.size * up / down))
    return np.interp(np.arange(m) * (down / up), np.arange(x.size), x)
