"""rs_capture.py — rsynth's analysis, the part osc.resynth's measurement stands on (2026-10-07).

VENDORED, NOT REWRITTEN: the functions below are copied from ~/Projects/rsynth/rsynth/capture.py (the
standalone resynthesis instrument, 2026-08-20 .. 09-23 — graft's listener-approved free-track capture),
with their measured reasons kept beside them. Changed: `capture` returns a dict instead of rsynth's
Asset (its C engine is not here), and nothing else. numpy only, so it runs in the browser's matcher
(Pyodide) as well as natively.

Free spectral peaks tracked across frames by cents continuity (`_track`), two windows spliced onto one
grid (`multi`), frame 0 on the onset (`align0`), the partials' mainlobes subtracted from each frame to
leave the NOISE in 24 bands (`_noise_plane`), the take's root from a window long enough to resolve it
(`f0_from_audio`) and its spectral envelope by the iterative true-envelope estimator (`true_envelope`).
resynth.py folds the tracks onto harmonics of one pitch curve and the bands into a few colours.
"""
from __future__ import annotations

import bisect
import math
from dataclasses import dataclass, field

import numpy as np

#: analysis window and hop, samples. 4096 at 44.1 kHz is 93 ms -- long enough
#: to separate partials a semitone apart down to about 130 Hz, short enough to
#: follow a plucked decay. The engine reads `hop_s` from the asset, so nothing
#: downstream depends on these two numbers except the analysis itself.
WIN = 4096

HOP = 512

#: frame i is CENTRED at (i + CENTRE_HOPS) * hop -- the STFT is uncentred, so
#: dropping this shifts every track 43 ms early against the sound it came from.
CENTRE_HOPS = (WIN // 2) // HOP

#: THE ATTACK WINDOW (multi=True). 1024 is 23 ms, and the number that matters
#: is not its length but its HALF-length: 512, exactly one hop. A window's
#: frame sounds at its own centre, so a 1024 window centred on the plane's grid
#: starts on the grid too -- the two analyses share a timeline instead of one
#: being resampled onto the other's. 512 would centre half a hop off the grid
#: and 2048 would only reach 23 ms in, which is not early enough to matter.
WIN_SHORT = 1024

CENTRE_HOPS_SHORT = (WIN_SHORT // 2) // HOP

#: how many grid frames the body window cannot reach at all -- the hole.
_MULTI_SHIFT = CENTRE_HOPS - CENTRE_HOPS_SHORT

#: how far apart two tracks may be AT THE JOIN and still be one partial. Wider
#: than LINK_CENTS on purpose: the two sides measure the same partial through
#: windows whose bins are 4x apart, so the disagreement here is the estimator's
#: and not the sound's.
MULTI_JOIN_CENTS = 120.0

#: frames over which a joined track's frequency is blended onto the body
#: window's reading, so the splice is not a step. The last short frame takes
#: the body's own value: a joined partial has ONE frequency at the seam.
MULTI_XF_FR = 3

#: a track that never leaves the attack region lives at most a handful of
#: frames, so MIN_FRAMES would delete every one of them -- and a two-frame
#: event in the first 40 ms of a take is not an artefact, it is the attack.
MULTI_MIN_FR = 2

#: a peak must clear the frame's own maximum by no more than this to count.
PEAK_FLOOR_DB = -70.0

#: how far a peak may move between frames and still be the same partial. Half a
#: semitone follows vibrato and drift without letting neighbours cross-link.
LINK_CENTS = 50.0

#: ...AND NEVER LESS THAN HALF A BIN. Cents are the wrong unit at the bottom of
#: a short window: at 100 Hz, 50 cents is 2.9 Hz, and the short window's bins
#: are 43 Hz wide. A kick's body falls 144 -> 77 Hz in 30 ms, 60-200 cents per
#: 2.9 ms frame, so every frame of it started a new track, every one-frame track
#: was deleted, and the loudest thing in the take -- 20x anything else in the
#: frame -- was absent from the model for its first 8 frames (the render sat
#: 30 dB under the recording, then burst when the tracker finally caught the
#: tail at 80 Hz). Half a bin is safe by construction: peaks are local maxima,
#: two bins apart at least, so a half-bin window around the last frequency can
#: never hold a neighbour's peak.
LINK_BINS = 0.5

#: shorter than this and it is a transient artefact, not a partial.
MIN_FRAMES = 4

#: A TAKE THIS SHORT IS ANALYSED ENTIRELY THROUGH THE SHORT WINDOW.
#:
#: The body window is 4096 samples = 93 ms, so `n_frames` is
#: 1 + (len - 4096)//512: a 122 ms snare yields THREE body frames and a 43 ms
#: kick yields none at all. The model then spans `(n_frames-1)*hop` -- 58 ms
#: of that snare -- and past its end the sines carry the tail alone with the
#: banded noise gated off. That is the measured cause of the drum failures
#: (proposal §14), and Levine/Verma/Smith 1998 named it in general: one-band
#: long windows "blur or eliminate any sharp attacks".
#:
#: Below this length the take is analysed with WIN_SHORT throughout -- ONE
#: window, not a splice, because the residual's band scale is calibrated per
#: window and mixing two of them across a join was measured to step the band
#: plane by +5.3 dB on one take and -35.2 on another. 0.6 s is where the body
#: window starts to yield enough frames to describe a take at all (~six).
SHORT_TAKE_S = 0.60

#: and the hop a short take is analysed on, in samples.
#:
#: The hop is the model's TIME RESOLUTION -- how often a partial's amplitude
#: and every noise band is allowed to change -- and at the shipped 512 (11.6
#: ms) it is far coarser than a drum's structure. Measured on six GM drums,
#: model-only render against the source (no recorded layers at all):
#:
#:     hop 512 (11.6 ms)   median 11.97 dB
#:     hop 256 ( 5.8 ms)   median 12.80
#:     hop 128 ( 2.9 ms)   median  9.40      <- 2.57 dB better
#:
#: with the biggest gains where the sound is fastest (kick 11.2 -> 6.9, tom
#: 7.9 -> 5.7, ride 12.8 -> 11.0). This is Levine/Verma/Smith 1998 restated:
#: their top octave uses a 5.75 ms hop for exactly this reason. It costs
#: frames -- four times as many for the same take -- which is why it applies
#: only where it was measured to pay.
SHORT_HOP = 128

#: THE NOISE BAND LAW, and the C engine repeats these three numbers rather than
#: reading them from the file -- a band plane is only meaningful against the law
#: that made it, so the law is a contract and not data. 24 bands from 40 Hz to
#: 20 kHz is 0.374 of an octave each, near enough a third-octave to be the
#: resolution the ear brings to noise.
#: AUTOMATIC track count: keep every track within this much of the loudest
#: one. A fixed ceiling is the wrong shape for the question -- an e-piano holds
#: 20 partials worth having and a voice holds a thousand, and the same number
#: cannot serve both without either starving one or making the other pay for
#: oscillators that are inaudible. Measured across the pack at -50 dB: e-piano
#: 20, brass 54, organ 228, strings 365, a recorded voice 1079.
#: and it is the SAME floor `prune` uses, deliberately. At -50 the automatic
#: count was stricter than the prune that follows it, so a sparse take lost
#: partials it used to keep: an e-piano went 22 -> 13 and its attack residual
#: rose from -9.5 to -2.6 dB. Auto must never keep less than the pipeline was
#: going to keep anyway.
TRACK_FLOOR_DB = -60.0

#: and a hard stop, because "keep everything above a floor" has no upper bound
#: on a noisy recording and the render pays per oscillator per block.
TRACK_CEILING = 1200

#: THE SPECTRAL ENVELOPE grid: log-spaced points over the noise band law's own
#: range, twice as fine because a formant is a narrower thing than a noise band.
#: This plane is what lets a transposed note keep the take's own resonances --
#: an additive engine knows where every partial is, so it can slide the
#: harmonics under a fixed envelope instead of dragging the envelope with them,
#: which is the thing a sampler cannot do and the reason a sample played an
#: octave up sounds like a smaller instrument.
ENV_BINS = 48

#: experiment switches for the true-envelope estimator (off = the frozen
#: peak-connect envelope, which is what the audit currently passes on)
_TRUE_ENV = True

_TRUE_ENV_ORDER = 0.20

def _CEP_TAPER(order: int):
    """Half a Hamming window over the kept quefrencies: 1 at q=0, tapering to
    the cut. See true_envelope for why a hard cut is not usable."""
    q = np.arange(order, dtype=np.float64) / max(order - 1, 1)
    return 0.54 + 0.46 * np.cos(np.pi * q)

NOISE_BANDS = 24

NOISE_F_LO = 40.0

NOISE_F_HI = 20000.0

#: how far either side of a partial its window skirt is subtracted. Hann's
#: sidelobes fall 18 dB/octave, so 16 bins reaches about -80 dB and the rest is
#: below anything the band sum can see.
NOISE_SKIRT = 16

#: the mainlobe is WIDENED by this many bins before subtracting. Parabolic
#: interpolation on a linear magnitude is biased by ~0.03 bins, and a lobe
#: displaced by 0.03 bins leaves a -27 dB scar that is not noise, it is the
#: estimator. Widening the model to cover the estimator's own error costs 2.5%
#: of the mainlobe and takes that scar to -66 dB.
NOISE_LOBE_WIDEN = 0.10

#: A WHOLE-TAKE decision, and deliberately not a per-band one. Gating single
#: bands against a floor was tried and it punched HOLES in the plane -- a band
#: at zero beside a loud neighbour -- which no synthesis with finite resolution
#: can reproduce, so the hole came back as a smear that was worse than the band
#: it replaced. Either a take has a residual or it does not: below this, against
#: its own partials, it is the estimator's own noise (a clean synthetic tone
#: measures -78 dB here; real takes measure -12 to -21) and the asset carries no
#: plane at all, which is also what makes such a take render bit-for-bit as it
#: did before this layer existed.
NOISE_MIN_DB = -45.0

#: lobe lookup resolution, samples per bin.
_LOBE_OS = 128

#: THE RAW HEAD. How much of the take's own PCM the asset keeps. 80 ms is long
#: enough to cover the window that cannot describe itself (frame 0 sounds 46 ms
#: in) with room for the crossfade, and short enough that a transposed note is
#: still mostly the model, which is the thing a key can actually play.
ATTACK_S = 0.08

#: a hair of the take BEFORE the onset, so the head starts where the recording
#: is quiet and its first sample cannot be a step.
ATTACK_PRE_S = 0.005

#: the onset: the first sample that clears this against the take's own peak.
#: Deliberately low. Cutting early costs a few ms of silence at the head of a
#: buffer that is played from note t=0 anyway; cutting late clips the transient
#: the head exists to keep.
ATTACK_ONSET_DB = -60.0

_LOBE = {}

@dataclass
class _Track:
    freq: list
    amp: list
    first: int
    phase: list = field(default_factory=list)

def band_edges_hz(n_bands: int = NOISE_BANDS):
    """The `n_bands + 1` band edges, log-spaced. The C engine's own law."""
    k = np.arange(n_bands + 1, dtype=np.float64)
    return NOISE_F_LO * (NOISE_F_HI / NOISE_F_LO) ** (k / float(n_bands))

def _lobe_table(win_n=WIN):
    """|W(d)| / |W(0)| for the analysis window, widened, at 1/_LOBE_OS bins.

    Cached PER WINDOW: it is a property of `np.hanning(win_n)` and nothing
    else, and multi-resolution means there is more than one of those.
    """
    if win_n not in _LOBE:
        win = np.hanning(win_n)
        spec = np.abs(np.fft.rfft(win, win_n * _LOBE_OS))
        n_need = int((NOISE_SKIRT + NOISE_LOBE_WIDEN + 1) * _LOBE_OS) + 2
        exact = (spec[:n_need] / spec[0]).astype(np.float64)
        w = int(round(NOISE_LOBE_WIDEN * _LOBE_OS))
        if w > 0:
            # a running max over +-w: the widened lobe DOMINATES the true one,
            # so a partial's own energy always subtracts to zero or below.
            pad = np.concatenate([exact[w:0:-1], exact, np.zeros(w)])
            wide = np.lib.stride_tricks.sliding_window_view(pad, 2 * w + 1)
            wide = wide.max(axis=1)[:exact.size]
        else:
            wide = exact
        _LOBE[win_n] = (exact, wide)
    return _LOBE[win_n]

def env_edges_hz(n_bins: int = ENV_BINS):
    """The `n_bins` envelope grid CENTRES, log-spaced. The C's own law."""
    k = np.arange(n_bins, dtype=np.float64)
    return NOISE_F_LO * (NOISE_F_HI / NOISE_F_LO) ** (k / float(n_bins - 1))

def _env_plane(F, A, n_bins: int = ENV_BINS):
    """The take's spectral envelope per frame: [n_frames, n_bins].

    Where the partials are, it IS the partials -- each grid point takes the
    loudest partial within half a step, so at a partial's own frequency the
    envelope returns that partial's amplitude and a note played at its root
    key is unchanged. Between and beyond them it is filled by interpolation in
    dB across log frequency, which is what makes it an envelope rather than a
    comb: a transposed harmonic landing between two of the take's own gets the
    level the take had THERE, not the level of the harmonic it came from.
    """
    n_fr = F.shape[0]
    c = env_edges_hz(n_bins)
    lg = np.log(c)
    step = (lg[-1] - lg[0]) / (n_bins - 1)
    out = np.zeros((n_fr, n_bins), dtype=np.float64)
    for t in range(n_fr):
        f, a = F[t], A[t]
        live = (a > 0.0) & (f > 0.0)
        if not live.any():
            continue
        lf, la = np.log(f[live]), a[live]
        idx = np.clip(np.rint((lf - lg[0]) / step).astype(int), 0, n_bins - 1)
        row = np.zeros(n_bins)
        np.maximum.at(row, idx, la)
        hit = np.flatnonzero(row > 0.0)
        if hit.size == 1:
            row[:] = row[hit[0]]
        elif hit.size > 1:
            # in dB, so a formant's slope is a straight line and not a curve
            db = 20.0 * np.log10(np.maximum(row[hit], 1e-12))
            row = 10.0 ** (np.interp(lg, lg[hit], db) / 20.0)
        out[t] = row
    return out


def true_envelope(y, sr, f0, n_bins: int = ENV_BINS, order_scale: float = 0.5,
                  iters: int = 60, tol_db: float = 1.0):
    """The take's spectral envelope by the ITERATIVE TRUE ENVELOPE estimator.

    Roebel & Rodet, "Efficient Spectral Envelope Estimation and its
    application to pitch shifting and envelope preservation", DAFx-05. It is
    the method that literature picks for exactly this job -- shifting pitch
    while keeping the envelope -- and it is picked over the discrete cepstrum
    and over peak-connecting precisely because those "produce artifacts in
    high-pitched signals", which is our worst case (two octaves up).

    `_env_plane` connects the loudest partial per log bin and interpolates in
    dB. That is a peak-CONNECTING estimate: jagged where harmonics are sparse
    (the low end of any take), and above the highest tracked partial it holds
    that partial's level flat forever -- so a partial transposed past the
    take's own top was multiplied by whatever the last dying harmonic
    happened to be. The cepstral envelope has no such edge: it is a smooth
    function fitted to the whole log spectrum, so it extrapolates the take's
    own trend instead of a single endpoint.

    The iteration is: smooth the log spectrum by truncating its cepstrum, then
    take the max of the original and the smoothed version, and repeat. The max
    is what makes it "true" -- the envelope is pushed up onto the peaks rather
    than averaging through the valleys between harmonics.
    """
    y = np.asarray(y, np.float64).ravel()
    if y.size < 2048 or not np.isfinite(f0) or f0 <= 0.0:
        return None
    n = 1 << 14
    hop = n // 4
    frames = []
    for a in range(0, max(len(y) - n, 1), hop):
        seg = y[a:a + n]
        if seg.size < n:
            break
        frames.append(np.abs(np.fft.rfft(seg * np.hanning(n))))
    if not frames:
        return None
    S = np.stack(frames)
    # LOUDNESS-WEIGHTED, so the envelope describes the take where the take is
    # actually sounding rather than being dragged down by its own tail.
    w = S.sum(1, keepdims=True)
    mag = (S * w).sum(0) / max(float(w.sum()), 1e-12)
    A_log = np.log(np.maximum(mag, 1e-10))

    # the cepstral cut sits BELOW the harmonic quefrency 1/f0 (index sr/f0),
    # or the envelope would be free to follow the harmonic ripple itself
    order = int(max(4.0, min(order_scale * sr / f0, n / 4.0)))
    V = A_log.copy()
    full = np.concatenate([A_log, A_log[-2:0:-1]])
    Sm = A_log
    for _ in range(iters):
        full[:len(V)] = V
        full[len(V):] = V[-2:0:-1]
        c = np.real(np.fft.ifft(full))
        # TAPERED, NOT TRUNCATED. Cutting the cepstrum dead at `order` is a
        # RECTANGULAR window in quefrency, and it rings in frequency exactly
        # as one would in time: on a 7-harmonic 1/k tone the envelope came
        # out non-monotonic -- -7.7 dB at 440 Hz but -6.4 at 880, where 1/k
        # says -12 -- and that bump made the 4th harmonic the loudest one an
        # octave up, doubling the dominant partial. Roebel & Rodet name the
        # remedy: "the use of a Hamming window as smoothing filter helps
        # remedy ringing effects in the spectral envelope".
        c[:order] *= _CEP_TAPER(order)
        c[order:len(c) - order + 1] = 0.0
        c[len(c) - order + 1:] = c[1:order][::-1]   # keep it symmetric
        Sm = np.real(np.fft.fft(c))[:len(A_log)]
        if float(np.max(A_log - Sm)) < tol_db * (np.log(10.0) / 20.0):
            break
        V = np.maximum(A_log, Sm)
    fr = np.fft.rfftfreq(n, 1.0 / sr)
    ctr = env_edges_hz(n_bins)
    out = np.exp(np.interp(np.log(np.maximum(ctr, 1e-9)),
                           np.log(np.maximum(fr, 1e-9)), Sm))

    # FLAT OUTSIDE THE TAKE'S OWN SUPPORT, which is the half of the old
    # peak-connecting envelope that was RIGHT. A cepstral envelope keeps
    # falling past the band edges of the take, and the formant ratio
    # env(f*r)/env(f) then crushes any partial transposed out of that band:
    # an octave down puts a 220 Hz fundamental at 110 Hz, below anything the
    # take contains, and it fell off the cliff -- 10.3 dB of shape error on a
    # synth tone that should have cost nothing, since a uniform ratio is only
    # a level change. Outside the support the envelope knows NOTHING, and the
    # honest value there is "no opinion": held flat, two partials both outside
    # share a ratio of exactly 1, which is tape -- the right default where
    # there is no evidence. Inside the support the cepstral estimate is what
    # buys the smoothness (Roebel/Rodet), so the two halves compose.
    lo_db = 20 * np.log10(np.maximum(mag, 1e-12))
    lo_db -= lo_db.max()
    live = np.flatnonzero(lo_db > -50.0)
    if live.size >= 2:
        f_lo, f_hi = fr[live[0]], fr[live[-1]]
        i_lo = int(np.searchsorted(ctr, f_lo))
        i_hi = int(np.searchsorted(ctr, f_hi))
        i_lo = min(max(i_lo, 0), n_bins - 1)
        i_hi = min(max(i_hi, 0), n_bins - 1)
        if i_lo > 0:
            out[:i_lo] = out[i_lo]
        if i_hi < n_bins - 1:
            out[i_hi + 1:] = out[i_hi]
    return out

def _noise_plane(mags, F, A_raw, sr, win_n=WIN):
    """Residual band POWER [n_frames, NOISE_BANDS], in the frame's own units.

    `A_raw` is the plane BEFORE the 4/win scale, i.e. the PEAK magnitude each
    partial was measured at, which is exactly what has to come back out of the
    frame spectrum for the leftover to mean anything. It is the peak and not
    the bin because `_frame_peaks` now corrects for the window's lobe at the
    sub-bin offset -- this pass used to make that correction itself, and the
    two would have applied it twice.
    """
    wide = _lobe_table(win_n)[1]
    n_fr, n_bins = mags.shape
    df = float(sr) / win_n
    freqs = np.fft.rfftfreq(win_n, 1.0 / float(sr))
    edges = band_edges_hz()
    bidx = np.searchsorted(edges, freqs, side="right") - 1
    bidx = np.where((freqs >= edges[0]) & (freqs < edges[-1]), bidx, -1)
    inb = bidx >= 0
    bsafe = np.where(inb, bidx, 0)
    # rfft holds one copy of every bin except DC and Nyquist: the two-sided
    # power of the rest is double what is written here.
    dbl = np.full(n_bins, 2.0)
    dbl[0] = 1.0
    dbl[-1] = 1.0
    offs = np.arange(-NOISE_SKIRT, NOISE_SKIRT + 1)
    lim = wide.size - 1

    out = np.zeros((n_fr, NOISE_BANDS), dtype=np.float64)
    for fi in range(n_fr):
        mag = mags[fi].astype(np.float64)
        live = A_raw[fi] > 0.0
        if live.any():
            nu = F[fi][live] / df
            peak = A_raw[fi][live]
            j = np.rint(nu)
            bins = (j[:, None] + offs[None, :]).astype(np.int64)
            d = np.rint(np.abs(bins - nu[:, None]) * _LOBE_OS).astype(np.int64)
            model = peak[:, None] * wide[np.minimum(d, lim)]
            ok = (bins >= 0) & (bins < n_bins)
            mag = mag - np.bincount(bins[ok], weights=model[ok],
                                    minlength=n_bins)
        np.maximum(mag, 0.0, out=mag)
        p = np.where(inb, dbl * mag * mag, 0.0)
        out[fi] = np.bincount(bsafe, weights=p, minlength=NOISE_BANDS)[:NOISE_BANDS]
    return out

def find_onset(y) -> int:
    """The first sample of the take that is not silence, by ATTACK_ONSET_DB.

    A threshold and nothing cleverer, because of what this number is for: it
    only decides where the raw head is CUT, and the head is played from note
    t=0 whatever the answer. An onset detector that reasoned about spectral
    flux would earn nothing here and would have opinions about vibrato.
    """
    y = np.asarray(y, dtype=np.float64).ravel()
    if y.size == 0:
        return 0
    peak = float(np.abs(y).max())
    if peak <= 0.0:
        return 0
    hit = np.flatnonzero(np.abs(y) >= peak * 10.0 ** (ATTACK_ONSET_DB / 20.0))
    return int(hit[0]) if hit.size else 0

def _frame_peaks(mag, freqs, floor_db, spec=None, win_n=WIN, sr=0.0):
    """Local maxima above the frame's own floor, with parabolic refinement.

    THE AMPLITUDE IS THE PEAK'S, NOT THE BIN'S. A partial sitting between two
    bins puts its mainlobe's SHOULDER in the taller of them, so the bin reads
    low by the window's own lobe at that sub-bin offset -- up to 1.42 dB, and a
    different amount for every partial, which is a timbre tilt and not a level
    offset. The residual pass already made exactly this correction before
    subtracting (it had to, or it would have left a scar where the partial was);
    the plane the engine plays did not, so the engine rendered every capture
    slightly short and slightly wrong-coloured. Corrected here, once, where the
    number is measured -- and `_noise_plane` no longer repeats it.

    With `spec` (the frame's complex transform) each peak also carries its
    PHASE AT THE FRAME'S CENTRE -- the instant the freq and amp beside it
    already describe, so all three planes speak about one time.

    Two corrections earn that. `np.hanning` is symmetric about (win_n-1)/2, so
    the transform's phase is the partial's phase THERE, and the linear term of
    the window's own transform has to be added back: a peak read at bin j is
    late by j*(win_n-1)/win_n half-turns. Then the grid's centre is win_n/2,
    half a sample later still, which at 10 kHz is 0.7 radians -- not a rounding
    error, a wrong answer. Neither correction depends on where between bins the
    peak fell, which is what makes this robust: the estimator's frequency bias
    moves the phase by half a sample of it and nothing more.
    """
    out = []
    if mag.size < 3:
        return out
    peak = float(mag.max())
    if peak <= 0.0:
        return out
    exact, _ = _lobe_table(win_n)
    lim = exact.size - 1
    thr = peak * (10.0 ** (floor_db / 20.0))
    hi = np.flatnonzero((mag[1:-1] > mag[:-2]) & (mag[1:-1] >= mag[2:])
                        & (mag[1:-1] > thr)) + 1
    for j in hi:
        # THE PARABOLA IS FITTED IN dB, not in linear magnitude. A window's
        # mainlobe is close to a Gaussian, and a Gaussian's LOG is exactly a
        # parabola -- fitting the linear magnitude instead fits the wrong curve
        # and lands off-centre by a consistent amount. Measured over 400 random
        # sinusoids through this window: 0.398 Hz of median error linear,
        # 0.120 Hz in dB, a 3.3x improvement for three logarithms. That is 0.69
        # cents against 0.21 at 1 kHz, and it is the number every partial's
        # frequency, phase wrap and amplitude correction is built on.
        a = 20.0 * np.log10(max(float(mag[j - 1]), 1e-12))
        b = 20.0 * np.log10(max(float(mag[j]), 1e-12))
        c = 20.0 * np.log10(max(float(mag[j + 1]), 1e-12))
        den = a - 2.0 * b + c
        off = 0.5 * (a - c) / den if abs(den) > 1e-12 else 0.0
        off = float(np.clip(off, -0.5, 0.5))
        df = freqs[1] - freqs[0]
        f = float(freqs[j] + off * df)
        d0 = int(min(int(np.rint(abs(off) * _LOBE_OS)), lim))
        amp = float(mag[j]) / max(float(exact[d0]), 1e-6)
        ph = 0.0
        if spec is not None:
            ph = float(np.angle(spec[j])
                       + np.pi * float(j) * (win_n - 1) / win_n
                       + np.pi * f / float(sr))
        out.append((f, amp, ph))
    return out

def _track(y, sr, win_n, starts, want_phase):
    """Free-peak tracking over the frames that BEGIN at `starts`.

    The one analysis pass, factored out so that multi-resolution is two calls
    to it and not a second tracker with its own opinions. `first` indexes
    `starts`, and the frame spectra come back with the tracks because the
    residual can only be measured once the track set is final.

    LINKING IS A WINDOW, NOT A SCAN. Comparing every live track against every
    peak is the whole cost of a capture -- 19 M scalar `abs` and as many
    `np.log2` calls on a 1.5 s take, which is a 6 s recording freezing the
    window for the better part of a minute. A peak list is ascending in
    frequency (local maxima are two bins apart at least), so the only peaks
    that can be within LINK_CENTS of a track sit in one contiguous slice of it,
    and a bisect finds that slice. The arithmetic INSIDE the slice is left
    exactly as it was -- same expression, same order -- so the answer is the
    same bits, not merely the same idea.
    """
    win = np.hanning(win_n)
    freqs = np.fft.rfftfreq(win_n, 1.0 / sr)
    n_frames = len(starts)
    mags = np.empty((n_frames, win_n // 2 + 1), dtype=np.float32)
    # the slice's half-width in log2, with room for the rounding that separates
    # `log2(a) - log2(b)` from the `log2(a/b)` the comparison below still uses.
    span = LINK_CENTS / 1200.0 * (1.0 + 1e-9) + 1e-12
    tol_hz = LINK_BINS * float(sr) / float(win_n)
    live, done = [], []
    for fi in range(n_frames):
        seg = y[starts[fi]:starts[fi] + win_n]
        if seg.size < win_n:
            seg = np.pad(seg, (0, win_n - seg.size))
        spec = np.fft.rfft(seg * win)
        mag = np.abs(spec)
        mags[fi] = mag
        peaks = _frame_peaks(mag, freqs, PEAK_FLOOR_DB,
                             spec if want_phase else None, win_n, sr)
        lf = [math.log2(p[0]) if p[0] > 0.0 else -1e30 for p in peaks]
        used = [False] * len(peaks)
        nxt = []
        for tr in live:
            f_last = tr.freq[-1]
            lt = math.log2(max(f_last, 1e-9))
            # the slice widens to half a bin where that is wider than the
            # cents (the bottom of the spectrum); above it nothing changes
            lo_b = math.log2(max(f_last - tol_hz, 1e-9))
            hi_b = math.log2(f_last + tol_hz)
            i0 = bisect.bisect_left(lf, min(lt - span, lo_b))
            i1 = bisect.bisect_right(lf, max(lt + span, hi_b))
            best, bd = -1, None
            for pi in range(i0, i1):
                f = peaks[pi][0]
                if used[pi] or f <= 0.0:
                    continue
                d = abs(1200.0 * np.log2(f / max(f_last, 1e-9)))
                if (d <= LINK_CENTS or abs(f - f_last) <= tol_hz) \
                        and (bd is None or d < bd):
                    best, bd = pi, d
            if best >= 0:
                used[best] = True
                f, a, ph = peaks[best]
                tr.freq.append(f)
                tr.amp.append(a)
                tr.phase.append(ph)
                nxt.append(tr)
            else:
                done.append(tr)
        for pi, (f, a, ph) in enumerate(peaks):
            if not used[pi]:
                nxt.append(_Track([f], [a], fi, [ph]))
        live = nxt
    done.extend(live)
    return done, mags

def _join(short, long_, b):
    """One track set from two analyses, spliced at grid frame `b`.

    A partial does not stop existing because the window changed, so the two
    sides are matched by nearest frequency at the seam -- greedily, over every
    pair sorted by distance, so the answer does not depend on track order --
    and the short side's last MULTI_XF_FR frames are bent onto the body
    window's reading. The seam itself carries ONE frequency: a joined track
    whose two halves disagreed by 40 cents would step in pitch exactly where
    the ear is listening hardest.

    AND THE PHASE IS DELIBERATELY NOT BENT WITH IT, which is the opposite of
    what it looks like it should be. The bend leaves a frequency the analysis
    never measured at frames whose phase it did, so re-integrating the phase
    over the bent frames -- adding the trapezoid the new frequency implies --
    looks like the repair. It was built and MEASURED and it LOSES: -0.19,
    -0.15, -0.07, -0.06, -0.00 dB of MQ reference SNR on the five takes. The
    reason is that MQ's cubic hits the measured PHASE at both ends of every
    hop, exactly, and reads the frequency only as a slope; the phase is the
    ground truth of that fit, and moving it to follow an invented frequency
    breaks the one thing the synthesis is matching. The bend costs the cubic a
    little extra curvature and nothing else.

    (The 0.7-2.9 dB the multi capture appeared to lose against a single-window
    one is not this either: it is the SPAN. A multi grid starts three hops
    earlier, so its reference is scored over 35 ms more of the take -- the
    onset, which no single-window model even attempts. Over the same window
    the two agree to 0.00-0.36 dB, and the audit now asks it that way.)

    Returns the tracks, indexed on the GRID.
    """
    ends = [i for i, t in enumerate(short) if t.first + len(t.freq) == b]
    heads = [i for i, t in enumerate(long_) if t.first == 0]
    pairs = []
    for si in ends:
        for li in heads:
            d = abs(1200.0 * np.log2(max(long_[li].freq[0], 1e-9)
                                     / max(short[si].freq[-1], 1e-9)))
            if d <= MULTI_JOIN_CENTS:
                pairs.append((d, si, li))
    # ties break on POSITION, never on identity: an analysis is deterministic
    # or it is not one.
    pairs.sort()
    taken_l, mate = set(), {}
    for d, si, li in pairs:
        if si in mate or li in taken_l:
            continue
        mate[si] = li
        taken_l.add(li)

    out = []
    for si, ts in enumerate(short):
        li = mate.get(si)
        if li is None:
            out.append(ts)
            continue
        tl = long_[li]
        # the bend: full at the seam, gone MULTI_XF_FR frames earlier
        n_s = len(ts.freq)
        delta = tl.freq[0] - ts.freq[-1]
        for k in range(1, min(MULTI_XF_FR, n_s) + 1):
            ts.freq[n_s - k] += delta * (MULTI_XF_FR + 1 - k) / MULTI_XF_FR
        ts.freq.extend(tl.freq)
        ts.amp.extend(tl.amp)
        ts.phase.extend(tl.phase)
        out.append(ts)
    for li, tl in enumerate(long_):
        if li not in taken_l:
            out.append(_Track(tl.freq, tl.amp, b + tl.first, tl.phase))
    return out

def _frame_mags(y, win_n, starts):
    """|rfft| of each frame, with no tracking -- the residual's half of `_track`.

    Multi-resolution needs the BODY window's spectrum at frames the body
    tracker never ran on, so the two halves of a capture can be measured
    through one window without being tracked through one.
    """
    win = np.hanning(win_n)
    out = np.empty((len(starts), win_n // 2 + 1), dtype=np.float32)
    for i, s in enumerate(starts):
        seg = y[s:s + win_n]
        if seg.size < win_n:
            seg = np.pad(seg, (0, win_n - seg.size))
        out[i] = np.abs(np.fft.rfft(seg * win))
    return out

def _band_scale(win_n):
    """Frame-magnitude power -> the amplitude a sinusoid would need for it.

    Per window, because both halves of a multi-resolution capture have to land
    in ONE plane and a band that changed units at the splice would read as a
    step in the residual that the take never had.
    """
    w = np.hanning(win_n)
    return np.sqrt(2.0 / (win_n * win_n * float((w ** 2).mean())))

def f0_from_audio(y, sr, f_lo=25.0, f_hi=5000.0) -> float:
    """The take's root, from a window long enough to RESOLVE it.

    The tracker cannot answer this question and it is not its job to. Its
    window is WIN (4096, 93 ms), chosen so a partial's frequency is meaningful
    across a transient -- and a Hann mainlobe at that length is 43 Hz wide,
    while the tones of a chord down at C2 are 17 Hz apart. They merge into one
    lobe, and the lobe's centre sits BETWEEN them: measured across the DX7
    pack, twenty-four takes had no tracked partial anywhere near their lowest
    sounding tone, and the estimate landed a semitone or two above it (65.78 Hz
    read as 71.2 -- C2 and E2, averaged).

    The root is one number for the whole take, so it does not need the
    tracker's time resolution and can have a window the tracker could never
    use: a second of the steady part, zero-padded, whose mainlobe is under
    5 Hz. The CHOICE among the peaks is then the same rule as ever --
    `f0_from_partials`, which is what makes this a better view of the same
    question rather than a second, disagreeing answer to it.
    """
    y = np.asarray(y, dtype=np.float64).ravel()
    if y.size < 4096 or sr <= 0.0:
        return 0.0
    # past the onset, because an attack is broadband and would only add peaks
    # that are not the note; and no longer than a second, because vibrato
    # smears a peak that is averaged for too long.
    i0 = int(0.10 * y.size)
    n = int(min(sr, y.size - i0))
    if n < 4096:
        i0, n = 0, int(min(y.size, sr))
    if n < 4096:
        return 0.0
    seg = y[i0:i0 + n] * np.hanning(n)
    nfft = 1 << int(np.ceil(np.log2(n * 4)))
    S = np.abs(np.fft.rfft(seg, nfft))
    fr = np.fft.rfftfreq(nfft, 1.0 / sr)
    top = float(S.max())
    if top <= 0.0:
        return 0.0
    thr = top * (10.0 ** (-55.0 / 20.0))
    lo = int(np.searchsorted(fr, f_lo))
    hi = int(min(np.searchsorted(fr, f_hi), S.size - 2))
    if hi - lo < 8:
        return 0.0
    m = S[lo:hi]
    idx = np.flatnonzero((m[1:-1] > m[:-2]) & (m[1:-1] >= m[2:])
                         & (m[1:-1] > thr)) + 1 + lo
    if idx.size == 0:
        return 0.0
    # sub-bin refinement in dB: a mainlobe's log is very nearly a parabola
    a = 20.0 * np.log10(np.maximum(S[idx - 1], 1e-12))
    b = 20.0 * np.log10(np.maximum(S[idx], 1e-12))
    c = 20.0 * np.log10(np.maximum(S[idx + 1], 1e-12))
    den = a - 2.0 * b + c
    d = np.where(np.abs(den) > 1e-9, 0.5 * (a - c) / np.where(
        np.abs(den) > 1e-9, den, 1.0), 0.0)
    d = np.clip(d, -0.5, 0.5)
    f = fr[idx] + d * (fr[1] - fr[0])
    return f0_from_partials(f, S[idx])

def f0_from_partials(freqs, amps) -> float:
    """The take's pitch, from the PARTIALS -- not from autocorrelation.

    The autocorrelation estimator this replaces was wrong on five of six pack
    sounds, by an octave or two (e-piano: 64.6 Hz for a take whose lowest
    strong partial is 259.7). Autocorrelation loves sub-harmonics, and nothing
    downstream could survive it: `capture_note` is the pitch a key transposes
    FROM, so an octave of error transposes the whole instrument by an octave.

    The rule that fixes it is one line of physics: A CANDIDATE MUST ITSELF BE
    PRESENT. Score each strong partial as a candidate f0 by how much of the
    spectrum's energy sits on its harmonic series, take the best, and never
    invent a fundamental that no partial supports.
    """
    f = np.asarray(freqs, dtype=np.float64)
    a = np.asarray(amps, dtype=np.float64)
    keep = (f > 20.0) & (a > 0.0)
    f, a = f[keep], a[keep]
    if f.size == 0:
        return 440.0
    # 0.10, MEASURED. A long-window spectrum is full of quiet company -- the
    # skirts of a mainlobe, tremolo and chorus sidebands, a detuned second
    # oscillator -- and a candidate sitting on one of those can still score
    # well, because the comb it lays down catches the REAL partials. Measured
    # on `voice1c`: a peak at 126.3 Hz whose own level was 0.067 of the
    # loudest scored 0.50 of the best, and being the lowest survivor it won,
    # putting the take a semitone flat. Swept over the pack: 0.05 lands 123 of
    # 137 takes on their own lowest tone, 0.10 lands 134, 0.20 lands 129 (it
    # starts refusing genuinely quiet roots), 0.30 lands 117.
    strong = a >= 0.10 * a.max()
    cands = np.unique(np.round(f[strong], 2))
    if cands.size == 0:
        return float(f[int(np.argmax(a))])
    scored = []
    for c in cands[:32]:                      # the lowest few are the only
        if c <= 20.0:                         # plausible fundamentals
            continue
        k = np.clip(np.round(f / c), 1, 64)
        # 0.04 of the candidate, not 0.06: at k=1 six percent is a hundred
        # cents, wide enough for a candidate to claim the true fundamental a
        # semitone above it as its OWN first harmonic, which is exactly how a
        # sideband outscored the note it was a sideband of.
        on = np.abs(f - k * c) / c < 0.04     # near a harmonic of this candidate
        # A CANDIDATE MUST HAVE A SERIES, not just itself. One partial alone
        # "explains" its own energy perfectly, so without this a stray low
        # track -- rumble, a room mode, a tracker splitting a fundamental into
        # neighbours -- can outrank the note now that the bar below is lower.
        if int(np.count_nonzero(on)) < 2:
            continue
        scored.append((float(c), float(a[on].sum())))
    if not scored:
        return float(f[int(np.argmax(a))])
    best_score = max(sc for _, sc in scored)
    # OCTAVE/HARMONIC CORRECTION, the standard rule and the one that matters:
    # a fifth or an octave ABOVE the true fundamental also explains most of a
    # harmonic series, so "highest score" picks it (clav read G4 for a B2 take,
    # organ read a fifth high). Take the LOWEST candidate that explains the
    # spectrum nearly as well as the best one does.
    #
    # 0.80 WAS FAR TOO STRICT, and the reason is that real takes are mostly
    # not single notes. Every one of the 137 files in the DX7 pack is a CHORD,
    # and a chord's third or fifth sits on more of the spectrum than its root
    # does -- so at 0.80 the root never made the cut and a chord tone won.
    # Measured against each take's own lowest sounding tone (which needs no
    # labels, and is the pitch a keyboard should transpose FROM), the estimate
    # agreed on 62% of the pack and landed +3, +4, +7 and +11 semitones high:
    # musical intervals, not harmonics. A minor third of that is what turns a
    # C into an A, which is what it sounded like.
    good = [c for c, sc in scored if sc >= 0.30 * best_score]
    return float(min(good)) if good else float(min(c for c, _ in scored))

def capture(y, sr, max_tracks=None, multi: bool = False,
            phase: bool = False, align0: bool = False) -> dict:
    """Track the free peaks of `y` into an `Asset`. Deterministic.

    `multi` analyses the attack through WIN_SHORT and the body through WIN and
    splices them onto one grid, which moves frame 0 from 46 ms into the take to
    11.6 ms. `phase` keeps each partial's phase at each frame centre, which is
    what `render_reference` needs and what the C engine cannot use.

    `align0` puts frame 0 ON THE HEAD'S FIRST SAMPLE (the onset less
    ATTACK_PRE_S) by padding the take in front by the window's own centre
    offset. Without it frame 0 describes the take `centre_hops` hops in, and
    three layers ran on three clocks: the head from the onset, the model and the
    residual 11.6 ms later -- and at the capture pitch the residual stands the
    head down, so THE FIRST 11.6 ms OF EVERY TAKE WITH A RESIDUAL WAS NEVER
    PLAYED. On a drum that is the hit: measured with `eval/fidelity.py`, the
    snare's full path nulled at -2.6 dB and the low tom's scored 13.7 dB tf,
    while every drum short enough to have no residual was exact. The early
    frames now see part of the pad, so their partials read low (the window is
    half empty) -- which the residual repairs exactly at the root, and which is
    the honest shape of an onset for a model to play anywhere else.

    ALL THREE ARE OFF BY DEFAULT, and that is not timidity: the audits pin
    today's plane byte for byte, and a capture is the one thing in this repo
    that every other measurement is taken against.
    """
    y = np.asarray(y, dtype=np.float64).ravel()
    sr = float(sr)
    y_src = y
    t0_src = max(0, find_onset(y) - int(round(ATTACK_PRE_S * sr)))
    # THE BODY WINDOW IS THE TAKE'S, NOT A CONSTANT. Short takes get the short
    # window for the WHOLE take (see SHORT_TAKE_S): the splice below exists to
    # reach frames the body window cannot, and on a take this short there is
    # nothing to splice TO.
    win, hop = WIN, HOP
    short = multi and y.size < int(SHORT_TAKE_S * sr)
    if short:
        win, hop = WIN_SHORT, SHORT_HOP
        multi = False                  # one window throughout, no join
    # take sample = analysis sample + lead, so frame 0 (centred `centre` hops
    # into the analysed signal) describes take sample `centre*hop + lead`
    lead = 0
    if align0:
        li_nat = (CENTRE_HOPS_SHORT * HOP if multi
                  else ((win // 2) // hop) * hop)
        # the take's OWN audio before the head where it has any (a trimmed
        # take keeps 20 ms of pre-roll), zeros only for what it lacks -- a
        # zero pad on a take that had real signal there measured +0.4 dB
        # worse on the piano's model-only render
        have = min(li_nat, t0_src)
        y = np.concatenate([np.zeros(li_nat - have), y[t0_src - have:]])
        lead = t0_src - li_nat
        # ...AND THE GRID REACHES THE TAKE'S END. The last body frame is centred
        # half a window (46 ms) before the audio runs out, so the model -- and
        # the residual, which is cut where the model's take-end release begins
        # -- stopped there: a GM crash (a loop sample cut while still at -21
        # dB) nulled at -55 dB for 545 ms and then released 55 ms early, which
        # was the whole of its 9.5 dB. The short path already pads by a window
        # for the same reason; this is the body window's half of it.
        if not short:
            y = np.pad(y, (0, win // 2 + hop))
    # where the TAKE ends in the analysed signal: a body frame reaching past it
    # straddles a cut, and its leftover is the cut's splatter, not the sound
    end_an = (li_nat + y_src.size - t0_src) if (align0 and not short) else 0
    pad_front = (li_nat - min(li_nat, t0_src)) if align0 else 0
    if short:
        # AND PAD BY A WHOLE WINDOW, so the frames reach the END of the take.
        # Without this a short take gets FEWER frames than the old long-window
        # path did (which padded up to 4096 and then gained _MULTI_SHIFT more):
        # a 43 ms kick went from 4 frames spanning 35 ms to 2 spanning 12, and
        # its FULL render regressed 0.0 -> 1.9 dB because the attack head was
        # crossfading into a model that had already ended. With the pad the
        # grid is 1 + len//HOP frames, i.e. it spans the take.
        y = np.pad(y, (0, win))
    if y.size < win:
        y = np.pad(y, (0, win - y.size))
    n_long = 1 + (y.size - win) // hop

    # THE AMPLITUDE SCALE IS APPLIED TO THE TRACKS BELOW, not to the finished
    # plane. `np.fft.rfft` of a Hann-windowed frame reports a sinusoid of
    # amplitude 1 as win/4, so without this the engine would render a capture
    # roughly 60 dB hot and every caller would need the same correction -- and
    # it belongs on the track because the two windows report the SAME sinusoid
    # as two different numbers, and the cut further down ranks tracks against
    # each other. Ranked raw, a short track is judged a quarter as loud as the
    # identical long one and loses its place to it.
    if not multi:
        # frame i begins at i*HOP and is centred CENTRE_HOPS hops later.
        starts = [i * hop for i in range(n_long)]
        done, mags = _track(y, sr, win, starts, phase)
        # a short take has few frames by construction, so the minimum that
        # keeps a track has to scale with the window or nothing survives
        _minfr = MIN_FRAMES if win == WIN else MULTI_MIN_FR
        done = [t for t in done if len(t.freq) >= _minfr]
        for tr in done:
            tr.amp = [v * (4.0 / win) for v in tr.amp]
        n_frames = n_long
        centre = float((win // 2) // hop)
        segs = [(win, 0, mags)]
        nz_hole = 0
    else:
        # ONE GRID, TWO WINDOWS. Grid frame i is centred at
        # (i + CENTRE_HOPS_SHORT)*HOP, so a short frame begins at i*HOP and a
        # body frame at (i - _MULTI_SHIFT)*HOP -- which only exists from
        # i = _MULTI_SHIFT on. That is the hole, stated as arithmetic.
        n_frames = n_long + _MULTI_SHIFT
        centre = float(CENTRE_HOPS_SHORT)
        # THE JOIN: the first body frame that BEGINS at or after the onset, so
        # no long window ever straddles it. Running the short window PAST that
        # point was tried -- two frames, four, eight -- to sharpen the contour
        # the body window still averages over 93 ms, and it lost: the residual
        # over the first 60 ms got worse on three of five takes and the mean
        # moved the wrong way. The short window's resolution is not what this
        # buys; the frames it can reach and the body window cannot is.
        onset = find_onset(y)
        b = -(-int(onset) // HOP) + _MULTI_SHIFT
        # never past the take, never before the first frame the body window
        # can reach at all -- below that there is nothing to splice TO.
        b = int(max(_MULTI_SHIFT, min(b, n_frames - 1)))
        s_starts = [i * HOP for i in range(b)]
        l_starts = [(i - _MULTI_SHIFT) * HOP for i in range(b, n_frames)]
        t_s, m_s = _track(y, sr, WIN_SHORT, s_starts, phase)
        t_l, m_l = _track(y, sr, WIN, l_starts, phase)
        for tr in t_s:
            tr.amp = [v * (4.0 / WIN_SHORT) for v in tr.amp]
        for tr in t_l:
            tr.amp = [v * (4.0 / WIN) for v in tr.amp]
        done = _join(t_s, t_l, b)
        # a track that never reaches the join is an ATTACK track and is held to
        # its own minimum; everything else answers to MIN_FRAMES as always.
        done = [t for t in done
                if len(t.freq) >= (MULTI_MIN_FR
                                   if t.first + len(t.freq) <= b
                                   else MIN_FRAMES)]
        # THE RESIDUAL IS MEASURED THROUGH ONE WINDOW, and the tracks through
        # two. The band scale is calibrated for a SINUSOID; the residual is
        # broadband, and the two windows attribute wildly different amounts of
        # it to the partials -- a 23 ms window resolves noise into peaks the
        # tracker takes for partials and models away, and its narrow bands own
        # a quarter as many bins. Measured across grid frame `b`, the band
        # plane stepped by +5.3 dB on one take and -35.2 on another: not a
        # constant, so not something a calibration ratio can repair. The body
        # window reaches every grid frame from `_MULTI_SHIFT` on, so it
        # measures all of them -- including the ones the SHORT window tracked.
        m_body = np.concatenate(
            [_frame_mags(y, WIN, [(i - _MULTI_SHIFT) * HOP
                                  for i in range(_MULTI_SHIFT, b)]), m_l])
        segs = [(WIN, _MULTI_SHIFT, m_body)]
        nz_hole = _MULTI_SHIFT

    # WHICH TRACKS SURVIVE THE CUT, and it is NOT simply the loudest.
    #
    # Ranking by amplitude alone spends the whole budget where the energy is,
    # and on a voice that is the bottom: measured on a recorded take, 400
    # tracks chosen by loudness reproduced 4-8 kHz at -63.6 dB and 8-16 kHz at
    # -70.1 dB against the recording -- nothing at all up there -- while the
    # same take at 1600 tracks came within 1.5 dB in every band. The high
    # partials existed and were tracked; they were simply thrown away before
    # the engine ever saw them, and what came back was a voice with its
    # brightness replaced by the noise layer's hiss.
    #
    # So the budget is spread over log frequency first -- each band keeps its
    # own loudest -- and only what is left over goes to the loudest anywhere.
    # A band with nothing in it costs nothing; a band with a quiet formant
    # keeps it.
    done.sort(key=lambda t: -max(t.amp))
    if max_tracks is None:
        # AUTOMATIC IS NOT A CLEVERER CUT -- IT IS NO CUT. Every level test
        # tried here was a second opinion about the one `prune` already
        # applies downstream, and a second opinion that disagreed: at -50 dB
        # an e-piano kept 13 where the pipeline had been keeping 22, and at
        # -60 it still kept 15, because a track's peak before the plane is
        # built is not the number `prune` ends up thresholding. So auto keeps
        # what the tracker found, `prune` decides what is worth keeping (it
        # always did), and the ceiling is the only thing this adds -- a bound
        # on what a noisy recording can cost the render.
        max_tracks = TRACK_CEILING
    if len(done) > int(max_tracks):
        k = int(max_tracks)
        fmed = np.array([float(np.median(t.freq)) if len(t.freq) else 0.0
                         for t in done])
        n_b = 16
        edges = np.exp(np.linspace(np.log(30.0), np.log(max(sr * 0.5, 60.0)),
                                   n_b + 1))
        band = np.clip(np.searchsorted(edges, fmed) - 1, 0, n_b - 1)
        # ROUND-ROBIN over bands, the bands themselves ordered by their loudest
        # track. Taking a fixed share per band walks the spectrum bottom-up and
        # ignores level entirely when the budget is smaller than the band count
        # -- ask for 3 tracks and you get the three lowest bands rather than
        # the three loudest partials. This way the first pass is the loudest
        # track of each band strongest-band-first, the second pass their next
        # loudest, and so on: level decides the order, frequency decides that
        # no region is left out.
        per_band = [list(np.flatnonzero(band == b)) for b in range(n_b)]
        per_band = [q for q in per_band if q]        # each already loud-first
        per_band.sort(key=lambda q: -fmed.size and -float(
            max(max(done[i].amp) for i in q)))
        kept, r = [], 0
        while len(kept) < k and any(len(q) > r for q in per_band):
            for q in per_band:
                if len(q) > r:
                    kept.append(int(q[r]))
                    if len(kept) >= k:
                        break
            r += 1
        done = [done[i] for i in kept[:k]]

    k = len(done)
    F = np.zeros((n_frames, k), dtype=np.float64)
    A = np.zeros((n_frames, k), dtype=np.float64)
    P = np.zeros((n_frames, k), dtype=np.float64) if phase else None
    hop_s = hop / sr
    for j, tr in enumerate(done):
        i0, n = tr.first, len(tr.freq)
        i1 = min(i0 + n, n_frames)
        fv = np.asarray(tr.freq[:i1 - i0], dtype=np.float64)
        av = np.asarray(tr.amp[:i1 - i0], dtype=np.float64)
        # frequency is HELD outside the track's span and amplitude is zero:
        # absence is an amplitude fact, never a frequency of 0.
        F[:i0, j] = fv[0]
        F[i0:i1, j] = fv
        F[i1:, j] = fv[-1]
        A[i0:i1, j] = av
        if P is not None:
            pv = np.asarray(tr.phase[:i1 - i0], dtype=np.float64)
            P[i0:i1, j] = pv
            # OUTSIDE the span the phase is CONTINUED, not held: the frequency
            # there is flat, so the phase there is a straight line, and MQ
            # wants a smooth polynomial across the frame where the amplitude
            # rises off zero. A held phase would ask the cubic to stand still
            # and then leap, which is a chirp the track never made.
            if i0 > 0:
                P[:i0, j] = pv[0] - (i0 - np.arange(i0)) * (
                    2.0 * np.pi * fv[0] * hop_s)
            if i1 < n_frames:
                P[i1:, j] = pv[-1] + (np.arange(i1, n_frames) - (i1 - 1)) * (
                    2.0 * np.pi * fv[-1] * hop_s)

    # THE RESIDUAL, taken here and not a line earlier: the tracks are final, so
    # everything the cut above threw away is still in the spectrum and lands in
    # the noise plane instead of vanishing. ONE window measures all of it, even
    # when two tracked it -- the band scale is calibrated for a sinusoid and the
    # residual is broadband, so the two disagree about what a band holds and the
    # plane steps where they meet.
    N = np.zeros((n_frames, NOISE_BANDS), dtype=np.float64)
    for win_n, at, mg in segs:
        n_seg = mg.shape[0]
        sl = slice(at, at + n_seg)
        # back to the magnitudes the frame was measured in -- exactly, because
        # win/4 is a power of two and the trip through it costs no bit.
        N[sl] = np.sqrt(_noise_plane(mg, F[sl], A[sl] * (win_n / 4.0), sr,
                                     win_n)) * _band_scale(win_n)
    if end_an:
        # THE FRAMES PAST THE TAKE'S END take the last one inside it, as the
        # hole below takes the first one measured. A window straddling a cut
        # reads the cut: a clean tone that stops at 20% of its level grew a
        # noise plane it never had (-24 dB of splatter over its last 5 frames),
        # which is a hiss burst at the end of every note the model plays.
        for win_n, at, mg in segs:
            inside = [i for i in range(at, n_frames)
                      if (i - at) * hop + win_n <= end_an]
            if inside and inside[-1] + 1 < n_frames:
                N[inside[-1] + 1:] = N[inside[-1]]
    if pad_front > 0:
        # ...and the frames that read the FRONT pad take the first one that
        # does not, for the same reason. This one is inaudible today -- the
        # engine reads the plane half a noise frame (46 ms) ahead, so these
        # frames are never played; measured identical on all 13 drums -- but a
        # plane is a description, and a clean tone that starts at full level
        # was being described as a -31 dB hiss burst it does not have.
        for win_n, at, mg in segs:
            first_in = [i for i in range(at, n_frames)
                        if (i - at) * hop >= pad_front]
            if first_in and first_in[0] > at:
                N[at:first_in[0]] = N[first_in[0]]
    if nz_hole:
        # the grid frames NO body window reaches -- the hole multi-resolution
        # exists to fill for the tracks, and cannot fill for the residual. They
        # take the first frame that is measured, which is 11.6 ms away, rather
        # than a reading through a window that means something else.
        N[:nz_hole] = N[nz_hole]
    ap = float((A.astype(np.float64) ** 2).sum())
    npow = float((N ** 2).sum())
    keep = ap > 0.0 and npow > ap * 10.0 ** (NOISE_MIN_DB / 10.0)
    noise = N.astype(np.float32) if keep else None

    # THE HEAD, taken from the SOURCE and not from anything modelled. It wants
    # no scale of its own: it is already the units the planes were just put
    # into, being the sound itself.
    # Under `align0` it is cut from the SOURCE at the same sample frame 0 now
    # describes -- the analysed signal carries a pad that the head must not.
    if align0:
        t0i = t0_src
        head = y_src[t0i:t0i + int(round(ATTACK_S * sr))]
    else:
        t0i = max(0, find_onset(y) - int(round(ATTACK_PRE_S * sr)))
        head = y[t0i:t0i + int(round(ATTACK_S * sr))]
    attack = head.astype(np.float32) if head.size >= 2 else None
    if P is not None:
        # wrapped, because float32 holds 7 digits and an unwrapped phase runs
        # to tens of thousands of radians by the end of a take -- which would
        # quantise the very number MQ is trying to hit. The wrap count comes
        # back at synthesis, from the maximally-smooth criterion.
        P = (P + np.pi) % (2.0 * np.pi) - np.pi
    # THE PITCH, from the partials this capture just tracked -- never from a
    # second pass over the audio (that recursed) and never from autocorrelation
    # (that was wrong by an octave or two on five of six pack sounds).
    _pk = A.max(axis=0)
    _fm = np.array([np.median(F[A[:, k] > 0, k]) if np.any(A[:, k] > 0) else 0.0
                    for k in range(F.shape[1])])
    # FROZEN IN TIME, which is the fix for the "short pump". The formant
    # ratio the engine applies is env(f*r)/env(f) read at the CURRENT frame,
    # so a time-varying envelope hands a transposed partial the decay of the
    # take's own content at the target frequency. Two octaves up that content
    # is the take's dying high end, and the note collapsed: at C6 a real
    # Steinway is 9.8 dB down at 0.5 s and the render was 24.3 -- heard as a
    # note that attacks and stops. Frozen it is 14.4 dB, and the brightness
    # hold exists for survives (centroid/f0 at C6: real 2.21, frozen 2.71,
    # time-varying 1.55, tape 4.91 -- tape being the "sounds over-pitched"
    # end). The envelope describes WHERE the take's resonances are, which is
    # a property of the instrument; how loud they are over time is the job of
    # the amplitude plane, and letting the envelope do it too applied the
    # decay twice.
    _te = None
    _ya = y_src if align0 else y            # the pad is not the instrument
    if _TRUE_ENV:
        try:
            _te = true_envelope(_ya, sr, f0_from_audio(_ya, sr),
                                order_scale=_TRUE_ENV_ORDER)
        except Exception:
            _te = None
    if _te is not None and np.all(np.isfinite(_te)) and float(_te.max()) > 0:
        env = np.tile(_te[None, :], (F.shape[0], 1)).astype(np.float32)
    else:
        _ev = _env_plane(F, A)
        _w = np.maximum(_ev.sum(1, keepdims=True), 1e-12)
        env = np.tile((_ev * _w).sum(0, keepdims=True) / _w.sum(),
                      (_ev.shape[0], 1)).astype(np.float32)
    # FROM THE AUDIO, through a window long enough to resolve a low chord --
    # see `f0_from_audio`. The tracks are the fallback, not the source: their
    # window cannot separate tones 17 Hz apart, and that is where every
    # remaining tuning error lived.
    # THE ROOT STAYS THE HARMONIC COMB, and `rsynth.pitch` (YIN) is NOT used
    # here -- measured, not assumed. YIN is the better answer to "what note is
    # this": on 24 signals whose answer is known by construction it is exact on
    # every monophonic case, including a missing fundamental and an
    # octave-doubled patch, where the comb is an octave out. But it collapses a
    # CHORD to a common sub-period (a triad repeats two octaves under its
    # root), and real takes are mostly chords -- across the 137-file DX7 pack,
    # always-YIN agrees with the take's lowest tone on 23%, the comb on 99%.
    # A confidence gate was tried and is not safe either: a synthetic triad is
    # strongly periodic at its sub-period, so it passes any threshold that
    # still admits real notes, and the audit's own minor-triad fixture came out
    # an octave low.
    #
    # So the comb decides the root, and `pitch.detect` is kept for the two jobs
    # it IS right for: telling the user what their recording reads as, and
    # measuring single notes. `tests/tuning.py` verifies the transposition a
    # third way, by log-spectral shift, which needs no opinion about roots.
    _f0 = f0_from_audio(_ya, sr) or f0_from_partials(_fm, _pk)
    # ...AND THE VALUE IS REFINED FROM THE PHASE PLANE, because that is what
    # the engine replays. The render's frequency is phase-implied (the turn
    # between stored phases); the tuning ratio is built from f0 -- and when f0
    # comes from the frequency-track median the two disagree by the median's
    # own bias, which lands on EVERY key as a constant detune. Measured on a
    # synthetic 220.000 Hz take: estimate +0.79 c, every transposed key -0.78 c
    # -- the estimator's error, negated. On an e-piano the bias was ~6 c, which
    # is "this piano is out of tune". The phase slope is the most accurate
    # frequency the data contains, and using it makes the ratio and the replay
    # agree by construction. `f0_from_partials` still decides WHICH partial is
    # the fundamental; the phase decides its value.
    if P is not None and _f0 > 0.0 and F.shape[1]:
        _c = int(np.argmin(np.abs(np.log(np.maximum(_fm, 1e-9) / _f0))))
        if abs(1200.0 * np.log2(max(_fm[_c], 1e-9) / _f0)) < 30.0:
            _ph, _fc, _ac = P[:, _c], F[:, _c], A[:, _c]
            _alive = _ac > float(_ac.max()) * 0.1
            _d = _ph[1:] - _ph[:-1]
            _nom = 2.0 * np.pi * _fc[:-1] * hop_s
            _err = _d - _nom
            _err -= 2.0 * np.pi * np.floor(_err / (2.0 * np.pi) + 0.5)
            _fi = (_nom + _err) / (2.0 * np.pi * hop_s)
            _w = np.sqrt(_ac[:-1] * _ac[1:]) * (_alive[:-1] & _alive[1:])
            if float(_w.sum()) > 0.0:
                _fr = float((_fi * _w).sum() / _w.sum())
                if abs(1200.0 * np.log2(max(_fr, 1e-9) / _f0)) < 30.0:
                    _f0 = _fr
    return dict(freq=F.astype(np.float32), amp=A.astype(np.float32), f0=_f0, hop_s=hop_s,
                centre_hops=centre + lead / float(hop), noise=noise, attack=attack,
                attack_sr=sr if attack is not None else 0.0, attack_t0=t0i / sr, env=env)
