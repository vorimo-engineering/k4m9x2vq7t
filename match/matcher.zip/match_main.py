"""THE MATCHER IN THE BROWSER: what match/worker.js calls, in Pyodide, on dnasynth's own code (the
matcher's modules ride in matcher.zip as they are in ~/Projects/dnasynth; match/pack.py swaps in
only the engine binding, the v1 voice's gene table and the registry -- the native ones are C
libraries -- and the five scipy calls).

    setup(registry_json)                      the engine's registry in; the kit and the dashboard installed
    analyse(pcm, trim)                        -> the note: midi, gate, the trimmed audio (the lab's estimates)
    grow(pcm, midi, gate, params, progress)   -> the result: alternatives with their documents and notes

BUILDERS is the browser's registry of matchers, the same schema as dnasynth/serve/builders.py's: the
tab draws its controls from it, so a builder added here is one more choice there."""
from __future__ import annotations

import concurrent.futures as _cf
import concurrent.futures.thread as _cft
import json
import time
import traceback


class InlineExecutor(_cf.Executor):
    """a thread pool for a runtime without threads: every task runs where it is submitted (the
    fitness splits its score in two halves on two threads natively; here one after the other)"""

    def __init__(self, max_workers=None, *a, **k):
        self._max_workers = max_workers or 1

    def submit(self, fn, *args, **kwargs):
        f = _cf.Future()
        try:
            f.set_result(fn(*args, **kwargs))
        except BaseException as e:                   # noqa: BLE001 -- handed to the caller's future
            f.set_exception(e)
        return f

    def map(self, fn, *iterables, timeout=None, chunksize=1):
        return iter([fn(*a) for a in zip(*iterables)])


_cf.ThreadPoolExecutor = InlineExecutor               # before any matcher module imports it
_cft.ThreadPoolExecutor = InlineExecutor

import numpy as np                                    # noqa: E402

SR = 44100

BUDGET = {"key": "budget", "label": "budget", "type": "choice", "default": 15000,
          "choices": [[1500, "quick look (1 500 renders)"], [5000, "fast (5 000 renders)"],
                      [15000, "standard (15 000 renders, the lab's)"], [30000, "thorough (30 000 renders)"],
                      [60000, "exhaustive (60 000 renders)"]],
          "help": "renders the search may spend: more finds better voices, slower. 15 000 is the desktop "
                  "GROW lab's default"}
SEED = {"key": "seed", "label": "seed", "type": "int", "default": 0, "min": 0, "max": 9999, "step": 1,
        "help": "another seed, another search: the same seed repeats a result exactly"}
POLISH = {"key": "polish_k", "label": "polish genes", "type": "int", "default": 20, "min": 5, "max": 60, "step": 5,
          "help": "genes the final polish searches together"}
TEMPLATES = {"key": "templates", "label": "templates", "type": "bool", "default": True,
             "help": "GROW's family templates join the starts"}
NETWORK = {"key": "network", "label": "network", "type": "bool", "default": True,
           "help": "the dashboard network's eight proposals join the starts, as in the desktop lab "
                   "(its first use downloads it: 63 MB, then the browser's cache)"}
SYNTH = {"key": "synth", "label": "synth", "type": "synth",
         "help": "the project's dashboard synth to tune, the one on the board first: the result moves its knobs and "
                 "depths and adds nothing -- keep it with 'save as...' as one of its presets"}
MODULATION = {"key": "modulation", "label": "modulation", "type": "bool", "default": True,
              "help": "also the depths from ENV 1, ENV 2 and the LFO into the knobs (the sensors are never tuned)"}
PRESETS = {"key": "presets", "label": "from its presets", "type": "bool", "default": True,
           "help": "start from the nearest of the synth's presets as well as the patch as it is (a preset may "
                   "also set knobs the dashboard does not show; off: only the dashboard moves)"}
BUILDERS = [
    dict(id="dashboard", label="Dashboard GROW",
         help="grows a dashboard instrument -- ENV 1 / ENV 2, filter, LFO, FX on the knobs -- any graph underneath",
         params=[BUDGET, SEED, POLISH, NETWORK], dashboard=True, network=True),
    dict(id="grow", label="GROW (full kit)",
         help="grows its own graph from the whole kit, block by block; no dashboard",
         params=[BUDGET, SEED, POLISH, TEMPLATES], dashboard=False),
    dict(id="tune", label="Tune a synth (dashboard)",
         help="keeps an existing dashboard synth as it is and turns only its dashboard knobs -- and the depths "
              "from ENV 1, ENV 2 and the LFO into them; the sensors and the graph stay untouched",
         params=[BUDGET, SEED, SYNTH, MODULATION, PRESETS], dashboard=False, tune=True),
]


def info():
    return json.dumps(dict(service="in-browser matcher", version=1, sr=SR,
                           builders=[{k: v for k, v in b.items() if k not in ("dashboard", "network", "tune")}
                                     for b in BUILDERS]))


def wants_net(builder_id, params_json):
    """whether a grow asks for the network (the builder has one and its box is on)"""
    b = next(x for x in BUILDERS if x["id"] == builder_id)
    return bool(b.get("network")) and bool(json.loads(params_json or "{}").get("network", True))


def _target(pcm):
    """the note as GROW scores it (build.grow: from its onset, at the fitness's loudness)"""
    from dnasynth import match as MA
    from dnasynth import fitness as FT
    x = _pcm(pcm)
    return FT.normalize(x[MA.estimate_onset(x):])


def net_inputs(pcm, midi, gate_s, meta_json, chord_json=None):
    """what the dashboard network hears of the note (model.Model.encode's inputs): its features
    (nnfeat_np, version 1, at the network's level rule) and its condition -> (feats [n_ch * T],
    cond [n_cond]) float32. A chord: the note `midi` isolated from it, as build.grow's networks hear it"""
    from dnasynth import model as MO
    import nnfeat_np as NP
    meta = json.loads(meta_json)
    x = _target(pcm)
    chord = json.loads(chord_json) if chord_json else None
    if chord and len(chord) > 1:
        from dnasynth import notes as NO
        from dnasynth import fitness as FT
        x = FT.normalize(NO.isolate(x, chord, float(midi)))
    feats = NP.features(x, float(midi), float(gate_s), secs=meta["secs"], norm=meta["norm"])
    cond = MO.cond_features([float(midi)], [float(gate_s)], meta["secs"])[0]
    return feats.ravel().astype(np.float32), cond.astype(np.float32)


class _Proposals:
    """the network as build.net_starts asks it (propose -> k canonical genomes), answered with the
    proposals the browser's sampler made (match/net.js) -- decoded as model.Model.propose_many
    decodes its tokens: Tokenizer.decode, the engine's canonical form, the first k distinct rows"""

    def __init__(self, tokens, meta):
        from dnasynth import model as MO
        tok = MO.Tokenizer(meta["bins"], meta["engine"])
        t = np.asarray(tokens, np.int64).reshape(-1, tok.n)
        G = tok.E.canonical(tok.decode(t))
        self.cfg = dict(engine=meta["engine"])
        self.G = G
        self.k = int(meta["sampler"]["k"])

    def propose(self, audio, sr=44100.0, midi=60.0, k=8, gate_s=None, **kw):
        keep, seen = [], set()
        for r in range(self.G.shape[0]):
            key = self.G[r].tobytes()
            if key not in seen:
                seen.add(key)
                keep.append(r)
            if len(keep) == k:
                break
        while len(keep) < k:                             # the model is sure: repeat rows
            keep.append(keep[len(keep) % max(1, len(seen))])
        return self.G[keep]


def setup(registry_json):
    """the engine's registry (the worker reads it off the wasm), then the kit's kinds and the
    dashboard's -- what dnasynth.grow.kit.install() reads from pchsynth natively"""
    from pchsynth import graph as G
    G.install(registry_json)
    from dnasynth.grow import kit, dash
    kit.install()
    dash.install()
    return len(G.TYPES)


def _pcm(x):
    return np.array(x.to_py() if hasattr(x, "to_py") else x, dtype=np.float32)


def analyse(pcm, trim=True):
    """the lab's reading of a take: mono 44.1 kHz with DC out, trimmed (its onset to its end), the
    pitch (YIN + a harmonic fit) and the gate"""
    from dnasynth import match as MA
    from dnasynth.grow import lab
    x = MA.to_mono_44k(_pcm(pcm), SR)
    if trim:
        x = lab.trim_take(x, SR)
    x = x[:int(30.0 * SR)]
    if x.size < int(0.05 * SR) or float(np.abs(x).max()) < 1e-5:
        raise ValueError("no note in the audio (silent or shorter than 50 ms)")
    midi, conf = MA.estimate_pitch(x)
    gate, found = MA.estimate_gate(x)
    return dict(midi=float(midi), midi_conf=float(conf), gate_s=float(gate), gate_found=bool(found),
                dur_s=x.size / SR, note=x.astype(np.float32), notes=notes_of(x, gate))


def notes_of(x, gate_s=None):
    """the notes sounding together (dnasynth notes.estimate_notes) -> [{midi, salience}], low to high:
    one for a note, several for a chord, none when no note stands out (a drum, a noise)"""
    from dnasynth import notes as NO
    return [dict(midi=float(n["midi"]), salience=float(n["salience"])) for n in NO.estimate_notes(_pcm(x), SR, gate_s)]


def grow(pcm, midi, gate_s, builder_id, params_json, progress=None, net_tokens=None, net_meta_json=None,
         chord_json=None):
    """one GROW run, as the lab's worker runs it (dnasynth/grow/lab.py _grow_worker): the result's
    alternatives as documents (JSON text), distances, families, parts and each one's note.
    net_tokens: the dashboard network's proposals (match/net.js), which join the starts as the
    lab's network's do. chord_json: the notes played together (a JSON list of fractional MIDI notes,
    `midi` one of them): every candidate is played and scored as that chord (build.grow chord=)"""
    from dnasynth.grow import build as GB
    from dnasynth.grow import blocks as BL
    from dnasynth.graph import lib as L
    from dnasynth import fitness as FT
    b = next(x for x in BUILDERS if x["id"] == builder_id)
    p = {q["key"]: q.get("default") for q in b["params"]}
    p.update(json.loads(params_json or "{}"))
    x = _pcm(pcm)
    if b.get("tune"):
        return _tune(x, midi, gate_s, p, progress, chord_json)
    last = [0.0]

    def report(line, frac):
        if progress is None:
            return
        now = time.perf_counter()
        progress(str(line), float(frac) if now - last[0] > 0.15 else -1.0)
        if now - last[0] > 0.15:
            last[0] = now
    t0 = time.perf_counter()
    model = None
    if net_tokens is not None and net_meta_json:
        tk = net_tokens.to_py() if hasattr(net_tokens, "to_py") else net_tokens
        model = _Proposals(tk, json.loads(net_meta_json))
    chord = json.loads(chord_json) if chord_json else None
    chord = [float(m) for m in chord] if chord and len(chord) > 1 else None
    r = GB.grow(x, SR, float(midi), float(gate_s), budget=int(p["budget"]), rng=np.random.default_rng(int(p["seed"])),
                progress=report, name="grown", model=model, dashboard=bool(b["dashboard"]), chord=chord,
                polish_k=int(p.get("polish_k", 20)), templates=bool(p.get("templates", True)), library=False,
                threads=1)
    k, _ = BL.key_cents(float(midi))
    play = k if chord is None else BL.chord_keys(float(midi), chord)    # the notes rendered: what was matched
    T = _fitness(x)
    alts, notes = [], []
    for i, a in enumerate(r["alternatives"]):
        y = L.render_note(json.dumps(a["play_doc"]).encode(), play, 100 / 127, float(gate_s), x.size / SR)
        notes.append(FT.normalize(y) if np.abs(y).max() > 1e-7 else y)
        alts.append(dict(label="ABCDEFGH"[i], play_doc=json.dumps(a["play_doc"]), score=float(a["score"]),
                         family=a["family"], kinds=[m.kind for m in a["mods"]], whys=[m.why for m in a["mods"]],
                         terms=_terms(T, notes[-1])))
    return dict(alternatives=alts, renders=int(r["renders"]), seconds=time.perf_counter() - t0,
                timing=r.get("timing"), onset=int(r.get("onset", 0)), chord=chord), notes


def _fitness(x):
    """the fitness GROW scored against (build.grow: the note from its onset, normalised, free gain)"""
    from dnasynth import match as MA
    from dnasynth import fitness as FT
    return FT.Target(_target(x), SR, free_gain=True, gain_cost=MA.GAIN_COST, mod=MA.MOD)


def _terms(T, y):
    """what a voice's distance is made of: the fitness's terms at their weights (they sum to it) --
    spectrum (per-bin dB, three resolutions), balance (third-octave magnitudes), envelope, wobble
    (the held part's modulation) and the level it needed"""
    from dnasynth import fitness as FT
    yy = np.zeros(T.n, np.float32)
    yy[:min(T.n, y.size)] = y[:T.n]
    if np.abs(yy).max() <= 1e-7:
        return None
    total, t = T.score(yy[None], terms=True)
    out = dict(total=float(total[0]), spectrum=float(FT.W_SPEC * t["spec"][0]), balance=float(FT.W_SC * t["sc"][0]),
               envelope=float(FT.W_ENV * t["env"][0]), level=float(T.gain_cost * abs(t["gain_db"][0])))
    if "mod" in t:
        out["wobble"] = float(FT.W_MOD * t["mod"][0])
    return out


def _tune(x, midi, gate_s, p, progress, chord_json):
    """THE THIRD BUILDER: an existing dashboard synth's knobs and modulation tuned to the note
    (dnasynth grow/tune.py); the document comes from the page (params["synth_doc"])"""
    from dnasynth.grow import tune as TU
    from dnasynth import fitness as FT
    if not p.get("synth_doc"):
        raise ValueError("no synth chosen: pick a dashboard synth to tune")
    doc = json.loads(p["synth_doc"])
    chord = json.loads(chord_json) if chord_json else None
    chord = [float(m) for m in chord] if chord and len(chord) > 1 else None
    last = [0.0]

    def report(line, frac):
        if progress is None:
            return
        now = time.perf_counter()
        progress(str(line), float(frac) if now - last[0] > 0.15 else -1.0)
        if now - last[0] > 0.15:
            last[0] = now
    t0 = time.perf_counter()
    r = TU.dash_tune(x, SR, float(midi), float(gate_s), doc, budget=int(p["budget"]),
                     rng=np.random.default_rng(int(p["seed"])), chord=chord, progress=report,
                     mod=bool(p.get("modulation", True)), presets=bool(p.get("presets", True)), threads=1)
    ev = r.pop("evaluator")
    T = _fitness(x)
    alts, notes = [], []
    for i, a in enumerate(r["alternatives"]):
        y = ev.note(a["play_doc"], x.size / SR)
        notes.append(FT.normalize(y) if np.abs(y).max() > 1e-7 else y)
        alts.append(dict(label="ABCDEFGH"[i], play_doc=json.dumps(a["play_doc"]), score=float(a["score"]),
                         family=a["family"], kinds=a["kinds"], whys=a["whys"], terms=_terms(T, notes[-1])))
    return dict(alternatives=alts, renders=int(r["renders"]), seconds=time.perf_counter() - t0,
                timing=r.get("timing"), onset=int(r.get("onset", 0)), chord=chord), notes


def use_pool():
    """THE EVALUATORS (match/worker.js): the search's Evaluator scores a batch by building its
    documents here -- exactly as blocks.render_batch builds them -- and handing them to the pool,
    which renders and scores them in parallel against a copy of the same target (the native
    Evaluator renders a batch on four threads and scores it in two halves; here the batch is
    split across the evaluators). The documents, the renders and the fitness are the native ones,
    so a score is the score the native matcher would give."""
    import js
    from dnasynth.grow import build as GB
    from dnasynth.grow import blocks as BL
    init0 = GB.Evaluator.__init__

    def __init__(self, T, midi, gate_s, n, threads=4, chord=None):
        init0(self, T, midi, gate_s, n, threads, chord)
        mod = "both" if (T.hold and T.mod_term) else ("hold" if T.hold else bool(T.mod_term))
        from pyodide.ffi import to_js
        js.pcksPoolTarget(to_js(np.asarray(T.audio, np.float32)),
                          json.dumps(dict(sr=T.sr, free_gain=T.free_gain, gain_cost=T.gain_cost, mod=mod)))

    def score(self, voices):
        t0 = time.perf_counter()
        k, c = BL.key_cents(self.midi)
        if self.chord is None:
            docs = json.dumps([json.dumps(BL.document(v, cents=c, seed=1)) for v in voices])
            key = float(k)
        else:                                        # a chord: every key, a document of as many voices
            keys = BL.chord_keys(self.midi, self.chord)
            docs = json.dumps([json.dumps(BL.document(v, cents=c, seed=1, voices=len(keys))) for v in voices])
            key = json.dumps(keys)
        t1 = time.perf_counter()
        r = js.pcksPoolScore(docs, key, 100 / 127, float(self.gate), self.n_s / SR, float(SR), int(self.n_s))
        s = np.array(r.to_py(), np.float64)
        self.n += len(voices)
        t2 = time.perf_counter()
        self.t_render += (t1 - t0) + 0.5 * (t2 - t1)     # the pool renders AND scores: half each, for the
        self.t_score += 0.5 * (t2 - t1)                  # timing line (documents counted as render, natively)
        return s

    GB.Evaluator.__init__ = __init__
    GB.Evaluator.score = score
    from dnasynth.grow import tune as TU             # the third builder scores documents in the pool too
    from pyodide.ffi import to_js as _to_js
    TU.POOL = (lambda audio, cfg: js.pcksPoolTarget(_to_js(np.asarray(audio, np.float32)), cfg),
               lambda docs, key, vel, gate, secs, sr, n: js.pcksPoolScore(docs, key, vel, gate, secs, sr, n))


_TARGET = []


def eval_target(audio, cfg_json):
    """an evaluator's copy of the search's target (fitness.Target from the same audio and terms)"""
    from dnasynth import fitness as FT
    cfg = json.loads(cfg_json)
    _TARGET[:] = [FT.Target(_pcm(audio), cfg["sr"], free_gain=cfg["free_gain"], gain_cost=cfg["gain_cost"],
                            mod=cfg["mod"])]


def eval_score(audio, B, n, ok):
    """an evaluator's share of a batch: the renders (B x n, zero where silent) -> distances, as the
    native Evaluator.score: every sounding render normalised (fitness.normalize), scored in one
    call; a silent one is build.SILENT"""
    from dnasynth import fitness as FT
    from dnasynth.grow.build import SILENT
    Y = _pcm(audio).reshape(int(B), int(n))
    okm = np.asarray(ok.to_py() if hasattr(ok, "to_py") else ok, bool)
    s = np.full(int(B), SILENT, np.float64)
    if okm.any():
        Z = np.stack([FT.normalize(Y[i]) for i in np.flatnonzero(okm)])
        s[okm] = np.asarray(_TARGET[0].score(Z), np.float64)
    return s


def safe(fn, *a):
    """call fn, a traceback as text instead of an escape (the worker posts it to the tab)"""
    try:
        return fn(*a), None
    except Exception:
        return None, traceback.format_exc()
