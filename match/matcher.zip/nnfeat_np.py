"""dnasynth/nnfeat.py's features() (version 1) in numpy -- what the dashboard network hears of a note,
for the browser (Pyodide has no torch): mel (128 log-mel bands, 2048-point frames), harm (64
quarter-harmonic magnitudes of the known pitch, 4096-point frames), env (4 fine-envelope values a
frame), gate (the key's step and whether it is known). The same windows, scalings, grids and
floors as the torch code, so the network reads the same numbers (checked against it to 1e-4 in
web/match/test_shims.py)."""
from __future__ import annotations

import numpy as np

SR = 44100.0
SECS = 2.5
N_FFT, HOP = 2048, 512
N_MELS, F_MIN, F_MAX = 128, 20.0, 20000.0
HARM_FFT = 4096
HARM_Q, HARM_DIV = 64, 4
HARM_TOP = 0.47
SUB = 4
DB_FLOOR, DB_CENTER, DB_SCALE = -100.0, -50.0, 25.0
NORM_MAX_DB = 60.0

_MEL = {}


def mel_matrix(n_fft=N_FFT, sr=SR, n_mels=N_MELS, f_min=F_MIN, f_max=F_MAX):
    key = (n_fft, sr, n_mels, f_min, f_max)
    if key not in _MEL:
        mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)                     # noqa: E731
        imel = lambda m: 700.0 * (10.0 ** (m / 2595.0) - 1.0)                   # noqa: E731
        edges = imel(np.linspace(mel(f_min), mel(min(f_max, sr / 2)), n_mels + 2))
        f = np.fft.rfftfreq(n_fft, 1.0 / sr)
        M = np.zeros((n_mels, f.size))
        for i in range(n_mels):
            lo, c, hi = edges[i], edges[i + 1], edges[i + 2]
            up = (f - lo) / max(c - lo, 1e-9)
            dn = (hi - f) / max(hi - c, 1e-9)
            M[i] = np.clip(np.minimum(up, dn), 0.0, 1.0)
            if M[i].sum() <= 0:
                M[i, int(np.argmin(np.abs(f - c)))] = 1.0
        _MEL[key] = M.astype(np.float32)
    return _MEL[key]


def _stft_power(x, n_fft, hop, T):
    """|STFT|^2 of x [n] (centred frames, zero padding, the periodic Hann torch.stft gets from
    np.hanning(n + 1)[:n]) -> float64 [n_fft // 2 + 1, T]"""
    w = np.hanning(n_fft + 1)[:n_fft]
    xp = np.pad(np.asarray(x, np.float64), (n_fft // 2, n_fft // 2 + hop))
    idx = np.arange(T)[:, None] * hop + np.arange(n_fft)[None]
    S = np.fft.rfft(xp[idx] * w[None], axis=1)
    return (S.real ** 2 + S.imag ** 2).T, float((2.0 / w.sum()) ** 2)


def features(audio, midi, gate_s=None, sr=SR, secs=SECS, norm=None):
    """one note (float32 [n] at SR) -> float32 [198, T] (T = 1 + n // HOP), as nnfeat.features"""
    n = int(round(secs * sr))
    x = np.asarray(audio, np.float32).ravel()[:n]
    x = np.pad(x, (0, n - x.size)).astype(np.float32)
    if norm is not None:
        fr = x[:(n // 1024) * 1024].reshape(-1, 1024).astype(np.float32)
        p = max(float((fr * fr).mean(axis=1).max()), 1e-20)
        gain = min(np.sqrt(10.0 ** (float(norm) / 10.0) / p), 10.0 ** (NORM_MAX_DB / 20.0))
        x = (x * np.float32(gain)).astype(np.float32)
    T = 1 + n // HOP
    lo = 10.0 ** (DB_FLOOR / 10.0)

    def db(p):
        return (10.0 * np.log10(np.maximum(p, lo)) - DB_CENTER) / DB_SCALE

    P, s1 = _stft_power(x, N_FFT, HOP, T)
    mel = db(mel_matrix(N_FFT, sr).astype(np.float64) @ (P * s1))
    f0 = 440.0 * 2.0 ** ((float(midi) - 69.0) / 12.0)
    P2, s2 = _stft_power(x, HARM_FFT, HOP, T)
    P2 = P2 * s2
    fq = np.float32(f0) * (np.arange(1, HARM_Q + 1, dtype=np.float32) / HARM_DIV)
    kb = np.clip(np.round(fq / (sr / HARM_FFT)).astype(np.int64), 1, HARM_FFT // 2 - 1)
    hp = np.maximum(np.maximum(P2[kb - 1], P2[kb]), P2[kb + 1])
    hp = np.where((fq < HARM_TOP * sr)[:, None], hp, 0.0)
    harm = db(hp)
    blk = HOP // SUB
    xp = np.pad(x.astype(np.float64), (HOP // 2, T * HOP - n - HOP // 2))
    e = (xp * xp).reshape(T * SUB, blk).mean(axis=1) * 2.0
    env = db(e).reshape(T, SUB).T
    t = np.arange(T) * (HOP / sr)
    if gate_s is None or not np.isfinite(gate_s):
        step, kn = np.full(T, 0.5), 0.0
    else:
        step, kn = np.clip((float(gate_s) - t) / (HOP / sr) + 0.5, 0.0, 1.0), 1.0
    gate = np.stack([step, np.full(T, kn)])
    return np.concatenate([mel, harm, env, gate], 0).astype(np.float32)
