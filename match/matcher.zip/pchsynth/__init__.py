"""THE BROWSER'S PCHSYNTH (match/py, packed into matcher.zip): only `pchsynth.graph`'s registry, the
one thing the matcher asks of pchsynth (dnasynth/grow/kit.py: every block's knobs, laws and ports).
Natively pchsynth reads it from the engine library through ctypes; here it is the web synth's own
engine's registry (pw_registry_json, the same table), handed over by the worker (graph.install)."""
