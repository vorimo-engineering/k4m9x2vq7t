"""pchsynth.graph's REGISTRY for the browser: NodeType / NodeParam / Port with the same fields and the
same knob laws as pchkraft-synth/pchsynth/graph.py, built from the wasm engine's registry JSON (the
worker calls install(json) before the matcher imports anything).

The laws are pcks_params.c's pcks_param_map / pcks_param_unmap, in float32 like the C: four curves
(LIN, EXP, QUAD, STEP) -- the same four web/js/engine.js reproduces. match/test_shims.py checks every
parameter of the registry against the native pchsynth (the C through ctypes)."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import numpy as np

SCOPE_VOICE, SCOPE_GLOBAL = 0, 1
KNOB, SELECT, TOGGLE = 0, 1, 2
LIN, EXP, QUAD, STEP = 0, 1, 2, 3
PORT_KINDS = ("audio", "cv", "gate")
F = np.float32

TYPES: list = []
BY_TYPE: dict = {}


def _clamp01(x):
    return F(1.0) if x > 1.0 else (F(0.0) if x < 0.0 else F(x))


@dataclass(frozen=True)
class Port:
    key: str
    label: str
    kind: int
    tip: str = ""

    @property
    def kind_name(self) -> str:
        return PORT_KINDS[self.kind] if 0 <= self.kind < 3 else "?"


@dataclass(frozen=True)
class NodeParam:
    index: int
    key: str
    label: str
    unit: str
    default: float
    min: float
    max: float
    kind: int
    curve: int
    steps: int
    detent: float
    moddable: bool
    enums: tuple
    tip: str
    row: object = field(repr=False, compare=False, default=None)
    matrix_dest: bool = False

    def physical(self, norm: float) -> float:
        t = _clamp01(float(norm))
        lo_, hi_ = F(self.min), F(self.max)
        if self.curve == EXP:
            lo = lo_ if lo_ > F(1e-6) else F(1e-6)
            return float(lo * np.power(hi_ / lo, t, dtype=F))
        if self.curve == QUAD:
            return float(lo_ + t * t * (hi_ - lo_))
        if self.curve == STEP:
            n = self.steps if self.steps > 1 else 2
            return float(lo_ + F(int(t * F(n - 1) + F(0.5))))
        return float(lo_ + t * (hi_ - lo_))

    def normalise(self, physical: float) -> float:
        v_, lo_, hi_ = F(physical), F(self.min), F(self.max)
        if self.curve == EXP:
            lo = lo_ if lo_ > F(1e-6) else F(1e-6)
            v = v_ if v_ > lo else lo
            return float(_clamp01(np.log(v / lo, dtype=F) / np.log(hi_ / lo, dtype=F)))
        if self.curve == QUAD:
            span = hi_ - lo_
            if span <= 0:
                return 0.0
            return float(_clamp01(np.sqrt(_clamp01((v_ - lo_) / span), dtype=F)))
        if self.curve == STEP:
            n = self.steps if self.steps > 1 else 2
            return float(_clamp01((v_ - lo_) / F(n - 1)))
        span = hi_ - lo_
        return float(_clamp01((v_ - lo_) / span)) if span > 0 else 0.0

    @property
    def default_norm(self) -> float:
        return self.normalise(self.default)

    @property
    def is_enum(self) -> bool:
        return self.kind in (SELECT, TOGGLE) and bool(self.enums)

    def to_file(self, norm: float):
        phys = self.physical(norm)
        if self.is_enum:
            i = int(round(phys - self.min))
            if 0 <= i < len(self.enums):
                return self.enums[i]
        return float(f"{float(phys):.6g}")

    def from_file(self, value):
        if isinstance(value, str):
            if not self.is_enum:
                raise ValueError(f"'{self.key}' takes a number, not {value!r}")
            try:
                return self.normalise(self.min + float(self.enums.index(value)))
            except ValueError:
                raise ValueError(f"'{self.key}' has no setting {value!r} (it has {', '.join(self.enums)})") from None
        return self.normalise(float(value))


@dataclass(frozen=True)
class NodeType:
    index: int
    type: str
    label: str
    desc: str
    group: str
    scope: int
    cost: float
    cycles: float
    max_instances: int
    inputs: tuple
    outputs: tuple
    params: tuple
    viz: tuple = ()
    curves: tuple = ()
    has_tap: bool = False
    matrix_source: bool = False
    widget: str = ""

    @property
    def is_voice(self) -> bool:
        return self.scope == SCOPE_VOICE

    @property
    def scope_name(self) -> str:
        return "per voice" if self.scope == SCOPE_VOICE else "global"

    def param(self, key: str):
        for p in self.params:
            if p.key == key:
                return p
        return None

    def param_index(self, key: str) -> int:
        for i, p in enumerate(self.params):
            if p.key == key:
                return i
        raise KeyError(key)


def install(registry_json: str):
    """the registry from the engine's JSON (web/js/engine.js readRegistry's `types`, or
    pw_registry_json's): fills TYPES and BY_TYPE in place, so `from pchsynth import graph as G`
    taken before the install still sees them"""
    reg = json.loads(registry_json) if isinstance(registry_json, str) else registry_json
    TYPES.clear()
    BY_TYPE.clear()
    for i, t in enumerate(reg["types"]):
        ports = lambda xs: tuple(Port(p["key"], p.get("label", p["key"]), int(p.get("kind", 0)), p.get("tip", ""))
                                 for p in xs)
        params = tuple(NodeParam(index=int(p.get("id", j)), key=p["key"], label=p.get("label", p["key"]),
                                 unit=p.get("unit", ""), default=float(p["def"]), min=float(p["min"]),
                                 max=float(p["max"]), kind=int(p.get("kind", 0)), curve=int(p.get("curve", 0)),
                                 steps=int(p.get("steps", 0)), detent=float(p.get("detent", 0.0)),
                                 moddable=bool(p.get("moddable", 0)),
                                 enums=tuple(e for e in (p.get("enums") or "").split("|") if e) if isinstance(
                                     p.get("enums"), str) else tuple(p.get("enums") or ()),
                                 tip=p.get("tip", ""), matrix_dest=bool(p.get("matrix_dest", 0)))
                       for j, p in enumerate(t["params"]))
        nt = NodeType(index=i, type=t["type"], label=t.get("label", t["type"]), desc=t.get("desc", ""),
                      group=t.get("group", ""), scope=int(t.get("scope", 0)), cost=float(t.get("cost", 0.0)),
                      cycles=float(t.get("cycles", 0.0)), max_instances=int(t.get("max_instances", 0)),
                      inputs=ports(t.get("in", t.get("inputs", []))), outputs=ports(t.get("out", t.get("outputs", []))),
                      params=params, has_tap=bool(t.get("has_tap", 0)), matrix_source=bool(t.get("matrix_source", 0)),
                      widget=t.get("widget", ""))
        TYPES.append(nt)
        BY_TYPE[nt.type] = nt
